---
title: 参考文献
---

# 参考文献

## ==== 第1章 ====

## 1
[岩波新書 知的生産の技術(梅棹忠夫 1969)](https://www.amazon.co.jp/dp/B014R3S71E)

## 2
>2001 年からは思考法、成功法といった自己啓発本もビジネス書として売り上げを上げるようになった。現在にみられる自己啓発本の人気はこの頃始まったのだとみられる。

ビジネス書ブームはなぜ起きたのか(浅倉理恵 2012): https://pweb.cc.sophia.ac.jp/amikura/thesis/2011/asakura.pdf

## 3
[覚えてます？「ライフハック」の語源とそれに引き続くおかしな歴史 | Lifehacking.jp](https://lifehacking.jp/2017/11/lifehack-the-origin/)

## 4
[独学大全 絶対に「学ぶこと」をあきらめたくない人のための55の技法(読書猿 2020)](https://www.amazon.co.jp/dp/4478108536)

## ==== 第2章 ====

## 5
Psychological Safety and Learning Behavior in Work Teams, Amy Edmondson(1999): https://web.mit.edu/curhan/www/docs/Articles/15341_Readings/Group_Performance/Edmondson%20Psychological%20safety.pdf

## 6
[Google re:Work - ガイド: 「効果的なチームとは何か」を知る](https://rework.withgoogle.com/jp/guides/understanding-team-effectiveness#foster-psychological-safety])

## 7
- [Getting Things Done: The Art of Stress-Free Productivity(Allen, David 2001)](https://www.amazon.com/dp/0142000280)
- [Getting Things Done® - David Allen's GTD® Methodology](https://gettingthingsdone.com/)

## 8
[バレットジャーナル 人生を変えるノート術 | ライダー・キャロル, 栗木さつき](https://www.amazon.co.jp/dp/4478102678)

## 9
[The PARA Method: The Simple System for Organizing Your Digital Life in Seconds](https://fortelabs.com/blog/para/)

## 10
[リーン・スタートアップ(エリック・リース, 伊藤 穣一 2012)](https://www.amazon.co.jp/dp/4822248976)

## 11
筆者では辿ることができませんでした。GPT-4 曰く、アイビー・リーが始まりではないかとのことです。以下抜粋します。

> しかし、"to-doリスト"という概念を一般的に広めたと言われている人物は、20世紀初頭のビジネスマンであり、自己啓発の講師でもあったイビー・リーです。彼は1910年代にスティール・ビジネスマンチャールズ・M・シュワブに対して優先順位の高いタスクから順に処理するという"イビー・リー・メソッド"を提案しました。これが現代のto-doリストの始まりと言えます。

個人的には納得感があります。TODOリスト、タスクリスト、あるいはタスク管理におけるタスクといった概念は「自然ではない」と感じます。何らかの形で学ばない限りは身につかないメンタルモデルであり、現に知らない人や使ったことがない人には全くピンと来ない「割と高度な概念」なんだなー、との体感もあります。TODOリストは、言葉で言うなら「1行に1つ書く（単一化）」「終わったものは終了状態にする（終了という概念）」「優先順位の高いものを上に持ってくる（優先順位）」となるでしょう。仕事術とかライフハックとかいった言葉が似合うものです。また、リストに書いて管理するためには「書く」ことも必要です。1990年初頭という昔において新鮮な概念だったとしても違和感はないなと改めて思いました。

## ==== 第3章 ====

## 12
Mitchell, K. E., Al Levin, S., & Krumboltz, J. D. (1999). Planned happenstance: Constructing unexpected career opportunities.

## 13
[異文化理解力 ― 相手と自分の真意がわかる ビジネスパーソン必須の教養 eBook : エリン・メイヤー, 田岡恵, 樋口武志 2015](https://www.amazon.co.jp/dp/B013WB5BJS/)
