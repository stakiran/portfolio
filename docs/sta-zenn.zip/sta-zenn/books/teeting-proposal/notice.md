---
title: この本について
---

# この本について
この本は Zenn Books 執筆の練習のためにつくりました。

内容は [Teeting - monolithic](https://stakiran.github.io/monolithic/teeting.html) を転記しているだけです。
