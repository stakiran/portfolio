---
title: 参考文献
---

# 参考文献

## 1
[異文化理解力 ― 相手と自分の真意がわかる ビジネスパーソン必須の教養 - エリン・メイヤー, 田岡恵, 樋口武志 - ビジネス・経済 - Kindleストア - Amazon](https://www.amazon.co.jp/dp/B013WB5BJS)

## 2
[Amazon.co.jp: デジタル・ミニマリスト　本当に大切なことに集中する eBook : カル ニューポート, 池田 真紀子: 本](https://www.amazon.co.jp/dp/B07YG2PH4Q/)
