---
title: 📘付録1 本書のGPTs
---

# [ChatGPT - SBOMを噛み砕くGPTs](https://chatgpt.com/g/g-0sQwq3gMu-sbomwonie-misui-kugpts)
試験的に、本書を食わせた ChatGPT をつくってみました。

GPTs によって実装されており、ChatGPT Plus 利用者が利用できます。ChatGPT 無料ユーザーにも最近解禁されましたが、Limit は厳しいようです。

## 更新履歴:
- 2024/05/31 v0.1
    - 公開
