---
title: SBOMの形式
---

形式（フォーマット）の話。

# フォーマット

## フォーマットには構造とファイルがある
SBOM のフォーマットには構造とファイルがあります。

構造とは SBOM をどのような概念を用いてどのように記述するかを定義したものです。現在では SPDX と CycloneDX の二つの規格が主流となっています。

ファイルとは txt や json など、どんなファイルフォーマットを使うかという話です。主に txt、json、XML、YAML などがあります。SBOM はただのリスト、ただの票ですので、プログラミング言語構文レベルの表現力は必要ありません。

つまり SBOM のフォーマットは構造とファイルの二点を指定することになります。以下に例を示します。

- SPDX, json
- SPDX, txt
- CycloneDX, yaml

## バージョン
SPDX にせよ、CycloneDX にせよ、規格ですのでバージョンがあります。

SPDX には 1.0 系、2.x 系と 3.x 系があります。CycloneDX には 1.x があります。

前項も踏まえると、SBOM のフォーマットは以下のような表現になります。

- SPDX 2.2, json
- SPDX 2.3, txt
- CycloneDX 1.6, yaml

# SPDX

## 概要
SPDX は Linux Foundation がリードする SBOM 規格です。

- https://spdx.dev/

正式名称は System Package Data Exchange です。元々は Software Package Data Exchange でしたが、バージョン 3.0 ではソフトウェアに限らず汎用的に扱う方向に進んでシステムとなりました。

## バージョンについて
1.0 系は古いので無視して構いません。

現在は 2.x 系が主流で、最新は 2.3 ですが、巷のツールは 2.2 以前を出力することもあります。

3.0 系は 2024 年に公開された最新版で、2.x との後方互換性はなく全面的に刷新されています。2.x との違いですが、元々 2.x 以前ではソフトウェアのライセンス管理に特化していました。しかし前章でも述べたとおり、SBOM 以外にも様々な BOM が必要であるため、汎用的な構造をつくれるように拡張性を内蔵する方向に刷新されました。

## 構造
バージョン 2.3 を取り上げます。

リファレンスは以下にあります。

- https://spdx.dev/use/specifications/
    - https://spdx.github.io/spdx-spec/v2.3/

全体構造は第5章(Clause)にあります。

- https://spdx.github.io/spdx-spec/v2.3/composition-of-an-SPDX-document/

画像も掲載されていますが、ここでも書くと、以下のように第一レベルにいくつかのカテゴリがあります。

```
(SPDX Document)/
  (Creation Info)/
  (Package Info)/
  (File Info)/
  (Snippet Info)/
  (Other Licensing Info Detect)/
  (Relationships between SPDX Elements)/
  (Annotation Info)/
  (Review Info)/
```

SBOM として最低限必要な部分については二つで、ドキュメントのメタ情報の Creation Info、コンポーネント情報の Package Info です。

それ以外にも色んな情報を載せられるようにはなっていて、検出したファイル自体の情報（File）、[組み込みのライセンス名一覧](https://spdx.github.io/spdx-spec/v2.3/SPDX-license-list/)に当てはまらないライセンスの情報（Other Licensing）、包含や依存や複製などコンポーネントとコンポーネントの関係（Relationships）などがあります。詳細はドキュメントの各章を見てください。

## 出力例
[HTMX](https://github.com/bigskysoftware/htmx) を対象に、[SBOM Tool ver2.2.5](https://github.com/microsoft/sbom-tool/releases/tag/v2.2.5) で SPDX 2.2, json を出力した例です。

### 出力コマンド

```
$ cd
d:\work\sbom_kamikudaku\htmx

$ mkdir sbom

$ sbomtool Generate -b sbom/ -bc ./ -pn "testpackage" -pv "ver1.2.3" -ps "test_namespace"
...
│ Total                │ 0.16 seconds         │ 217                  │ 11                  │
└──────────────────────┴──────────────────────┴──────────────────────┴─────────────────────┘
```

### 確認

```
$ code sbom\_manifest\spdx_2.2\manifest.spdx.json
```

出力はこちらにもアップロードしています: https://github.com/stakiran/sbom_kamikudaku/blob/master/spdx2.2_htmx.json

jq コマンドを用いて少し詳しく見てみましょう。

まず直下ですが、メタ情報の入った creationInfo、コンポーネント情報の入った packages などがありますね。

```
$ cat manifest.spdx.json | jq "keys"
[
  "SPDXID",
  "creationInfo",
  "dataLicense",
  "documentDescribes",
  "documentNamespace",
  "externalDocumentRefs",
  "files",
  "name",
  "packages",
  "relationships",
  "spdxVersion"
]
```

メタ情報を見てみましょう。作成日と作成者情報が埋められていますね。

```
$ cat manifest.spdx.json | jq ".creationInfo"
{
  "created": "2024-05-23T09:19:15Z",
  "creators": [
    "Organization: test_namespace",
    "Tool: Microsoft.SBOMTool-2.2.5"
  ]
}
```

次にコンポーネント情報を見てみます。名前（name）とバージョン（versionInfo）、あとは識別子として Package URL（externalRefsの0番要素）くらいはわかりますね。その他もライセンスやダウンロード場所などいくつか属性がありますが、情報なし（NOASSERSION）とあります。

```json
$ cat manifest.spdx.json | jq ".packages[0]"
{
  "name": "readable-stream",
  "SPDXID": "SPDXRef-Package-DC2DA7F8AAF47E0872212F8A1CC0CB6608DFAC69E8A513ACA466117BC41BC454",
  "downloadLocation": "NOASSERTION",
  "filesAnalyzed": false,
  "licenseConcluded": "NOASSERTION",
  "licenseDeclared": "NOASSERTION",
  "copyrightText": "NOASSERTION",
  "versionInfo": "2.3.8",
  "externalRefs": [
    {
      "referenceCategory": "PACKAGE-MANAGER",
      "referenceType": "purl",
      "referenceLocator": "pkg:npm/readable-stream@2.3.8"
    }
  ],
  "supplier": "NOASSERTION"
}
```

コンポーネント数を見てみましょう。218 個と出ました。これを信じるなら、HTMX は 218 個のコンポーネントを使っています。

```
$ cat manifest.spdx.json | jq -r ".packages[] | .name" | wc -l
218
```

# CycloneDX

## 概要
CycloneDX は OWASP がリードする SBOM 規格です。

- https://cyclonedx.org/

## バージョンについて
1.x 系が存在します。1.0 から 1.6 まであります。

当初から汎用的なデータ構造を謳っており、SPDX のような大きな刷新はありません。

## 構造
バージョン 1.5 を取り上げます。

リファレンスは以下にあります。json や Protocol Buffer のスキーマとして公開されています。

- https://cyclonedx.org/specification/overview/
    - https://github.com/CycloneDX/specification/tree/1.6/schema
        - https://github.com/CycloneDX/specification/blob/1.6/schema/bom-1.5.schema.json
        - https://github.com/CycloneDX/specification/blob/1.6/schema/bom-1.5.proto

bom-1.5.proto を少し読み解いてみましょう。

構成票を示す構造は messsage BOM として定義されています。一部だけ抜粋します。

```protobuf
message Bom {
  string spec_version = 1;
  optional int32 version = 2;
  optional string serial_number = 3;
  optional Metadata metadata = 4;
  repeated Component components = 5;
  ...
}
```

コンポーネント情報は Component として持ってそうですね。repeated なので配列です。

次にコンポーネントを示す構造ですが、message Component として定義されています。

```protobuf
message Component {
  // Specifies the type of component. For software components, classify as application if no more specific appropriate classification is available or cannot be determined for the component.
  Classification type = 1;
  ...

  // The person(s) or organization(s) that authored the component
  optional string author = 5;
  // The person(s) or organization(s) that published the component
  optional string publisher = 6;
  ...

  // The name of the component. This will often be a shortened, single name of the component. Examples: commons-lang3 and jquery
  string name = 8;
  // The component version. The version should ideally comply with semantic versioning but is not enforced. Version was made optional in v1.4 of the spec. For backward compatibility, it is RECOMMENDED to use an empty string to represent components without version information.
  string version = 9;
  ...

  // DEPRECATED - DO NOT USE. This will be removed in a future version. Specifies a well-formed CPE name. See https://nvd.nist.gov/products/cpe
  optional string cpe = 15;
  // Specifies the package-url (PURL). The purl, if specified, must be valid and conform to the specification defined at: https://github.com/package-url/purl-spec
  optional string purl = 16;
  ...
}
```

type はコンポーネントの種類を指しています。（ここでは抜粋しませんが） enum Classification として定義されており、アプリ、フレームワーク、ライブラリ、OS、デバイス、コンテナ、ファームウェアなど色々定義されています。

author や publisher はコンポーネントの開発元や供給元を書くフィールドです。

コンポーネント名は name、バージョンは version として定義されていますね。コメントに補足があり、バージョンは Semantic Versioning で書くべきだが強制ではないとありますね。

識別子としては cpe と purl がありますが、cpe の方は DEPACATED になっています。

――と、このような形で、スキーマの定義を読み解くことで追っていけます。

## 出力例
[HTMX](https://github.com/bigskysoftware/htmx) を対象に、[syft ver1.4.1](https://github.com/anchore/syft/releases/tag/v1.4.1) で CycloneDx 1.4, json を出力した例です。

### 出力コマンド

```
$ cd
d:\work\sbom_kamikudaku\htmx

$ syft ./ -o cyclonedx-json > cyclonedx14_htmx.json
 ✔ Indexed file system                                                                   .
 ✔ Cataloged contents              cdb4ee2aea69cc6a83331bbe96dc2caa9a299d21329efb0336fc02a

   ├── ✔ Packages                        [219 packages]
   └── ✔ Executables                     [0 executables]
...
```

### 確認
そのままだと未整形で読みづらいので、jq で Pretty Print したものを開きます。

```
$ jq . cyclonedx14_htmx.json > cyclonedx14_htmx_pretty.json
$ code cyclonedx14_htmx_pretty.json
```

出力はこちらにもアップロードしています: https://github.com/stakiran/sbom_kamikudaku/blob/master/cyclonedx14_htmx_pretty.json

同様に jq で少し見てみましょう。

まず直下ですが、ほぼコンポーネント情報（components）のみの出力に割り切っているようです。

```
$ cat cyclonedx14_htmx_pretty.json | jq "keys"
[
  "$schema",
  "bomFormat",
  "components",
  "metadata",
  "serialNumber",
  "specVersion",
  "version"
]
```

メタ情報を見てみましょう。作成日や使用ツール情報などが埋められています。

```
$ cat cyclonedx14_htmx_pretty.json | jq ".metadata"
{
  "timestamp": "2024-05-23T19:03:03+09:00",
  "tools": {
    "components": [
      {
        "type": "application",
        "author": "anchore",
        "name": "syft",
        "version": "1.4.1"
      }
    ]
  },
  "component": {
    "bom-ref": "08329a07b4eb8eac",
    "type": "file",
    "name": "./"
  }
}
```

コンポーネント情報を見てみます。

```json
$ cat cyclonedx14_htmx_pretty.json | jq ".components[0]"
{
  "bom-ref": "pkg:npm/%40sinonjs/commons@1.8.2?package-id=51a9235e6851e30d",
  "type": "library",
  "name": "@sinonjs/commons",
  "version": "1.8.2",
  "cpe": "cpe:2.3:a:\\@sinonjs\\/commons:\\@sinonjs\\/commons:1.8.2:*:*:*:*:*:*:*",
  "purl": "pkg:npm/%40sinonjs/commons@1.8.2",
  "properties": [
    {
      "name": "syft:package:foundBy",
      "value": "javascript-lock-cataloger"
    },
    {
      "name": "syft:package:language",
      "value": "javascript"
    },
    {
      "name": "syft:package:type",
      "value": "npm"
    },
    {
      "name": "syft:package:metadataType",
      "value": "javascript-npm-package-lock-entry"
    },
    {
      "name": "syft:location:0:path",
      "value": "D:\\work\\sbom_kamikudaku\\htmx\\package-lock.json"
    }
  ]
}

```

名前（name）とバージョン（version）、識別子としては Package URL（purl）と CPE（cpe）がわかります。cpe は DEPRECATED でしたが、syft はまだ出力するようですね。

その他には種類がライブラリであることや、npm パッケージである等の情報も入っています。

最後にこのフォーマットのバージョンを見てみましょう。

```
$ cat cyclonedx14_htmx_pretty.json | jq -r ".specVersion"
1.5
```

CycloneDX 1.5 のようです。筆者がアップロードしたファイル名には 1.4 とつけていますが、これは README のフォーマット解説欄で `cyclonedx-json: A JSON report conforming to the CycloneDX 1.4 specification.` と書いてあったからです。README 側の修正漏れでしょうか。

# フォーマットと現実
上述した構造フォーマットは規格であるため厳密に踏襲するべきですが、実情としてはそうなっていません。すでに NOASSERSION（情報なし）が入っていたり、DEPRECATED が反映されていなかったりなどは取り上げました。

もう一つ、2024/05 現在で SPDX の最新は 3.0、CycloneDX の最新版は 1.6 ですが、これらの形式で出力できるツールはまだありません。ちなみに本章で示した SBOM Tool と Syft は、オープンソースの中では最も高品質と思われるツールです。有償製品でしたら、すでに対応したものがあるかもしれません。

このようにフォーマットとツールとの間には微妙なギャップが存在することに注意してください。

# SBOM が満たすべき最小要素
現在のところ、SBOM のフォーマットに法的な制約はありません。2024年5月現時点ではまだ[NTIAの最小要素](ref#22)の定義になるべく従いましょうねという空気感です。ちなみに NTIA とは米商務省国家電気通信情報局です。

この文書では「これらは現時点では最小」「組織や政府はもっと多くの情報を求めるかもしれない」「ソフトウェアサプライチェーンの改善に伴う進化もありうる」と書いてあり、（最小といいつつ結構な情報量なのですが）スタートラインくらいのニュアンスなのだと感じます。

定義の部分は和訳を使わせてください。[経産省の手引](ref#1)から引用します。

![minimum_element](/images/sbom-kamikudaku/minimum_element.png)

最小要素としてはデータフィールド、自動化対応、運用方法定義の 3 つがあります。一方で、実文脈では最小要素＝データフィールドとなっていることがあります。たとえば SBOM 生成ツールが「NTIA の最小要素を満たした SBOM をつくれます」と謳う、などです。

いずれにせよ、最小要素という言葉が登場したら、この NTIA の定義を指していると理解してください。

## 最小要素にどこまで追いついているか
筆者が触れたことのあるツール（syft などオープンソース系ツールと、Black Duck など有償セキュリティ製品）をベースに、2024/05 現時点の所感を述べます。

### データフィールド
おおよそ明確に出力できていると感じます。

コンポーネント名については、ツールによって表記揺れが生じることがあります。同じコンポーネントでも Vue.JS だったり vuejs-core だったり Vue.js Core だったりするわけです。だからこそ CPE や PURL など一意な識別子も要求されています。タイムスタンプはコンポーネント毎というよりも SBOM ドキュメントのメタ情報として挿入されています。

足りないのは依存関係で、今のところ直接的な依存関係がメインで、Black Duck など有償レベルで推移的な依存関係も検出できることがあるというくらいです。依存関係について少し解説すると、たとえば製品Xがいくつかのコンポーネントから成っている場合、

- 製品X
    - コンポーネントA
    - コンポーネントB
    - コンポーネントC
    - ……


直接的な依存とは X → A や X → B のことです。一方、推移的な依存とは A や B が何に依存しているかという話です。改めて現状を言うと、良くて推移的な依存も少し検出できるかも、という程度です。すべての深さを隈なく辿って、すべての依存を出力することは到底叶いません。そもそも SBOM はパッケージマネージャの設定ファイルからつくるものですが、その設定ファイルに直接的な依存しか書かれていないからです。

### 自動化サポート
サポートされています。

事前のインストールが済んでいれば、コマンドライン一発で SBOM を生成できます。インストール自体の自動化については、有償製品だと難しいかもしれません。オープンソース系であれば可能です。インストールスクリプトが用意されているケースもありますし、なかったとしても最悪 GitHub などから Zip をダウンロードして展開・配置するだけです。CI/CD に組み込むこともできるでしょう。

フォーマットについては、SPDX、CycloneDX、SWID の 3 つが挙がっていますが、SPDX と CycloneDX の 2 つのみ使われています。どちらの出力にも対応するのが主流ですが、[Microsoft の SBOM Tool は SPDX のみサポート](ref#18)しています。

### プラクティスとプロセス
国内ではまだプロセスを定めるほどの段階には至っていないイメージです。あるいはすでに進めている組織があるかもしれませんが、まだ観測はできません。

SIer がリーチする領域はどうでしょうか。2022/08 の[経産省の企業ヒアリング事例](ref#3) では SBOM の運用自体が希少です。2023/05 の[タニウムの調査](ref#17)によると、SBOM導入済みの企業は14％とのこと。一年以上経った現在では、もう少し進んでいるかもしれません。個人的には自動車や医療など人命にかかわる分野が先行しているイメージはありますが、内情はわかりません。Web や雑誌などで企業事例を見かけることはありますが、プロセスの整備にまで踏み込んだ情報はまだ見当たらない印象です。一方で、大手ベンダーで唯一ソリューションが充実している日立ソリューションズでは、[SBOM ソリューションとしてガイドライン策定支援や特定業界向け支援などを用意しているようです](https://www.hitachi-solutions.co.jp/sbom/sp/solution/sbom/)。

Web 系やテック系ベンチャーの領域はどうでしょうか。SBOM というよりは脆弱性対応を行っているイメージがあります。[yamory](ref#yamory) や [Snyk](ref#snyk) のような製品を導入したり、コンテナの場合は Trivy が有名でしょう。そうでなくとも GitHub などプラットフォーム側がサポートしていることもあります。この界隈はプラクティスやプロセスの取り組みがあればすぐに情報が共有されますが、本件に関しては筆者は見たことがありません。もしあったら教えてほしいくらいです。

ちなみに[経産省の手引 Ver2.0](ref#2) ではプロセスや対応モデルの解説が拡充されており、まさに本件の対応を後押しするものでしょう。
