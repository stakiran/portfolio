---
title: SBOMのつくりかた
---

SBOM のつくりかた。種類や方式などを扱います。

# 手段

## オープンソース
オープンソース系 SBOM 生成ツールはいくつも存在します。GitHub で探すことができます。

ツールの一覧については、[OpenChain Project Japan Work Group の SBOM サブグループがメンテしている一覧](ref#4)や[経産省の手引Ver2.0の付録](ref#2)などが詳しいです。後者については後述の有償ツールも扱ってます。

以下に著名なツールをいくつかピックアップします。URL と 2024/05/25 時点の GitHub Star 数を載せます。

- syft
    - https://github.com/anchore/syft
    - 5.6k
- SBOM Tool
    - https://github.com/microsoft/sbom-tool
    - 1.5k
- OSS Review Toolkit(ORT)
    - https://github.com/oss-review-toolkit/ort
    - 1.5k
- Trivy
    - https://github.com/aquasecurity/trivy
    - 21.6k

ツールのコンセプトは様々です。syft と SBOM Tool は SBOM 生成ツールです。ORT は SBOM 生成もメイン機能ですが FOSS policy automation and orchestration toolkit を謳っています。Trivy はコンテナ用脆弱性スキャナーがファイルシステムのスキャンと SBOM 生成機能もサポートしましたというテイストです。

## 有償ツール
構成管理やセキュリティ診断――いわゆるSCAツールは有償製品として提供されていることが多いです。以下に例を挙げます。

- [Black Duck](ref#black-duck)
- [Snyk](ref#snyk)
- [yamory](ref#yamory)
- [Cybellum](https://cybellum.com/ja/)
- [FOSSA](https://fossa.com/)

いずれも SBOM 生成ツールというよりは、SCA ツールが SBOM 出力機能を備えています。yamory のように[SBOMをインポート](ref#21)できるものもあります。

雰囲気を見たければ、Black Duck を覗いてみると良いでしょう。Black Duck はスキャナーで構成票をつくり、構成票からレポートや SBOM をつくるものですが、前者のスキャナーは Synopsys Detect としてオープンソース化しています。また、ドキュメントもあります。

- コード
    - https://github.com/blackducksoftware/synopsys-detect
- ドキュメント
    - [使用： Synopsys Detect（Desktop）](https://sig-product-docs.synopsys.com/ja-JP/bundle/bd-hub/page/ComponentDiscovery/DetectDesktop.html)
    - [All Properties](https://sig-product-docs.synopsys.com/ja-JP/bundle/integrations-detect/page/properties/all-properties.html)

## プラットフォーム
構成管理系のプラットフォームも SBOM 出力機能をサポートしていることがあります。

たとえば [GitHub がそうです](ref#10)。リポジトリの画面から Insights > Dependency Graph > Export SBOM と辿ることでダウンロードできます。

他には AWS も Amazon Inspect が対応していたり、IBM Cloud でも CycloneDX で生成できるようです。

- [Amazon Inspector による SBOM のエクスポート - Amazon Inspector](https://docs.aws.amazon.com/ja_jp/inspector/latest/user/sbom-export.html)
- [cyclonedx 形式でのソフトウェア部品表 (SBOM) の生成 | IBM Cloud 資料](https://cloud.ibm.com/docs/devsecops?topic=devsecops-generate-cyclonedx-sbom&locale=ja)

## 自作
既存の手段が気に入らない場合、自製することもできます。

処理としては「対象をスキャンしてコンポーネント情報を収集」と「収集した情報を SBOM に変換」の 2 ステップがあり、前者が難しそうです（スキャン方式は後述）。オープンソースの解析処理を拝借することはできるでしょう。[SBOM Tool は CycloneDX をサポートしない](ref#18) そうですが、その理由として「Component Detector を使えば自分でつくれるから」とあります。他にも上記のオープンソース系ツールを Fork して改造するなどもできます。

## (手作業)
SBOM は自動化を想定したものですが、特に日本では高品質な SBOM をつくる雰囲気と DX のしづらさの両面があり、手作業に頼りがちに感じます。

実際、SPDX には手作業で記述する用のサブセット [SPDX Lite](ref#19) が定義されていますし、トヨタはすでに SPDX Lite を導入しています。

# スキャン方式
SBOM はソースコード等をスキャン（解析）することでつくります。このスキャンの方式がいくつかあります。

## パッケージマネージャ
現在ソフトウェア開発ではパッケージマネージャを使うのが主流ですが、この設定ファイルをスキャンします。Node.js の NPM でいうと package.json、Python の pip でいうと requirements.txt、Java の Maven では pom.xml など。もちろん他にも色々あります。

どのプログラミング言語、どのパッケージマネージャに対応しているかは SBOM 生成ツール（あるいはその内部で使われているスキャン機能）次第です。ドキュメントで示されていることが多いので、確認すると良いでしょう。

## ファイルマッチング
あるソフトウェア X は xxx というファイルを持っているはずだから、xxx というファイルがあったならおそらく X を使っているはずだ――と推測できます。これがファイルマッチングです。

主に有償ツールが備えていますが、[Black Duck が現在非推奨にしている点](what_is_sbom#まず技術的には「いいえ」) はすでに述べました。素人の筆者に細かい事情はわかりませんが、推測するに、単純なファイルとソフトウェアの対応では精度が出ないことと、そもそも対応をデータとして持っておくことが大変であることが関係していると思います。

## スニペットマッチング
あるソフトウェア X はこれこれのスニペット（コード片） Y を使っているから、もしソースコードの中に Y が見つかったら、それはおそらく X からコピペしたものだろう――と推測できます。これがスニペットマッチングです。

これも有償ツールの機能という印象です。

参考までに、Black Duck ではスニペットマッチングにより検出した結果は「コンポーネントの候補」として利用者に見せます。利用者は各候補がコンポーネントなのか、それとも誤検出だから違うのかといった判断を下します。つまり疑わしいので一応検出したけど、判断するのはあくまで利用者に任せているわけですね。そうして判断を反映した後、その構成票から SBOM をエクスポートするわけです。

参考: [スニペットマッチについて - Black Duck Documentation](https://sig-product-docs.synopsys.com/ja-JP/bundle/bd-hub/page/ComponentDiscovery/Snippets.html)

## バイナリスキャン
ソースコードや設定ファイルなどはテキストファイルであり、中身を解析できますが、バイナリやアーカイブなどはかんたんには解析できません。しかし、これらを解析するスキャンを持つツールもあります。同様に有償ツールの機能という印象です。

当然ながら、精度面でも他の方式と比べると落ちます。

## コンテナスキャン
コンテナイメージもバイナリの一種ですが、解析可能な構造になっています。コンテナイメージはレイヤと呼ばれる概念でファイルシステムを差分的に表現しており、これを解析して再構築したファイルシステムをスキャンすればファイルマッチングやパッケージマネージャの設定ファイル解析に帰着できます。

Trivy などまさにコンテナイメージの解析を生業とするツールもあります。

## 環境スキャン
サーバーやクライアントPCの場合、OS のパッケージシステムを見ることでインストール済ソフトウェアを知ることができます。Linux の場合は yum、apt、pacman などがありますし、Windows だと「アプリと機能」から見ることができます（内部的にはレジストリに情報があります）。こういったツールの設定ファイルやデータストアの中身を解析するのです。また環境変数にも一部のソフトウェア（特にミドルウェア）の情報が含まれていることがあり、情報収集手段として使うことができます。

とはいえ、現在環境スキャンを内蔵したツールは筆者の知る限り、ありません。強いて言えば、Trivy は `trivy fs` にてファイルシステムのスキャンが行えるため、これでルートディレクトリを指定して丸ごとスキャンする、などはありえます。Linux はこのやり方でカバーできますが、Windows ではできませんし[そもそも想定されていません（対応していません）](https://aquasecurity.github.io/trivy/v0.27.1/docs/vulnerability/detection/os/)。

## まとめ
スキャン方式の主流はパッケージマネージャです。

ファイルやスニペットは有償製品が備えていますが、Black Duck を見る限りでは精度面で劣りそうです。バイナリスキャンも同様で、やはり精度は落ちますが、コンテナに限っては Trivy など進んだツールもあります。

環境スキャンを行うツールは無さそうですが、ディレクトリを丸ごと調べれば他の方式で代用できます。
