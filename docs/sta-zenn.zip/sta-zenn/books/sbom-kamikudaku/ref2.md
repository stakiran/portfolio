---
title: 📘参考情報2
---

SBOM に関するビジネスを検討する際に使えそうな情報。筆者の備忘含む。

# 分類や段階

## CISA, 6分類
https://www.cisa.gov/sites/default/files/2023-04/sbom-types-document-508c.pdf

- design
- source
- build
- analyzed
- deployed
- runtime

## yamory, SBOMの活用段階
https://www.jnsa.org/seminar/2023/iot/data/Session3.pdf

- 1: 手動でSBOMを作成
- 2: SBOMを機械的に生成
- 3: SBOMをDB化、リスク照合も⾃動化、リスク管理
- 4: BOMもインポート管理できる

## OWASP, BOM成熟モデル
- [BOM Maturity Model - SCVS](https://scvs.owasp.org/bom-maturity-model/)
- https://github.com/OWASP/Software-Component-Verification-Standard/blob/BOM_Maturity_Model/BOM_Maturity_Model/1.0.0-rc.1/bom-maturity-model-1.0.0-rc.1.json

.

- 難易度は3段階
    - 3: 高入手困難。手作業、人による観察、または制限されたドメイン内に保持されているデータへのアクセスが必要な場合
    - 2: 中程度。ドメイン固有のツールやプラグインを使用した自動観察によって取得するのが中程度に困難
    - 1: 低。既存のツールを使用した直接の自動観察により取得が簡単
- サポートレベルは6段階
    - 0 サポートされてない
    - 1 データフィールドとフィールド名がないためいちいちパースが必要
    - 2 フィールドはサポートしてないがフィールド名と値を個別に格納する程度はできている
    - 3 データフィールドをサポートする拡張機能を開発している
    - 4 公式拡張機能？を通じて仕様をサポートしている
    - 5 仕様はデータフィールドをネイティブにサポートしている

# パッケージマネージャの仕様
`npm spec` のように `spec` を入れて検索するか、GitHub のスキーマ定義系のファイルを漁るなどすれば出てきます。馴染みない言語であたりをつけられない場合は ChatGPT などに聞いてあたりをつけます。

## NPM
[package.json | npm Docs](https://docs.npmjs.com/cli/v9/configuring-npm/package-json)

## Yarn
[Manifest (package.json) | Yarn](https://yarnpkg.com/configuration/manifest)

## Pip
- [Requirement Specifiers - pip documentation v24.0](https://pip.pypa.io/en/stable/reference/requirement-specifiers/)
- [PEP 508 – Dependency specification for Python Software Packages | peps.python.org](https://peps.python.org/pep-0508/)

## Poetry
[pyproject.toml ファイル - Poetry documentation (ver. 1.1.6 日本語訳)](https://cocoatomo.github.io/poetry-ja/pyproject/)

## RubyGems
[Specification Reference - RubyGems Guides](https://guides.rubygems.org/specification-reference/)

## go.mod
[go.mod file reference - The Go Programming Language](https://go.dev/doc/modules/gomod-ref)

## Cargo
[The Manifest Format - The Cargo Book](https://doc.rust-lang.org/cargo/reference/manifest.html)

## Nuget
[NuGet の .nuspec ファイル リファレンス | Microsoft Learn](https://learn.microsoft.com/ja-jp/nuget/reference/nuspec)

## winget
[winget-cli/schemas/JSON/manifests/v1.7.0/manifest.singleton.1.7.0.json at master · microsoft/winget-cli](https://github.com/microsoft/winget-cli/blob/master/schemas/JSON/manifests/v1.7.0/manifest.singleton.1.7.0.json)

## Scoop
[Scoop/schema.json at master · ScoopInstaller/Scoop](https://github.com/ScoopInstaller/Scoop/blob/master/schema.json)

## RPM
[第3章 ソフトウェアのパッケージ化 Red Hat Enterprise Linux 7 | Red Hat Customer Portal](https://access.redhat.com/documentation/ja-jp/red_hat_enterprise_linux/7/html/rpm_packaging_guide/packaging-software)

# オーバーオールセキュリティ

## CNCF, Secure Software Factory
https://github.com/cncf/tag-security/blob/main/supply-chain-security/secure-software-factory/secure-software-factory.md


## CNCF, Software Supply Chain Best Practices
https://github.com/cncf/tag-security/blob/main/supply-chain-security/supply-chain-security-paper/sscsp.md

## Linux Foundation, SLSA(Supply-chain Levels for Software Artifacts)
https://slsa.dev/

# SCA

## Black Duck
[Black Duckにようこそ 2024.1.0](https://sig-product-docs.synopsys.com/ja-JP/bundle/bd-hub/page/Welcome.html)

## Black Duck スキャナー
- Synopsys Detect(Detector Scan)
    - 設定値: [All Properties](https://sig-product-docs.synopsys.com/ja-JP/bundle/integrations-detect/page/properties/all-properties.html)
    - 実装: https://github.com/blackducksoftware/synopsys-detect/tree/master/detectable/src/main/java/com/synopsys/integration/detectable/detectables
    - 実装(ドキュメント): https://github.com/blackducksoftware/synopsys-detect/tree/master/documentation/src/main/markdown/packagemgrs
- 署名スキャン(Signature Scan)
    - [署名スキャナコマンドラインの使用によるコンポーネントスキャンの実行](https://sig-product-docs.synopsys.com/ja-JP/bundle/bd-hub/page/ComponentDiscovery/CommandLine.html)

# カンファレンス

## FOSDEM2024
[FOSDEM 2024 - Software Bill of Materials devroom](https://fosdem.org/2024/schedule/track/software-bill-of-materials/)

# BOM規格

## protobom
- https://github.com/protobom/protobom
- https://github.com/protobom/protobom/blob/main/api/sbom.proto

## KBOM(Kubernetes Bill of Materials)
https://github.com/ksoclabs/kbom

## HBOM by CISA
https://www.cisa.gov/resources-tools/resources/hardware-bill-materials-hbom-framework-supply-chain-risk-management

