---
title: 📘参考情報
---

# 経済産業省

## 1
[「ソフトウェア管理に向けたSBOM（Software Bill of Materials）の導入に関する手引」を策定しました （METI/経済産業省）](https://www.meti.go.jp/press/2023/07/20230728004/20230728004.html)

手引の Ver1.0 です。

## 2
[サイバー攻撃への備えを！「SBOM」（ソフトウェア部品構成表）を活用してソフトウェアの脆弱性を管理する具体的手法についての改訂手引（案）を公表します （METI/経済産業省）](https://www.meti.go.jp/press/2024/04/20240426001/20240426001.html)

手引の Ver2.0 ですが、2024/04/26 時点では案です。

## 3
[OSS の利活⽤及びそのセキュリティ確保に向けた管理⼿法に関する事例集](https://www.meti.go.jp/policy/netsecurity/wg1/ossjirei_20220801.pdf)

## 4
https://github.com/OpenChain-Project/OpenChain-JWG/tree/master/subgroups/sbom-sg/outcomes/SBOM/SBOM_Tools_Document

OpenChain Project Japan Work Group の SBOM サブグループによる、ツールやドキュメントの一覧です。

# 大手SIerのブログ記事

## 5
[「初めての人のためのSBOM入門セミナー」でSBOMに関する講演をおこないました｜OSS管理ブログ｜ソフトウェア部品管理ソリューション｜日立ソリューションズ](https://www.hitachi-solutions.co.jp/sbom/sp/blog/2023020103/)

日立ソリューションズの記事です。

## 6
[SBOMが解決する課題と関連資料の紹介 : NECセキュリティブログ | NEC](https://jpn.nec.com/cybersecurity/blog/230414/index.html)

[第35回 「SBOM」とは | サイバーセキュリティ | NECソリューションイノベータ](https://www.nec-solutioninnovators.co.jp/ss/insider/column35.html)

NECとNECソリューションイノベータの記事です。

## 7
[全世界待望！SBOMによるサプライチェーンセキュリティ強化 | DATA INSIGHT | NTTデータ - NTT DATA](https://www.nttdata.com/jp/ja/trends/data-insight/2023/0207/)

NTTデータの記事です。

# プラットフォーマーのWebページ

## 8
[Google Developers Japan: SBOM in Action: 「ソフトウェア部品表」で脆弱性を見つける](https://developers-jp.googleblog.com/2022/08/sbom-in-action.html)

Googleの記事です。

## 9
[Windows のセキュリティ基盤 - Windows Security | Microsoft Learn](https://learn.microsoft.com/ja-jp/windows/security/security-foundations/)

Microsoftのドキュメントです。サプライチェーンの一要素として SBOM が一言紹介されています。

## 10
[セルフサービスのSBOMが登場 - GitHubブログ](https://github.blog/jp/2023-04-06-introducing-self-service-sboms/)

[リポジトリのソフトウェア部品表のエクスポート - GitHub Docs](https://docs.github.com/ja/code-security/supply-chain-security/understanding-your-software-supply-chain/exporting-a-software-bill-of-materials-for-your-repository)

GitHubもSBOM出力機能をサポートしています。

## 11
[Software Bill of Materials (SBoM) - Practicing Continuous Integration and Continuous Delivery on AWS](https://docs.aws.amazon.com/ja_jp/whitepapers/latest/practicing-continuous-integration-continuous-delivery/software-bill-of-materials-sbom.html)

AWSのドキュメントです。

# 規格

## 12
[SPDX – Linux Foundation Projects Site](https://spdx.dev/)

## 13
[OWASP CycloneDX Software Bill of Materials (SBOM) Standard](https://cyclonedx.org/)

## 14
[Specifications – SPDX](https://spdx.dev/use/specifications/)

SPDXの仕様ドキュメント。オンラインドキュメントとして整備されています。

## 15
[CycloneDX Specification Overview](https://cyclonedx.org/specification/overview/)

https://github.com/CycloneDX/specification/blob/1.6/schema/bom-1.6.proto

CycloneDXの仕様ドキュメント。GitHub 上に JSON や Protocol Buffer の形で定義されています。

# その他

## 16
[プレスリリース：『2023 ネットワークセキュリティビジネス調査総覧 市場編／ベンダー戦略編』まとまる（2023/12/27発表 第23140号）](https://www.fcr.co.jp/pr/23140.htm)

## 17
[タニウムが国内のSBOM市場調査の結果を発表 | タニウム合同会社のプレスリリース](https://prtimes.jp/main/html/rd/p/000000025.000089232.html)

## 18
> Thanks for your feedback. However, we have decided to focus on SPDX format for the SBOM generation, and as Aasim mentioned you can extend our tool to generate a CycloneDX format SBOM. But please feel free to leverage the component detector to build a CycloneDX format SBOM generator yourself.

https://github.com/microsoft/sbom-tool/issues/210

## 19
[SPDX Lite | OpenChain Japan Work Group (JWG)](https://openchain-project.github.io/OpenChain-JWG/subgroups/licensing/SPDX_Lite.html)

## 20
[導入進めるトヨタ　供給網で統一書式 | 日経クロステック（xTECH）](https://xtech.nikkei.com/atcl/nxt/mag/nc/18/040800414/040800002/)

トヨタの事例は[経産省の事例集](#3)でも紹介されています。

## 21
[SBOMインポート機能をリリース | yamory Blog](https://yamory.io/blog/start-sbom-import/)

## 22
The Minimum Elements For a Software Bill of Materials (SBOM): https://www.ntia.doc.gov/files/ntia/publications/sbom_minimum_elements_report.pdf

## 23
[「SBOM」の認知率は41.3％、導入率は33.1％--ビジョナル調査 - ZDNET Japan](https://japan.zdnet.com/article/35212809/)

# ツール

## in-toto
[in-toto | A framework to secure the integrity of software supply chains](https://in-toto.io/)

## SBOMit
[SBOMit](https://sbomit.dev/)

## yamory
[yamory | 脆弱性管理クラウド](https://yamory.io/)

## Snyk
[【公式】Snyk株式会社のウェブサイトです](https://go.snyk.io/jp.html)

## Black Duck
[Black Duckソフトウェア・コンポジション解析（SCA） | Synopsys](https://www.synopsys.com/ja-jp/software-integrity/software-composition-analysis-tools/black-duck-sca.html)

## jq
https://jqlang.github.io/jq/
