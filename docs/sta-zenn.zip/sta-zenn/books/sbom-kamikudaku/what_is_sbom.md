---
title: SBOMとは
---

SBOM の概要と状況。

# SBOM とは
**SBOM(Software Bill of Materials), ソフトウェア部品票** とは、あるソフトウェアがどんなソフトウェアを使っているかを一覧化したものです。一覧の各要素は **コンポーネント（Component）** や **パッケージ（Package）** や **ライブラリ（Library）** と呼ばれることもあります。

# SBOMの目的

## 元々の目的は脆弱性
SBOM の本来の目的は脆弱性管理です。

あらかじめコンポーネントを一覧化しておけば、あるソフトウェア X に脆弱性が出たときに、一覧から X の有無を調べるだけで済みます。もっとも、一覧という意味では、すでに構成情報管理などのジャンルで古典的に管理されていましたが、している組織としていない組織にばらつきがありますし、やり方の人手による手作業ゆえに時間もかかれば調査の質にもばらつきがあります。このような状況を打開するために、プログラムで処理できる形式で一覧化して、X の有無もプログラムで自動的に調べてしまえばいいと考えました。

つまり脆弱性の対応を完了させるまでの時間――リードタイムを短縮したいのです。ゼロにはできませんが、みんなが同じ形式を使い、プログラムで自動化するようにすれば、だいぶ短縮できます。

## 色んな目的が合流
2024年現在では複数の目的が合流しています。

大別すると以下の 5 つになります。

- 透明性の確保
    - 食品の栄養成分表示と同様、構成要素を見える化したいという話です
    - ブラックボックスを解消すれば隠し立てできなくなり、健全性が高まります
- ライセンス管理
    - ソフトウェア開発≒オープンソースソフトウェアの使用、であることは[前章「前提知識」](prerequisite)で述べました
    - そしてオープンソースソフトウェアにはライセンスがついています
    - ライセンスを守らないと訴訟や評判落ちのリスクがあるため、守られているかの確認は必要です
    - SBOMにライセンス情報も含めてやれば、これらのリスク調査も行えるようになります
- サポート情報の管理
    - ソフトウェアも製品であり継続的なサポートがつきますが、無限にサポートするのは酷なので EOL（期限）があります
    - また製造元やサポート連絡先といった情報もあると便利です
    - このような情報も SBOM に持たせておくと活用がしやすいです
- 情報集約、分析、ナレッジ
    - SBOM は部品票なので、たとえば社内の全プロジェクトのSBOMを収集すれば膨大な情報になります
    - これを分析することでインサイトを発見したり、ナレッジとして活用したりできる余地があります
        - 例: 推奨コンポーネントや類似プロジェクトの提案、組織の傾向を可視化、よく使われているコンポーネントのランキング
- オーバーオールセキュリティ
    - 開発や運用を含む工程全体の目線でセキュリティを確保すべし、との潮流が盛り上がっています
        - 造語ですが **オーバーオールセキュリティ(Overall Security)** と呼ばせてください
    - ソフトウェアサプライチェーン、DevSecOps などこの手の概念は多数存在します
        - 昔から存在するのもありますし、最近提唱され始めたものもあります
    - SBOM は構成要素の一覧化という「別に目新しい発想ではないが面倒くさかった営み」を業界レベルで加速させるものであり、オーバーオールセキュリティの背中を押しています

# SBOM対応が騒がれる理由

## 理由1. 間に合わないから
今のうちに準備しておかないと間に合わないからです。

サイバーセキュリティの担保は世界的な関心事であり、そもそも事の発端は米国における大統領令への署名です。IT 先進国の影響は無視できませんし、現に経産省も実証実験や手引書の公開などを始めています。国内でも自動車や医療など一部業界では事例も増えています。今後、法や要件として要求される可能性は高いのです。

一方で、SBOM の生成や管理や提供は、片手間ですぐにできるものではありません。要求されたときに準備を始めても遅い――間に合わなければ案件の失注や信頼の低下など機会損失に繋がりかねません。

肌感覚として、エンジニアの人は **開発フェーズが一つ増えるほどのインパクトが想定される** と考えれば良いでしょう。 「ドキュメント作成」は（後回しになることも多いですが）フェーズの一つとして知られています。これの仲間として「証明の作成」フェーズが加わるイメージです。証明として SBOM があります（構成要素の証明）が、SBOM だけではなさそうです。オーバーオールセキュリティが盛り上がっており、たとえば「SBOM の正しさを保証するための署名もつくれ」などがあるかもしれません。実際に[in-toto](ref#in-toto) や [SBOMit](ref#sbomit)などこの手のツールも出始めています。

## 理由2. ビジネスチャンスだから
要は SBOM には法や要件といった「皆が従うべきルール」を新たにつくるポテンシャルがあります。ルールをつくる立場に絡んだり、ルールを守るために必要なツールを売ったりなど、ビジネスとして絡める余地は大いにありますよね。

実際、海外ではいくつもの団体が規格や製品を立ち上げて乱立状態にあります。たとえば SBOM の規格として SPDX、CycloneDX、SWID と 3 つ挙がっていますが、現状ツールがサポートしているのは SPDX と CycloneDX の 2 つです（SWID は無視されています）。一方で、Microsoft が持つ SBOM Tool は SPDX しかサポートしていませんし、国産の mjcheck4 は SWID で出力します――と、ここだけ見てもバラバラですね。

国内では大手ベンダーが公式サイトや[ブログ](ref#大手sierのブログ記事)などで情報を散りばめている他、SBOM、特に脆弱性管理を謳った製品も出す企業も出てきています（[yamory](ref#yamory)や[Snyk](ref#snyk)など）。また[富士キメラ総研による調査](ref#16)ではSBOM・脆弱性の市場規模は 2028 年で 100 億円にのぼると見られています。一方で、[タニウムの調査](ref#17) によると SBOM の認知度は「大企業のIT関係者」に限定しても 75% です。

# SBOMの歴史
詳細は深追いしませんが、2021年、米国にてバイデン大統領がサイバーセキュリティに関する大統領令に署名したことが始まりです。

- 参考: [Executive Order on Improving the Nation's Cybersecurity | The White House](https://www.whitehouse.gov/briefing-room/presidential-actions/2021/05/12/executive-order-on-improving-the-nations-cybersecurity/)

# SBOM の中身

## SBOMは概念、規格は2つ
まず SBOM 自体はソフトウェア部品票という概念にすぎません。実際にどんな形式でどんな情報を書くかという形式は「規格」として定義されねばなりません。

規格として現在スタンダードになっているのが [SPDX](ref#12) と [CycloneDX](ref#13) です。もう一つ、SWID という名前が挙がることがありますが、なぜ挙がっているのかわからないほど場違いな存在であり、実情としてもスルーされているので気にする必要はないと思います。

つまり SBOM をつくるとは、現状では SPDX か CycloneDX の形式に従ってつくることを意味します。

## SBOM の中身
SPDX にせよ CycloneDX にせよプログラムで読むためのデータフォーマットとなっており、人間が読むのは少々苦しいです。

かんたんに構造を説明すると、以下のようになっています。

```
(SBOM)
  -(メタ情報)
    -タイトル
    -作成日
    -...
  -(コンポーネント一覧)
    -(コンポーネント1)
      -(名前)
      -(バージョン)
      -(このソフトウェアの開発元)
      -(このソフトウェアの入手先URL)
      -...
    -(コンポーネント2)
      -...
    -...
  -(その他あると便利な情報をカテゴライズしてぶら下げる)
    -(細かい構造はカテゴリ次第で様々)
    -    
  -(その他あると便利な情報をカテゴライズしてぶら下げる)
    -...
  -...
```

煩雑な構造になりがちですが、コンポーネント情報を全部律儀に記載しているものだと思えば間違いはありません。

以下にいくつか例を挙げます（全部載せると長いので途中で端折ります）。

### SPDX、TagValue形式

```txt
SPDXVersion: SPDX-2.2
DataLicense: CC0-1.0
SPDXID: SPDXRef-DOCUMENT
DocumentName: hello
DocumentNamespace: https://swinslow.net/spdx-examples/example1/hello-v3
Creator: Person: Steve Winslow (steve@swinslow.net)
Creator: Tool: github.com/spdx/tools-golang/builder
Creator: Tool: github.com/spdx/tools-golang/idsearcher
Created: 2021-08-26T01:46:00Z

##### Package: hello

PackageName: hello
SPDXID: SPDXRef-Package-hello
PackageDownloadLocation: git+https://github.com/swinslow/spdx-examples.git#example1/content
FilesAnalyzed: true
PackageVerificationCode: 9d20237bb72087e87069f96afb41c6ca2fa2a342
PackageLicenseConcluded: GPL-3.0-or-later
PackageLicenseInfoFromFiles: GPL-3.0-or-later
PackageLicenseDeclared: GPL-3.0-or-later
PackageCopyrightText: NOASSERTION

Relationship: SPDXRef-DOCUMENT DESCRIBES SPDXRef-Package-hello

FileName: ./build/hello
SPDXID: SPDXRef-hello-binary
FileType: BINARY
FileChecksum: SHA1: 20291a81ef065ff891b537b64d4fdccaf6f5ac02
FileChecksum: SHA256: 83a33ff09648bb5fc5272baca88cf2b59fd81ac4cc6817b86998136af368708e
FileChecksum: MD5: 08a12c966d776864cc1eb41fd03c3c3d
LicenseConcluded: GPL-3.0-or-later
LicenseInfoInFile: NOASSERTION
FileCopyrightText: NOASSERTION
...
```

from: https://github.com/spdx/spdx-examples/blob/master/software/example1/spdx2.2/example1.spdx

### SPDX、JSON形式

```json
{
  "SPDXID": "SPDXRef-DOCUMENT",
  "name": "SBOM-SPDX-2d85f548-12fa-46d5-87ce-5e78e5e111f4",
  "spdxVersion": "SPDX-2.3",
  "creationInfo": {
    "created": "2022-11-03T07:10:10Z",
    "creators": [
      "Tool: sigs.k8s.io/bom/pkg/spdx"
    ]
  },
  "dataLicense": "CC0-1.0",
  "documentNamespace": "https://spdx.org/spdxdocs/k8s-releng-bom-7c6a33ab-bd76-4b06-b291-a850e0815b07",
  "documentDescribes": [
    "SPDXRef-Package-hello-server-src",
    "SPDXRef-File-hello-server"
  ],
  "packages": [
    {
      "SPDXID": "SPDXRef-Package-hello-server-src",
      "name": "hello-server-src",
      "versionInfo": "0.1.0",
      "filesAnalyzed": false,
      "licenseDeclared": "Apache-2.0",
      "licenseConcluded": "Apache-2.0",
      "downloadLocation": "NONE",
      "copyrightText": "NOASSERTION",
      "checksums": [],
      "externalRefs": [
        {
          "referenceCategory": "PACKAGE-MANAGER",
          "referenceLocator": "pkg:deb/debian/libselinux1-dev@3.1-3?arch=s390x",
          "referenceType": "purl"
        }
      ]
    },
    {
      "SPDXID": "SPDXRef-Package-SPDXRef-Package-cargo-hyper-0.14",
      "name": "hyper",
      "versionInfo": "0.14",
      "filesAnalyzed": false,
      "licenseDeclared": "NOASSERTION",
      "licenseConcluded": "MIT",
      "downloadLocation": "https://github.com/rust-lang/crates.io-index",
      "copyrightText": "NOASSERTION",
      "checksums": [{
        "algorithm" : "SHA256",
        "checksumValue" : "02c929dc5c39e335a03c405292728118860721b10190d98c2a0f0efd5baafbac"
      } ],
      "externalRefs": [
        {
          "referenceCategory": "PACKAGE-MANAGER",
          "referenceLocator": "pkg:cargo/hyper@0.14",
          "referenceType": "purl"
        }
      ]
    },
    ...
```

from: https://github.com/spdx/spdx-examples/blob/master/software/example11/spdx2.3/sbom.spdx.json

### CycloneDX、JSON 形式

```json
{
  "bomFormat": "CycloneDX",
  "specVersion": "1.2",
  "serialNumber": "urn:uuid:d7a0ac67-e0f8-4342-86c6-801a02437636",
  "version": 1,
  "metadata": {
    "timestamp": "2021-05-16T17:10:53+02:00",
    "tools": [
      {
        "vendor": "CycloneDX",
        "name": "cyclonedx-gomod",
        "version": "v0.6.1",
        "hashes": [
          {
            "alg": "MD5",
            "content": "a92d9f6145a94c2c7ad8489d84301eb9"
          },
          {
            "alg": "SHA-1",
            "content": "a5af6c5ef3f21bf5425c680b64acf57cc6a90c69"
          },
          {
            "alg": "SHA-256",
            "content": "dc215a651772356eca763d6fe77169379c1cc25c2bb89c7d6df2e2170c3972ab"
          },
          {
            "alg": "SHA-512",
            "content": "387953ab509c31bf352693de9df617650c87494e607119bc284b91ba9a0a2d284a2e96946c272dc284c4370875412eea855bc30351faedd099dbdbed209e4636"
          }
        ]
      }
    ],
    "component": {
      "bom-ref": "pkg:golang/github.com/ProtonMail/proton-bridge@v1.8.0",
      "type": "application",
      "name": "github.com/ProtonMail/proton-bridge",
      "version": "v1.8.0",
      "purl": "pkg:golang/github.com/ProtonMail/proton-bridge@v1.8.0",
      "externalReferences": [
        {
          "url": "https://github.com/ProtonMail/proton-bridge",
          "type": "vcs"
        }
      ]
    }
  },
  "components": [
    {
      "bom-ref": "pkg:golang/github.com/0xAX/notificator@v0.0.0-20191016112426-3962a5ea8da1",
      "type": "library",
      "name": "github.com/0xAX/notificator",
      "version": "v0.0.0-20191016112426-3962a5ea8da1",
      "scope": "required",
      "hashes": [
        {
          "alg": "SHA-256",
          "content": "8fd1da69f6a90db3db1910e4bba7bf1d1b3a28131c287896726d7ff526f19e5e"
        }
      ],
      "licenses": [
        {
          "license": {
            "id": "BSD-3-Clause",
            "url": "https://spdx.org/licenses/BSD-3-Clause.html"
          }
        }
      ],
      "purl": "pkg:golang/github.com/0xAX/notificator@v0.0.0-20191016112426-3962a5ea8da1",
      "externalReferences": [
        {
          "url": "https://github.com/0xAX/notificator",
          "type": "vcs"
        }
      ]
    },
    ...
```

from: https://github.com/CycloneDX/bom-examples/blob/master/SBOM/proton-bridge/proton-bridge-v1.8.0.bom.json

# SBOM はどうやってつくるか

## 基本的にはツールでつくる
上記のフォーマットを見てもらえればわかるとおり、人間が手作業でつくるのは現実的ではありません。そもそも SBOM は元からプログラムによる自動生成を想定しています。なので基本的にはツールを使ってつくります。

ツールを起動して、SBOM を生成したい対象（ソースコードをまとめたフォルダなど）を指定すると、その対象をツールが解析して SBOM をつくります。

## 国内では手作業文化も強そう
一方で、国内では票に記入するイメージで手作業でつくる想定も強いと思われます。実際、SPDX には SPDX Lite という「Excel などで手作業で書ける用の SPDX」が組み込まれていますし、[トヨタ](ref#3)ではすでに採用されているようです。

## 自動 vs 手作業
「ツールによる生成だけで済むのか？」は SBOM を知る人なら誰もが通る疑問でしょう。

### まず技術的には「いいえ」
まず技術的には「厳密にすべてのコンポーネントを洗い出せるほどではない」です。SBOM 生成ツールは「パッケージマネージャ」という使用ライブラリを管理する仕組みの設定ファイルを解析しているので、そこで扱われていない情報はそもそも拾えません。

パッケージマネージャ自体が比較的近年の発明であり、10 年以上前など古いソフトウェアや昔のプログラミング言語ではそもそも使われていないことも多く、「生成ツールを通しても全く生成されませんでした」もよく起きます。昔のセキュリティ製品はパッケージマネージャではなくソースコードなど各種ファイルを解析する機能を持っており、これらが SBOM の出力にも対応し出したというケースもあります。そういった機能は精度とメンテナンスに限界があります。たとえば Black Duck は、昔の解析機能と近年のパッケージマネージャベースの両方を持っていますが、前者は非推奨としています。

> Note: Black Duckを長く使用しているユーザーは、Signature Scannerを直接起動することに慣れているかもしれません。現在この方法は推奨されていません。宣言された依存関係を備えたパッケージマネージャファイルを検索して活用するためのDetectorの能力が失われるためです。 / [スキャンのベストプラクティス](https://sig-product-docs.synopsys.com/ja-JP/bundle/bd-hub/page/ComponentDiscovery/BestPracticesScanning/ToolTipsNew.html)より

つまり、

- ソースコードなどを直接解析する手法では限界がある
- 近年ではパッケージマネージャの設定ファイルを解析する
    - しかし、パッケージマネージャをどれだけ正しく使っているかは現場のエンジニア次第
    - 正しく使われていないと、設定ファイルにもその分の記載が漏れるから、そもそも検出できない

### クオリティをどこまで求めるか
あとはクオリティをどこまで求めるか次第だと思います。

ツールがつくった SBOM をそのまま信じるのであれば、答えは「イエス」でしょう。あるいはそもそもツールでつくれるよう現場のやり方やあり方を変えていく動きをすることになります。DX――デジタルトランスフォーメーションでも散々言われていますが、デジタルの流儀に私達が合わせにいくわけですね。

一方で、それじゃ信用ならんから人間でもチェックするぞ修正するぞとか、そもそもツールで出力できる状態になってないけどそうするつもりはないので手作業でつくるぞ、手作業ならクオリティも突き詰められるし IT に無知でも運用できるしな、とかいった場合は答えは「ノー」でしょう。

筆者の肌感覚では、国内の SI が絡む領域では後者ノー派が強いと思います。経産省の手引などでも手作業の必要性は想定されていますし、前述したように SPDX Lite なるフォーマットが事実として存在します。一方で、テクノロジー企業はデジタルにも造詣が深く、前者のやり方を採用している印象です。[yamory](ref#yamory)や[Snyk](ref#snyk)は前者寄りの製品です。

# SBOM のようで SBOM ではないもの

## SBOM と xBOM
SBOM とはあくまで「あるソフトウェア」が「どんなコンポーネント（ソフトウェア）」から構成されているか、の一覧です。一方で IT システムを取り巻く環境はそれだけではありません。

たとえば以下があります。

- 1: あるサーバーには、どんなソフトウェアがインストールされているか
- 2: あるクラウドサービスは、どんなサブサービスを使っているか
- 3: ある装置は、どんな部品から構成されているか
- 4: ある機械学習モデルは、どんなモデルやデータセットから構成されているか etc

これらは SBOM（**Software** BOM）で扱うことはできません。あえて名付けるなら Server BOM、Service BOM、Devide BOM、Machine-Learning BOM でしょうか。当然ながらこれらにはこれら用の規格が必要です。

2、3、4 はすでに存在しており、それぞれ SaaSBOM、HBOM（Hardware BOM）、ML-BOM と呼ばれます。

## SPDX と CycloneDX は SBOM 用？
答えを書くと、元々は「イエス」だったが最近は「ノー」となった、です。

まず CycloneDX は元々汎用的なデータ構造となっており、SBOM だろうが HBOM だろうが色んな BOM を柔軟に表現できるポテンシャルを持っていました。SaasBOM や ML-BOM といった言葉は、CycloneDX の公式サイトが使っているものです。

SPDX については、元々 SBOM のみを想定したデータ構造でしたが、それでは他の BOM に対応できないよね、ということで Version3 から CycloneDX と同様、汎用的なデータ構造になりました。やはり「色んな BOM を柔軟に表現できますよ」という路線です。

## SBOM は xBOM の一種にすぎない
SBOM という名前が盛り上がっているのは、2021 年の大統領令が発端だと思いますが、実情としては Software 以外にも様々な BOM が存在します。それに対応するべく、SBOM 規格の双頭はどちらも汎用的な構造となっています。

SBOM は BOM の一種にすぎません。この関係はぜひ頭に入れておいてほしいと思います。でないと、Software ではない BOM の話なのに SBOM を適用しようとする、みたいなおかしなことになりかねません。

## とはいえ SBOM がメインではある
とはいうものの、大統領令から始まる一連の流れはソフトウェアに注目しており、xBOM の中でも SBOM が最も重要かつ盛り上がっているのは間違いないと思います。そもそも脆弱性も、ソフトウェアの分野が盛り上がっているからこそ日々発生するものです。盛り上がっているからこそ悪事がビジネスになり、悪意も集まります。

一方で、xBOM もおざなりにはできません。たとえばハードウェアの分野にも部品の脆弱性というものはあります。部品にソフトウェアが内蔵されているパターンもあります（組み込みソフトウェアなど、インターネットで主に想定されるソフトウェアとは別ジャンルになりがちですが）。特に自動車や医療など人命がかかわる部分は、無視できるものではありませんし、国内でも他の業界より歩みが早いと感じます。しかし、SBOM のやり方がそのまま通じるとは限りません。それこそ、自動化できるだけのツールが業界レベルで整備されていないから手作業による作成が必然になってしまう、等もありえます。

ビジネスチャンスと書きましたが、まさにそうでもあります。世の中をリードするソフトウェア業界で取り沙汰されたSBOMの概念を持ち込み、ルールや規制やツールや事例などの形で上手く絡むことができれば儲かりますよね。企業としては一種のチャンスであり、開発者や現場作業者としては鬱陶しいノイズでもあります。

SBOMがメインという事実はありますが、無闇に踊らされず、一歩引いて冷静に向き合いたいものです。
