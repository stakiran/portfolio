# encoding: utf-8

import os
import sys

def file2list(filepath):
    ret = []
    with open(filepath, encoding='utf8', mode='r') as f:
        ret = [line.rstrip('\n') for line in f.readlines()]
    return ret

def list2file(filepath, ls):
    with open(filepath, encoding='utf8', mode='w') as f:
        f.writelines(['{:}\n'.format(line) for line in ls] )

def replacer(lines):
    newlines = []
    for line in lines:
        newline = line

        # Zenn上じゃないので相対パスが補われない、明示的に追加する
        if line.find('/images/') != -1:
            newline = line.replace('/images/', '../../images/')
        
        newlines.append(newline)
    return newlines

lines = file2list('config.yaml')
filenames = []
MODE_SEARCH = 0
MODE_APPEND = 1
mode = MODE_SEARCH
for line in lines:
    if mode == MODE_SEARCH:
        if line == 'chapters:':
            mode = MODE_APPEND
        continue
    if mode == MODE_APPEND:
        l = line.strip()
        if len(l)==0:
            continue
        # `- filename` → `filename.md`
        filename = l[2:] + '.md'
        filenames.append(filename)
        continue
# print(filenames)

outlines = []
for i,filename in enumerate(filenames):
    lines = file2list(filename)
    # Cut front matter
    #
    #   >---
    #   >title: xxx
    #   >---
    #   >
    #    # aaa
    title = lines[1][7:]
    chapter = i+1
    lines = lines[4:]

    lines = replacer(lines)

    outlines.append(f'# === Chapter-{i} {title} ===')
    outlines.append('')
    outlines.extend(lines)
    # last blank line
    outlines.append('')

list2file('merged.md', outlines)
