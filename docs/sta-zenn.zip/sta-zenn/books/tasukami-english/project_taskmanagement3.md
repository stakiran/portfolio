---
title: Project Task Management(3/3)
---

# What Else Does Project Task Management Manage?

When management goes too far, it becomes toxic. The more you manage, the less flexibility you have—and you end up spending so much time on management that there is little left for the actual work. This drains motivation and lowers satisfaction. Sometimes, “managing to get by” or “faking it” becomes the primary goal, and **the project itself becomes ossified.** Many of you may have seen (or are currently experiencing) situations where everything becomes bogged down. This phenomenon is well known—see, for example, [Goodhart’s Law](https://www.publickey1.jp/blog/24/10_13.html).

Even though in the past it might have been acceptable as long as the desired results were achieved, that is no longer the case, and it should not be so. Few people truly favor micromanagement nowadays, and organizational paradigms have shifted from top-down, hierarchical, performance-based systems to more egalitarian, flat, self-managed (teal) organizations. Of course, there are situations where strict management is necessary, but that should not be the norm. That said, project task management often ends up managing many peripheral elements—and if you are not careful, you manage too much. Recognizing this and reducing unnecessary management is crucial.

Below are five management targets that lie behind the concept of task management. They can be summarized as follows:

| Name     | In Japanese | Explanation                                        | Example                        |
| -------- | ----------- | -------------------------------------------------- | ------------------------------ |
| Progress | 進捗        | The degree of advancement toward the goal          | 37%/100                        |
| Quality  | 質          | The excellence or stability of the outcome         | 2% error rate; 73% high satisfaction |
| Process  | プロセス    | The degree to which procedures and rules are followed | Procedures, formalities, formats, regulations |
| Resource | リソース    | The consumption relative to the total amount       | Time, money                    |
| Property | 専有        | The sense of ownership and compliance              | Attendance at work/meetings; (as in Edo-period) alternate attendance |

Taken literally, **task management is simply about managing task progress.** Nothing more, nothing less. Task management is ultimately about getting tasks finished—and by knowing the progress, especially if delays occur, you can take corrective action.

In reality, however, elements other than progress tend to be managed—quality, process, resources, and even property. Of course, progress alone is rarely sufficient to ensure success, and managing these peripheral aspects can help motivate individuals. But as mentioned earlier, excessive management becomes toxic. The key is to be aware of these extra management layers and work to eliminate what is unnecessary.

Let us now examine each management target in detail. Understanding the nature of each target will help you decide what to manage—and to what extent.

## Managing Progress

**Managing progress** means tracking how far along a task is in reaching its goal. At its simplest, you might use a binary system of “done or not done,” or a three-state system of “not started / in progress / complete.” More detailed systems might represent progress as a percentage.

How much progress management you impose depends on the skill of the manager (or the team, if no single manager exists). Simply put, if tasks are progressing smoothly, it might be enough to occasionally check if they are finished. It is overkill to require, for example, that you record a percentage (from 1 to 100) every day or report every morning. In a business context, such strictness might be justified by the notion “this is work” or “professionals must do this,” but in reality it is merely an adherence to traditional norms.

**It is best to manage progress using an additive approach.** Start with minimal management and, if problems occur, add management gradually. However, progress management tends to become overly strict due to two factors: the manager’s convenience and the reporter’s convenience.

First, from the manager’s perspective, a manager who has nothing else to do may force management tasks or cling to strict management in order to protect their own work. As an organization grows, this tendency naturally increases. To counteract this, an organization must be designed to grow healthily (for example, using a teal organization model). Another issue is that some managers lack the patience to wait for results and instead opt for superficial checks. This tendency is sometimes referred to as having low [negative capability](ref#9). Additionally, managers may see strict management as a way to communicate—for example, by diffusing responsibility or providing an excuse for delays. They may even take pleasure in number-crunching and strictly tracking progress. In extreme cases, managers may abuse their power by “putting pressure on” or “scolding” subordinates purely for the sake of management.

Second, from the reporter’s side, if a contract stipulates that you must submit detailed progress reports every week, then you have no choice but to comply—even if it results in excessive management. Even if such requirements eventually become mere formalities, they can persist for a long time as long as no major incidents occur. Although this might seem like the fault of the reporting party, in reality the burden is shared by both managers and reporters. A single authoritative remark (“the boss’s word”) is a classic example. Even if a manager could theoretically ease the burden, if they are merely a yes-man the responsibility still falls to the reporters.

In any case, this is ultimately a human issue. Whether it is the manager or the reporter, those with strong authority tend to enforce strict rules. The degree to which you can relax progress management depends on how well you can correct these behaviors or avoid involving such individuals altogether.

You might ask, “If everything is set by rules and processes, isn’t this inevitable?” While that might be the case for quality management, what about progress management? Except in cases where it is dictated by contract, I believe that strict progress management ultimately stems from the preferences of managers and reporters. The prevailing mindset is simply that “strict management is the only way,” because they are unaware of alternative approaches. One of the important lessons of learning task management is to break free from these fixed ideas.

Another point is “importance.” You may have experienced situations where, after a major incident or accident, the entire organization is forced into harsh measures—even though a single mistake should not justify such extreme responses. Over time, this leads to an environment where every employee suffers because of one person’s error. Although this might be justified by some as inevitable, it is in fact simply the result of rigid management practices. For example, imagine a company that decides “Because an employee had an accident in a company car, we will now abolish all company cars and force everyone to use public transportation.” Such a blanket approach is absurd. Today’s consumers are very discerning, and although such decisions might seem appealing in theory, a thoughtless one-size-fits-all application is simply not acceptable.

**Summary:**

- It is best to manage progress using an additive approach:
  - Start with minimal management and gradually increase it only if problems arise.
- The tendency toward strict progress management is largely due to the preferences of managers and reporters:
  - This is a natural phenomenon both in human behavior and organizational dynamics.
  - To relax progress management, either correct these individuals or avoid involving them in the first place.

## Managing Quality

**Managing quality** is not about the task itself but about the agent (the person or system executing the task) or the output (what is produced as a result of the task). A well-known example is quality control.

In quality management, the goal is to define and measure “quality” quantitatively and monitor it so that it does not fall below a certain standard. Even if it is difficult to quantify, you should at least describe it in words; if it is not immediately obvious, then work hard to define it. In product management, teams often seek a “North Star Metric” as a key indicator. The idea is to translate quality into numbers so that it can be objectively monitored.

**Quality management is best carried out rigorously and stably.** You cannot simply say “I don’t know” about error rates, nor can you expect them to be zero forever; you want to minimize errors as much as possible. In areas where brand value or added value is critical, high quality must be ensured by quantitatively defining what high quality means and monitoring it. Although this requires significant time and money, it is essential to create a service that customers will choose.

In task management, activities related to quality monitoring and improvement exist as tasks themselves. (I will refer to these as **Q-Tasks**.) As you have seen, task management tends to focus on the core work tasks, and quality-related tasks are often overlooked. Sometimes, when a predecessor leaves, the quality of work deteriorates because that person was handling many Q-Tasks. In the realm of fiction, there is even a subgenre (a branch of the so-called Narou series known as “exile” stories) in which the catharsis comes from that perspective.

How should you manage Q-Tasks? First, make sure that Q-Tasks are recognized as tasks. If they are Shadow Tasks, capture them and convert them into formal tasks. If they are “incidental” tasks performed as part of another process without clear definition, separate them and formalize them. In short, **do not underestimate Q-Tasks—treat them as formal tasks and give them due respect.**

Next, if possible, introduce the following measures (if you are already familiar with quality management, you may skip these):

- **Verbalization and Quantification**
  - As mentioned above, clearly define what quality means.
  - If it is difficult to quantify, at least describe it in words.
- **Automation**
  - Because human monitoring has its limits, try to automate the process using machines or software.
  - It is even better if you can view the status freely and receive notifications only when problems seem likely.
- **Specialization**
  - Assign someone exclusively to handle Q-Tasks (a quality manager or quality watcher).
- **Review**
  - Set up a dedicated forum or meeting to check quality.
- **Casual Conversations**
  - Build relationships that allow for casual discussion about any doubts or irregularities regarding quality.
  - This helps prevent issues from developing.

There are two main approaches: either completely automate the process using software or repeatedly have human reviewers (or use collective team consensus) to ensure quality. Although you can combine both, resource constraints typically force you to lean toward one approach. Of course, these activities themselves should be treated as tasks. Regarding casual conversation, think of it not so much as a task but as an activity to build relationships (similar to the activities described in Buffers and Slack). Q-Tasks are especially prone to becoming ossified or turning into Shadow Tasks, so be very careful.

Finally, continuously review your Q-Tasks. If they become too time-consuming or unnecessary, they will quickly become ossified. For this reason, the ability to assign dedicated personnel is key. Many organizations have a dedicated quality management department, but such departments often become overburdened or turn into bottlenecks themselves, leading to ossification. Ideally, your team should have a quality specialist. In software development, the role of a QA Engineer is exactly that.

One more point: activities to ensure quality may suit some people better than others, so it is important not to force someone who is unsuited to handle them. In the world of writers, quality assurance is often handled by an editor; in general, a division of labor is preferable. On the other hand, if someone completely ignores quality, supporting them can become very challenging. When pursued in depth, this topic is extremely complex.

**Summary:**

- Quality should be managed rigorously and stabilized.
- In order to manage quality in task management:
  - (1) First, ensure that Q-Tasks are properly recognized as tasks.
  - (2) Use either automation or human review.
    - It is particularly important to assign dedicated personnel and formalize any incidental quality-related activities as tasks.
  - (3) Continuously review to prevent ossification or the transformation of Q-Tasks into Shadow Tasks.
- Since suitability varies greatly, it is important to carefully evaluate and adjust how much responsibility each person should bear.

## Managing Processes

**Managing processes** means managing procedures.

In task management, processes appear as “procedures” or “formalities.” They are intended to secure the quality of the work and ensure stability by instructing everyone to work in a prescribed manner. This is sometimes referred to as reproducibility—ensuring that the same result can be achieved regardless of who performs the work. Procedures that are agreed upon by the team are simply called procedures, but those set at the company, industry, or legal level are known as formal processes. In any case, the essence is that tasks should be executed in the specified order. For our purposes, “process” and “procedure” can be considered synonymous.

**Process management is especially prone to becoming Shadow Tasks.** For example, suppose task T is estimated to take 3 hours (that is, it is expected to be completed in 3 hours). If 1.5 hours of that time is spent on process activities (i.e. following prescribed procedures), then only 1.5 hours remain for non-process activities. Let us call the time spent on following the process as **process activities** and the remaining as **non-process activities.** Thus, a task consists of process activities plus non-process activities—and if one of these is neglected (becomes a Shadow Task), the overall estimate becomes too optimistic. For example, if task T requires 3 hours to “shape the idea” and 1.5 hours for the process required to formally adopt it, then the correct estimate should be 4.5 hours. If you mistakenly estimate it as 3 hours, you have no choice but to compress the non-process portion from 3 to 1.5 hours, which inevitably leads to a drop in quality. If you do not wish to compromise, you must either estimate 4.5 hours or split task T into two separate tasks—“shaping the idea” and “formalizing the process.” (This is an example where the non-process time becomes a Shadow Task; the reverse can also happen.) Once people become accustomed to a process, they tend to forget that the process itself takes 1.5 hours.

So far we have discussed Shadow Tasks—that is, tasks that actually exist but are not captured by the system (and are therefore handled outside of it). However, excessive management is also a problem. When you impose too many processes, or when the process itself is so elaborate that it consumes too much time, or when the process includes approval steps that become bottlenecks because approvers are busy, the task management system becomes ossified. Confronting all these issues is often absurd, so inevitably a significant portion of process activities goes unrecorded as formal tasks—thus the entire system becomes ossified.

How can we address this? First, let’s break the situation down:

- Process Activities:
  1. The essential parts.
  2. The excessive parts.
- 3. Non-Process Activities

(We will omit non-process activities since they fall outside this discussion.)

For (1), the essential parts, you must formalize them as tasks. In the example above, you would split task T into two tasks, or include the process activities in the overall estimation (resulting in an estimate of 4.5 hours).

For (2), the excessive parts, you should eliminate them. As I suggested in the progress management section with the additive approach, adopt only the process components that are truly necessary—and add additional process requirements only if problems occur.

In business, we tend to prescribe elaborate processes even when tasks can be accomplished without them. Processes are set up to ensure reproducibility—a remnant of the industrial era of mass production—but is reproducibility really needed? Why not simply allow individuals to handle tasks their own way and then review the results? I encourage you to question whether “this process is absolutely necessary” and to critically assess it.

It should also be noted that unscrupulous managers often appear even in process management. Many managers treat the process as if it were infallible—claiming “the process is correct by definition.” Some even advocate what is known as [process fundamentalism](ref#11). (To use a legal analogy, managers might argue, “The law is absolute, so it must be followed,” even though laws only set broad guidelines and cannot be arbitrarily expanded by individuals.) In contrast, processes can be easily extended by managers (or their superiors), which leads to runaway escalation. The old saying “the road to hell is paved with good intentions” is quite apt here.

Addressing process management is extremely challenging. In addition to the difficulties that come with progress management, you must contend with a nearly dogmatic adherence to process, similar to legal doctrine. In practice, it is almost impossible. There is little that can be done; your options are to either remove yourself from such managers, pretend to comply, or (in collaboration with higher-ups or by forming a coalition within the team) expel those individuals. Modern theory suggests that the best solution is to design and maintain systems (or organizations) that naturally involve less management from the start.

**Summary:**

- Process management is especially prone to becoming Shadow Tasks.
  - A task consists of process activities and non-process activities; if one part is neglected, that portion becomes a Shadow Task.
- In process activities, it is crucial to distinguish between the essential parts and the excessive parts—and to eliminate the latter.
- Unscrupulous managers often appear in process management:
  - They may treat processes as if they were absolute laws.
  - If you wish to address the issue sincerely, you may need to either pretend to comply or even expel such individuals.

## Managing Resources

**Managing resources** means monitoring time and money.

All activities consume resources, and because resources are finite, you must ensure that they are not exhausted.

In task management, this is reflected by having people record or report the consumption of resources. For example, a task page might include “time spent,” or you may be required to record how much time you spent on various tasks each day and then submit a monthly report. Similarly, if you wish to spend money, you might have to request approval beforehand; if you work overtime, you might have to apply for it in advance.

These practices often become Shadow Tasks—especially the Indirect Shadows that are not directly related to the project. Since time and money are personal resources, individuals are typically expected to manage and report their own consumption. In business, such reporting is linked to compliance, and even in personal life, it can be a matter of survival. Because these records are viewed as a barometer of trust, even indirect resource consumption cannot be arbitrarily reduced. In fact, they are often justified as necessary.

How should we address this? The approaches are similar to what has been discussed previously:

- **Formalize the tasks:**
  - For necessary items such as money, equipment, or supplies, formalize the request process.
  - For items that might be needed spontaneously, pre-formalize them as tasks (i.e. put them in a pool) so that when needed, they are readily available.
- **Establish Buffers and Slack:**
  - If individuals are required to record or report, incorporate a buffer to absorb that extra effort.
- **Hold Record/Reporting Meetings:**
  - Set up dedicated meetings (or sessions) for recording and reporting resource usage.
  - In these meetings, everyone stops what they are doing and focuses solely on recording and reporting.
  - When the team gathers, they can remind one another of any missing data, thereby preventing a last-minute scramble.
- **Specialize:**
  - Appoint someone as a Resource Manager or Resource Watcher who monitors resource usage and handles the necessary processes.
  - This role is best suited for someone who may not be great at core work but excels at these follow-up or administrative tasks.
- **Automate and Streamline:**
  - Particularly for recording, having humans manually track every detail is extremely inefficient; it is preferable to automate the process.
  - If full automation is not possible, at least simplify the process so that only the minimum necessary steps are required.
  - This is where IT—and more broadly, digital transformation (DX)—comes into play.

Note that this is not a matter of “our in-house system will take care of it” or “the accounting department is there,” because in small units such as individual teams, resource management often becomes a burdensome Shadow Task. We must address it directly.

Furthermore, if possible, you want to reduce the overall amount of resource management. For time, ask yourself whether it is truly necessary to record every minute. Even if you cannot change the process itself, you can often improve the operation. If taken to an extreme, it might conflict with compliance, but strictly managing every number precisely is simply impractical. Yet, outwardly you cannot admit that, so you must find a way to handle it covertly. Conversely, if managers are unscrupulous, they may abuse the system (for example, forcing unpaid overtime by not allowing overtime reports). Unfortunately, such abuses seem to be more common today.

As for money, it may be possible to simplify the reporting process. While money is important, unnecessarily complicating the approval process is typical of an overly managerial mindset. In recent years, various methods have been developed; for example:

- Provide each employee or team with money or cards they can use freely—and make every transaction transparent so that misconduct is quickly discovered.
- Give each employee or team a fixed sum or card for expenses or allow them to use an expense reimbursement system.
  - This is especially useful for using paid tools, particularly SaaS.
- Randomize the approver.
  - For instance, depending on the amount, one of several team members might be randomly assigned as the approver.
  - This prevents one manager from becoming a bottleneck.
- In combination with setting a rate limit, so that a maximum usage limit is enforced. Banks can set withdrawal limits, and services like ChatGPT now use a pre-purchase model—if you buy $50 worth of credits, you can only use $50 until you purchase more. Since programs can easily create loops that send tens of thousands of requests per second, if your token (a sort of password for usage) is leaked, it could be massively abused. But if there is a cap, once the limit is reached the system will generate an error and stop further processing, thus preventing disaster. Recent improvements have even implemented a pre-purchase system (if you buy $50, you can only use $50 worth of resources until you buy more).

In short, there is plenty of room for creative solutions. Resource management—particularly when it comes to time and money—tends to lead to excessive management. Reassess whether such rigorous management is truly necessary, and try to introduce flexibility.

**Summary:**

- Resource management in task management appears as the recording or reporting of time and money consumption, which can itself become a Shadow Task.
- The approaches to address this are similar to those discussed earlier:
  - Formalize Shadow Tasks.
  - Build in buffers and slack to accommodate individual needs.
  - Specialize, automate, and streamline.
  - Hold dedicated meetings for resource management.
- Ultimately, you want to reduce management itself.
  - For time, reduce the burden of record-keeping.
  - For money, reduce the reporting burden.
  - In any case, various approaches exist.

## Managing Exclusive Ownership

**Managing exclusive ownership** refers to managing people as if they were objects—treating them as if they are entirely owned by someone, without regard for their circumstances. With objects, the owner has complete control and need not consider the “needs” of the object (since objects have no will). The idea is that an object is always available for the owner’s use. When this concept is applied to people, it is known as exclusive ownership or privatization.

We are often subjected to exclusive ownership. In our personal lives, terms like restrictions, curfews, and overprotection are common; at work, companies inevitably “own” their employees. However, these days people are not treated like property or slaves in the literal sense. Instead, rules and environments are set up to ensure compliance. **The hallmark of exclusive ownership is that it imposes restrictions on time and space.** Typical office workers or part-timers have fixed working hours and are required to be present at a designated workplace (such as an office). You might ask, “Are such restrictions really necessary?” The answer is no. Especially in recent years, thanks to the pandemic, remote work has become widespread, and it is now well known that work can be done without physically going to the office. Although many jobs still require on-site presence, these requirements will likely diminish over time as technology and methods advance.

Exclusive ownership imposes costs, yet these costs are not captured in task management. In other words, actions related to exclusive ownership are not recorded as tasks—even though they are necessary, each individual handles them on their own. Consequently, these become Shadow Tasks. (As mentioned earlier, commuting is a prime example of a Shadow Task created by exclusive ownership.)

Often when project task management does not work as expected—when tasks are not completed on time—it is frequently because exclusive ownership is holding things back. I want to emphasize: **exclusive ownership hinders progress far more than one might expect.** Commuting is an obvious example, but there are many others. For instance, if there is only one tool or piece of equipment and everyone must gather around it, or if regular meetings or important events are scheduled in such a way that unless you are physically present you are effectively excluded—the demands imposed by such restrictions are everywhere. Each individual instance may be minor, but cumulatively they impose a significant burden. If the term “exclusive ownership” is unclear, you can think of it as “scheduling.” In work, being excessively scheduled is akin to being overburdened with commitments. In everyday life, consider how exhausting it is to have appointments with numerous people in one day or to have an overly packed travel itinerary. Even just the travel time can be substantial—and above all, it is draining. The same holds true in the workplace.

So how can we address exclusive ownership? As with Shadow Tasks, capacity-based planning with buffers and slack can be applied. However, exclusive ownership is even more pervasive and will not simply disappear on its own, so it is crucial to deliberately reduce it. In other words, you must ask yourself, “How can we work without being restricted?” and “How can we complete tasks without being bound by fixed schedules?” I will refer to the approach of resisting restrictions as **liberation from exclusive ownership.**

What is needed for liberation? Both methodologies and tools. For example, remote work is only possible if you have the right methods and tools; you cannot invent them if you are unaware of them (nor are you typically given enough time to develop them). Liberation from exclusive ownership is such a voluminous topic that entire books could be written about it, but I will mention a few examples:

- **Asynchronous Communication**
  - Synchronous communication, in which everyone is tied to each other’s time and interacts in real time, is contrasted with asynchronous communication, where people read and write at their own pace (via letters, emails, or chats).
  - For liberation from exclusive ownership, the asynchronous method is essential. **The key to liberation is how extensively you can adopt asynchronous communication.**
  - Currently, synchronous communication remains dominant—many people believe that work is not possible unless face-to-face interaction occurs. That makes the transition challenging.
- **QWIC**
  - This is a term I have coined as a general term for the main forms of asynchronous communication.
  - QWIC stands for Q&A, Wiki, Issues, and Chat.
  - Many of you are already familiar with Chat (e.g., Teams), which is essential for remote work.
  - Wiki, as seen in Wikipedia or various strategy wikis, is excellent for organizing and searching for information.
  - Issues refers to systems like [GitHub Issues](ref#github-issues), which facilitate discussion on a per-topic basis.
  - Q&A refers to websites like Yahoo! Chiebukuro, Oshiete Goo, Stack Overflow, or Quora that specialize in question-and-answer communication.
- **Communication Injection**
  - While asynchronous communication is key, humans are not entirely comfortable with it; without some synchronous communication, people may become frustrated and it is harder to build trust or rapport.
  - Thus, even in a liberated (asynchronous) system, you must intentionally “inject” some synchronous communication when necessary.
  - In other words, think in terms of:
    - ❌ Synchronous communication only
    - 🔺 Synchronous communication as the primary method, with asynchronous as supplementary
    - ⭕ Asynchronous communication as the primary method, with synchronous as supplementary
  - The goal is to adopt a predominantly asynchronous approach, with synchronous communication injected as needed.
- **Personal Task Management**
  - As liberation from exclusive ownership progresses, individuals must work autonomously.
    - This approach does not work for those who can only act when told or who are overly influenced by the environment.
  - It is not something that can be overcome by sheer willpower alone; it requires ingenuity in methods and thinking.
  - In fact, this is essentially equivalent to personal task management—that is, how to effectively manage your own actions in both work and personal life.
    - (As an aside, this book is precisely about personal task management.)

Digital transformation (DX) is about aligning our ways of working with digital methods. Similarly, **for liberation from exclusive ownership, we must align our practices with asynchronous communication.** Without this shift, we cannot reduce the costs imposed by exclusive ownership. In companies where remote work is successful, each individual can secure their personal life while also working effectively. Many such companies have already achieved strong performance.

On the other hand, even top companies such as GAFAM have shown a tendency to revert to in-person work. Thus, liberation from exclusive ownership is an ongoing challenge. In terms of methodology, it has not yet become widespread. (The terms QWIC and Communication Injection are my own coinages. The fact that I can coin these terms indicates that this area is still relatively unexplored.) Of course, there are organizations and teams worldwide that have achieved high levels of liberation, but when it comes to applying this to the general public or to large organizations, I honestly feel we are still far from it.

Personally, I believe that generative AI will become a turning point. Asynchronous communication is demanding because it involves a lot of reading and writing, but generative AI excels at summarizing and translating, so it may help cover those challenges. It may even eventually be able to create pseudo-personalities. In the future, rather than having a meeting with person A, you might have a meeting with an AI representation of A. Many people claim that “humans are naturally social beings who want to meet face-to-face, so synchronous communication will never disappear,” but there is no need to reduce synchronous communication to zero—as long as you can inject it as needed. More importantly, our personal lives are precious, and there is already a trend toward valuing and respecting life. In fact, standards have improved significantly, and remote work—propelled by the pandemic—has accelerated this trend. Ultimately, because people’s lifestyles differ, exclusive ownership is not a good fit, and asynchronous communication is inevitable. The era when slavery was acceptable is over. Although modern work is not as brutal as slavery, the restrictions remain. Right now we rely on synchronous methods only because alternatives were not available—but as those alternatives become more refined and widespread, a shift toward asynchronous communication is inevitable. Boldly speaking, I believe that modern people will increasingly be liberated from restrictions.

Forgive me for getting carried away with the topic of liberation from exclusive ownership. Although reducing the cost of exclusive ownership requires liberation, the concept of liberation is still difficult (or unfamiliar and unapproachable) for many, which is why I have dedicated this section. There may be other approaches to reducing exclusive ownership—or even trends that accept it—but those are beyond the scope of this book.

**Summary:**

- We are subject to exclusive ownership—we are often bound by restrictions on time and space.
- Exclusive ownership hinders progress far more than one might expect, yet it does not appear in task management systems, making it hard to notice.
- To address exclusive ownership, strategies for handling Shadow Tasks can be effective, but more importantly, you must reduce exclusive ownership itself through liberation.
- Liberation from restrictions is challenging:
  - It is difficult but not impossible; there are methods and examples.
  - Remote work is an excellent example of liberation.
  - I predict (and hope) that this movement will inevitably gain momentum in the future.

# Summary

- The essence of project task management is the 3A’s:
  - **Assign:** Assign tasks to people.
  - **Adjust:** Change the attribute values of tasks.
  - **Alternate:** Switch between a holistic view (macro) of all tasks and a detailed view (micro) of specific tasks.
  - If you can handle these effectively, then additional management is not necessary.
- The extent to which you can alternate between a holistic and detailed view depends on the capabilities of your tools—and there are distinct levels:
  - The Alternate Model comprises four stages.
  - The stage at which you use a task management tool is Level 3—and there is a significant “chasm” to overcome.
  - In other words, project task management is inherently a challenging endeavor.
    - In reality, it often ends up relying on excessive, ad hoc communication.
    - Like digital transformation (DX), it requires a shift in mindset: you must use the tool properly and align your methods with it.
- There are various types of views to achieve a holistic perspective, each with its own advantages and disadvantages:
  - List (simple list), Table (grid), Board, Chart, Network, and Sentence (narrative) views, etc.
  - Later types are newer and have higher learning costs, and Network and Sentence views have few real-world examples.
  - Currently, the safest option is the Table view; aim to get your project task management working effectively with a Table view first.
- There exist hidden tasks—“Shadow Tasks”—that are not recorded in task management.
  - Approaches to address them include capacity-based planning, buffers and slack, and formalizing Shadow Tasks.
- Project task management inadvertently also ends up managing peripheral elements:
  - Progress, Quality, Process, Resources, and Exclusive Ownership.
  - However, these are not formally recorded as part of task management (they become Shadow Tasks).
  - Excessive management is toxic; you must consciously work to reduce it.
