---
title: A Look at Task Management
---

People have different ways and approaches to task management, so it’s necessary to find one that suits you personally. To do that, it is useful to take a look at the various elements, characteristics, and examples that make up task management. Once you’ve observed these, you can try out what seems to work for you—that’s what this discussion is all about.

This perspective forms the very core of this book. **The purpose of this book is to present the many different methods and ideas so that you can explore and develop your own approach to task management.**

# The Importance of Exploration

## The Essence Is “Everyone Is Different”
In a nutshell, the essence of task management is that “methods and ideas differ from person to person.” The simple conclusion is: “find what works for you.”

That said, it isn’t realistic to start exploring from scratch. Studying task management is difficult in itself. There are no textbooks or formal courses on it. Sure, there are paid seminars, but they’re expensive—and the difference between what suits you and what doesn’t is very marked. You might get many hints from books and the internet, but the quality is mixed and it’s not straightforward. Many people are out there freely sharing various methods and ideas—that is the current state of affairs.

## Explore on Your Own
Ultimately, there is no other way than to personally explore and find the task management method that suits you best.

Task management is like a hobby. And as with hobbies—whether it’s consuming, competing, exercising, creating, or serving—what works for one person may not work for another. Moreover, even for the same person, what works may change over time or according to one’s mood or circumstances. Task management is no exception.

Some might say, “No, task management is for work, so there must be a standard method.” That’s partly true, but the fundamental fact is that we are human. We all have different responsibilities, physical stamina, and sources of motivation—and as a common trait, people tend to be lazy, indecisive, and forgetful. Even if there were some magical method that, if followed, would guarantee success, could anyone really stick to it? Anyone who has managed tasks within a team already knows that even in a serious work context things often don’t go as planned.

**Task management is essentially personal.** The only way forward is to find a balance that seems workable and sustainable for you. Since that balance is different for everyone—and usually requires taking into account your own quirks and circumstances (even if only intuitively)—there’s no choice but to discover it for yourself.

## Is There a Magical Tool? → No.
Continuously exploring on your own can be very tedious. You might wonder if there’s some tool that can handle everything. At this point, I believe the answer is “no.” As mentioned above, since task management is inherently personal, I don’t believe any tool can fully support it. Even though generative AI is in vogue as of 2024, it too can only support you in part—it cannot be entirely depended upon.

On the other hand, there is a well-known approach that has been around for a long time—what is known as “delegation.” For example, secretaries or butlers are typical examples. People with money or power don’t need to deal with the tedious aspects of task management themselves; they can delegate it. Since these are human beings rather than mere software tools, they are flexible and convenient. This is a well-known concept that hardly needs further explanation, yet for most ordinary people such resources are out of reach. Even if you can afford a secretary or butler, it doesn’t mean you can hand over every aspect of task management in your life. No CEO or wealthy person completely outsources everything. In the end, you may only delegate certain tedious chores or the management of schedules (even though you might desperately want more help). It would be great if a tool could replace secretaries or butlers, but that is still a long way off.

## Don’t Shy Away from Exploration
I may have just hit you with a harsh reality, but it’s important. There is no escaping the need to explore and find the task management method that suits you best—and as long as you avoid that exploration, you will never get there. However, it might not be as dire as it seems. Once you learn more, you might find yourself thinking, “Oh, it’s not that bad.” On the other hand, you might despair thinking, “It’s even harder than I expected…” or “No way I can do that…” But that’s just how it is. For example (as will be discussed later), the ability to manage tasks depends on your individual traits, and for those with traits that make it difficult, task management can be very challenging (in which case, the solution is to rely on people or systems). Harsh as it may sound, one of this book’s themes is to lay out the realities of task management—the aptitudes and limitations. Nevertheless, since it is inherently personal, there are ways to approach it. Even incorporating just some parts to make things a little easier can be very effective. To reiterate, it’s important not to run away from exploring what suits you. Society, relationships, and work are all full of hassles—and task management is no different. Let’s overcome these turbulent waves in our own way.

## Observing in Order to Explore
Even if you’re told to explore, as mentioned earlier, it’s unrealistic to come up with something entirely from scratch. Fortunately, there is already a certain structure to what is called “task management.” There are examples, methodologies, and tools available. Although it isn’t a field systematized at an academic level, bits of wisdom from predecessors are scattered everywhere—from ideas developed by individuals to what is known within circles, and even things that most people have an inkling of without it being explicitly stated.

In this book, I aim to put these ideas into words and present them as clearly as possible. By reading this book, you can shortcut your own exploration. Specifically, you might recall, “Oh, there’s that method too,” decide, “That probably won’t work for me,” or simply think, “That looks good—I want to try it,” or even, “Hmm, that’s trivial,” or “I don’t feel like it.” Remember, task management is inherently personal. The way you choose to approach it is entirely up to you—so relax and browse through the options as if you were shopping in a store or online.

## Welcome
Now, let’s begin our journey of exploration. Let’s dive right into the content.

# Task Management Can Be Classified into 3Ps
There are three types: Project, Partner, and Personal (individual).

When people think of task management, some imagine managing tasks within a team at work, while others envision managing one’s own tasks as an individual. It is extremely important to recognize the differences between these two. In this book, we will primarily focus on the latter—the personal aspect. Therefore, if you are looking for information on project task management, this book might not be as helpful. Nonetheless, we will briefly summarize the former as well, and even in project contexts, insights from personal task management can be useful—so please feel free to take a look.

Now, let’s delve into the details of the 3P classification.

## The 3P Classification
Task management can be classified into 3Ps.

| Name    | Target                      | Main Characteristics                          |
|---------|-----------------------------|-----------------------------------------------|
| Project | Projects (Teams)            | Assignment, coordination, overall overview and detailed breakdown |
| Partner | Partners (Spouses, Parent-Child) | Sharing tasks and exchanging messages        |
| Personal| Personal (Individual)       | It varies from person to person               |

## Project Task Management
We will refer to task management performed by teams at work as **Project Task Management**.

- **Examples of Tools**
  - Trello
  - Asana, ClickUp, monday.com
  - Redmine, JIRA, GitHub Issues
  - Microsoft 365, Notion

- **Examples of Frameworks**
  - WBS (Work Breakdown Structure), Gantt Charts
  - PERT (Project Evaluation and Review Technique), CPM (Critical Path Method)
  - Kanban
  - Burndown Charts

In the past, frameworks based on project management were primarily used, and they could be operated manually. There were also many instances of using spreadsheet software like Excel or Google Sheets (which are still in use today). Nowadays, SaaS-based task management tools are common. These tools create individual units called tasks, allow you to assign responsible persons and exchange information on individual task pages, and present all tasks visually in lists or boards so you can get an overall picture. Each team member can update their own tasks independently, while managers can view the overall status. In recent years, many tools have emerged with advanced features—such as data integration with other tools, partial workflow automation, flexible customization of configuration and classification options, and customizable overview views. In short, the keywords are integration, automation, and customization.

In any case, the core functions are as follows: breaking down large tasks into smaller ones, setting deadlines for tasks, assigning responsible persons to tasks, providing views that allow you to see multiple tasks at once, and ensuring that all team members view and update the tasks in the same place (centralization). In essence, it is about externalizing task-related information and using that as the original reference to align everyone’s direction and understanding. Put simply, it is nothing more than visualization. Conversely, you could say that it has no capabilities beyond visualization. In practice, we often find ourselves urging people verbally or by chat, chasing updates that have become mere formalities outside the tool, or scheduling frequent meetings because it’s simply faster to ask in person.

Also, there is a tendency to focus solely on executing the tasks in front of you while neglecting medium- to long-term efforts such as improvements, learning, or exploring new ideas. Because of these characteristics, such tools are mainly used on the operational front. At levels above middle management (except for those directly involved in managing operations), these tools are rarely used. After all, people in higher management deal with much more information, communicate with many more people, and face constantly changing circumstances, so they tend to rely on their own mental faculties rather than on a tool—and this often manifests in the form of numerous meetings.

Overall, project task management can be described as the externalization and maintenance of tasks (or decisions on what needs to be done) in order to ensure they are completed.

## Partner Task Management
Partner task management refers to the task management used among small, intimate groups—such as couples or parent-child relationships—who live together on a regular basis.

Originally, no tools were used; everything was handled verbally. Due to the intimacy, there was no need for formalities and it was simply faster to speak up. Historically, with sexist notions like “men work, women do the housework,” many domestic tasks were often handled unilaterally by the wife.

Later, with the rise of communication tools, people began to use them for task-related exchanges. The most famous example is LINE. You probably regularly ask your partner to do things or remind them via LINE. However, simple tools like LINE only exchange messages, so they are somewhat insufficient for proper task management. For example, old messages can get lost—and once they’re lost, they’re forgotten. Also, because notifications come in frequently, you can’t communicate too often, or your messages may be overlooked.

In recent years, there has been a trend of couples using more advanced chat tools like Slack or Discord. Additionally, task management apps designed for couples or families—such as TimeTree or Cross—have emerged. These are characterized by being user-friendly for the general public (for example, available as smartphone apps), allowing for categorization by tasks or topics, saving information for later reference, and facilitating message exchanges.

In short, because of the uninhibited nature of a partner relationship, communication is essential; and since it isn’t work, using a full-blown task management system is either too cumbersome (or one might simply lack the skills if not a businessperson), so people want something simple—but without any record, misunderstandings can occur. Thus, there is a need to record things (whether tasks or topics) in clearly defined units. I refer to this category as **Partner Task Management**. So far, I have observed this mainly among couples and families, but it might also apply to roommates.

## Personal Task Management
Task management in which an individual manages their own tasks is called **Personal Task Management**. This is the primary focus of this book.

As mentioned earlier, the essence is “everyone is different.” For instance, there might be someone like Person A who only wants to focus on truly important tasks, someone like Person B who wants to perfectly control everyday chores such as cleaning, nail clipping, and taking out the trash, and someone like Person C who turns into a machine that relentlessly works through a schedule packed with appointments. Person A’s approach to task management might not work for Person B or Person C—and the same goes for others.

Moreover, even the method of task management you use can change for the same person. For example, there might be someone like Person C who, during weekdays, becomes a machine as a manager, but on weekends, there might be someone like Person D who wants to use their time more effectively by prioritizing and executing important tasks (in other words, Person A’s style); conversely, there might be someone like Person E who, while working freely without being bound by appointments on weekdays, fills their weekends with scheduled activities in a very structured (Person C–like) way because they want to be active.

While saying “everyone is different” may sound dismissive, there are indeed trends. The approach of “relying on schedules” described so far is probably known—and even used—by many. In addition, busy people such as managers tend to adopt this style (unless they consciously resist it). In this book, I also intend to neatly organize and discuss these tendencies.

Another point: we are human, and as mentioned, we tend to be lazy, indecisive, and forgetful. Even if that weren’t the case, concepts such as concentration and motivation are well known. No matter how perfect your task management might be, it is meaningless if the person executing the tasks cannot function effectively. In that sense, the peripheral elements around task management are actually very important—and this book will discuss those in detail.

# Narrow vs. Broad Task Management

Task management can be interpreted in a narrow sense or in a broad sense.

## Narrow Task Management
First, **narrow task management** refers to managing tasks in the strict, literal sense. This is especially true for project task management. It only considers the management of tasks, making it difficult to address whether the tasks themselves are appropriate, who is handling them, or the environment in which they are managed. These aspects are not even considered. For better or worse, people are simply machines that execute tasks.

## Broad Task Management
However, as mentioned earlier, we are human and cannot operate like machines. While it might be expected for workers to act mechanically, in today’s world where well-being is emphasized, that approach is not welcomed. Furthermore, in this so-called VUCA (Volatile, Uncertain, Complex, Ambiguous) era, the need for individuals to make proactive decisions has increased. In such cases, merely managing tasks in the narrow sense isn’t enough—you must also consider the peripheral elements.

For example, discussions about your goals or vision might seem tiresome, but they are important—after all, the tasks you undertake depend entirely on what your goals and vision are. There are also considerations about who you associate with or what organization you belong to, discussions about which tools to use, as well as, on a personal level, matters of spirit such as concentration and motivation, and even physical condition.

In the truest sense, task management is not limited to managing tasks narrowly—it involves taking into account all these peripheral factors. This is what I refer to as **broad task management**.

## Not Being Bound by Task Management
If you become too fixated on narrow task management, you may find yourself stuck when the tasks or the environment around them are problematic. Especially in busy situations, when you’re already short on time, or in severe cases where you might be subject to information blockades, brainwashing, or even curses of a similar nature, sticking rigidly to narrow task management will only lead to trouble. Such extreme examples aside, even in less severe cases, you may encounter trivial routines, procedures, forms, or cultural practices that hinder you. In situations where you should question and address the tasks themselves, thinking “I’ll just work harder” or “I’ll try to improve my task management so I can work harder” is simply foolish. Of course, this doesn’t mean that you should develop habits of laziness or avoidance, but you should respect your own well-being, time, and intentions. In organizational settings, the dynamics are complex and heavy, and while you might not be able to handle everything on your own, you can still take steps to protect yourself. When you’re overwhelmed with tasks, I recommend first taking a broad perspective and questioning the situation. If action is necessary, then act decisively—whether by tackling everything at once or by preparing properly. It’s okay to fail; it’s better than continuously exhausting yourself by ignoring the broader issues. Unless you act with a broad perspective, the situation will persist (and while things might improve if you’re lucky, ultimately it’s largely a matter of chance).

I know I’ve written at length and in a somewhat convoluted way up to this point—you might think I’m stating the obvious—but it turns out that these issues are surprisingly difficult. Without this knowledge, you can’t even begin to conceive of an effective approach; and even if you do know it, when you’re busy, it’s hard to switch gears, and being calmly corrected by others can make you irritable and defensive. It’s not a simple matter. That’s why it’s important to confront these challenges head-on and learn to manage them effectively. This broad perspective will appear frequently in this book.

# Task

But what exactly is a task?

## What Is a Task?
What exactly is a **Task**? It can be called work, something to do, a to-do, an action, an activity, or even a project—the names vary.

There is no one correct answer; rather, it depends on the context. In personal task management, the individual can define it as they see fit, and in a team setting, there may be definitions specific to that team. Similarly, the tools or methods used in task management might provide their own definitions—or sometimes no fixed definition exists, leaving it up to each person’s interpretation.

Here are a few examples:

1. A task is simply “anything to be done.”
2. A task is something for which the action is confirmed.
3. A task is something that has a deadline and an assignee.
4. A task is something that cannot be completed in one go but is sufficiently granular so that it can be tackled in several attempts to eventually reach completion.
5. A task is something for which specific procedures and criteria for completion have been defined.

Definition 1 is the broadest and includes almost anything. Definition 2—“something that is confirmed to be done”—would apply to company work, orders from a boss, or even critical personal administrative tasks. Definition 3, which mentions deadlines and assignees, is common in project task management. Definition 4 is a bit wordy, but essentially it means “a piece of work that can be completed through multiple efforts”—which might be more appropriately called a project rather than a task. Lastly, definition 5 emphasizes specificity and also tends to apply in work contexts.

None of these definitions are absolutely right or wrong—they’re all valid in the appropriate context. Use the definition that best suits you, your team, or your family.

## Avoiding Tragedy
Usually, when you use a tool for task management, you don’t consciously think about definitions. However, in practice, a definition does exist. By being aware of what you define as a task, you can reduce the risk of mistakenly treating non-tasks (elements that fall outside your definition) as tasks.

For example, if you base your definition on number 5—that a task is something for which specific procedures and completion criteria are defined—but you encounter a task with vague procedures or criteria, you can guard against it by saying, “That is not a task,” “Please specify the procedure,” or “If you can’t do it, don’t even register it.” This helps maintain order. Without such order, vague tasks will mix in with proper ones, and when you review or update them later, confusion ensues. One vague task might not be a big deal on its own, but when many accumulate, it becomes troublesome—and ultimately, task management itself becomes superficial.

Let’s consider a more personal example. Suppose there is someone like Person A who can’t get motivated without a deadline. In that case, it would be best for Person A if tasks are defined as things that have deadlines. Otherwise, not only will they lack motivation, but if there are many pseudo-tasks without deadlines, they might lose track of the real tasks. This could eventually lead to them becoming fed up with task management altogether. When using any task management tool, Person A should ensure that each task has a properly set deadline. It would be even better if there were a mechanism to notify about any missing deadlines, and even better if Person A could adjust the overall workload based on their own capacity (how many tasks they can handle and complete).

In this way, it is best for those managing tasks to define for themselves what they consider a “task” and then only deal with items that fit that definition. Even a rough understanding—such as “to us, tasks generally refer to things like this”—is much better than having no definition at all.

## Distinguishing Tasks from Non-Tasks
Up to this point, I’ve talked about how you can define tasks in your own way, but there is one theory that can make things much easier: distinguishing between tasks and “things that look like tasks but aren’t really tasks.”

I will refer to such things as **Altasks (Alternative Tasks)**. (Short for Alternative Task.) Literally, it means “alternative task.” It refers to things you do in place of a task—activities that require a different approach than a typical task.

Examples of Altasks include:
- **Containers:** Concepts of classification such as folders, categories, and tags.
- **Appointments/Schedules**
- **Vision, Philosophy, Slogans, or Guidelines**
- **Notes**
- **Habits or Daily Routines**

I will discuss these in more detail in later chapters. For now, just keep in mind that Altasks are not tasks and require a different approach. Managing an Altask as if it were a task won’t work effectively.

# Task Management

We’ve now discussed what a task is. So, what is task management?

## What Is Task Management?
**Task Management** is simply the management of tasks.

But what does “management” mean? I’ve been saying that it depends on the person and the situation—and, unfortunately, that applies to management as well.

## The Nuances of Management
Let’s first look at the nuances of “management.”

I believe management can be broadly categorized into three aspects, known as the MCA framework. (The original sources are [1](https://note.com/4bata/n/n5e23d03c22cf) and [2](https://brevis.exblog.jp/10625203/).)

| Name            | Description                                          | In a Nutshell          |
|-----------------|------------------------------------------------------|------------------------|
| Management      | Using every possible means to “make things work”   | Like mixed martial arts|
| Control         | Ensuring things proceed according to plan or standards (filling the gap) | Filling the gap        |
| Administration  | Setting direction or systems (steering)            | Top-down control       |

Next, using this framework, let’s clarify the nuances of various types of management. I will list the main ones:

| Name         | MCA             | Description                                                        |
|--------------|-----------------|--------------------------------------------------------------------|
| Progress Management | Control  | Whether tasks can be completed by the deadline and if the pace is adequate |
| Completion Management | Control  | What has been accomplished and what has been finished               |
| Estimation Management | Control  | How long tasks will take to complete and how to make accurate predictions |
| Meeting Management    | Management | What kind of meetings should be set up for success, including ad hoc or emergency meetings |
| Utilization Management | Administration | How to define human resource capacity and what constitutes resource consumption *(1)* |
| Backlog Management    | Administration | How to manage tasks that are to be done later or in the medium to long term *(2)* |

- *(1) A typical example is work-hour management: `Work Hours = (Time Required) x (Hourly Rate)`.  
- *(2) Approaches such as maintaining a backlog or “someday” list, where tasks are pooled and periodically reviewed, are common.  
- *(3) A “1on1” is a meeting between a supervisor and a subordinate. Originating in Silicon Valley and popularized in Japan through initiatives at Yahoo (now LINE Yahoo), these meetings can range from casual conversations to serious career discussions. In my view, you can often gauge the character of a company by its 1on1 practices.*

When you look at it this way, it becomes apparent that Control (filling the gap) and Administration (top-down control) are more common. Management is less common, but meetings are a good example of it. If it were just about setting up regular meetings or review sessions, that would fall under Administration, but reality isn’t that simple—there are interruptions, emergencies, casual chats, and even well-established 1on1 meetings. This is where leaders and managers can really showcase their skills—it is truly like mixed martial arts.

## Task Management Is Management
On the other hand, in English, we call it “Task Management.” It is not merely about Control or Administration—it’s about Management. Isn’t this consistent with what we’ve discussed so far—that task management is inherently personal and that the optimal solution depends on the situation? In short, as long as it works well, that’s enough. Control and Administration are well-known methods and can be effective, but that is not the whole picture.

In this book, I will introduce various aspects of what is called task management, but which ones and how you use them is entirely up to you. In order to manage tasks, don’t be confined by rigid frameworks—use what works and discard what doesn’t, and explore your own way.

## The Axioms of Task Management
Even regarding “task management,” there are premises that have been roughly common throughout its history. I will refer to these as **The Axioms of Task Management**. An axiom is something assumed to be true as a starting point for a theory—it’s a premise.

There are two axioms of task management:

- **1: The Tool Axiom**
  - In task management, you always use some sort of tool.
- **2: The Interpretation Axiom**
  - It is up to the individual to decide whether something is a task.

### The Tool Axiom
The Tool Axiom essentially states that **if something is managed solely in your head, it is not task management.** If you can manage everything in your head, then you wouldn’t need the hassle of task management—and those who are confident in their mental capacity likely wouldn’t bother anyway. However, the amount of information one person can handle is limited, and humans are prone to laziness, indecision, and forgetfulness. To overcome these limitations, we externalize information in the form of tasks (using tools) and then maintain what we have externalized. This is true even in project task management involving multiple people; otherwise, you’d end up with “he said, she said” disputes and endless meetings to check on the status. With a tool, you simply check or update it.

### The Interpretation Axiom
The Interpretation Axiom is something I have emphasized repeatedly. Whether something is considered a task depends on the individual, and even the same person’s view can change over time. To put it in extreme terms, writing this book is a task for me as of 2024/04/30, but for everyone else it is not. Moreover, a year from now it probably won’t even be considered a task for me. On a broader scale, if we think of it as “systematizing task management” or “promoting task management,” there are likely several people who regard it as a task—and I am one of them.

In other words, the act of deciding whether something is a task is itself crucial. Most of us are workers and, in a way, have become machines that simply execute tasks handed down from above—but even those tasks are ultimately just decisions made by someone. As I’ve written, in personal task management you are the main actor, so it is up to you to decide what constitutes a task. Similarly, even in project task management, it is important not to simply accept tasks as given, but to question them from your own perspective (as discussed in the section on broad task management). In reality, you might have no choice but to follow the tasks as they are handed down, but as an axiom, it is not so—it is a matter of decision-making. Please keep that in mind.

## Task Management Is a Skill
What can we conclude from these axioms? First, that tools are important. When we say “tool,” you might think of an app or service, but it also includes analog items such as a note board on your refrigerator or a notebook. It also includes conceptual tools such as methods, processes, and frameworks. Many people already try out various tools without consciously considering the underlying method or philosophy of task management—this, in other words, shows that tools themselves have considerable power. Even if you don’t know much about task management, merely using a tool can enable you to manage tasks.

Next, decision-making is important. Deciding what to consider as a task is a matter of decision-making—it sounds simple, but it is surprisingly challenging. Since making decisions comes with responsibility, those who are reluctant to shoulder that responsibility might avoid making decisions. Also, some people are simply not good at making decisions. Even if you overcome that, you need criteria or guidelines on which to base your decisions. You must consider how to create and nurture those guidelines. Moreover, decision-making is tiring—in fact, our “attention resources” are like hit points that do not recover without sleep. This means that you must be selective rather than greedy. This also involves aspects such as habits and lifestyle improvements. While managers and executives might have decision-making as a central part of their work, decision-making itself can be considered an advanced skill. In task management—especially from the broad perspective of deciding what constitutes a task—you are embarking on this advanced endeavor. It is not something that can be mastered overnight. You must continually develop and maintain your decision-making criteria, accumulate experience, and learn to use your attention resources efficiently. In short, it must be honed.

Tools and decision-making—these require skill. In that sense, **task management is a skill.**

# Summary
- **Task Management:**
  - Its essence is that it differs from person to person.
  - You must explore and find what works for you.
  - There is no magic tool; it’s important not to shy away from exploration and to keep confronting the challenge.
- **The Direction of This Book:**
  - It provides various hints to help you shortcut your own exploration.
  - This book introduces various aspects of what is called “task management.”
  - Think of browsing through the hints like shopping in a store.
- **Task Management Can Be Classified into 3Ps:**
  - **Project:** Project Task Management (team-based)
  - **Partner:** Partner Task Management (for couples and families)
  - **Personal:** Personal Task Management (individual)
- **Narrow vs. Broad Task Management:**
  - The narrow perspective is simply managing tasks.
  - In reality, a broader perspective is necessary.
  - Extreme examples, such as in exploitative companies, illustrate this clearly.
- **Tasks:**
  - Since definitions depend on context, find the one that fits your situation.
  - Distinguish between tasks and non-tasks.
  - It is especially useful to remember the concept of Altasks—activities that require a different approach from typical tasks.
- **Task Management:**
  - The term “management” often refers to Control (filling the gap) or Administration (top-down control), but task management is about Management in the broader sense—if it works well, that’s enough.
  - Keep in mind both the Tool Axiom and the Interpretation Axiom.
    - Task management is a skill.
