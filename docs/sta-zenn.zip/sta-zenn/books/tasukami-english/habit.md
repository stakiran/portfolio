---
title: Habits
---

Daily duties, habits, routines, and routine tasks (regular tasks) — in personal task management, the act of doing things continuously is unavoidable. Although we have touched on these topics in fragments so far, this chapter will consolidate the ideas. In particular, we will focus on explaining what habits are.

In this chapter, the continuous activities are divided into **daily duties, habits, and routines**. Of these, daily duties and routines have already been explained elsewhere, so here we provide only a brief explanation with links to other chapters. This chapter focuses in detail on the remaining topic: habits.

# Daily Duties

## Overview
**Daily Duty (Daily Mission)** refers to tasks that must be done on a daily basis. Tasks that carry the nuance of “MUST” or “SHOULD” are sometimes called missions; when such tasks are performed every day, they become daily duties. In English we say “duty,” though “mission” might work just as well.

## How to Manage Daily Duties
By their nature, daily duties simply require you to manage whether you do them once each day—if you complete everything, you’re fine. In fact, you can manage them with a habit tracker. Although it is called a “habit tracker” by name, it would be more accurate to call it a “daily duty tracker.”

## How to Choose Daily Duties
How you choose your daily duties is entirely up to you. **You decide what becomes a daily duty.** Anything you feel you must do (MUST) or should do (SHOULD) can be made into a daily duty. Of course, if you turn everything into a daily duty, it will become difficult to accomplish them all; it is advisable to start small and gradually add more.

## The Timing of Daily Duties Is Flexible
Daily duties need only be completed sometime during the day. In other words, **it doesn’t matter when you complete them.** If scheduling them rigidly makes you feel burdened, it may be better to simply list them and complete them at your own pace. In fact, that is exactly how a habit tracker works—you just list your daily duties and mark whether each one is done. On the other hand, if the timing is completely optional, you might be more prone to procrastination. There is a trade-off between strictly scheduled timing and the tendency to slack off.

Ideally, you should design a specific timing for each daily duty. For example, taking your dog for a walk may not require strict management because the dog will likely prompt you (an event-driven action). Watering the plants and tending the flower bed, however, have no such prompt and cannot be forgotten, so it is best to schedule them or set reminders. Likewise, suppose your profession is creative and you need about an hour of practice each day to hone your skills (and prevent them from deteriorating). If your work is erratic—with peaks of busyness and downtime making your life irregular—when will you practice? You can’t predict the day’s circumstances. Will you simply do it when you find a free moment without any management, or schedule “skill practice” into your calendar every day, or even set a strict time (say, 6 AM for one hour)? Of course, there is no single correct answer, and it varies from person to person; however, it is generally better to individually design the timing for each daily duty (even if it seems a bit cumbersome at first), so that it naturally fits into your life and works smoothly.

## Where This Is Explained
This topic is discussed in the Strategy chapter as [Tracker](strategy#tracker) (using the word “habit” for simplicity). It is also addressed in the [Task Source chapter](source), where the importance of creating regular tasks is emphasized in the context of maintenance tasks.

# Routine Tasks

## Overview
**Routine (Routine Task)** refers to tasks that are executed regularly. You can also call them **regular tasks**. Because the only point at issue is whether a task is performed at regular intervals, even daily duties or habits can sometimes be treated as routines. (There are also terms like “routine work” or “routine performance,” but let’s set those aside for now.) In this chapter, I will use the term **routine tasks**.

A routine task is essentially a task with a frequency attached to it. For example, “taking out the trash” is just a task, but “taking out the trash every Tuesday and Friday” is a routine task—in other words, you set the frequency (every Tuesday and Friday) for the “taking out the trash” task.

## The Majority Are Routine Tasks
Most of the actions and tasks we perform are routine tasks. Whether in daily life or at work, there are many things you perform at specific intervals. Depending on the person, you might have roughly 20 to 60 routine tasks in a day. That might sound like a lot, but consider, for example, the actions you perform before leaving for work: “eat breakfast,” “brush your teeth,” “groom yourself,” “prepare for work” – and that’s already four tasks. (Of course, if you break them down further into “get out of bed” or “go to the bathroom,” the number could be much higher, but that would be extreme. I mean that if you list tasks at the former level of granularity, you’d end up with around 20 to 60 tasks.)

The actions before leaving for work are easy to understand, but there are many other routine tasks. For instance, taking out the trash occurs only on Tuesdays and Fridays, and even within trash tasks, combustible and non-combustible items might have different designated days. For those who work in a hybrid mode (switching between remote work and office work), the routine tasks related to preparation and tidying up will increase on office days.

## The Benefits of Managing Routine Tasks
In other words, we are **handling a great many routine tasks solely in our heads without any formal management—and completing them daily.** But is this approach really optimal? Haven’t you experienced moments like “Oh, I forgot to do that,” or “I need to do this and that, and it’s so confusing—what should I do?” Such forgetfulness and procrastination occur in eight or nine out of ten cases; sometimes you may not even be aware of them.

By managing routine tasks with a task management system, you can reduce instances of forgetfulness and procrastination. You can control which routine tasks to perform, when to perform them, and in what order—allowing you to complete them efficiently and avoid omissions. Of course, it is not as simple as that; you may still end up slacking off or postponing tasks, and you might not be able to articulate every single routine task you have into a tool (nor is such rigorous management usually possible). Even so, it is much easier than keeping everything in your head without any management, and it helps reduce forgetfulness and procrastination.

## How to Manage Routine Tasks
Use a dedicated task management tool. In particular, you need a tool that can handle frequencies. A simple TODO list or an analog method won’t suffice, and even a calendar app may be too cumbersome for managing dozens of routine tasks. The frequencies vary—from “perform every day,” “every other day,” “every Tuesday and Friday,” “once a week,” “at the end of the month,” “at the beginning of the month,” etc.—so you need a tool that can handle all these variations. A dedicated tool is necessary.

Some examples of such tools are [Todoist](ref#todoist) and [TaskChute](ref#タスクシュート). There are also apps specialized in routine task management, such as [Routam](ref#ルータム) or [Routinery](ref#routinery). There are many tools capable of handling frequencies beyond these examples, but most are inadequate. In managing routine tasks, **it is absolutely essential to have a lightweight tool that operates smoothly—because you will be interacting with a large number of tasks repeatedly.** It is not uncommon to operate these tasks dozens or even hundreds of times a day.

If you do not like existing tools, you might even consider creating your own. That’s how delicate this tool is. (I myself have [created my own](strategy#概要-7) and experimented with various approaches—even organizing theories for an analog method, which eventually led me to [write an e-book](ref#21).) Incidentally, the analog approach is considerably cumbersome, and the reception to such books has not been favorable. It is best to use a dedicated digital tool.

## Where This Is Explained
This topic is discussed in the Strategy chapter under [Robot](strategy#robot).

Even if you do not manage your routine tasks as strictly as a “robot,” you can still manage them in a somewhat rough manner. For example, simply listing your routine tasks in a habit tracker (which is better than keeping them solely in your head) can be effective. Since this is also discussed in the Strategy chapter, if you want to face routine tasks head-on, please refer to it and experiment in your own way.

# Habits

## Overview
A **habit** is something you perform regularly without exception. First, it has a regularity—you might do it once a day, twice a day, or once every three days; the frequency can vary and it does not necessarily occur at strictly fixed intervals, but it is performed regularly. Second, it is done without even a single exception—it is performed reliably every time. In other words, a habit is **a regular, well-ingrained action.**

A habit is much like a skill. A skill is not merely knowledge or experience, but something that has been trained and ingrained to the point that you can perform it effortlessly and consistently. The same applies to habits—a realm where the word “training” fits perfectly. To make a habit stick, you must accumulate sufficient practice. It does not happen overnight, and trying to acquire a habit without effort is simply mistaken. In short, habits require effort.

When we think of habits, we may imagine acquiring new ones; however, there are also cases where you want to “break a bad habit.” Habits can be good or bad—you adopt the good ones and discard the bad ones. Each requires a different strategy, but in any case, they are like skills and require effort.

## What Are Not Habits
Daily duties are not habits. As mentioned earlier, daily duties are simply daily missions whose timing is flexible. A habit, by contrast, is something you perform automatically without the need for management. Conversely, if a daily duty becomes so ingrained that you complete it every day without any management, you might say it has become a habit.

Routine tasks are also not habits. Routine tasks are tasks with a set frequency—a concept used in task management tools. For example, if you want to take a 30‑minute walk every day, you would set up a “take a walk” task with a frequency of “daily” and position it prominently (say, at the top of your task list) so you see it each morning. By simply using your task list daily, you will likely see the “take a walk” task in the morning and, if you act accordingly, complete it. However, this is just you giving yourself instructions and following them—it does not quite count as a habit. In contrast, a habit is something you perform automatically every day (barring extraordinary circumstances). Conversely, if through routine task management you eventually reach the point where you perform the task automatically without management, then you can say it has become a habit.

One more thing: **cognitive habits (or “thinking habits”) are not considered habits.** When people hear “habit,” they may think of habitual ways of thinking or approaching tasks, but in this book those are not regarded as habits. Instead, they are treated as [mottos](motto). Mottos require you to act appropriately according to the situation (what I refer to as “application”), and these are more an ability than a skill—they depend on your talents and inherent traits.

## There Are Three Types of Habits
There are three types of habits:

- **Good Habits**
  - Habits you want to adopt or continue.
  - You might newly adopt them or, if they are already established, make slight adjustments to improve them.
- **Bad Habits**
  - Habits you want to stop or reduce.
  - You might quit them abruptly or gradually decrease their frequency or occurrence.
- **Ambiguous (Odd) Habits**
  - Habits for which it is not clear whether they are good or bad.
  - You might leave them as they are, or decide whether to treat them as good or bad and act accordingly (if good, adopt them properly; if bad, eliminate them).

When it comes to habits, people tend to focus on increasing good habits or stopping bad ones, but since both exist, it is best to address both. Additionally, there are ambiguous habits whose classification is unclear; you need to decide whether to treat them as good or bad (or strategically leave them alone if you cannot decide).

Because you cannot have an infinite number of habits—and because human capacity is limited—you must choose carefully. Thinking in terms of the three axes (good, bad, and ambiguous) is an accessible starting point.

## The Significance of Habits Is Maximizing Action
What is the benefit of habits? Why do we want them? It is because we want to become stronger (※1). To become stronger, you must take action. Action brings you knowledge and experience, and at a physiological level, stimulation and stress cause your brain to learn and adapt. On the other hand, incorrect knowledge or excessive stress can be damaging and may even break you down mentally or physically. In short, the more you act, the stronger you become (and the fewer damaging actions you take, the less harm you incur).

Thus, the remaining question is: how do you increase your actions? This is where habits come in. Since habits are actions performed regularly without exception, they maximize your actions. For example, if acquiring a certain ability requires one hour of action per day for 300 days, the ideal is to perform that action every day for 300 days without fail. It might be difficult to do this by willpower alone, but with a habit it becomes much easier—you do it automatically, and if you miss a day, you’ll feel uneasy and even scramble to make it up.

There is a saying, “What you love, you do well.” People who do something because they love it do not see their actions as effort; hence, those who act solely out of effort are at a disadvantage. The same goes for habits—when you act out of habit, you don’t feel that you’re exerting effort.

- ※  
  - 1 There may be purposes other than “becoming stronger.” For example, you might want to form a habit of cleaning regularly so that you can live more comfortably. That is a perfectly valid reason. In my view, it is merely a difference in expression—a habit of cleaning regularly can also be seen as becoming “stronger” in the sense of gaining the ability to clean consistently. In the end, whether you say “I want to become stronger” or “I want to live more comfortably,” you can use whichever expression you prefer.

## The Limitations of Habits
There are two limitations.

The first is that you cannot have an unlimited number of habits. How many you can maintain depends on the person and the nature of the habits. While physical strength and time are obviously finite, factors like concentration and attention are often overlooked.

For example, even if you have established the habit of reading one new book per day, reading requires concentration and attention. It is best to do it during times when your mental resources are not depleted—for instance, shortly after waking up (within the first few hours of the day). People with high mental performance or who do not tire easily might manage even later in the day, but when you are busy with work, it becomes difficult. You might exceed your personal capacity, so the reading habit no longer fits. You might force it, but it won’t be effective. Many have experienced that their eyes “slip” and they cannot read as well, and even after taking a break and trying to resume, the difficulty remains. Especially nowadays, with smartphones and other devices draining your cognitive resources, it is not uncommon to have many hours until bedtime when your mind simply does not function optimally.

The second limitation is that a habit is simply the repetition of an action. It does not inherently account for the effectiveness of the action itself or the value derived from repeating it. In other words, just as effort is meaningless unless it is applied correctly, the same applies to habits: in order to truly become stronger, you must build the right habits (ones that enable you to perform the action properly). Without repeating the correct actions, you cannot significantly improve, and if you have a bad tendency, it can even lead to a decline. In particular, just as it is very difficult to break an ingrained habit, eliminating a bad habit is also challenging.

# Habit Engineering

Let’s call the process of increasing good habits, reducing bad habits, or deciding how to handle ambiguous habits **Habit Engineering**. In this section—titled “Habit Engineering”—we will cover the mindset and techniques for actually managing your habits.

## The GSAAD Loop
Habits are not something you can suddenly adopt or eliminate effortlessly. They must be earned by setting a target, taking small actions every day, checking the results, and making slight adjustments—a steady process. I call this typical cycle the **GSAAD Loop**.

- **1: Get**  
  - Acquire the target (define the specific action you want to address)
- **2: Set**  
  - Implement a mechanism to interact with that target
- **3: Act**  
  - Let the mechanism trigger you into action
- **4: ADjust (Adjust)**  
  - Make slight adjustments based on the results of your actions  
    - “Results” include whether you acted, didn’t act, quit midway, or acted at an unexpected time  
    - “Adjustments” refer to modifications to the target, the mechanism, or the action itself

![GSAAD](/images/taskmanagement-kamikudaku/gsaad.png)

Note that unlike a typical cycle, the final “Adjust” step can lead in several different directions.

### 1: Get – Define the Target
First, decide on the habit you want to address. If you want to increase a good habit, it might be something like “I want to go for a walk,” “I want to read more,” or “I want to practice vocal training.” If you want to reduce a bad habit, you might decide “I want to stop drinking before bed” or “I want to stop surfing the internet during my commute.” The same applies to ambiguous habits (which you might call “candidate bad habits”). The important point is to define it at the level of **a specific action**. Do not settle for vague desires like “I want to lose weight,” “I want to be smarter,” or “I want to read more”—focus on the action.

When you decide based on an action, it may seem bland and you might not feel motivated, but that is fine. In fact, even if you are not enthusiastic, you must choose an action that you feel you want to make into a habit. If you cannot identify such an action, then habit engineering will not work for you—at least not for now. To work on habits, you must begin by pinpointing a specific action. If you can’t do that, nothing will work. I recommend breaking down your vague desires to understand which specific habits (actions) you need to acquire, or simply brainstorming and reflecting persistently to list them out.

### 2: Set – Implement a Mechanism
Whether you’re working on a good habit or a bad habit, some action is involved—but you cannot rely solely on willpower to act every time. So what do you do? You create a mechanism that automatically triggers the action when certain conditions are met. This may sound complicated, but here are a few examples:

- **[Movement Patterns and Reminders](dousen_and_remind)**
  - (Covered in the previous chapter.)
  - Setting up reminders ensures you will be alerted even if you forget.
  - If you place tasks along routes you frequently travel, you will see them repeatedly over time.
  
- **Habit Stacking**
  - Attach the new action to an existing habit.
  - Since you reliably perform your existing habit, adding the new action to it makes it easier to do.
  - For example, if you brush your teeth every morning but have not yet made trimming your nose hair a habit, place a nose hair trimmer near your toothbrush.
    - For even greater assurance, you might put your toothpaste in a small bag or box and seal it, then place the nose hair trimmer on top.
    - (Note that this requires an additional action—“sealing the toothpaste”—which itself may need to become a habit.)
  
- **IF-THEN Planning**
  - Set up a rule such as “If XXX happens, then I will do YYY.”
  - This is similar to the [motto](motto) discussed in the previous chapter, though its effectiveness depends on the individual.
  - It helps if you can reinforce the “if” part (XXX) with things like movement patterns or reminders.
  
- **Adding to a Task List or Inbox**
  - Write down the “new action you want to take” or the “action you want to stop (or a new action to help you stop)” in your regular task list or inbox.
  - Because you use these lists daily, you are likely to see the entry.
  - Although seeing it does not guarantee you will act, it is better than not seeing it at all and completely forgetting.

There are many other techniques, but essentially there are two key ideas:  
1. Ensure you are alerted so that you do not forget, and  
2. Strengthen the trigger so that once you notice it, you actually take action.

A prime example of a stronger trigger is having **external reminders** (such as human reminders or ambient cues, as discussed in [Movement Patterns and Reminders](dousen_and_remind#雰囲気リマインド)). Conversely, some “athlete-type” people can act just by having a single line on their task list.

The important point is to set the trigger strong enough that you actually take action. Think through and implement a mechanism that works for you. I am an “athlete type” so simply writing it on my usual task list works for me, but most people may need more. Some individuals simply cannot manage on their own and must rely on their environment or other people. This really depends on the individual—and even for the same person, it can vary depending on the specific habit.

### 3: Act – Take Action Triggered by the Mechanism
Once you have set up the mechanism in the “Set” phase, you are in a position to take action.

Now the question is: what exactly should the action be? How should you perform it, and to what extent? For example, if you want to go for a walk, consider:
- How many minutes should you walk?
- What kind of clothes or shoes should you wear?
- What should you bring?
- Where will you walk?
- What should you do if it rains? etc.

The details of the action—in other words, the settings you choose—are called **Action Parameters**. In the walking example, the parameters would include the duration of the walk, the clothes and shoes, what to bring, the location and route of the walk, and whether or not it rains.

In fact, these action parameters are extremely important. Whether the action you set up through your mechanism becomes an ingrained habit depends on whether these parameters are appropriately set. For instance, if you try to start with a three‑hour walk immediately, you won’t be able to sustain it; or if you begin during the rainy season, the rain might be so bothersome that you give up. It might be better to start with just 10 minutes, decide not to walk when it is raining, or—if you frequently have access to a spacious indoor location such as a shopping mall—attach your walking action there (effectively eliminating the “rain” parameter).

This may sound abrupt, but there is a concept called [“Just Getting Started”](https://diary.hyuki.net/p/20210828). It is the idea that once you begin, progress has been made. As the saying “activation energy” suggests, once you start, you tend to keep going; the challenge is only in getting started. To overcome that hurdle, allow yourself to feel good even if you only start—the simple act of beginning counts as progress. This mindset is effective in the Act phase as well.

Remember, a habit is formed by the accumulation of actions—it is not about the quality of each individual action but the number of times you act. There are many sayings like “better to score 60 than 100,” and similarly with habit formation, you should focus on increasing the number of actions, even if they are initially rough or unrefined. In other words, aim to increase your action count. To do that, experiment with which parameters lower the barrier for you to get started.

When experimenting with parameters, be mindful of both finding a balance that suits you personally and following established principles. What matters most is whether you act, so tailoring it to your own preferences will help maintain motivation. On the other hand, if you are uncertain, you might follow conventional wisdom and then fine-tune. (Nowadays, asking a generative AI like ChatGPT might be even faster for conventional advice.)

That said, it is not as simple as “just make the parameters easier.” For example, if you want to form a walking habit, merely saying aloud “I will walk now” might be too trivial and likely ineffective. While you might get used to saying it, it won’t necessarily lead to further action. It is often easier to simply “put on your shoes at the front door.” And if even that seems too challenging, start with an even simpler action.

### 4: Adjust – Make Minor Adjustments
After you have acted (or even attempted to act) in the Act phase, you will have some results. Use these results as feedback to make slight adjustments. Here is a simple breakdown:

- **If you were able to act:**  
  - Adjust the action parameters to make it even more comfortable to continue (in the Act phase).
- **If you were unable to act:**  
  - Reconsider the mechanism (Set).  
  - Reconsider the action parameters (Act).
- **If you did not act at all:**  
  - Reconsider the target itself (Get).  
  - Reconsider the action parameters (Act).

I am intentionally distinguishing between “were unable to act” and “did not act at all.” “Were unable to act” implies that something (e.g., forgetting or being too tired) prevented you from acting; in that case, adjust the mechanism or the parameters so that action becomes possible. “Did not act” implies that although you were capable of acting, for some reason you did not feel motivated enough. The two main reasons for that are: either the action parameters are too demanding (making the hurdle too high), or the target itself is inappropriate. In the Get step I advised you to define a specific action, but in order to do so you must have sufficient motivation. Our mind and body are honest; if you define an action carelessly (simply because you feel you should, or because “everyone is doing it”), you will not follow through. That is what “did not act” means. Since a habit is something that is meant to continue indefinitely—even forever—a low level of motivation simply will not suffice. The remedy is either “wait until you feel motivated” or “choose a different action for which you do feel motivated.”

## Establishing a Habit
**Habituation** refers to either acquiring a good habit or eliminating a bad one. How far you must go for a habit to be considered “established” is subjective. It might be one month, two months, or even a year; the key is that you can perform the action every day without fail and without relying on any external management, and you begin to feel that “it’s finally sticking.” In particular, when you start to ignore the mechanisms you set up in the GSAAD Loop or feel that “I can do this without the mechanism now,” that is a sign.

Once you confirm that a habit is established, you can dispense with the GSAAD mechanisms and adjustments altogether. I call this **withdrawal**. Even after withdrawal, you may need to maintain or even improve the quality of the established habit (the action itself), but that can be done within the context of the habit without needing to adjust the GSAAD Loop. For example, imagine a philosopher who has established a habit of walking to stimulate thought. Because the quality of the walk directly affects the quality of his thinking, it is best to continually refine the walk—but not by adjusting the parameters in the GSAAD Act or Adjust steps, rather naturally within the habit of walking.

Sometimes, however, you might forget an established habit (i.e. the action you are performing) after withdrawal. What to do in that case depends on the person. Being human, errors occur—**even established habits can occasionally break down.** But if it is only temporary, do not worry. If it happens repeatedly, then it is time to reexamine the habit. Often, the most common cause of a habit breaking down is a change in your lifestyle (as noted in [The Limitations of Habits](#習慣の限界)): when your life changes, the habit you once performed may no longer fit your capacity. In other words, **people whose lifestyles change chaotically are less likely to establish lasting habits.** In that sense, if you want to establish a habit, it may actually be quicker to keep your lifestyle as consistent as possible—a steady daily rhythm is key.

## Reducing Bad Habits
The GSAAD Loop is relatively easy to understand when increasing good habits, but reducing bad habits is more challenging. (I have already used the cumbersome phrase “the action you want to stop—or a new action to help you stop.”)

Indeed, reducing a bad habit is more difficult to conceptualize than increasing a good habit. Increasing a good habit can be phrased as “doing something,” but reducing a bad habit means “stopping something,” or more precisely, “not doing something.” As the saying goes, negative instructions are harder to understand, and it is difficult to prove a negative—so turning “not doing something” into action is challenging.

When it comes to bad habits, there are three approaches:

- **1: Interfere**  
- **2: Eliminate the Root** (see [Outside-the-Board Battle](partner_taskmanagement#盤外戦))  
- **3: Disrupt**

For approach **1: Interfere**, you add some action or mechanism that interferes with the bad habit (the action you are performing). For example, if you want to stop drinking before bed (even if it is not to the level of an addiction), it might help if there is no alcohol in your refrigerator. You could add an action somewhere that empties the refrigerator of alcohol before bedtime. Alternatively, you might chew gum to ruin the flavor, or change your tooth-brushing time to just before bed, etc.

This is a simple example—and it may not guarantee success—but the idea behind interference is the same. In any case, insert an additional action or mechanism to interfere with the bad habit. Especially if you cannot insert something directly before the habit occurs, set up an action to establish an interference mechanism. This interfering action does not need to become a habit; it can be managed as a routine task or daily duty.

Next, approach **2: Eliminate the Root**. Sometimes interference alone is not enough or cannot keep up. This indicates the limits of individual ingenuity. In such cases, you have no choice but to directly intervene with the root of the bad habit. For example, if you want to stop drinking before bed because it is causing health issues or dependency, then seeking treatment (e.g., going to a clinic) might be best. Alternatively, you might need to identify and eliminate or avoid the stressor that prevents you from falling asleep—perhaps by stopping stressful social interactions, being direct with someone when subtle hints fail, or even changing your lifestyle (by increasing “good habits” that help you get more sleep if you are chronically sleep-deprived due to excessive smartphone use). The causes vary.

When we speak of intervention, you might imagine actively forcing change, but distancing yourself (choosing to ignore) is also an option. In fact, actively intervening often leads to trouble, so it is usually best to first try simply ignoring the bad habit; if that still does not work, then you must resolutely intervene. In any case, it will consume energy and willpower, and if you cannot solve it by your own ingenuity, you must simply brace yourself. Incidentally, such direct intervention with the root is referred to as [Outside-the-Board Battle](partner_taskmanagement#盤外戦), which has been mentioned several times in this book. It is an important perspective not only for the GSAAD Loop but for task management in general.

Finally, approach **3: Disruption** involves dramatically changing your living environment. For example, moving to a new home or changing jobs is straightforward. Ultimately, our habits are heavily influenced by our environment, and there is an adage that “there are only three ways for a person to change: by changing how they allocate their time, where they live, or who they associate with.” If you do not have a level of environmental impact that effects change, nothing will change. In that case, the idea is to completely change your environment—that’s disruption. As the name implies, it means shaking things up.

## Addressing Ambiguous (Odd) Habits
Habits come in three types—good, bad, and ambiguous. Ambiguous habits are those for which it is not clear whether they are good or bad. In fact, it is not uncommon for a habit to have both positive and negative aspects. For example, strength training is good in terms of increasing muscle strength and providing physical and mental stimulation, but on the other hand, it may also lower your immunity or cause temperature fluctuations that make you prone to illness.

The approach to handling ambiguous habits is simple: decide whether the habit is good or bad. Using the strength training example, you might decide to continue it if you think “I want muscle strength, so this is fine,” or decide to stop it if you feel “it causes too many negative side effects and, frankly, having muscles isn’t that rewarding.” If you do not decide, you will be left wondering whether to continue or stop, which drains your cognitive resources. That kind of noise is not trivial. If you decide it is a good habit, continue it; if you decide it is a bad habit, then—using the methods mentioned above for reducing bad habits—eliminate it. In that sense, **ambiguous habits can also be called “candidate bad habits.”**

You might struggle with making a decision, but since there is no definitive answer anyway, it is best to decide quickly. Once decided, as you live with it for a while, the effects will become clear, and you can adjust accordingly. If you decide it is a good habit but then find that the negative effects are too strong, treat it as a bad habit and eliminate it; conversely, if you decide it is a bad habit and stop it, but later find that you miss some of its benefits and it becomes inconvenient, then consider it a good habit and incorporate it again.

Incidentally, I sometimes find that strength training oscillates between being a good habit and a bad habit. For example, in the spring when pollen levels are high, I tend to treat it as a bad habit.

Because there is a limit to how many habits you can manage, you want to promptly decide on ambiguous habits and deal with them accordingly. I believe that the ability to quickly handle these ambiguous habits is a key to the success of habit engineering. If you can’t do this, you may end up accumulating too many good habits to the point of becoming overwhelmed, or conversely, too many bad habits that lead to chronic deterioration.

## Forcibly Acquiring a Habit: “All In”
Habit engineering, including methods such as the GSAAD Loop, is based on the idea of setting up and taking action on your own. However, some people, by their nature, have difficulty with such autonomous actions. What can those people do to form or eliminate habits?

There is no single answer. If I must say something, then—similar to the “Set” section—you might need to devise a mechanism that relies on external forces such as your environment or other people, or use disruption (changing your entire environment, like moving) as one approach to reducing a bad habit (※1).

Incidentally, in professional fields this approach is often used. In apprenticeships with craftsmen, sports club activities, dormitory living, or training camps, lifestyles are strictly controlled, and because these conditions persist for years, you inevitably acquire the habits associated with that world—even if you do not choose to. In other words, habits inherently require a kind of drastic intervention. However, since it is not practical to always use such drastic methods, we usually proceed steadily via habit engineering. If you cannot manage the steady approach, then drastic measures are your only option—and that is what I refer to as “all in.”

- ※  
  - 1 Personally, I believe it would be ideal to further develop the external approach—the method of relying on external forces. Currently, the options are limited to joining an organization based on strong trust or shared interests (such as at work or with a partner) or changing the environment of your independent activities (for example, studying at a café). I wish that technology could offer more creative solutions. For instance, there might be a social network that matches pseudo-colleagues or partners so that they can monitor and support each other, or a service that offers a highly structured, school-like environment for anyone to use flexibly—but I have not yet found a breakthrough. The challenge is not merely to create a space, but to create an environment or mechanism that motivates and pushes those who have difficulty with autonomous habit engineering.

# Summary

- Continuous activities can be divided into daily duties, routine tasks, and habits.
  - Daily duties are managed via daily missions or a habit tracker.
  - Routine tasks are managed using dedicated task management tools.
- Habits are:
  - Actions performed regularly without exception.
  - Much like a skill, they require training.
  - Their significance lies in maximizing your actions.
- Habit Engineering:
  - Habits can be classified as good habits, bad habits, or ambiguous (odd) habits.
  - The GSAAD Loop involves:
    - Defining the target habit (action), setting up a mechanism to trigger the action, taking the action, and making adjustments.
    - Both the mechanism and the adjustments require “tuning”—if it could be done by willpower alone, there would be no struggle.
    - To establish a habit, focus on the quantity of actions rather than their quality. Aim to increase the number of times you take action. (For example, simply starting counts as progress.)
  - For those who cannot run the loop on their own, the only recourse is to rely on the power of your environment or other people—or, as a last resort, to resort to disruption (completely changing your environment).
