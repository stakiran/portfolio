---
title: Exploratory Task Management(3/4)
---

In this chapter we introduce various hints and ideas that can be useful when working with ETM (Exploratory Task Management). Some of these hints apply whether you’re working alone or with others. (See also the “Literary Task Management” chapter for more on the fundamentals.)

# Literary Task Management as the Basis

ETM is built on the foundation of Literary Task Management, so its various techniques are available. For basic techniques, please refer to the [Literary Task Management chapter](literate). Because ETM uses a networked note tool, the literary task management approach is particularly relevant. In fact, ETM is nothing but Literary Task Management that has been re‐constructed with an exploratory twist. This was mentioned as an assumption at the beginning of the previous chapter.

---

# Squeeze Out

**Answer:** When it comes to limiting your effort, using the “I squeezed out 100% of what I could do at this moment” as a guideline is useful.

In ETM the phrase “once it becomes clear” serves as a signal. Ultimately, what you’re trying to achieve is based on what “becomes clear” from all the topics you’ve built, and you even create topics that verbalize what has become clear.

At the same time, you may never reach clarity or sometimes you won’t be able to invest enough resources to see it clearly. For example, if you have 100 ideas, it is impossible to spend enough time on every single one until clarity emerges.

Because there is no “right answer” in exploratory ETM, you must eventually decide to stop (limit your effort). Of course, you shouldn’t stop arbitrarily; rather, you can use a rough guideline. “Squeeze Out” works well as such a guideline.

**Squeeze Out** means “to extract 100% of what you can do at this moment.” The original meaning is “to squeeze out” as if you were extracting juice from a fruit. Although that may sound desperate, it isn’t meant in a negative way. “At this moment” implies that your current ability, mood, and motivation are taken into account. For example, you might think to yourself, “This is about as much as I can do right now,” or “I’ve done all I can for now, so I’ll stop here,” or “I’m getting bored, so I’ll leave it at this.” 

Notice the phrases “done everything I can” and “I can’t do any more.” These expressions are not about the visible output or the time spent but about whether you feel you’ve given your 100% in your current state. I often ask myself, “Can I say I’ve given it my all?” Although this may seem similar to “best effort,” it is slightly different. Best effort simply means “I’ll try my hardest,” which lacks any explicit information about whether you truly have done all you can. With Squeeze Out, you assess whether you have exhausted your own possibilities. In the beginning you may find it hard to judge your own “exhaustion,” but with time you will learn to recognize your limits and tendencies.

Squeeze Out is extremely important in ETM. The reason is that if you’ve truly squeezed everything out, you will have a high degree of satisfaction and confidence in your decision-making. And if, even after squeezing out, things don’t work out, you can then question whether you might have overlooked something or needed more input. Once you have squeezed out everything, you can say with confidence that there is nothing more you can do. This confidence accelerates decision-making. In short, **Squeeze Out accelerates decision-making.**

---

# On Block Writing

**Answer:** Here we introduce a method of building topics using blocks.

In this section we introduce a writing method that is useful for nurturing topics. It starts with a simple approach called CBS and then expands into the idea of Block Writing.

## CBS (Consideration Breakdown Structure)

**Answer:** CBS is one method of divergent–convergent thinking that you can use when squeezing out your ideas. It is done using text plus bullet points.

(As explained in “Part 3 of Getting Started,” ETM is an intellectual production activity. By repeatedly diverging (generating ideas) and converging (organizing them), you try to extract the essence. In Part 3 we explained this as “expanding topics,” “refining them,” and “deriving conclusions.”)

There are many methods of intellectual production. Brainstorming in its casual sense is well known for divergence; other systematic methods include the KJ method. Some well-known techniques are freewriting, mind mapping, and the use of an infinite canvas tool like Miro. There are also trigger lists such as SCAMPER or Osborn’s checklist.

The CBS method described here is primarily a writing style. Its name is taken from WBS (Work Breakdown Structure), but unlike WBS you do not strive for a hierarchical exhaustiveness.

**CBS (Consideration Breakdown Structure)** means a method that supports intellectual production by breaking down and structuring your considerations as you write. The method is simple: you use the following format.

```
Write in a line-oriented manner as follows.
Use a 1-space indent for each level.

What CBS is:
 Consideration Breakdown Structure
 A method for breaking down and structuring your considerations to support intellectual production
 Merits:
  One of the few methods for intellectual production (lowers the barrier for intellectual work)
  Can be written quickly using only text on a text editor
   and can be applied to any note-taking tool
  It has a natural affinity with Scrapbox’s format and culture, so if you’re familiar with it, you can start using it right away
 Demerits:
  There is a learning curve to the world of line orientation, indentation, and text
  It does not use images or spatial elements (or rather, it avoids them), which may be inconvenient for those who think spatially
  It is more difficult than normal prose for others to read and understand
```

In general, you write like this:

```
(Consideration 1)
 (Details of Consideration 1)
 (More details of Consideration 1)
 …

(Consideration 2)
 (Details of Consideration 2)
 (More details of Consideration 2)
 …
```

By the way, **“Consideration”** here means “a chunk of information with a title.” Although it is intended to be something you have thought about and verbalized, it can also include a list of ideas, random thoughts, or even a collection of information gathered from others that you give a name to. The title may be just a short comment or an impression. However, it is important that there is always a title. You could temporarily leave it untitled if nothing comes to mind, but if you allow that then it will just become a storage place for information rather than a piece of intellectual production. Even if it is rough or brief, always try to give it a title in your own words.

Below is a further explanation of how to write using CBS.

You may use an indent of more than 1-space—for example, 2 spaces or more.

```
indent0 (This indicates one “consideration”)
 indent1
  indent2
   indent3
    indent4
     …
```

The indented lines under a line indicate a loose inclusion. You do not need to have a strict hierarchical or logical structure; you simply attach items that you subjectively feel are related. In short, it is just grouping.

```
Lines under an indent indicate a loose inclusion.
 (Content 1)
  The items indented under here are related to Content 1.
  Likewise, the items under here are related to Content 1.
  You can subdivide further:
  (Content a)
   This contains details about Content a.
   More details about Content a.
  This line is not part of Content a (though it is related to Content 1).
This line is not related to Content 1 (i.e. it is not under Content 1).
```

Next, regarding blank lines: Lines that are connected without blank lines are considered one “consideration block.” Therefore, if you have, for example, four considerations, they would be separated by three blank lines, forming four consideration blocks.

```
(Consideration 1)
 Details of Consideration 1…

(Consideration 2)
 Details of Consideration 2…

(Consideration 3)
 Details of Consideration 3…

(Consideration 4)
 Details of Consideration 4…
```

You can use more than two blank lines if you wish. You might even use separator lines (such as `---`) to distinguish different parts. For example, you might separate with two blank lines plus a separator line:

```
(Current considerations I’m working on)
 Details…

(Current considerations I’m working on)
 Details…

---


(Old considerations)
 Details…

(Old considerations)
 Details…

(Old considerations)
 Details…
```

**How you use blank lines and separator lines is a matter of personal taste.** However, if you are working with others (or even if you are the only one writing but it’s a note meant to be read by others), it is best to standardize the style.

The unit of a consideration block is completely flexible. You might first write a title with no indent at the left and then write the content below, or you might write a lot of lines and later decide that “this and that belong together” or “they say the same thing” or “this part is unclear so I’ll group it as unorganized.” You can also rearrange the order of blocks freely, and **the order does not matter at all.** If the order does have meaning, please state that explicitly. I sometimes add numbers in front of each block at the beginning, but note that it might be unclear whether the numbers mean “there are n items” or “the order matters.” Adjust as needed.

Below is an example of a typical way to write:

```
Summary
 I think the point is whether to dig deeper into Consideration 3 or not.
  1. In Consideration 4, after squeezing out ideas, Considerations 2 and 3 emerged.
  2. I tried to dig deeper into Consideration 3, but it turned out to be unpromising.
   Although I did not really stick around long enough to fully squeeze out all possibilities.
   I feel there might still be something there, but for now I’ve given up.
  3. It was confirmed by a paper that Consideration 2 was a dead end early on.
  4. In Consideration 1, I listed the voices of experts and stakeholders, but nothing novel emerged.


---


(Consideration 1)
 Details…

(Consideration 2)
 Details…

(Consideration 3)
 Details…

(Consideration 4)
 Details…
```

How does that sound? Looking at the “Summary” block, you can see how the flow between the various consideration blocks has progressed. Of course, the details of each consideration are explained in their respective blocks.

That is the explanation of CBS. There are various other detailed techniques, but the basic idea is simply to write out blocks (using a 1-space indented bullet list) separated by blank lines that denote each consideration block.

## Summary-Driven Approach

**Answer:** It is an exploratory style in which you periodically write a summary to “reset” the discussion.

One important point about CBS is that as you write more, the information can become unmanageable. To address that, you need to boldly summarize at some point. For example, at a natural break you can write a summary block such as “Based on all these consideration blocks, here’s what we can say.” Then, using that summary block as input, you start fresh with a new set of consideration blocks. Doesn’t that seem like an efficient way to regain control while moving forward?

In effect, it is simply the verbalization of your decision-making. Without doing this, the sheer volume of notes will become unmanageable and eventually collapse. This is something I mentioned in [Context Management](exploratory#context-management). Even if it is too much trouble to write a full summary block, at the very least you should write a brief list of key points (or maintain the context) so that when you resume later you can quickly recall the main ideas.

This process—periodically creating a summary block and then restarting using that summary as the input—is what I call a **Summary-Driven** approach. If “summary” sounds vague, think of it as a checkpoint or save point. In ETM this is an important concept. In order to overcome the cognitive limits and the overhead of context switching, even though it is a hassle, you must summarize and narrow down your information. As mentioned earlier, although we introduced CBS and other techniques, the most important thing is this Summary-Driven approach. If you can achieve something equivalent to this, the exact technique becomes less important.

## Writing from the Bottom Up

**Answer:** Although we usually write text from top to bottom, in CBS you can also place blocks in reverse order.

Normally, we write text from the top down, but in CBS you can also write from the bottom up. Here is an example where Consideration 1 is old and Consideration 3 is new, so the blocks are written in reverse order:

```
(Consideration 3)
 Details…

(Consideration 2)
 Details…

(Consideration 1)
 Details…
```

It may not feel intuitive at first, but it’s a matter of getting used to it. If you think of the order as being in “newest first” order, it doesn’t feel so odd. The main advantage is that you don’t have to scroll when writing, and when reading you can start with the conclusion or the latest status.

That said, you can also write from top to bottom. In other words, in CBS **there are two possible directions—top to bottom or bottom to top.** Usually the direction is apparent from the context, but sometimes it might be unclear. In such cases, the writer should add a note or design the note in such a way (for example, by numbering the consideration blocks) that the order is clear.

In an ideal world, **the direction in which you read the blocks shouldn’t be so important.** Block Writing is about arranging blocks to extract the essence; the order in which you read them isn’t as critical as the content of the summary and the way you mark the cycles.

---

# Block Writing

**Answer:** Block Writing is a generalization of the CBS method. It uses blocks not only for considerations and summaries but also for other purposes, making it more versatile.

The basic writing style and format of Block Writing are the same as those for CBS (so please refer to the CBS section above). Here we explain the various types of blocks that Block Writing supports.

First, let’s explain the system of block “letters” (or simply “letters”). In CBS, a line without any indent is typically just the title of a consideration or a result. But in Block Writing there are many types of blocks. Without knowing the type, it can be very hard for the reader later to keep track. To help with this, you can designate a block type by using a single letter. (For example, summary blocks are denoted by “s”, taken from Summary.) 

Here is a summary of the block types defined so far:

- **s:** Summary Block

Let’s now discuss the basic **ABCD blocks**. The letters stand for Action (tasks), Brast (brainstorming), Concept (concepts), and Direction (direction). 

In Block Writing, you first use a **Brainstorming Block** (b) to diverge your ideas. In this process you try to “squeeze out” as many ideas as possible. During this process you might also perform convergence if you can see a way to do so, or if you identify a theme you want to explore in depth, you may jump into a **Consideration Block** (k) later. You might not finish all the brainstorming in one go. For example, you might add to your brainstorming block five days later. However, since there is no definitive end, you should eventually decide where to cut it off.

As you diverge (and possibly converge), many insights emerge. If you feel that it would be beneficial to introduce a new concept or term, you can organize it using a **Concept Block** (c). Similarly, if you start to see an emerging direction or policy, use a **Direction Block** (d).

There is also a type of block for when you start to see actionable items: the Task Block. The letter “a” comes from Action, and here it refers to a list of tasks. These should be the items that are concretely actionable. You might even mark individual lines with a check mark (✅) to indicate completion, which is important for visualizing progress. At the same time, marking each item can be tedious, so how strictly you do it is a matter of personal preference.

Given all of the above, the flow of work is as follows. You cycle through divergent thinking (using b or k blocks) to generate ideas; then you flesh out those ideas using concept (c) or direction (d) blocks; once actionable items emerge, you write a task list in an a block; and finally, at a natural stopping point, you write a summary in an s block. This whole process constitutes one **cycle**. You may repeat the cycle as many times as you wish, and when you begin a new cycle, use only the previous cycle’s summary as the input. The idea is that you don’t need to look at every single block from the previous cycle; the summary should capture the essence.

Let’s summarize the block types:

- **Block Types:**
  - **s:** Summary Block (Summary)
  - ——
  - **a:** Task Block (Action)
  - **b:** Brainstorming Block (Brast, Brain Storming)
  - **c:** Concept Block (Concept)
  - **d:** Direction Block (Direction)
  - **k:** Consideration Block (from “Kento,” hence k)
- **Workflow:**
  - For one cycle:
    1. Use b or k blocks to diverge your ideas.
    2. Use c or d blocks to develop concepts or direction.
    3. When actionable items emerge, write a task list in an a block.
    4. At a natural stopping point, write an s block (summary).
  - You repeat the cycle as many times as you like, and when starting a new cycle, use the previous summary as input.
- **Other Notes:**
  - It is helpful to mark completed blocks with a check mark (✅) or similar indicator, though rigorous use is optional.
  - Using separators such as `---` or `===` to mark cycles can improve readability.
    - There is no strict requirement on the number of characters—between 1 and 4 is recommended.

## Customizing the Block Letters

**Answer:** You may add, change, or customize the letters (block types) as necessary.

Block Writing is very customizable. Essentially, it is just a matter of arranging various types of blocks; the ones described above are not exhaustive. If you find a new type of block useful, feel free to define it, and you may also change the letters if something suits you better.

For example, I personally do not use labels such as cx0, cx1, etc. for context blocks; I simply write the initial context in a block labeled cx. For the rest of the cycles I either incorporate the context into the summary or do not write it at all. As an engineer, when I need to think about “how to implement this,” I might use an Implementation Block (i) or even a Title Block (t) to name a cycle. Of course, you might decide that using “a” for a task block is too confusing and change it to “t.” The key is that if you are working with others, everyone should agree on the same system. Creating and maintaining a “list of letters” note is very useful.

## Writing from the Bottom Up, Part 2

**Answer:** In Block Writing, as in CBS, you can also write blocks in reverse order.

As mentioned earlier in the section “Writing from the Bottom Up in CBS,” in Block Writing it is also common to order blocks from bottom up, and the direction might vary from cycle to cycle. For example:

```
cx1
 Cycle 2: “I’ve done two cycles and I’m running out of time so I want to decide in the next one.”

---

s
 [Summary of Cycle 2]
 ...

k
 [Consideration/Comment area]
 ...

b
 [Brainstorming]
 ...

---

cx0
 [Context for Cycle 1]
 ...

b
 [Brainstorming]
 ...

k
 [Consideration]
 ...

k
 [Another Consideration]
 ...

s
 [Summary]
 ...
```

This structure can be read as follows:

```
Cycle 3

---

Cycle 2

---

Cycle 1
```

Also note that in Cycle 1 the blocks are written top-to-bottom (context → brainstorming → consideration → consideration → summary), while in Cycle 2 the blocks are written bottom-to-top (brainstorming → consideration → summary). This is merely one example. In reality, everyone has their own style. If the change in direction makes reading difficult, add a short note to clarify.

Ideally, **the direction in which you read shouldn’t be too important.** Block Writing is all about using blocks to extract the essence; the reading order is only a matter of convenience when writing or reading.

---

# Personal Versus Collaborative Boundaries

**Answer:** When multiple people engage in ETM, it is important not to trample on each other’s writing. Here’s how to respect individual contributions.

## Topics Should Be Created by Individuals

**Answer:** When multiple people work on ETM, one person should initially create the topic and then share it with the others.

When working with multiple people on ETM, it is best for one person to take the initiative to create the topic. In traditional models you might start by discussing and collaboratively creating a topic, but discard that idea here. Instead, one person should create a topic and then have others review it. (Even in the early “Topic” stage of the 3T model, this principle holds.) The reason is that a topic often has no single “correct” answer, and if you try to collaborate from the very beginning you may end up with conflict. It is better for one person to create something tangible first and then let others modify it as needed.

For example, suppose person A creates topic T1 and person B does not like it. In a traditional model you might debate or edit T1 directly, but in ETM person B should create a new topic T2 and show it to person A. Then person A, rather than directly editing T2, revises T1. In this way, **everyone’s individual domain is respected** while still allowing reference and feedback. In this example the domain unit is the topic, but the same applies at the level of blocks or even individual lines.

## Personal Space

**Answer:** The individual’s area of contribution is called their personal space. Respecting personal space across several layers helps maintain a comfortable collaborative environment.

Personal space refers to each individual’s domain of contribution. There are several layers:

| Layer | Name        |
| ----- | ----------- |
| 4     | Venue       |
| 3     | Topic       |
| 2     | Block       |
| 1     | Line        |

In the previous section we discussed topics (layer 3) as an example. But there can also be larger domains (layer 4 “venue”) or smaller units (blocks or lines).

**Respecting each person’s personal space is crucial for maintaining ETM.** If personal space is not respected, the writing process becomes stifled and eventually turns into a mere formality.

That said, it is not possible to perfectly respect each other’s personal space from the start. In practice, you will work out the boundaries as you engage in ETM. For instance, person A might prefer a wide personal space while person B’s space is narrow. Such tendencies vary among individuals and across teams. Either implicitly or by writing up guidelines, you need to negotiate these differences. In my experience, Japanese culture tends to be high-context—people often “endure in silence” or “ignore” issues—so frank discussion is advisable. Otherwise, those who prefer more personal space may end up not contributing much, or conversely, those who freely write might dominate, causing problems like those described in [“Topics Should Be Created by Individuals”](#topics-should-be-created-by-individuals).

---

## The Layers of Personal Space

Let’s look at each layer.

| Layer | Name        |
| ----- | ----------- |
| 4     | Venue       |
| 3     | Topic       |
| 2     | Block       |
| 1     | Line        |

### Layer 4: Venue

This is the overall space where one conducts ETM individually.

For example, when multiple people work together in a main venue, each person might also create a personal venue for themselves (or for regular use). Such personal venues are typically private, although they can be shared with the group. 

In ETM, using personal venues is not recommended. When you’re doing ETM, you should write in the main venue. If each person writes in their own separate venue, ETM cannot really function properly.

The main purposes of a personal venue are as follows:

- To write content that is too personal or irrelevant to others in the main venue
  - Such as personal notes or fragments of thought that others would not understand
  - Sensitive personal information
  - Rough drafts or memos that are only useful as personal reminders
- To serve as your personal channel of expression
  - Just as blogs are used for public expression, some people choose to publish their personal ETM
  - This is sometimes seen in the Scrapbox community (see note below)
    - The best example might be [Helpfeel’s partially public Cosense], though in that case ETM isn’t the focus but rather communication/knowledge sharing.

In any case, others are not expected to read these personal venues. At a minimum, you should link from the main venue.

- *Notes:*
  - 1. A good example from this context is [Helpfeel’s Cosense support page “Avoid Writing Comments Under Your Own Icon”](https://scrapbox.io/support-doc-jp/%E8%87%AA%E5%88%86%E3%81%AE%E3%82%A2%E3%82%A4%E3%82%B3%E3%83%B3%E3%82%92%E4%B8%AD%E5%BF%83%E3%81%AB%E3%82%B3%E3%83%A1%E3%83%B3%E3%83%88%E3%82%92%E6%9B%B8%E3%81%8F%E3%81%AE%E3%82%92%E9%81%BF%E3%81%91%E3%82%8B). Scrapbox’s culture, where you place your own icon and then hang your notes beneath it, emphasizes personal space—but this can hinder the growth of shared knowledge.
  - 2. Do not count ordinary blogs or memos as ETM. Only count those that share the exploratory process or similar approaches. As of August 2024, such examples are rare in Scrapbox (though they may exist in other note tools like Obsidian, where people perform ETM and publish it via static sites or GitHub).

### Layer 3: Topic

This is the layer that appears most frequently in ETM. (See [Topics Should Be Created by Individuals](#topics-should-be-created-by-individuals) for details.)

### Layer 2: Block

This is probably the most frequent layer in ETM. In a single topic (i.e. a note) there may be personal spaces contributed by multiple people. In other words, you have a “block” of person A, then a block of person B, then another block of person A, etc.

Since everyone writes freely, it is easy to end up with a collection of personal spaces that don’t contribute to progress. In ETM you want to make decisions, so that outcome is undesirable. One countermeasure is the “Target Management (3T Model)” described earlier in [Target Management](exploratory#target-management), but another solution is to create Public Spaces.

Below is a brief explanation of Public Space and Nameplates.

---

## Public Space

**Public Space** is exactly what it sounds like—a shared space where anyone can contribute. Unlike personal space, no one can claim ownership over public space. It is a shared resource in which everyone writes objectively, removing personal details or extraneous information to create concise, useful knowledge (see note below). In a topic you will typically see both blocks that are personal in nature and blocks that serve as public space. With this hybrid strategy, you can combine the benefits of personal and public spaces.

- *Note:*  
  A good illustration of this discussion is again found in Scrapbox—for example, [“Avoid Writing Comments Under Your Own Icon” by shokai](https://scrapbox.io/shokai/WOM(Write_Only_Member)). In Scrapbox, while personal spaces are created by placing your own icon and hanging your comments underneath, that setup can lead to notes that do not grow into shared knowledge.

### Nameplates

When asserting personal space at the block level or even at the line level, you need a way to indicate who is contributing. These identifying symbols or images are called **Nameplates**.

Without a nameplate, it is difficult to tell whose block is whose. Traditionally you might write something like “(Yoshirano Sta)” to indicate a name, but that is both laborious and hard to read.

A good example is Scrapbox’s icon notation. By pressing Ctrl + i, you can insert your own avatar image as an icon.

If you do not have such a feature, you can substitute with an emoji. For instance, I often use the bunny emoji (🐰). Since I use it frequently, I have it in my text expansion dictionary (I register “usa” for it). The exact emoji is up to you, but be sure it clearly indicates the contributor. Until you get used to it, it may be helpful to create a note that explains the system. (Changing it later is a hassle, so choose something you’re likely to stick with.)

Nameplates can be used at the block level as well as the line level. Below is an example for a topic called “What is Brainstorming?”:

```
There is a discrepancy in the meaning of the word “brainstorming.”
I’d like to hear everyone’s opinions.

🐰
 I think it simply means “idea generation.”
 It doesn’t matter whether it’s done individually or in a group.
  However, I personally think that group brainstorming is nearly impossible at this point—
   🐴 I’m curious why 🐴 thinks group brainstorming is too early.
   🐰 On my side → [Brainstorming is too early for humanity]

🐴
 Isn’t it a method devised by Osborn for meetings?
 [The origins of brainstorming]

🐼
 Group brainstorming done face-to-face.
```

In the block layer above, there are nameplates for three people. In the personal space of 🐰, note that one line is marked with 🐴—indicating that although it appears in 🐰’s block, that particular line belongs to 🐴.

### Layer 1: Line

Returning to the discussion of layers: the line layer is the personal space that is defined on a per-line basis.

Specifically, there are single-line and multi-line personal spaces. In the example above, the line that starts with 🐴 (“I’m curious why...”) is a single-line personal space. If the following line is indented beneath it, it remains part of 🐴’s personal space. In this way, 🐴 does not need to add a nameplate on every single line; subsequent indented lines automatically belong to 🐴. However, contributors other than 🐴 should add a nameplate to indicate that the line is theirs (otherwise it might look as if 🐴 said it).

---

# Make Decisions in Public Space

**Answer:** If everything is in personal space, the discussion can become disjointed. Therefore, create a Public Space to consolidate decisions.

ETM involves handling many topics, but without making decisions the process will never converge. If everything remains in personal space, everyone will simply post their own opinions and nothing further happens. In that case, you need to create a Public Space in which you (even if provisionally) settle on a decision. That is, you decide “this is the option we are going with” for that topic.

Alternatively, you can use the 3T Model (as described earlier in [Target Management](exploratory#target-management)) to designate the “stakeholders” or the topic owner. However, if a topic is completely personal it becomes harder for others to engage, so please make sure that when it’s turned into a decision the note is written in a way that is easy for everyone to read.

Of course, it is unrealistic to require that every topic reach a decision. In topics that are just for general discussion or chitchat, it is common to see only personal spaces.

---

# Balancing the Individual and the Collective

**Answer:** Here are some hints on how to balance respect for individual contributions with overall coherence.

When multiple people participate in ETM, it is important to respect each person’s individuality. Differences in style and ideas should be tolerated. If you don’t like someone’s way of doing things, don’t try to change it directly; instead, write up your own ideas and share them, or simply let it pass. On the other hand, as mentioned earlier in [Public Space](#public-space), sometimes a decision needs to be made so that everyone aligns. Here are some hints on striking that balance.

## Interest-Driven

**Answer:** Acting based on your own interests makes it easier to coexist naturally.

In everyday work or life you might have to deal with things you are not interested in or even dislike (duty-driven), but that is not ideal in ETM. ETM is meant to be a playful process in which each person leaves behind topics as they explore freely. There is no need for the kind of endurance normally required by obligations.

You might wonder if this will still allow coherence. It surprisingly works well because the topics that are important or interesting will naturally gain traction. In this sense, it is best to be **interest-driven.** Even if most topics end up being solitary or garnering only one or two reactions, that’s fine. As the saying goes, “One success is built on a hundred failures.” Underneath every great idea there may be dozens or hundreds of lonely topics.

After all, if you are not driven by interest, you won’t have the motivation or energy to continue. ETM is an exploratory, inherently lonely process without a single “correct” answer. In contrast, even if you are duty-driven in a goal-oriented approach, you can bear tasks you are not interested in because there is a right answer to be found. ETM lacks that guarantee.

## Attracting Interest

**Answer:** When you want others to read or comment on your note, do not use orders or commands. Instead, write in a way that naturally draws interest.

There will be times when you want others to read your note or comment on it, but ETM does not allow you to force people with mentions or orders. Even so, there are occasions when you really want others’ input. In such cases, you need to boost the chance that they will notice by making your writing attractive. There are various ways to do this. Here are a few examples:

- Introduce the topic along a “flow” such as a [date topic](#date-topic) for casual discussion.
- Use techniques like the “eye-catch” and “excitement” described in the [Literary Task Management chapter](literate#eye-catch-and-excitement).
- Name the topic in a plain and catchy way.
- Use a popular topic T1 to introduce another topic T2 that you want people to check out.
  - Don’t be too forceful; rather, indicate that T2 naturally solves a problem discussed in T1.
- Use a “give and take” approach:
  - Help out others by supporting their considerations or adding comments; they will be more inclined to help you.
  - Information tends to cluster around those who share it. If you contribute generously, your presence increases and others will notice you more.
  - However, be careful not to overextend yourself so that you remain interest-driven.

The point is to find a way to appeal to others. Many people already have techniques from work or hobbies; feel free to use them. In ETM, other participants are both colleagues and early adopters.

## Allowing “Passing Over”

**Answer:** Do not force yourself to add reactions or replies if you don’t feel like it.

In traditional communication you might feel obligated to reply with thanks or a greeting. But in ETM, where information is simply laid out, such reactions do not feel natural. Even if you consciously try to do so (or if you are especially considerate), you might find that you end up writing less overall—and that is perfectly acceptable. In fact, such reactions add little information and can even be noisy.

A good guideline is to **allow “passing over.”** In other words, if you do not feel like reacting, simply let it go. In chat applications, “read but not replied” is often frowned upon and can lead to fatigue, but that does not apply in ETM. In short, **do not assume that everyone will react.**

This is not to say that no one should react. If someone wants to or does so automatically, that is fine. Naturally you may see some people who always say thank you, some who do it occasionally, and some who almost never do. People who do it a lot might find those who rarely do it off-putting, and vice versa, but allow for individual differences. ETM does not require you to become close friends or form deep relationships. The goal is simply to write topics collaboratively and extract a conclusion—and that is enough. And if it’s fun, mutual respect and coexistence will follow.

## “Otaku Warning”

**Answer:** Although freedom is paramount, refrain from sharing a flood of content that only interests you.

In ETM, each person writes topics freely, and sometimes even engages in casual conversation. In this relaxed environment, it sometimes happens that one person dumps an overwhelming amount of content (much like an otaku raving at a rapid pace). For instance, you might suddenly create 20 topics, one for each book, piece of music, or film you like. I call this **“dumping”** or “racking off.” 

Dumping is noisy and should be avoided. Even if the ETM venue is a networked note system and passing over is allowed, there is still a limit. Often the venue displays a list of topics or a view filtered by recent updates—and if one person dumps a lot, it can clutter these views. A long list of dumped content may result.

If you really want to dump a lot of content, create a dedicated topic such as “Movies: My Recommendations” and then post everything there. That way only one topic is used and it won’t be noisy. If you feel the urge to create a separate topic for each work (or even each memorable scene or sentence), wait until that specific moment rather than dumping them all at once. In short, know your limits.

Of course, the exact line depends on the team or situation, so discuss it if needed. The goal is to avoid situations where someone’s dump becomes so overwhelming that others feel “I can’t stand A’s dumping” or “I’m too afraid to say anything about it.” If left unchecked, dumping degrades the quality of the venue. Each person should simply bookmark what they like; the venue is not a showcase. ETM’s venue is not meant to be an exhibition hall. For further discussion on this, see shokai’s page [WOM (Write Only Member) - Hashimoto Shokai](https://scrapbox.io/shokai/WOM(Write_Only_Member)).

## Explicit Negative Responses

**Answer:** When a topic requires responses from everyone and you are not inclined to reply, explicitly state that you won’t or can’t respond.

In ETM, everyone is free to work as they wish and ETM does not expect individual, direct communications. Nevertheless, there are times when topics converge or when issues that affect everyone arise (for instance, in business situations where everyone must see the information). At such times, you might need input from all (or most) members. I call this waiting for responses a **“wait.”**

In ETM you should aim to have as little waiting as possible. (Note 1) In practice, if everyone is acting autonomously, responses should come quickly—if someone consistently does not reply, perhaps they are not suited to the team (see [Members](exploratory#members)). Still, sometimes responses do not come, especially when a topic is negative rather than positive. In those cases, you can use an **Explicit Negative** response, for example writing “No” or “I’m not interested” or “I don’t care enough to respond.” Although negative responses are culturally hard to give in Japan, if waiting drags on it burdens everyone, it is better to express your negative response explicitly. If doing so causes problems, that issue can be discussed separately—perhaps in its own topic.

Waiting is generally caused by members who are too lazy to respond. Allowing such laziness means that someone always ends up having to follow up, which is unacceptable. Since the reluctance to give negative feedback is a major cause of such laziness, explicitly stating your negative response can resolve the problem. It might feel awkward at first, but it’s important to overcome the downsides of waiting.

- *Note:*  
  1. Ideally, waiting should not happen at all. If it happens frequently, the topic might be unsuitable for ETM (e.g. you might be over-directing others) or perhaps the topic itself is not appropriate for ETM. In corporate settings, for topics that affect everyone, consider covering them through other means. For instance, if you set aside a three‑week exploration period (assuming an 8‑hour workday), you might designate 7.5 hours for exploration and 0.5 hours for company duties. However, such arrangements can quickly lead to issues like “Let’s have a 30‑minute meeting every day at 16:30” or “This is a regular meeting; during this time please don’t answer calls or mentions.” In effect, part of your exploration time is being encroached upon. Moreover, if meetings are held unnecessarily, issues that should be discussed in ETM are moved to the meeting room, and if those discussions are not fed back into the main venue, ETM loses its meaning. As mentioned earlier in [Scope and Exploration Period](exploratory#scope-and-exploration-period), **the exploration period/time is a sacred zone that must not be encroached upon.**

## Roles and Their Use

**Answer:** Each member has different strengths and weaknesses, so define these as “roles.”

In ETM you will often see people naturally assume different roles. A role represents a strength or area of expertise and is usually indicated by a label. Some examples of roles are:

- **Brester:** Someone who is good at generating ideas (divergence).
- **Summarizer:** Someone who is good at summarizing and distilling divergent ideas.
  - If you wish to separate summarization and distillation, you might have a “Summarizer” and a “Distiller.”
- **Linter:** Someone who points out or corrects improper writing or format according to the rules or culture of the venue.
- **Linker:** Someone who, when seeing a topic, can suggest related topics.
- **Decision Maker:** The person who makes the final decision—usually a CEO or manager.
- **Sticker:** Someone who writes harsh but direct comments.
- **Trickster:** Someone who writes in a uniquely unconventional way that others cannot imitate.
- **Reminder:** Someone who nudges others when responses are slow or when progress lags.

For example, person A might naturally take on the roles of Brester (good at divergence) and Linker (good at connecting ideas), person B might be a Trickster, and person C might serve as both Linker and Linter. The idea is not to force everyone to act strictly by their roles but to allow each person to contribute in areas where they are strong. It is also helpful if roles are clearly defined. Roles are dynamic by nature. While some teams may keep roles fixed, in many cases roles change with circumstances or mood (this is what I refer to as **Dynamic Roles**). Some teams even randomly assign roles. Think of roles as “hats” that say “X role” which members may choose to wear for a period. Once you see someone wearing a particular “hat,” you know that “Oh, right now A is acting as a Brester.” Just put on the hat and play the role. However, be careful not to lean on a role too much and become complacent—for example, linters and linkers might be tempted to rely on their roles to avoid doing any real work.

Note that this discussion is not the same as taking a personality test like the [StrengthsFinder](ref#18) or [MBTI](https://www.16personalities.com/ja/%E6%A0%BC%E8%A8%BA%E6%96%AD%E3%83%86%E3%82%B9%E3%83%88); roles in ETM are not strictly determined by aptitude. It is natural for someone to take on a role they are good at, but in ETM you might temporarily take on a role you’re not comfortable with, or try something you’re not interested in. In some cases, roles may even be assigned at random. In effect, roles are like “hats” labeled with “Role X” that anyone can put on, regardless of whether they are naturally suited to it.

...
