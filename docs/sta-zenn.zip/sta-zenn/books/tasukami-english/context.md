---
title: Context(1/2)
---

One of the inescapable polysemous terms in task management is **context**. In this chapter, we will take an in‐depth look at context.

# Overview of Context

## Context
**Context** literally means “the surrounding circumstances” or “situation” and refers to the peripheral conditions or ancillary information associated with a given scenario or subject. It is an extremely polysemous term, and in some fields there are distinct definitions.

In task management there is no strict definition; rather, it is used in several nuances. In the broad sense, you can understand it simply as the definition above—the surrounding conditions or ancillary information linked to a task. We will discuss the specifics of each nuance later, as diving in now would only make things unnecessarily complicated. For now, please bear with me through this conceptual discussion.

One thing we can say for certain is that a task is not so simple that you can just look at it and say, “Alright, I’ll do it.” Without a sense of conviction, you won’t feel motivated to act, and you also want to be able to decide whether it is best to do it now or later. In order to gain that conviction and to have hints for making a decision, you need to understand the context.

If you wish to escape being “a machine that merely completes tasks in front of you,” then instead of simply checking off tasks one after another, you need to understand their context and plan your approach accordingly.

## The Importance of Understanding Context

### What Happens When You Ignore Context
Let me suddenly list a few phenomena that occur when context is ignored:

- **1: In Q&A sessions or during discussions, you may not receive a direct answer.**  
  - Instead, you might be met with a question in return or be subjected to unsolicited pedantic explanations.
- **2: If you give someone careless advice, they will find it off-putting.**
- **3: When you offer advice in a consultation, the other person may not follow it obediently.**
- **4: Even if your argument is logically sound, it won’t necessarily be accepted—and often, it won’t.**

All of these phenomena occur precisely because the context is being ignored.

> **1: In Q&A sessions or during discussions, you may not receive a direct answer.**  
> The answerer, in order to understand the questioner’s context, may provide a roundabout answer. Alternatively, they may suspect that the questioner’s context is off in some way and attempt to correct it. This often happens when a beginner asks a question to an expert.

> **2: If you give someone careless advice, they will find it off-putting.**  
>  
> **3: When you offer advice in a consultation, the other person may not follow it obediently.**  
>  
> For both 2 and 3, the person receiving the advice has various circumstances, constraints, and emotions of their own; advice on its own is not very useful. In a sense, the advisor is either ignoring or completely missing the point of the recipient’s context.

This generalizes to point 4:

> **4: Even if your argument is logically sound, it won’t necessarily be accepted—and often, it won’t.**  
> In other words, “the truth doesn’t always prevail.” Even if your words are objectively correct or reasonable, they are often of little use because they disregard the personal context of the listener. In fact, the listener might even feel, “I already know that,” “I have my own issues,” or “What do you know about me?” This not only renders the advice ineffective but may even backfire.

The same is true in task management. Ignoring context when simply checking off tasks is like blindly following advice without understanding the situation. Of course, for tasks that are absolutely necessary—those that must be done regardless—you simply do them (and sometimes there are situations in work where you have no choice but to act immediately). However, most tasks allow some room for choice or judgment, and they ideally should. If there is no room to maneuver in the medium or long term, it would only lead to exploitation or overwork. It may not be “a bad way to live” per se, but it is a world with significant variations in suitability.

Without knowing the context, you lose your ability to choose or judge. Conversely, once you know the context, possibilities open up. It may not be possible to know everything, nor does knowing it guarantee that everything will work out—but the difference between not attempting to understand and trying to do so is enormous.

### The Everyday Pursuit of Knowing Context
For example, both consulting and counseling aim to understand the client’s context. In consulting, the focus is on grasping the context of the client’s company through data and numbers. In counseling, the goal is to build a trusting relationship so that the patient willingly shares information. Similarly, activities like interviewing for a new business venture, conducting surveys, or engaging in co-creation all aim to grasp the stakeholder’s context. Whether it’s a client or any other stakeholder, each has its own context, and understanding it can change how you structure your ideas or business. Even managers and team members, day by day, are constantly navigating the different contexts of those around them.

Though “context” might sound abstract or complicated, it is actually a very familiar and everyday concept. If “context” seems too opaque, you can think of it as circumstances or background information.

### Knowing Context So You Won’t Get Cut Off
Although understanding context is an everyday activity, there is one common challenge:

It is hard to experiment with understanding someone’s context. Those who program or play games might enjoy experimenting freely, but in work situations involving people, experimentation is often not an option because **you can’t afford to experiment on people**.

People have emotions, and especially in work environments, opportunities to experiment are rare. Many people struggle just to set up a single meeting. Given that people have emotions but few opportunities, the first impression you make is crucial. If you don’t succeed the first time (at least to some extent), you might not be given a second chance. In order to overcome this harsh reality, you need to prepare thoroughly beforehand to increase your chances of success. There are many types of preparation—for example, [projecting proper etiquette](https://www.businessinsider.jp/post-170499)—but in this chapter we deal with context itself. By knowing and respecting the context, you can greatly increase your chance of success (or more accurately, decrease the chance of obvious failure).

Whether in society or in personal relationships, most of our lives are played out in this harsh game. People who navigate life skillfully invariably do so by understanding context. While it is sometimes possible to succeed by disregarding context and relying solely on one’s performance, such cases are rare and should not be relied upon. In short, ignoring context is extremely disadvantageous.

I also believe that one reason why groups are often slow to act or make decisions is that people need time to understand the context. A relationship where everyone speaks frankly and acts immediately without considering context is merely an illusion—it only works in special cases such as small teams with very high psychological safety or among individuals with developmental disabilities. That is, a “grace period for context understanding” is necessary. The cultural characteristics of high-context versus low-context societies come down to how that grace period is spent. In high-context cultures, people are expected to “read between the lines,” whereas in low-context cultures, you are expected to “say it clearly.” In either case, there must be enough time to either infer or communicate clearly.

To summarize:

- When dealing with people, you cannot simply experiment with their context.
- To avoid failure, you must get it right the first time.
  - And to make that decision, you need to have context—so you need to know it.
- I hypothesize that there is always some margin available to gather context.
  - This is why group decision-making is often slow.
  - On the other hand, if conditions are special, one can avoid getting bogged down.
    - (Although not mentioned in the main text, there are other methods—for example, in a strict military environment.)

## Dynamic vs. Static Context
Having explained the importance of knowing context, let’s now discuss its connection with task management—especially by noting that there are different types.

In task management, context can be broadly divided into two types: dynamic and static.

### Dynamic Context
**Dynamic context** refers to the current situation.

For example, if you spend an hour preparing a document and then take a break, your mind still retains various details about that document. You remember what you did, perhaps think “I had to cut corners there,” or “I’ll continue from here next time,” or “I need to refine certain parts.” These are all aspects of the context generated or changed by doing the work. You want to keep them in mind. If you resume work immediately after your break, that’s ideal—but if you get busy and resume days later, it can be a disaster. Much of the context may be lost, forcing you to start over from scratch, which can lead to an inconsistent document if you force it.

Furthermore, when working with others—especially in hectic environments where the “situation” is constantly changing—every action by someone alters the situation. In such environments, you must be fully immersed on the spot, unable to make careful adjustments or provide detailed follow-ups. In other words, in such dynamic settings, you have no choice but to remain on site, which can often be exhausting.

This kind of context, which changes every time you interact or continuously shifts, is what we call dynamic context.

### Static Context
**Static context** refers to the ancillary information or attributes that do not change as rapidly as dynamic context. You might also call these attributes.

For instance, a person’s feelings, beliefs, lifestyle constraints, sexual orientation, or other characteristics are (to some extent) static context. You might say that feelings change dynamically, but here we consider the core aspects to be relatively unchanging—their manner of expression may change, but the underlying characteristics remain. While persuasion, coercion, or even indoctrination can sometimes change these factors, they are generally not as dynamic.

Tasks, too, have static context attached to them. Take a document-preparation task, for example. There is context regarding why it is needed, the background behind it, who will see the document, when it can be prepared, where it should be done, and so on.

Here is one concrete example:

- “Our department’s business is slowly declining; therefore, we need to explore new ventures.”
- “This is also the directive of our executives, and a corresponding budget has been allocated.”
- “In our department, all proposals must be reviewed by the executives.”
- “Since our compliance is in order, you can only work on this during office hours.”
- “Although the work can be done remotely, company policy forbids working in cafés or similar settings.”

And here is an example regarding the context of the worker:

- “I enjoy coming up with new ideas and talking with people.”
- “I don’t find it interesting or suitable for me to work as an operator or manager in the existing business, so I want to explore new opportunities.”
- “I have a child and have bought a house, so I need to earn more money and get promoted.”
- “But as long as I remain in this department, I cannot avoid the scrutiny of the executives—and they tend to base decisions more on trust than on content. I believe it is a waste of time and effort to tailor explanations and considerations for executives who have neither the time nor the knowledge.”
- “I’d ideally like to change jobs, and I’ve been casually looking, but nothing has come up. The overall conditions of the company aren’t bad, so I feel that for now, I should master the role and do my best.”

How is that? When you consider the task of preparing a document alongside all this context—both at the individual and department level—the approach you take will be very different compared to having no context at all. If the context matches well for both you and your department, you will be more motivated to “really do your best.” On the other hand, if either the department or you lack that motivation, then even if you try hard, it may only result in a half-hearted performance, prompting you to either cut corners or decide not to do it again in the future. With context in hand, you can make such decisions more wisely.

...
