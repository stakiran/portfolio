---
title: Project Task Management(1/3)
---

Although this book deals with personal task management, we will briefly cover the remaining two types—project task management and partner task management.

In this chapter I will succinctly outline the essence of project task management. I will not cover frameworks like the PMBOK, explain various project management tools, or introduce any quick-fix techniques. This discussion is organized from my perspective as someone attempting to systematize personal task management. I hope that readers will gain insights and useful hints.

# The 3A’s of Project Task Management

I believe the essence of project task management can be expressed by the three A’s:

| English   | Keyword    | Explanation                           |
| --------- | ---------- | ------------------------------------- |
| Assign    | アサイン   | The act of assigning tasks to people  |
| Adjust    | 調整       | Changing the attribute values of tasks |
| Alternate | 全体と詳細 | Alternating between a holistic view of all tasks (macro view) and a focused view of individual tasks (micro view) |

## Assign / アサイン

This refers to assigning tasks to people.

Because project task management involves multiple team members, there is always the need to decide **who will be assigned which task**. An assignment is a kind of promise; for example, assigning task T to person A means you are “charging” A with the responsibility to carry out task T diligently. Why do we do this? Because without assignments, progress will stall. People are prone to forgetting, getting confused, or slacking off—and in a group, factors such as politeness or cut corners may also come into play. Without deliberate management, things will simply not get done.

On the other hand, in recent years a “management‐less” trend has emerged. You may have heard claims like “We don’t need managers” or “We have abolished middle management.” The idea is that if people can work autonomously and simply get their tasks done, there is no need for someone to “manage” them. However, it is not as simple as it sounds—assignments are already embedded in company rules, processes, and even contracts (managers are, after all, paid to manage). Most workers have become accustomed to being managed, and few have the motivation to work entirely autonomously. For now the management‐less approach remains a minority method and is unlikely to become mainstream in the coming decades.

Even in management‐less environments, task management tools are still used. (This ties in with the “Alternate” section below.) In order to share the situation with others, you must eventually input data into a tool; otherwise you have to ask people one by one—and that interrupts work. In fact, merely holding meetings to “hear the status” is itself a form of management. In a way, even meetings are a kind of task—and during meetings assignments are being made. So “management‐less” isn’t as “management‐less” as it might seem.

Nowadays there is even a trend of abandoning input into a tool altogether. Such organizations are sometimes called “teal organizations.” Teal organizations are characterized by having [minimal unnecessary processes, high employee discretion, high psychological safety, and extremely frequent communication](ref#5) (even if not stated explicitly, that is how I see it). Many people hold the mental model “if something’s wrong, just ask about it,” but in practice various constraints and busyness prevent that. Teal organizations are designed precisely so that this is possible. There are various examples, but at its core the model is strikingly similar to a startup company founded by a handful of people—where everyone can focus solely on the business without unnecessary constraints or interruptions and can consult each other freely. The challenge is to scale that feeling and maintain it as the organization grows.

## Adjust / 調整

Here, **“adjust” means changing the attribute values of a task.**

An attribute is a characteristic a task possesses. For example, attributes include:

- Name
- Status (Not Started / In Progress / Complete / Cancelled, etc.)
- Assignee
- Deadline
- Start Date
- Priority (High/Medium/Low, or on a 1–5 scale)
- Time Spent (often referred to as “man‐hours”)
- Comments

In systematic terms, project task management is the practice of changing these attribute values as circumstances evolve. Consider the following example in which we modify the attributes of a task T. (In reality, many—if not countless—tasks exist.)

| Progress | Event                                         | . | Name | Assignee | Status     | Priority | Deadline    | Comments                          |
| -------- | --------------------------------------------- | - | ---- | -------- | ---------- | -------- | ----------- | --------------------------------- |
| 1        | Create new task T                             | . | T    |          |            |          |             |                                   |
| 2        | Assign person A to task T                     | . | T    | A        |            |          |             |                                   |
| 3        | Task T is started                             | . | T    | A        | In Progress|          |             |                                   |
| 4        | It is determined not to be urgent             | . | T    | A        | In Progress|          |             | “No deadline, so pending”         |
| 5        | Situation changes—becomes urgent              | . | T    | A        | In Progress| High     | 2024/05/09  | ~~“No deadline, so pending”~~     |

As you can see, the attribute values change in response to events—but they do not change on their own. It is up to us to change them deliberately. Even if we do not use a tool, we perform the same mental adjustments. However, keeping such adjustments only in one’s head is unreliable; it requires conversations to extract the correct information, and differences in individual interpretations of what constitutes a task and what attributes it should have can lead to conflicts. Recording the results of adjustments is essential—and for that, a tool is indispensable. In project task management, tools are essential.

What is particularly troublesome is that **adjustments occur very frequently.** Projects are by nature full of irregularities, and even in simply busy circumstances the number of adjustments increases. Once tasks have been input into a tool, you cannot simply “set it and forget it”—new tasks are added and existing tasks disappear at any time. If you cannot reflect all these changes in the tool, the details remain only in each person’s mind. As a result, you end up having to hold meetings to “hear the status” again—and because each person may have a different view of what constitutes a task or its attributes, discrepancies arise, consuming time and energy. Projects tend to become overwhelming primarily because the tool does not accurately reflect the changes.

There are currently two ways to cope with “the frequent failure to update the tool due to frequent adjustments.” One is simply to be meticulous about updating the tool—but in reality, most people do not have the time or skill to do that. The other is to sink into a **Reactive Situation.** A Reactive Situation is one in which you simply react immediately to whatever happens. In a hectic world, this is often the default. In a Reactive Situation, adjustments (and the corresponding updates to the tool) cannot keep pace; you can only react spontaneously to what you see. In effect, task management fails. Conversely, one might say that you no longer have to engage in the cumbersome business of task management. That is why many people prefer a Reactive Situation. It is also why projects often become unnecessarily busy.

## Alternate / 俯瞰と注視

This refers to the act of alternating between an overall (holistic) view of all tasks and a detailed view of a specific task.

“Alternate” here means “to switch back and forth” (see note [1]). There are many similar phrases such as “seeing the forest and the trees,” “bottom-up vs. top-down,” “the whole vs. the details,” etc. Although almost everyone in modern society is familiar with this concept, it also appears in project task management.

- *Note 1: “Alternating” does not mean an even 50/50 split; it might be 20/80, 5/95, etc. The optimal balance depends on the situation and the individuals involved. The important thing is that you must view both the overall situation and the details.*

### Macro (Holistic) View

In any workplace there may be a vast—or even uncountable—number of tasks that interconnect organically. They are often organized hierarchically, but sometimes they form a network similar to human relationships or geographic routes. Tasks do not necessarily become visible in their entirety from the start; rather, they are broken down from a larger goal. What is important is not each individual task, but the overall tapestry they weave. Can the goal be reached? How far are we from it? Is there any point where things look “in trouble?” Such a broad perspective is only possible if you can see the relationships among all the tasks.

How do you achieve that? You need to somehow display all the tasks. You might list them (even arranged hierarchically), embed them in a table, or display them as cards on a Kanban board. In the case of personal task management, one might simply spread them out on a desk or desktop. But in project task management, where multiple people must see the tasks, the arrangement is usually more orderly. (There are exceptions—for example, in a loosely managed analog workplace or in triage in a medical setting, where tasks are represented by physical items such as people—but such cases are less common.) In any event, the goal is to arrange tasks so that you can get an overall view.

In digital tools there are mechanisms that make a holistic view even easier. Especially when there are, say, 1,000 tasks, it becomes a challenge just to look at them all; you need to be able to narrow them down. Here you use filtering and sorting. **Filtering** displays only those tasks that meet specified criteria (for example, “show only high-priority tasks” or “hide completed tasks”). Searching (for example, “display those tasks that match a given keyword”) is also well known. **Sorting** means rearranging tasks according to a specified order (for example, toggling between ascending and descending order by name or date). By combining these two functions, you can narrow down the tasks quite flexibly. However, to filter correctly, you must understand the criteria and ensure that the task attributes are properly filled in; if, for example, a high-priority task is missing its priority attribute, it will not appear in a high-priority filter. When such omissions become common, the filtering results lose credibility and become meaningless. Even if everything works well initially, when people get busy, the process becomes cumbersome, or if some people start slacking off and influence others, the system will eventually become ossified. As a result, you may find that everyone eventually gathers in meetings to discuss and manually review the tasks.

### Micro (Detailed) View

Next, “micro view” refers to focusing on a particular task.

In a task management tool, this corresponds to opening the page that represents a single task. That page displays the task’s attributes and allows anyone to see its status—and even add comments. In recent years many tools have added chat-like functions such as comments or mentions, which can even support a certain level of communication.

It is easy to be dazzled by features, but **the essence of the micro view is that anyone involved can, at any time, focus on that one task at their own pace.** Why is this desirable? Because you want to see the specific status of the task or even intervene in it. An overall view might tell you the general situation, but it cannot show you which particular task is stuck and where. Moreover, in a work setting, many people are working at their own pace; it is better if each person can review a task as needed. Sometimes intervention is necessary. To achieve this, each task should have its own dedicated page that anyone can view at any time.

This is a function unique to digital tools; analog tools cannot do this easily. In the worst case, with analog tools you might have to dedicate a physical sheet of paper to each task, and people would have to go to that location (think of a quest board in an RPG guild). Even with digital tools, unless it is a web service–level tool, you cannot easily achieve this. For example, spreadsheets can provide an overall view but do not allow you to “zoom in” on a particular task.

Taken together, it can be said that **the ability for each member to autonomously work at their own pace depends crucially on how well the micro view functions.** Business chat tools like Slack or Teams are now very popular precisely because they offer excellent micro-view features. They allow you to exchange messages, react to them, attach files, send notifications with mentions, and are very easy to use. Although one might think that chat is not a task management tool, it is not entirely so. Business chat is organized into “rooms” (workspaces or teams, then channels, then threads), which correspond roughly to pages. Instead of one page per task, you might have one page per organizational unit or per goal—but an organization or goal is simply a collection of tasks. In other words, you can view these as “tools that create a page for each major task, using a familiar method of message exchange.” Of course, whether this actually works for task management is debatable—in many cases it ends up with endless remote meetings.

The refinement of the micro-view function is something I will address in the next chapter on partner task management. That system skillfully integrates task management with messaging, making it very easy to use in personal life (outside of a business context). I believe that if we further develop this idea, we could greatly improve project task management as well. Some hints of this already exist, which I will introduce later (as an advanced form of task management).

## The Alternate Model

Let us now look at how a project task management system might support both a holistic (macro) view and a detailed (micro) view. I call this the **Alternate Model.**

Before outlining the model, let me define two terms:  
- A “macro view” refers to an overall, holistic perspective.  
- A “micro view” refers to a focused, detailed perspective.

### Overview

There are four stages:

| Stage | Name              | Scope of Implementation             | Example                                               |
| ----- | ----------------- | ----------------------------------- | ----------------------------------------------------- |
| 1     | N-Micro           | Only micro (detailed) view exists   | Tasks exist only in each person’s mind                |
| 2     | 1-Macro           | Only macro (holistic) view exists   | A board or list that all members see                  |
| 3     | 1-Macro N-Micro   | Both macro and micro views exist    | A task management tool with a fixed view              |
| 4     | N-Macro N-Micro   | Both macro and micro views exist, with customizable views | A task management tool whose views can be fully customized |

## N-Micro

This is the stage where only the micro (detailed) view exists.

The simplest example is that tasks exist only in each person’s mind. In personal life or in the context of hobbies, this is essentially the norm—manually managing tasks is too much trouble, and it is “good enough” if things work out. Even in business, if there are only a few people, this method may suffice. In an ideal scenario, like in a teal organization, “we communicate as issues arise,” and that is enough—but if that were the case, you wouldn’t experience any difficulties. In reality, however, each person manages tasks in their own head. In effect, there are as many “original” copies of a task as there are team members (i.e. brains). Not only is it impossible to have a holistic view, but even knowing the status of each task becomes challenging. For example, person A might say, “It’s done,” while person B claims, “No, it isn’t,” because in A’s mind the task is complete but in B’s it is not.

## 1-Macro

This is the stage where only the macro (holistic) view exists.

The simplest example is a situation where only a manager’s mind contains the holistic view. This is common even in large companies that support remote work—the manager communicates frequently with team members to construct an overall view. Unless you speak with the manager, you cannot access it. Even if team members gather information on their own, they usually cannot compile as complete a view as the manager can. This is clearly a primitive arrangement designed solely for the convenience of the manager, and it inevitably creates a bottleneck. While a highly competent manager may compensate, this method tends to enforce strict hierarchies.

To solve this bottleneck, some teams use a “holistic apparatus” such as a Work Breakdown Structure (WBS) or Gantt chart. Even simple “management boards” or “charts” naturally appear (even if team members are not experts in task management). While this may suffice for project task management, in modern practice it is often insufficient—mainly because such holistic apparatuses only display the “select” tasks, and many tasks that fall through the cracks are ignored. In many cases, the untracked tasks accumulate—and inevitably someone (or everyone) ends up taking on too much work. For a manager, it is tedious to continually change the scope of what is managed; furthermore, the tasks may have become fixed (by contract or budget) so that they cannot be altered. In any event, there is little flexibility under a top-down, fixed view.

## 1-Macro N-Micro

This is the stage where both holistic and detailed views are supported by a task management tool with a fixed view.

Tasks are registered in the tool and updated daily. The tool can then generate a holistic “view” based on these data so that the manager (and, if necessary, team members) can grasp the situation. Each task also has its own dedicated page so that detailed follow-up is possible. In addition, records are kept so that you do not have to rely solely on imperfect memory. In recent years we hear much about DX (Digital Transformation), which is, in essence, about digitizing data to create a holistic view. This third stage of project task management can be seen as the DX of task management.

At this stage, because tasks are externalized and accessible to everyone, the exclusivity and opacity of management is reduced. In other words, you can think of it as “making task information a common language for communication.” Team members can also discuss tasks with one another. That said, it is often still convenient to have a designated decision maker, so the role of the manager persists. If team members could handle everything, then a manager would become superfluous.

### The Chasm in Project Task Management

Reaching stage 3 (1-Macro N-Micro) requires overcoming a very high hurdle—a chasm, if you will. (This is analogous to the “chasm” described in the theory of innovators, where there is a high barrier to bring a new product from a small core of enthusiasts to the majority.) In 1-Macro N-Micro, not only must you have a task management tool in place and team members with the necessary skills, but you must also continuously input data into the tool and use it to communicate—this is extremely challenging. Imagine having to force everyone to use the same digital tool regularly; you can probably imagine how difficult that is.

In practice, tools of the third stage are mainly used in teams or organizations that work on creative tasks. Creators tend to have many opportunities to learn new tools, and they understand the importance of working at their own pace. Conversely, it is not easy for ordinary people to easily cross this chasm.

For a group of ordinary people to overcome the chasm, long-term education and continuous training are required. You must also secure the cost of the tool and the personnel required for education. In other words, the cooperation of the management (or, in large companies, those who control budgets and hold authority) is indispensable. (This again relates to the discussion of DX in [ref#6] and [ref#7].)

In the case of project task management, while you may not need to think on as grand a scale as a CEO, similar dynamics apply within the team or project unit. Whether it is the manager, department head, or another key person depends on the situation, but some form of cooperative investment is necessary.

## N-Macro N-Micro

This is the stage where both the holistic and detailed views are supported and the tool allows you to customize the view.

In stage 3 (1-Macro N-Micro), the view is fixed—only the views supported by the tool are available. Even if you wish for a view from a different perspective, it is not possible; you either have to search for another tool or else the system becomes ossified—and you eventually end up with meetings and having to ask people. Researching, migrating, and establishing a new tool is very time-consuming, and if it were that simple, you wouldn’t have any difficulty. Ossification is always lurking, waiting for you.

To avoid such a tragedy, it would be ideal if the tool provided the function to customize the view. For example, monday.com’s Work Management allows you to create views via widgets. Task attributes can be customized freely. You might set priority on a 1–5 scale or create an “emergency” attribute separate from priority, so that if its value is 1, you must start that task immediately. As a view, you could create a widget that lists tasks with the emergency attribute (which normally remains hidden, but when displayed indicates that you must act immediately). This is just one example; by creating views that suit each team or workplace, you can gain flexibility.

### API

Customization does not have to be achieved by one method alone. Another way is to use an API.

An API is an “access point” designed for programs to call each function or data element. Modern digital tools are typically built using various APIs. You can think of APIs as parts which are combined to implement a process. These parts are usually not available to external users, but there is a trend toward making them public. By making them public, others can use them; they might even allow unexpected functions to be realized, or at worst let you say, “Just handle it via the API.” 

With an API, you can write your own program to retrieve the data you want and display it in any format you desire. Of course, this requires specialized development skills and time to build, but if you are inclined, you can customize your system accordingly.

# Types of Views

There are various ways to view tasks in a holistic manner. The types of views differ by tool, and as mentioned in the fourth stage above, the view itself can be customized. However, there are only a few general types.

| Name         | In a word        | Examples/Tools | Characteristics |
| ------------ | ---------------- | -------------- | --------------- |
| List         | List             | ⭕             | Easy to create, but not very engaging and details are hard to see |
| Table        | Table            | ⭕             | Two-dimensional with rows and columns, high information density but can be cognitively demanding and tiring |
| Board        | Board            | ⭕             | Cards arranged in an intuitive layout; visually appealing but can be overwhelming |
| Chart        | Diagram          | ⭕             | Can visually represent complex information; many types exist, which can lead to a high learning curve |
| Network      | Web              | ❌             | Can represent multidimensional relationships among nodes (see later) |
| Sentence     | Paragraph        | ❌             | Presented as text so context can be included, but limited in the amount of task-specific information |

When choosing or creating a view, keep these types in mind. There is no magical view that transcends these basic formats—after all, they merely gather and display tasks. More important than switching between different views is that **everyone who sees the view becomes accustomed to it.** Rather than constantly changing views, it is better to choose one and master it. Otherwise, you might end up endlessly chasing the ideal view, which for project task management is not only impractical but also disruptive.

Having discussed the general categories, let us now look at the details of each type.

## List

A **List** is simply a bulleted or numbered list.

Each task is displayed on a single line, and because there is an order, filtering or sorting can help make it easier to read.

The advantage of a list view is that it is very easy to create. For example, a to-do list is just a list; you can even create one by hand. It is, after all, just a list. However, there are several disadvantages.

First, a list view can be unappealing to read because it relies entirely on text. In some cases, it might not even form coherent sentences—it can become nothing more than a string of words. This is inherently off-putting to many people; for instance, when you think of leisure reading, a story or engaging narrative is far more inviting than a mere list of words. Because a task list is simply a list of words, even avid readers or those who love text can find it difficult to get motivated to read it. For this reason, list views are rarely used in practical work; instead, other types of views are developed or meetings are held to discuss tasks directly. In short, a list view is often more challenging than it appears.

Another disadvantage is that details about each task are hard to display in a one-line format. Since you can only show text, the amount of information per task is limited. In modern project task management tools, table views (with rows and columns) are much more common because they can display more information.

## Table

A **Table** is a grid format.

Tasks are arranged in rows, and columns exist so that each column corresponds to an attribute of the task. While filtering or sorting adjusts the number of rows, table views also allow you to adjust (customize) which columns are displayed. Many tools allow you to click on a column header to sort the table (toggling between ascending and descending order).

The advantages of table views are their familiarity and ease of reading. Spreadsheet software like Excel is extremely popular, and the concept of a table is very common in business. Most professionals—from office workers to students—are familiar with tables. Displaying data in rows and columns makes information easier to understand. In fact, choosing a table view is often a “safe” and reliable option. One might even say, **“If you choose a table view, you can’t go wrong.”** In other words, if a project task management system does not work with a table view, then there is a fundamental problem. If you wish to enable a holistic view of project task management, you should first aim to have it function well in a table view.

There are, however, some disadvantages. First, a table view can be fatiguing. When task information is packed continuously, reading it carefully can quickly deplete your cognitive resources. Unlike casually browsing the web, social media, or checking emails or chats, constantly scrutinizing a table view (much like a timeline) can be very tiring. Some people try to look at a table view frequently, but it is not recommended because it is so exhausting. Of course, with some ingenuity, you can reduce the fatigue. For example, you might display only high-level tasks (omitting details) or apply filtering and sorting so that you only see the information you need. In other words, **do not try to interpret information that has not been properly input.** Even if you try to guess, you are likely to be wrong; so encourage proper data entry (which, as mentioned, is difficult and part of the “chasm” problem).

## Board

A **Board** is a board-like display.

When you hear “board,” think of a bulletin board or message board where items are affixed. In a board view, tasks are represented as cards (or sticky notes) arranged in a two-dimensional space. Rather than allowing free-form placement, they are usually arranged in an orderly fashion. In project task management, the board view is often influenced by the Kanban method, with designated areas for “Not Started,” “In Progress,” and “Complete,” into which task cards are placed and moved accordingly.

The main advantage is that board views are very easy on the eyes. Unlike a list, which is merely a string of words, or a table, which is densely packed with information, a board view displays visually appealing cards with ample white space. The cards can be adjusted in size, and you can design them so that the information is presented in a thoughtful way. This is where designers can really show their skills.

Most importantly, because the tasks are represented as cards, you can “move” them from one area to another. For instance, if a task has been started, you can simply drag its card from the “Not Started” column to the “In Progress” column. This intuitive operation is much easier and less cumbersome than opening the task’s detail page and manually changing a status attribute from “Not Started” to “In Progress.”

Because board views are both easy to read and require minimal effort, they are well suited for hectic project environments. When everyone gathers for a meeting, you can quickly review the board and say things like, “There are too many tasks here—let’s discard this one,” or “This task is finished, so move it to Complete.” This rapid updating is not possible with list or table views.

There are two disadvantages. First, because board views are highly graphical, they can become visually “noisy” and fatiguing. Also, because they rely on spatial arrangement, they can be challenging for those who are not strong in spatial awareness. As a rough guideline, **some people work better with board views while others prefer list views.** Those who are strong in visual and spatial tasks tend to do well with boards; others may find lists easier to work with. Secondly, the number of tasks you can display on a board is limited, so it is best suited for work organized in agile cycles (for example, planning tasks every one to two weeks). If you have 100 tasks in total but can only display 20 on the board, you must narrow down the focus to those 20 tasks.

Board views are a later development than list or table views, so if a board view does not suit you, you should not force it.

## Chart

A **Chart** is a diagrammatic view.

This category includes various ways to visualize information—what you might call graphs or diagrams. In task management, charts are often used as frameworks.

Examples include:

- Work Breakdown Structures (WBS)
- PERT diagrams
- Gantt charts
- Burndown charts
- Cumulative flow diagrams

The essence of a chart is that you choose one or more “axes” (vertical, horizontal, etc.) and arrange the data (information about tasks) along these axes so that you can visually assess the situation. Charts are particularly useful for detecting warning signs—for example, if elements overlap too much or if the slope of a line becomes too steep, it may indicate a problem. What you can discern depends on the chart, so you must learn the relevant framework.

Collections of various charts assembled into a single view are sometimes called dashboards. While the term “dashboard” is not common in the context of task management, it frequently appears in statistical analysis or security contexts. Terms like “data-driven management” have also become popular recently, emphasizing a trend toward prioritizing data. In the future, we might see task management tools that rely heavily on dashboard views.

The advantages of charts are that they allow you to visually and easily grasp complex situations. These frameworks are carefully designed to accomplish that—they are not something that can be cobbled together by a non-expert. In short, a chart is typically not something you create from scratch but rather something you use that is supported by a framework (and by the tool). When used correctly, charts provide an easy, visual holistic view.

The disadvantages are precisely that you must study and learn the framework. Some tools support their own unique charts, but even then you must learn how to read and interpret them. And even after learning, you must train yourself to make accurate assessments based on the charts.

Furthermore, each type of chart is intended for a specific situation, so you may need to compare your situation against the intended use of the chart. For example, a WBS or Gantt chart is appropriate in stable, plan-driven contexts, while a burndown chart or cumulative flow diagram is more suited to agile development environments where plans are dynamically updated and short-term cycles are repeated. Using a burndown chart in a plan-driven context or a WBS in an agile environment would be mismatched.

## Network

A **Network** view is one that displays information in the form of a network.

The term “network” might sound too literal and is hard to grasp, but it refers to a structure where points (called nodes) are connected by lines (called edges). Although this is a specialized theoretical concept, it is frequently seen in contexts like human relationships, website link structures, or citation networks in books. The idea is to apply this to tasks—to show the relationships between tasks as a network. However, there are currently almost no examples of a network-style view in task management.

To create a network structure, you would need to continuously connect tasks (by registering some kind of relationship between them). Normally, this is not done in project task management. Some tools (such as Redmine or GitHub Issues) may display source and target references, but that is only a matter of detailed status checking rather than a true network view of all task relationships. There are also tools with workflow features that display network-style views, but those views depict the workflow rather than the tasks themselves. (In fact, workflow features fall more into the realm of visual programming.)

Recently, some note-based tools have appeared that can be used for task management and offer a network view—but this is a highly advanced topic that I will discuss in a later chapter (under Literary Task Management).

Because there are currently no real-world examples of a network view in task management, I will omit a discussion of its pros and cons.

### (Side Note) Visual Programming, Task Management, and Automation

Visual programming refers to programming in a visual manner. You arrange visual “parts” (modules) and connect them with lines to indicate the flow of information—much like assembling a puzzle—to create an overall process.

While you must understand the available parts and what they do, the difficulty is comparable to that of a game; indeed, with some practice, even beginners in elementary or high school can learn it. The educational tool [Scratch](https://scratch.mit.edu/) is a well-known example.

In other words, even the difficult art of programming becomes relatively easy when done visually. In recent years, the “no-code” (writing no program code) or “low-code” (writing very little code) movement has gained traction. For example, non-programmer back-office workers can use visual programming to create their own business improvement tools. In Japan, Cybozu’s [kintone](https://kintone.cybozu.co.jp/) is a well-known example.

This same idea is now arriving in task management. That is what we call Automation. Automation, literally “automation,” is a mechanism to automate the operations related to tasks. (I mentioned this briefly in the “Streamlining” section earlier.) By defining in advance that “if XXX happens, then do YYY,” you can have YYY executed automatically as soon as XXX occurs. If you have an established workflow, automating it makes life easier. In other words, **Automation is the mechanism by which the workflow of task operations is automated.**

To summarize this section in three points:
1. There is a method—visual programming—that makes programming relatively easy.
2. The flow of visual programming has begun to enter into business practice, and even ordinary people are increasingly capable of assembling processes.
3. This approach is also making its way into task management, and some tools already support automation so that task operations can be automated.

Thus, becoming familiar with visual programming will make it easier to adopt automation in the future.

## Sentence

A **Sentence** view is one presented in the form of text (or written narrative).

There are currently no real-world examples of a sentence-style view. One might say that with the power of generative AI it would be possible to create one, but because the accuracy of the result cannot be guaranteed, its practical value is limited. For the time being, we would have to create such a view manually. What this means is that we pre-write a narrative that describes the overall situation in a way that provides a holistic perspective.

For example, imagine a project to create a book. Consider the “Before” to be the list view and the “After” to be the sentence view.

**Before (List View):**
- ✅ Table of Contents Draft
- 43% Chapter 1
- 20% Chapter 2
- 00% Chapter 3
- 16 References

**After (Sentence View):**

> First, create the “✅ Table of Contents.” Just like a plot in a novel, having a compass makes writing easier. This is non-negotiable. Finalize the table of contents before you start the main text—although a provisional version is acceptable since it will change.
> 
> Then proceed with “Chapter 1 (43/100),” “Chapter 2 (20/100),” and “Chapter 3.” Although the chapters can be developed in parallel, Chapter 1—where the foundational terms are introduced—should be completed first.
> 
> “References (16 items)” should be appended as you write. While rough notes are acceptable during drafting, make sure to record necessary information such as URLs and book titles. Also, since correcting links later is a hassle, verify them as you go.

In a sentence view, additional commentary and context are provided in narrative form. Up to this point, views merely displayed tasks, but sentence view also includes explanatory text. Of course, the task information (such as checkmarks or percentages like “✅” or “43/100”) will be automatically displayed by the tool; you will not have to enter those manually. More details on this will be discussed in a later chapter (Literary Task Management).

The advantage is that context becomes clear. While other views only display tasks, sentence view includes narrative context, making decision-making easier. In the above example, the text clearly explains what should be done in which order, so that when the team reviews it, they might notice “Shouldn’t we complete Chapter 1 first?” or “Chapter 2 seems a bit advanced; shouldn’t we focus more on Chapter 1?” Such insights become much easier to obtain.

The disadvantage is that writing narrative text is laborious. This is not so much a matter of writing skill as it is about achieving consensus. In project task management, the view might be seen by all team members, so the text must be acceptable to everyone. The context must be agreed upon—ambiguity is not acceptable. If the narrative is ambiguous, the value of a sentence view is lost, and it becomes mere clutter. Furthermore, sentence views cannot convey as much task-specific information as table or list views. Consequently, if you have many tasks, you might end up needing to create several separate sentence views. For example, if you have 100 tasks, a table or list view might be sufficient with just a few pages, but a sentence view might require 10 separate passages. That is quite burdensome. Moreover, because the narrative serves as a guideline, it must be revised as circumstances change—in short, you will have to continually write and revise text. This can be very challenging for those who are not comfortable with writing.

Finally, there are no current tools that automatically display task information in a sentence view. To achieve the type of narrative expansion shown in the example above, you would have to use the tool’s API—as discussed in stage 4—and build such a system yourself.

...