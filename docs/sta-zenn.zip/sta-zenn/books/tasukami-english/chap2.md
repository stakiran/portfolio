---
title: 📘Part 2 "Basics of Personal Task Management"
---

This section covers the basics of personal task management.
