---
title: Literate Task Management(2/2)
---

# Task Management in LTM

Up to this point, I have emphasized using notebooks, building a network of notes, and especially creating a home from which everything expands.

Now we finally come to task management. In the world of networked notes, how should you read and write about tasks? Let’s look in detail at the ideas and methods.

## Create Your Home

First of all, just create a home.

If you’re unsure, create any note called “Home,” “Desktop,” “Test,” or whatever—it doesn’t matter. Choose one note and designate it as your home. You can change it later, but you must have a concept of “home” to get started.

Also, ensure that you can start writing into it within a few seconds. The [3-second barrier](plaintext#3-秒の壁を突破する) refers to the time it takes to add a task; here, I mean “the time it takes to start writing in your notebook.” There may be several places to write, but the simplest is the home. In other words, you should be able to start writing in your home within seconds. Achieving this speed generally requires that the home is always open or that you can launch it immediately via a button or shortcut key. Reducing the startup time is extremely important—if it takes too long to start, you will be less inclined to write, and you risk abandoning LTM. Think of it like how you glance at social media in an instant. You likely have your social media apps ready to check instantly. You want the same for “writing something in your home.” 

## Three Types of Information Concerning Tasks in LTM

In LTM, please keep in mind that there are three types of information related to tasks:

- Memos
- Tasks
    - Task view
    - Task note
- Context

A memo is something you quickly jot down to be processed later. As discussed in [the memo chapter](memo#メモを書くとき), speed is of the essence when writing a memo. Of course, even if you write quickly, it is meaningless if you cannot process it later, so you must devise a way to handle them afterwards.

A task is something you have decided to do. Whether it is a Must, Should, or Want, it is something you have resolved to “do it!” or wish to decide upon.

Tasks must be able to be reviewed in a view. Whether you automatically extract tasks into a view or manually compile them into a list, you need to have a view for tasks. I call this the **task view**.

Another point is that a task itself carries various kinds of information. (I have already discussed the topic of “3A” including attributes.) However, since LTM is literary in nature, these attributes, relationships, and functions are all expressed in text. Also, as mentioned earlier, when you respect context to improve QoL, you do not want to get bogged down in rigid management like setting start times, deadlines, classifications, or progress updates. You want to be more free-form. To that end, the idea of topic orientation comes in. If there is a task T, simply create a note for T and write everything related to T in that note. If there are related notes, link to them. In doing so, the note for T (what I call a **task note**) accumulates all information, that is, the context of T, in its content or via its network of links. In short, with LTM you manage tasks by both creating task notes (which document each task’s context in a networked, note-like manner) and by creating task views to review them. This dual approach allows you to manage tasks without resorting to overly rigid management methods—because that would be just conventional task management rather than literate task management.

Finally, context is not memos or tasks—it is all other information. In short, everything you write in your notes is context. From this context, ideas, information, tasks, or decisions emerge. You are not simply following orders blindly or paralyzed by the absence of a “correct answer.” In LTM, you rely on the power of the context accumulated in your notes to make your own decisions and move forward. With enough context, natural conclusions typically emerge (including “just try it” when you are unsure). And since LTM naturally accumulates context through continuous writing, as I mentioned in the “second brain” concept, you are not merely writing a task list from thoughts in your head—you are writing down everything you think and then maintaining it. You nurture your notes. **Well-cultivated notes become a treasure trove of context. At the very least, they serve as a nurturing ground for context.**

- *Note: I mention GTD’s “next actions” here simply because it is an easy-to-understand example of collecting tasks in one place. In GTD, you filter “things that catch your attention” through a workflow that includes an inbox or project lists and finally distill them into small, concrete actions—the next actions. For instance, if you have 20 projects and 5 actions per project, you might end up with 100 next actions. In reality, this number fluctuates as items get filtered into “Someday” or “Waiting” categories or as you initially dump in a lot of ideas. The ideal is that your next actions are exactly what you should do next. You only have to choose one next action and do it, then choose another and do it. That’s the idea behind “collecting in one place.”*

## Areas and Marks

Both memos and tasks are things that must be processed later. Memos, if not reviewed quickly, will be forgotten (or you’ll forget what you wrote), and tasks must be completed without negligence.

So, in LTM, how can you “process later” the memos or tasks you write?

The essence is simple: you must re-read them later. The problem then becomes the cost of re-reading. To reduce the effort required for re-reading, you can do one of two things:

- Areas
    - Define specific areas where you later review the content you have written.
- Marks
    - Mark the portions that need to be reviewed, and later search for and display only the marked parts.
    - In other words, create a view that shows “only the marked items.”

Technically, you could also use generative AI to read everything and remind you, but as discussed in [a side note](#余談2%3A-ノートの欠点を補う), the accuracy is not yet sufficient for practical use.

### Areas

“Areas” are defined manually. You designate a specific note or a specific part of a note as the “area” that you will review later, and then you write things there, and later review that area at a different time. While the home note is one area, it often becomes too large to serve as an effective area on its own.

An area is much smaller. For example, you might create a “Daily Task List” area within your home note where you dump all the tasks for that day and review them frequently. That is an area—the daily task list area. Of course, you are not limited to this method; you might create a separate “Daily Task List” note, or even have a daily task list area in each of your project notes.

The important thing is ease of writing and, most importantly, **ensuring that you actually review it later.** In a home note, you would see it every day, so you might review it without extra effort. However, because of familiarity, you might inadvertently overlook it because you assume you have seen it. Creating a separate note for the area might prevent this over-familiarity, but then it might become less accessible. This balance is also discussed in [the chapter on pathways](dousen_and_remind#動線のデザイン). You can also set up a calendar or reminders that tell you “check this area!” For instance, you might compile a list of areas to review and then review them weekly. Although areas seem like a lot of manual work, they function surprisingly well in LTM. In LTM, you are continually writing, linking, and creating new notes, so you gradually develop a strong “sense of place.” You can usually reach your desired area within just a few hops (where a hop is following one link), and because you become accustomed to which link leads where, you rarely get lost. Although it might take some time to develop this sense of place, the effort is not as burdensome as you might think.

### Marks

You are probably familiar with the idea of using tags to list items, but “marks” refer precisely to this concept. You put a mark (or symbol) on text (or even a specific line) that you want to review later, and later you extract and display only the marked portions.

The simplest method is to use the search function provided by your note tool. In text editors, this might be called “full-text search” or “grep.” By specifying a particular keyword as the mark, you can display only the marked parts.

Now, the remaining issue is how to choose a mark. In the past, it was common to prefix text with something like `@task`, or use symbols such as `●task` or `■task`. Nowadays, you can also use emojis. Emojis have the advantage of catching your eye visually, so rather than relying solely on search, they are naturally noticeable as you read and write. For example, there is no “correct” emoji for a task, but you can choose any that you understand—such as 📒 (notebook), ✅ (check), 🏃 (runner), 📌 (pin), or 💣 (bomb). Ideally, if possible, designate a specific mark (for example, ✅) to indicate completion, separate from the mark that indicates an uncompleted task. For instance, when you complete a task written as `💣Task1`, you could change it to something like `✅💣Task1` so that you know it is finished.

The search results from these marks form a view, which you can think of as your task view if you strictly mark only tasks. However, viewing a search result every time can be burdensome. If it takes too many steps to see the view, you might become lazy, and if laziness continues, the system becomes merely a shell. Therefore, **minimize the effort required to open the search results.** If your tool provides shortcut functions, set them up so you can access the view with one keystroke, or if you are using a web-based note tool, bookmark the search results page. If you are using an editor, you might use an extension to achieve this. In any case, if you use marks, do not compromise on making it easy to build a view.

An even more advanced approach is to attach additional attributes to tasks beyond just a mark. For example, in [hown](ref#hown), tasks are written as `[2002-10-22]@ Task` (using symbols like `@`, `!`, `+`, or `-` in different ways), which includes a date attribute. Then, when constructing a view, you can compare this date with the current date to naturally control the priority—for instance, displaying tasks with dates closer to today higher up, or vice versa. I won’t go into further detail here, but with this method you can naturally control the order of tasks based on dates. Of course, this works only if the system (like hown) is programmed to interpret the written format correctly; if you want to do the same yourself, you must build it.

## Addressing the Aspects That LTM Cannot Cover

LTM is a literary practice with the goal of enhancing QoL. That is, it is about writing to improve your sense of self-satisfaction and self-esteem while also managing tasks to some extent. However, LTM does not have the full potential to cover every aspect of task management. There are always parts that LTM cannot fully address. I call these the **Uncovered** parts.

Here are examples of what is uncovered and how to deal with them:

- Routine tasks versus “optional” tasks
    - See [the chapter on plain text](plaintext#扱わないもの) for details.
- Sharing tasks or context with others
    - This is also discussed in the plain text chapter.
    - LTM is intended for personal use only, so in its raw form it is not suitable for sharing.
    - Although it is possible to set up an LTM system that is visible to others, it is not recommended because you tend not to write as freely when other people can see your work.
- Fine-grained management or advanced views based on attributes
    - For these, please use a standard task management tool.
- Strict adherence to deadlines or strict task management
    - Again, use a standard task management tool.
    - If necessary, supplement with a calendar or reminder system, or consider joining events that enforce strict deadlines → treat these as optional tasks.

That said, if you rely solely on these uncovered methods, you will never be able to fully use LTM. It is best to try to accomplish as much as possible within LTM and only resort to other methods for the truly cumbersome parts.

It is much like cooking or DIY. If you say “There are already good products out there, so why build your own?” then nothing will ever get done. Knowing full well that this is the case, you still choose to build it yourself in order to improve your QoL. The same applies to LTM—despite the capabilities of conventional task management tools, you deliberately choose to do it yourself in a literary way with your own notes. That said, don’t try to replicate everything; for the more tedious parts, it is best to rely on off-the-shelf solutions.

## How to Understand and Create Context

### How to Understand It

In LTM, I have stated that there are memos, tasks, and context, and that everything in your notes that is not a memo or a task is context. In other words, everything you write becomes context. But what exactly is context?

The goal of LTM is to improve QoL through task management by handling tasks. How do you handle them? You do so in a literary manner—that is, by reading and writing. Traditional task management often involves tasks that “must be done” and forces you to respond without question, with limited resources that require you to carefully plan priorities and timing. LTM, on the other hand, is not like that. Instead, you decide on your tasks based on the text you have written in your daily notes.

Context is like a hint.

That is why there is no “correct answer.” If you were to simply record events and facts like a ship’s log, you would be documenting an objective record as context; if you were to write out your feelings at length, you would be documenting subjective context. It is also acceptable to collect valuable ideas or aphorisms from books or social media and analyze them, or to let yourself be immersed in profound thought or philosophy that no one else might understand. In short, anything you write becomes context, and in LTM, tasks are derived from that context.

The point about deriving tasks is also crucial. You do not just write and finish; you must eventually take action on what you’ve written. After all, nothing changes unless you act. There are various ways to take action, but in LTM you choose to write down your thoughts in a notebook, read them later, reflect on them, and then incorporate your insights—repeating this cycle until you arrive at a satisfying decision. I am not saying that this is objectively “right” or “wrong”—it is simply the approach used in LTM.

To sum up:

- In LTM:
  - You expand your thoughts based on what you have written (context).
  - Since you want to take action, you must eventually translate that into a task.
- There is no right answer to what you should write; it’s entirely up to you.

### How to Create It

So, how do you create context? In other words, what should you write?

I believe there are three key points.

The first is to write about what you want to write. LTM is a practice that continues day after day, so you must have topics that you will enjoy writing about continuously. If you write about things you dislike or do not care about, you will not persist. Choose subjects that will motivate you to write without hesitation—even if it’s a diary, or even if you let your hobbies shine through. If you have something you want to say or complain about, go ahead and write it. In short, pick topics that seem sustainable for you.

The second point is to capture topics that can be “explored in depth.” At the very least, capture tasks that are visible to you right now—whether they are tasks you must do immediately, tasks you want to do eventually, or tasks you feel you should do even if you are reluctant. If there’s something you want to explore further because of your hobbies, include it. When you see a topic that seems promising for exploration, note it down. You might also use a “trigger list” (as discussed in the chapter on reflection [furikaeri#トリガーリスト]) to collect such ideas, or you might catch interesting topics from social media, news, or books. In essence, keep your antennas up for ideas. Whenever something makes you go “aha,” especially if it seems like it could be explored in depth, make a note of it. Even in conversation at work, spontaneous chats can lead to deeper exploration and might even lead to work opportunities. LTM is similar: it is not only about handling tasks that directly affect you, but rather about exploring everything you might want to handle. In doing so, you gradually become accustomed to writing in the LTM style, and you begin to see which topics are suitable for you. These “tasty topics” eventually become the foundation for your personal axis.

The third point is to engage in self-questioning. Although you will accumulate a lot of material from the first two points, you must also add your own insights. If you do not write in your own words, your collection will remain nothing more than a list or display of items. Self-questioning is the best way to write in your own words. For example, ask yourself:

- What do I think about this?
- What actions can I take from here?
- (If you feel envy or jealousy) Why do I feel this way?
- What is the appropriate stance on the surface, and what do I truly believe?
- What aspects of this do I find interesting?
- If I were to continue from here, what would I do next? etc.

At first you may be confused about what questions to ask, but keep at it. In the beginning, you might create a trigger list and refer to it. Over time, you will develop “your own favorite questions” and you will be able to continue writing as naturally as breathing. For example, I personally feel a strong desire to “say something brilliant that people will admire,” to “create a new work method or concept,” and to “express beneficial learning and knowledge in my own words.” If I were to phrase these as questions, they might be: “What brilliant insight or witty remark can I come up with that people will admire?”, “What new concept can I derive from this?”, or “How would I express this in my own words to truly understand it?” Of course, these reflect my own preferences and are not meant to be taken as the absolute truth.

## The Writing Stack

Usually, we have an original “version” in our heads. We then articulate that internal version into language when we write or communicate. I call this the **image stack**—a stack of images in your mind.

In contrast, LTM follows a different philosophy: the original is not in your head but in your notebook. Your internal thoughts are merely a workspace for reading and thinking about what you have written. The true original is what is in your notes. This means that you need to continually read, write, and cultivate your notes. If, for example, you have three personal philosophies, they should not remain solely in your head; they should be written down as notes. And if your philosophy changes, that change should be reflected in your notes. Your notes are the original. I call this the **writing stack**.

Whether LTM takes hold depends on whether you can adopt this idea of the writing stack. Of course, as humans, we can never completely abandon the image stack, but for matters related to LTM you should lean toward the writing stack. Without this shift in mindset, the practice of LTM will not persist. Just as a writer’s original work is the text they have written, and a programmer’s original work is the code they have written, for someone practicing LTM their notes become the original record. This is why I urge you to adopt the writing stack approach—only then will you truly be able to write.

Especially when it comes to tasks, try to stick to the writing stack. One of the main benefits of task management is that by saving tasks in a task management tool rather than in your head, your mind becomes clearer. With LTM, by reading your notes at the appropriate times, you can recall or switch tasks without having to store them mentally. This allows you to concentrate on reading, writing, and thinking. Although it is not suited for hectic situations, this mode of operation promotes a self-directed, creative lifestyle that improves QoL.

## Excerpting

Please actively excerpt (or “cut out”) sentences or words that you find valuable. **Excerpting** means taking a particular sentence (or even a word) and turning it into the title of a new, separate note.

For example, suppose you want to study and internalize the concept of the writing stack and you come across the following excerpt:

> “Whether LTM takes hold depends on whether you can adopt the writing stack. Of course, we can never completely abandon the image stack, but for matters related to LTM, you should lean toward the writing stack. Without this mindset change, the practice of literate task management will not persist. Just as a writer’s original work is the text they have written and a programmer’s original work is the code they have written, for those practicing LTM their written notes are the original record. It is by adopting the writing stack approach that one is able to write.”

If you want to study the concept of the writing stack, you might excerpt it by choosing “For those practicing LTM, their written notes are the original” as the title of a new note. In practice, you would create a link in your original note that looks something like this. In Scrapbox you would enclose it in `[ ]`, in Obsidian you would use `[[ ]]`, or follow the notation of your tool. For example, you might write:

> … (omitting some text) … just as a programmer’s original work is the code they have written, so too, for [for those practicing LTM, their written notes are the original]—it is by adopting the writing stack approach that one is able to write.

This automatically links the text, so when you click the link, you open the “for those practicing LTM, their written notes are the original” note. You can then write your own insights there or include a link back to the original note. In this way, the note titled “for those practicing LTM, their written notes are the original” becomes available for you to use as a building block. For instance, if later you are studying LTM in another note and realize “Oh, so that means the note is the original,” you can add a link to this note. As more and more notes reference it, you’ll see that “for those practicing LTM, their written notes are the original” becomes recognized as important to you. By actively excerpting—even if roughly—you reinforce your context. At the very least, you can confidently say, “This is what I believe,” and later when you revisit your notes, you may find new insights.

Writers often collect proverbs or aphorisms they find compelling and reuse them in their writing. Similarly, programmers reuse useful snippets of code by packaging them into functions, modules, or libraries. In the same way, **in LTM you can modularize any piece of text.** A note consists of a title (the note name) and the body text, so you can include only the essential idea in the title while writing the details in the body. One of the most common ways to modularize in LTM is through excerpting.

This technique is also useful when managing tasks. For example, if you come across a term you do not understand, you might create a separate note titled with that term to study it, perhaps using dictionary or search results to add information. Or, you might excerpt a portion of a chat message from Person A, then add your own commentary by excerpting the relevant part and writing your thoughts. Although it takes a little extra effort, by excerpting and working with the excerpted note, you reinforce your context. It makes it easier to reach a satisfying conclusion because you have taken the time to process it. At the very least, you can confidently say, “This is what I think,” and later your note might inspire you again.

Of course, you do not have to excerpt everything, but if you gradually accumulate excerpts, your context will evolve. Just as studying and practice require small, steady efforts over time, LTM requires a gradual accumulation. In fact, one might say that excerpting is what creates context. The excerpted note is essentially your choice, your context. You gradually build your personal context through daily excerpting.

## Micro-Corrections and Aliases

I have discussed the writing stack and excerpting. When any text can be modularized and used (linked) to form a network among notes, your original notes are developed—they become your second brain.

At this point, an important principle comes into play: make your note titles as clear and catchy as possible. Since links are based on note titles, how you write the title greatly affects the ease of use (visibility and ease of reference). If the title is not user-friendly, you might forget to re-read or reuse that note. Make it clear to you. For instance, if you created a note titled “For those practicing LTM, their written notes are the original” in the previous section but you don’t like that phrasing, you should change it. Here are some examples:

- Before Correction:
    - “For those practicing LTM, their written notes are the original”
- After Correction (examples):
    - “In LTM, written notes are the original”
    - “In LTM, your written notes are the original”
    - “In literate task management, your written notes are the original”
    - “Written notes are the original”
    - “The Notebook Is the Original”

There is no right answer; the key is that it should be clear to you. Of course, if you prefer to stick with the original wording, that is acceptable.

Next, using **aliases** (alternative names) is also very useful, so use them liberally. For example, if you find that while you want to preserve the name “For those practicing LTM, their written notes are the original” you personally find “Written notes are the original” or “In literate task management, your written notes are the original” easier to use, then create all those variants.

![](/images/taskmanagement-kamikudaku/ltm_alias.png)

In this way, from the “Written notes are the original” note or the “In literate task management, your written notes are the original” note, you can always reach the “For those practicing LTM, their written notes are the original” note. This is just one example; the idea is to gather links pointing to the source note. It is best to follow a 1-source-to-n-many-aliases approach. The source should be unique. Also, do not create too many aliases unnecessarily, because that may later cause confusion—use aliases only when you naturally end up with two choices (or a small number).

## Eye-Catchers and Excitement

As you continue with LTM, you will accumulate many notes and links, forming a sea of text. Even for those accustomed to it, re-reading or maintaining all these notes can be quite a chore. After all, it is unrealistic to review every note in its entirety.

To maintain your motivation to keep interacting with your notes, you need some form of incentive—this is where eye-catchers and excitement come in.

**Eye-catchers** refer to elements that grab your attention, such as images or thumbnails in a blog post, or the thumbnail of a video. In LTM, this can include catchy note titles, images, GIFs, videos, etc. The idea is to add visual accents to the sea of text, livening up the overall appearance of your notes. The content need not even be related to task management. For example, I include images of popular social media posts, videos of VTubers, or even my own gaming or dance videos. Although these may seem unrelated to task management, they elevate my mood and motivate me to re-read my notes. Displaying your own content proudly can also boost your self-esteem (although this depends on personal taste).

Only a limited number of note-taking tools allow you to include eye-catchers. If you are using an offline editor, it might be difficult. In this chapter, I have recommended Scrapbox, which as a SaaS tool supports inserting moving images and thumbnails. (Even though moving images or non-text elements might seem to be important, the key point is that you must secure eye-catchers using text alone if necessary. Catchy headlines are common in social media and news, and that’s the idea. Strive for expressions that are natural to you and that motivate you. However, be careful not to merely display other people’s words—if you only save others’ content, your own context will not develop. In that case, LTM becomes little more than a bookmark gallery.)

Next is **excitement**, which means designing your system so that it triggers a burst of activity. More specifically, it means prioritizing the display of notes that are in the process of being written. Scrapbox provides a good model for this: it has a “Date Modified” function that arranges pages (notes) by the order in which they were last updated, or you can pin certain pages to the top. By using these functions, notes that are in progress—that is, incomplete or unfinished notes—are displayed first, making them easier to get started on. If you are using a tool without such a view, create your own by, for instance, lining up links as a makeshift collection. Although it takes some extra effort, without this extra step you won’t have enough excitement to motivate you.

It is important not to overdo the excitement. If you have too many unfinished notes lined up, you may become overwhelmed by the choices and lose momentum. I recommend balancing between a static excitement—notes that are permanently pinned (and thus limited in number, say 3–7)—and a dynamic excitement—notes that are sorted by “Date Modified” and change over time. I typically review the static excitement only a few times, and aside from a weekly review, I casually glance at the dynamic excitement as it naturally updates, and make adjustments as needed. This balance seems optimal for me. Trying to include too many items or increasing the frequency of checking them can be counterproductive and exhausting. **There is no single “correct” way to read and write notes; the process cannot be simplified to a single, definitive method.** Because there is no absolute right answer, every review involves considerable judgment and thought, and if you overthink it, you may end up stuck or unmotivated. To prevent that, design both static and dynamic parts according to your own capacity. Think of it as sustainability—aim to do it in a way that you can maintain over the long term.

## In Conclusion

I have explained how to read and write about tasks in the world of networked notes.

What I have emphasized in this section is not so much the mechanics or theories of task management itself but rather the art of building your notes—especially how you weave context. You might think, “Isn’t this more about note-taking than task management?” And indeed it is. **Literate task management, although it is called task management, is fundamentally about note-taking.** By creating notes, you solidify context, and once context is solidified, tasks naturally form. Moreover, well-defined tasks may be better managed using conventional task management tools rather than LTM.

I view this as “once something becomes clear, act immediately.” Task management involves both the stage of deciding on tasks and the stage of simply executing them. LTM focuses on the former. It is about writing your own notes—notes that are solely for your own use—to determine what needs to be done in a way that improves your QoL.

# Summary

The overview and key ideas are as follows:

- LTM (Literate Task Management) is a method that manages tasks based on the practice of reading and writing.
    - It handles memos, tasks, and context.
        - Memos are written quickly as temporary notes to be processed later.
        - Tasks are handled via both a task note (a note that details an individual task) and a task view (a way to overview multiple tasks).
        - Context is everything you write in your notes. What you write—and how you maintain it—is entirely up to you, but it becomes the context that defines you.
    - You continuously weave your context into your notes and then, once things become clear, you transform them into tasks and act on them. The research, thinking, and deliberation that lead up to tasks are conducted in your notes.
- LTM follows the writing stack principle.
    - The original record is not in your head but in your notes. Your notes become your second brain.
- When tasks become apparent, or when something is too cumbersome to handle within your notes (the Uncovered), it is best to rely on a different tool.
    - Even so, if your notes are well established, merely writing a task list in an appropriate note may be sufficient.
    - That said, a notebook has its limits (the Uncovered), so do not forget to use another tool when necessary.
    - Ultimately, for those with many appointments, it is inevitable to use a calendar—trying to cover everything in your notes is going too far.
