---
title: Strategies for Task Management
---

A strategy for task management refers to the approach or mindset you adopt when managing tasks—that is, your guiding principle regarding “what you base your work on.” As you can tell from a glance, strategies vary considerably in their nature. It is essential to use the one that suits you best. Moreover, having a larger “hand” (more available approaches) expands your range of application, so if you have extra capacity, it’s worthwhile to practice with strategies that you are not yet familiar with.

In this chapter, I will discuss each strategy in detail. For tools and methods, please refer to the [References](ref). This chapter will focus solely on the underlying ideas.

# Time-Based Strategies

Time-based strategies involve how you partition time and determine what to do in each segment. They are well suited for creating a clear structure and contrast in your day.

## Dailer

### Overview
Dailer is a strategy that views tasks on a “daily” basis.

In particular, it divides tasks into “today” and “everything else.” Once all of today’s tasks are completed, you consider the day finished. This prevents endless work and creates a clear cutoff, while also allowing you to postpone tasks that do not need to be done today until later. When tomorrow comes, you treat that day as “today” and repeat the process.

This concept is referred to as **Daily**; I call it the **Daily Area**. In addition to a Daily Task List that aggregates tasks for today, there are also Daily Pages or Daily Notes that apply to general information. Many mobile games even include daily quests. It is a familiar concept that many have encountered.

In other words, imagine there is an area called “today” where you place everything you intend to handle today. Ideally, you would complete everything, but there is no need to force yourself to finish every single item—it serves merely as a guideline. If you feel too tired, you can decide “I’ll do this tomorrow.” Of course, depending on the situation, there may be tasks that cannot be postponed, but ultimately, we are only human—fragile and lazy. Simply resetting each day on a daily basis is sufficient. Even that small degree of structure yields a remarkable boost in productivity compared to not partitioning your day at all. The day is the smallest natural unit that includes sleep—a “conveniently bounded unit” that works extremely well.

### Application: Dividing the Daily Area
How finely you subdivide your day is a matter of personal taste.

The simplest division is into two parts: “today” and “tomorrow and beyond.” If you want to keep a log (record) of what you have done, you might divide it into three parts: “today,” “tomorrow and beyond,” and “yesterday (the log).” If you are meticulous, you might even divide your day into “today,” “tomorrow,” “the day after tomorrow,” “three days from now,” etc.—essentially, in daily units like a calendar. For convenience, let’s call these divisions **Twin**, **Triple**, and **Infinity (Unlimited)**, respectively.

Fewer divisions result in simpler operations, but the “tomorrow and beyond” segment tends to become bloated. To prevent this—since to-do lists are notorious for becoming unwieldy—the Infinity division is preferable, as it allows you to specify exactly when tasks are postponed. For instance, you might decide “I’ll do this in about three days,” “a week later is fine,” or “I don’t have an immediate need, but I don’t want to forget, so let’s say in about 20 days.” For example, if today is 2024/05/01, you might assign tasks to areas for 05/04, 05/08, and 05/21. However, the more divisions you have, the more energy you must expend to decide when to postpone tasks (which can feel burdensome).

If you find Infinity too troublesome, you might reduce the number of divisions. Perhaps dividing your day into five parts—“today,” “tomorrow,” “this week,” “this month,” and “beyond”—would work. Let’s call this the **Quintuple** division. These are just examples; there are many other ways to partition your time, and you may experiment to find the division that best suits you.

Incidentally, as mentioned in the Triple division example, opinions also differ regarding logs. If you want to review what you have done, you should keep the log. On the other hand, if you find keeping records tedious or unnecessary, you can ignore it. If it becomes a hindrance, you may delete or discard it (especially when using analog means like a planner). There is also a certain appeal to having a history or diary, so I personally recommend keeping it.

### Pros and Cons
**Pros:**

- You gain the benefits of dividing your day into clear segments.
  - It creates a clear structure (e.g., “finish everything today and then stop”).
  - It makes postponement easier.
  - Daily logs are maintained, which makes reflection easier.

**Cons:**

- Minor maintenance is required every day.
  - You have to switch the “today area” and transfer its contents, etc.
- Decision-making costs during postponement or maintenance are high, consuming cognitive resources.
  - Especially at the start of each day, when you must review “yesterday’s daily area and the area for tomorrow and beyond” and decide what to leave in today’s area.

### Suitability
This strategy is best suited for people such as writers, creators, or freelancers—those with fewer scheduled appointments and more discretion. Such individuals must decide everything for themselves and also maintain input, idea management, and review of outcomes. Using the Dailer strategy allows you to determine and review what to do on a daily basis, making everything more manageable. It is also flexible, allowing for adjustments when your mood or circumstances change.

It is not suitable for those who rely heavily on calendars driven by appointments. Although Dailer might seem similar to a calendar approach at first glance, **Dailer presupposes that you have discretion in how you approach your tasks.** That is why you can adjust tasks by deciding, “I’ll do this in the afternoon,” or “I’ll postpone that until tomorrow.” In a strictly appointment-driven system, such adjustments are not feasible.

# Topic-Based Strategies

This strategy involves assigning a dedicated space to each task—such as one task per page—so that you can focus on each item in depth while preserving information over time. It is ideal for those who want to work on something continuously or “shelve” it for a later time.

## Issueist

### Overview
Issueist is a strategy that utilizes BTS (Bug Tracking Systems) such as [GitHub Issues](ref#github-issues).

As a brief note on BTS: It stands for Bug Tracking System, a tool originally designed to manage software bugs one by one with one ticket (or page) per task. Tools such as [Redmine](ref#redmine) or [Backlog](ref#backlog) are common in the context of project task management. GitHub also offers a similar feature called Issues, which has been refined to be particularly user-friendly for personal task management and is primarily used by engineers (※1). Nowadays, project task management typically involves alternating between a holistic view and detailed views (as described in [Alternate: Macro and Micro Views](project_taskmanagement#alternate%2F俯瞰と注視)), a concept that I believe originates from BTS.

Issueist is a strategy that uses a BTS to focus on both holistic and detailed views. Since each task gets its own page, you can focus on each one thoroughly. If you record information, you can recall the status even two weeks or a month later. Because text and images can be retained like in a chat, it is not difficult to document. Additionally, it offers holistic functions through flexible filtering and sorting. When properly operated, you can extract the necessary tasks from among hundreds or even thousands. In recent tools, many now also include board functions similar to [Kanban](ref#カンバン) (for example, GitHub also has a Projects board), which makes it easier for those who do not like list views to get an overview.

- ※  
  - 1 For example, imagine using a tool like Slack or Discord designed for team communication for personal use. Typically, such tools are too feature-rich and cumbersome for individual use, but GitHub was exceptionally smooth (especially in its early days), to the point where even engineers who are particular about usability were impressed. There is little doubt that GitHub has inspired many modern task management tools among engineers—I count myself among them.

### Application 1: How Strictly to Operate It
If you operate Issueist very meticulously, it essentially becomes full-fledged project task management. Applying such meticulous management to your entire personal life would be exhausting, and as noted in the [Oplan](#応用4%3A-オプラン) section, it could be mentally draining. However, if you apply it to specific major projects or tasks, it is acceptable. For example, on GitHub you can create repositories (which are equivalent to projects) for moving, writing a book, etc., and manage tasks meticulously within each repository.

You can also operate it more loosely. In my experience, I tend to lean toward the looser approach. I tend to throw in various tasks that I might not necessarily have to do but want to try—especially tasks related to brainstorming, research, or experimentation—and then process them sporadically. Although this means that the rate and pace of task completion are unstable, it still produces better progress than not managing anything at all.

The trade-off is that the looser approach is easier to operate, but task completion may be less stable, whereas the stricter approach results in smoother progress but is more tiring. You should choose according to your own temperament and the nature of your work.

A common compromise is to use the system as a “backlog.” You simply dump all the tasks you want to do in the future as Issues, and when you have spare capacity, you review the backlog and process them. When you are too busy, you simply ignore it. However, if you come up with a new task, you must not forget to add it. Once added, it will not be forgotten (although retrieving it is another matter). If you are concerned that tasks will be left untouched forever, you might perform a periodic inventory (e.g., weekly or monthly). Spending a few hours on a holiday morning reviewing your backlog and deciding what to do can be enjoyable.

Another approach is to use it like an inbox. In other words, your goal is to achieve a state of “inbox zero” on a daily basis by continually adding tasks as Issues, processing them, and closing them once done. This is akin to the Dailer method implemented via Issues. Even if not as extreme as Dailer, it can be useful to aim for Inbox Zero for at least part of your work or personal life.

### Application 2: Which Tool to Use
If there are no particular issues, GitHub Issues is likely the best choice. It naturally segments tasks by repository, operates quickly, and is superior in terms of flexibility and lightness.

If you are already accustomed to another task management tool (especially one oriented toward project task management such as a BTS), you might as well stick with that. In the end, Issue-based tools have little difference in functionality, and it comes down to familiarity and personal preference. However, note that for individual use, some of these tools may not be cost-effective.

In any case, these tools are generally advanced and intended for engineers, so beginners might find them challenging to adopt. For example, GitHub does not offer a Japanese UI.

### Pros and Cons
**Pros:**

- It is familiar to those already accustomed to BTS.
- It enables you to focus on both the overall view and the detailed view in a simple manner.

**Cons:**

- The barrier to entry is high for beginners.
  - Both the underlying concepts and the operational skills required by the tool are challenging.
- It is difficult to strike the right balance between strict management and flexibility.
  - You may end up defaulting to a compromise such as using a backlog, or it may become as ossified as a traditional to-do list.
- It is cumbersome to handle very small tasks or a large number of tasks.
  - Task operations can be labor-intensive, so you tend to manage only larger-grained tasks.
  - It is not suitable for tasks that require quick adjustments (e.g., managing only shopping-related tasks).
- Achieving a holistic view is challenging.
  - With filtering and sorting, you need to skillfully utilize priorities, tags, or labels.
  - With board views, you must frequently maintain the placement of task cards.

### Suitability
This strategy is likely best suited for those who are already comfortable with BTS. A good indicator is whether you know and can use GitHub Issues. It primarily applies to software developers. I say “likely” because even if you are accustomed to BTS, it is not guaranteed that the strategy of dedicating one page per task (topic-based segmentation) will suit you. Some may find BTS familiar but not a good fit.

It is also suitable for knowledge workers. These individuals often need to research or consider issues without a definitive answer, and Issueist allows them to accumulate their thoughts in a “one topic per page” format. This is especially useful for tasks that you want to capture in a rough manner rather than in detailed notes or documents. For example, it is easy to create a task like “think about …” (※1).

- ※  
  - 1 This tendency is characteristic of knowledge workers. Typically, the tasks they think of are either “things that come from external demands that must be processed” or “measures to prepare for future threats.” However, knowledge workers are those who want to generate new knowledge and build upon it—they might think “Even if nothing falls on me, I still want to think about it.” Relying solely on memory is not enough, and rough memos are often forgotten after one reading. But at the same time, they do not feel the need to engage in fully formalized task management. They often simply want to create an “area to think about …” that they can casually revise over time. BTS-based segmentation is exactly ideal for that.

## Topician

### Overview
Topician is a strategy that uses Wiki or note-taking tools.

It deals with “topics” (subjects) on a one-topic-per-page basis, including tasks. The main focus is on note management, with task management being integrated as a secondary function. There are various ways to take notes, but the philosophy of Topician is “one topic, one page.” For any topic A, you write on page A. Let’s call this **topic-oriented**. A topic-oriented approach prevents topics from becoming muddled or off-track; if you want to focus on A, you simply go to page A. It also facilitates concentration and resumption of work. Of course, this means you have to physically go to page A every time you want to work on topic A, but that extra effort is worthwhile. You can even maintain thousands of pages without them collapsing.

This strategy partially overlaps with other strategies. For instance, if you create pages titled “2024/05/01,” “2024/05/02,” etc., that would resemble Dailer, and if you manage only tasks, that would resemble Issueist. One might then think Issueist is sufficient, but Topician is not about task management per se—it is about writing notes. Task management is secondary. In fact, if you want to focus exclusively on a particular set of tasks, Issueist might be more appropriate (or Dailer if you want daily structure). Topician is chosen when you want to take notes for your own sake and accumulate them over time. The idea is to eventually work out a method to somehow incorporate task management into your note-taking. In a simple approach, you might tag lines you consider tasks with `#task` and then search for `#task` (using full-text search—often referred to as Grep in text editor contexts) when you need to see your tasks. This requires some knowledge of full-text search and the discipline to tag consistently, even in a simple method. Alternatively, you might use a “review method” where you periodically (daily or at some other regular interval) review your notes to extract tasks manually, or you might use a tool like [hown](ref#hown) that offers creative ways of displaying and linking entries, or even a “generative AI method” where you let AI analyze your notes and extract what you need. Like DIY, the possibilities for customization are endless, and there are likely many approaches that I have not encountered. The common denominator is that **advanced technical skills in programming or text editor customization are required.**

### Application 1: Which Tool to Use
Classically, Wikis such as MediaWiki or Pukiwiki are preferred. When you think of a Wiki, you might envision something like Wikipedia or fan-created game strategy Wikis that accumulate massive amounts of content collaboratively; however, Topician is about creating content solely for yourself—for your own benefit. However, traditional Wikis have the following disadvantages: the hurdle of self-hosting (i.e. having to set up your own server) and their limited functionality and extensibility, which restrict their ability to support effective task management. Let’s call these **first-generation** tools.

In recent years, the importance of note-taking tools akin to Wikis has grown, and more products in this category have emerged. There are commercial options such as Microsoft OneNote, Box Notes, or Dropbox Paper, as well as user-friendly tools geared toward engineers like esa.io or Qiita Team. Notion also falls into this category. Additionally, outliners such as Workflowy or Dynalist belong here. Let’s refer to these as **second-generation** tools. Second-generation tools are user-friendly as note-taking tools, but they still lack the flexibility required for full-fledged task management—or if they can support task management, they tend to evolve into something resembling project task management.

There is also a set of tools that might be called **third-generation.** Examples include [Scrapbox](ref#scrapbox) and [Obsidian](ref#obsidian). The hallmark of third-generation tools is their emphasis on linking; they make it very easy to create links between pages. In addition, features such as “a list of pages linking to this page” allow you to navigate related content, thereby enhancing your overall perspective. Third-generation tools view your entire note collection as a network—a paradigm shift in note-taking. Since network structures mirror the structure of the brain and naturally support recall, they are especially effective. Instead of filtering lists or maintaining boards, you traverse links to recall information. Although it is difficult to explain in words, once you experience it, you may find it addictive. Generative AI also mimics brain processes, which may explain why this paradigm is so natural. I believe it will become increasingly mainstream.

For task management, this approach forces a paradigm shift. In practice, it will likely rely on the “review method” mentioned earlier—regularly writing, re-reading, and transcribing your notes to continuously maintain the information related to your tasks. This discussion is fairly advanced and overlaps with Topician, so I will address it in a later chapter ([Literate Task Management](literate)).

Finally, let me summarize the characteristics by generation:

- **First Generation**
  - ✔︎ Has been familiar since ancient times.
  - ✖︎ Has the hurdle of self-hosting.
  - ✖︎ Lacks the capacity to support effective task management.
- **Second Generation**
  - ✔︎ There are many tools available, and you are likely to find one that suits you.
  - ✖︎ The sheer number of tools means you must experiment and choose carefully, and adoption may take time.
  - ✖︎ They still lack the flexibility required for effective task management, or if they support it, they tend to become more like project task management systems.
- **Third Generation**
  - ✔︎ Emphasizes a network paradigm through links, which is naturally easy to navigate and recall.
  - ✖︎ As a new concept, it may require extra effort for learning and adaptation.
  - ❓ When used for task management, it requires continuous maintenance of task-related information.

### Pros and Cons
**Pros:**

- It allows you to manage tasks as an extension of your note-taking.
- You can naturally integrate and interlink information and tasks, making it easier to acquire information and act on it.

**Cons:**

- Implementing task management itself is inherently difficult.
  - It may be an antiquated approach that relies on manual, manpower-intensive maintenance.
  - Alternatively, you may have to build your own system using programming or text editor extensions, which requires advanced skills.

### Suitability
This strategy is most suitable for those who habitually use digital note-taking methods. A good indicator is whether you primarily use a text editor for writing in your daily life. If not—for example, if you mainly use a smartphone or cloud-based tools—this approach is probably not suitable. In today’s world, only those who are exceptionally committed to using a text editor for task management will be successful.

It is generally not suitable for engineers or programmers. This may seem counterintuitive, but more important than your skill with editors or typing speed is whether you enjoy managing and revising your own text. Typically, engineers focus on technical coding rather than on the text itself. In that sense, bloggers or writers may be better suited.

# One-Place Aggregation

This is a strategy for aggregating tasks (and “object tasks”) in one place. It is suited for those who want to keep things simple and low-effort.

## Preliminary Knowledge: Object Tasks

First, some preliminary knowledge.

**Object Tasks** are those items that trigger the recall of a task or serve as the constituent elements of a task. For example, a “broken clock” triggers the task “repair the clock,” so the broken clock is an object task; similarly, a photo of your boss can remind you of a task that was assigned by that boss.

Whether something qualifies as an object task depends on one’s interpretation, and even the same person might interpret it differently depending on the situation.

The difference from a “task” is that a task is something that has been verbalized or documented. Whether it is in a planner or an app, it is something that is entered into a task management tool. This point was discussed in the [Axioms of Task Management](view_taskmanagement#タスク管理の公理). In contrast, object tasks refer to potential tasks that might arise from physical objects.

In this strategy, both tasks and object tasks are aggregated. To “aggregate tasks” means, for example, writing today’s tasks on sticky notes and sticking them on your display. To “aggregate object tasks” means, for example, placing objects that represent things you want to handle when you go out (such as a broken clock tied to a garbage bag, or a set of dress-up items for an after-work event) near the entrance. More precisely, it is the idea of establishing a rule like “if you want to handle something outside, leave it at the entrance” (rather than handling it on the spot).

# Repeating Strategies

This is a strategy that treats tasks as items you repeatedly engage with. It is well suited for people who want to respect their own rhythm.

## Preliminary Knowledge: Routine Tasks

**Routine Tasks** are tasks that you perform on a regular basis.

“Regularly” means, for example, tasks you perform every day, every other day, once a week, twice a day, etc.

Essentially, tasks can be regarded as routine tasks. For example, taking out the trash may be performed on a specific day each week; checking email or chat can be set as “twice a day.” Daily habits are a kind of routine task, and even tasks like “read a book” or “start a new activity” can be scheduled on a routine basis (e.g., “set aside time every three days”). 

The reason for introducing this somewhat complex concept is that it makes task management easier. Many task management tools include features to handle recurring tasks, and this strategy relies entirely on those features.

## Robot

### Overview
Robot is a strategy in which you create a detailed task list that, if followed exactly, will ensure your day runs smoothly.

Because most of your daily activities fall into routine tasks, a Robot task list contains many routine tasks. Since it is impossible to create such an ideal task list from the start, you gradually reveal it based on records and hypotheses. It takes a long time for this system to fully settle in—often much longer than a month.

For example, if I were to adopt Robot, I would create a task list that looks something like this. Routine tasks are marked with a 🔁 symbol, and their frequency is noted in parentheses.

```
5:00 🔁 (Daily) Wake up after sleep
5:04 🔁 (Daily) Use the bathroom, open the curtains, wash face
5:07 🔁 (Daily) Boil water, tidy up the mattress
5:10 🔁 (Daily) Bring coffee and bread to the desk
5:40 🔁 (Daily) Catch up on information, reply to community messages
5:50 🔁 (Weekdays) Prepare for work
5:50 🔁 (Tuesdays & Thursdays) Take out combustible trash
5:55 🔁 (Weekdays) Start remote work
6:10 🔁 (Daily) Check today’s calendar and set an alarm 10 minutes early
6:10 🔁 (Weekdays) Send a “work start” notification
6:10 🔁 (Weekdays, every other day) Input attendance data
6:10 🔁 (Weekdays) Read chat and email; convert items requiring action into tasks
6:20 🔁 Assemble today’s tasks ...
```

The content is very personal, so you may disregard the details; however, you should get the general atmosphere. As you can see, it consists almost entirely of routine tasks. Regular tasks appear only after 6:20 (the tasks generated after assembling what needs to be done today). Operating in strict accordance with a fixed routine makes you almost like a robot. It might seem pathological, but for me it is natural—it is merely a reflection of my daily rhythm. In fact, everyone has their own inherent rhythm, even if they are unaware of it. The Robot strategy explicitly captures this rhythm, converts it into a task list, and then endeavors to operate exactly according to that list.

The outcome is that Robot delivers a sense of continuous stability. If, in an ideal world, you could perfectly follow your own rhythm, then to achieve that, you must strive to “stick to it as much as possible.” That is precisely what Robot aims to do.

To implement Robot, you need a tool capable of handling routine tasks. It is not realistic to manually determine “what tasks should I do today?” every time. A tool that allows you to set frequencies for each task can automatically display tasks accordingly. In Japan, [TaskChute](ref#タスクシュート) became a pioneer in this field, and simpler tools like [Todoist](ref#todoist) can also be used. However, calendar-based tools are insufficient. Robot must handle tens of routine tasks per day and perform hundreds or thousands of operations, so if the tool isn’t lightweight enough, you will quickly become frustrated. For some people, even TaskChute or Todoist may not suffice; I, myself, once developed my own tool for Robot as an extension of Monolith (※1).

- ※  
  - 1 For details, see [Tritask](https://tritask.github.io/tritask-web/) and [todaros](https://github.com/stakiran/todaros). Both are text-editor-based tools for managing routine tasks. I have tried to document them so that others can understand, but they are not for everyone. This is partly because I am a text-editor enthusiast who lives entirely on a PC without a smartphone.

### Application 1: How Rigidly to Define It
With Robot, the extent to which you cover various aspects depends on your personal preference.

- **Time Slots:**
  - You might cover your entire day—from the moment you wake up until you go to sleep.
  - Alternatively, you may choose to handle only work hours or only personal time.
  - You could even choose to cover only the hectic time periods, such as before work and after work.
- **Tasks:**
  - Routine daily tasks like cleaning, shopping, and organizing that must be done regularly.
  - Daily habits and routines.
  - Communication and input tasks such as checking chats, emails, RSS feeds, or social media.
  - Standard work tasks during working hours.
- **Record of Execution:**
  - You might record when a task starts and ends (TaskChute does this).
  - Or you might simply record when a task is completed.
  - Or just mark whether it was completed or not.
  - Alternatively, you might not record at all—simply delete the task once it’s done (as in my todaros).
- **Order:**
  - The task list might require that tasks be completed in order from the top.
  - Alternatively, you may prefer that tasks are generally done from top to bottom but allow skipping.
  - Perhaps you display only today’s tasks (a daily task list), and then choose which ones to do based on your mood.
  - Or you might even abandon the list view entirely and simply allow tasks to aggregate for the day.

In other words, it depends on whether you apply the strategy to your entire life or only to a specific portion.

Applying it to your entire life is more of a hobby; you might choose Robot only for particularly troublesome time slots that you want to blitz through. It may also be suitable if you want to form a habit around something you want to achieve—but Robot is quite rigid, so if that is your goal Tracker might be a better choice.

### Application 2: Strong Robot vs. Loose Robot
When you think of Robot, you might imagine strictly following the task list, but that is not necessarily the case—you choose your level of adherence.

A style that follows the list strictly is called a **Strong Robot.** This provides excellent stability, but its inflexibility means that even a slight deviation can cause stress. It only works for a very select group of people—perhaps only one in twenty can operate as a Strong Robot. It is likely feasible only for those who have a strong sense of necessity and determination, or those who are naturally meticulous and exacting.

Alternatively, there is a style in which you maintain the task list but are more lenient about following it; we call this a **Loose Robot.** With a Loose Robot, you might think, “Today is trash day, but I’m feeling lazy, so I’ll postpone it until later” (and you still perform the action to postpone the trash task). A Loose Robot is not as stable as a Strong Robot, but it is more flexible, and while you might procrastinate, you are less likely to forget tasks, which is much easier on your mental state.

One might then ask, “Wouldn’t a Loose Robot be sufficient?” However, even a Loose Robot remains a Robot—it still demands a high degree of familiarity with the task management tool (and frequent operations) to work properly. In contrast, a habit tracker allows for a much more relaxed approach. Although setting up such a tracker from scratch is tedious, once it is in place you only need to check off completed tasks. This approach provides a balance whereby you can see what needs to be done without being overwhelmed.

### Application 3: There Are Various Rhythms Too
Robot is also a strategy to visualize your personal daily rhythm, and there are several aspects to this rhythm.

- **Timing:**
  - This concerns when you perform tasks.
  - For example, some people may find that taking out the trash works best at 6:00 AM, while others may prefer 9:00 AM.
  - Additionally, certain tasks have fixed constraints—for example, “please take out the trash by 8:30 AM.”
- **Frequency:**
  - Routine tasks can be scheduled “once every n days.” You determine the value of n.
  - For instance, I check my email once every two days (n=2), but some might prefer to do it daily.
  - If you need to perform a task multiple times a day, you can duplicate the routine task.
    - For example, if you want to check email three times a day, you create three routine tasks with n=1.
  - Frequency may also be governed by constraints (as often happens in practice).
    - In remote work, you might be required to check in daily, which is effectively a daily routine task.
- **Capacity:**
  - This pertains to how many tasks you can cram into your schedule.
  - Each person has their own quirks and limits in terms of motivation and cognitive resources; ignoring this can lead to an unsustainable task list.
    - For instance, if the “laziness” factor kicks in and your task list becomes filled with unchecked items, you might begin to “forget” tasks.
  - For example, I have a routine task for “catching up on industry news” that I do every three days because doing it more frequently would be too demanding.
    - But if you reduce the frequency too much, it might become a hassle and the task list could collapse.
    - I found that n=3 works well for me (though I sometimes skip, so in practice it might be every 4–5 days).

It may be hard to determine your rhythm immediately, but you should fine-tune it through a process of hypothesis and verification. In your task management tool, set an initial value for n and then adjust it based on actual performance. For example, if n=2 is too frequent, increase it to n=3; or if tasks A, B, and C are scheduled for the morning (n=1) but you find C too burdensome, you might move it to the afternoon and set its frequency to n=2, and so on.

**Your ability to perform such micro-adjustments fluidly will be the critical threshold for successfully adopting Robot.** If you find it too burdensome or unsustainable to make constant adjustments, then you should re-examine your tool. Next, recall [Trement](view_personal_taskmanagement#トレメント) and try to train yourself by enduring it. If that still doesn’t work, then you’re probably not suited for Robot—after all, Robot is a strategy that is very selective, and it is not surprising if only a few people can truly make it work.

### Pros and Cons
**Pros:**

- It enables you to live a stable life in accordance with your own rhythm.
- It provides reassurance by ensuring that all your tasks appear at the appropriate frequency.

**Cons:**

- The barrier to entry is extremely high.
  - It requires selecting the right people, and the process to achieve stable use is lengthy.
- It means committing yourself to a lifetime of continuous micro-adjustments.
  - I, myself, was a Robot for a time but eventually (partially) abandoned it because it was too exhausting.

### Suitability
This strategy is best suited for people who live in a fixed, orderly rhythm.

It is also appropriate for busy business people who juggle work with household and childcare responsibilities. Although it might seem counterintuitive, such individuals tend to have a fixed routine (even if only due to extreme busyness). If they can visualize their rhythm and adhere to it, that can serve as a “model answer” for daily life—preventing slacking off and making it a game of “how well can I stick to the plan.” The challenge is whether these people can even find the time to start Robot or operate the tool. For that, off-board actions as described in [Partner Task Management](partner_taskmanagement#盤外戦) may be necessary. Another hurdle is that you might not always be able to sit in front of a PC, so you must either create an off-board system that lets you work from wherever you are or become proficient enough to operate it on a smartphone. With effort, analog methods such as using a planner or bulletin board may also work.

This strategy is not suitable for people who cannot adhere to plans—those who are naturally hyperactive or slovenly. As mentioned earlier, the essence of task management is Trement, meaning that you must execute what you set out to do faithfully, and Robot requires this more than any other strategy; if you cannot, then it is simply not for you—and such people probably wouldn’t even consider trying.

# Self-Reliance: Trusting Your Own Mind

This is a strategy aimed at minimizing your reliance on tools. It is for people who prefer not to be burdened by the minutiae of task management tools.

## Inboxer

### Overview
Inboxer is a strategy in which you use only an inbox—a place to accumulate uncompleted items—for task management.

Instead of establishing an entirely new tool or method, you simply appropriate an existing communication tool or part of your environment to serve as an inbox. For example, this could be your email inbox, the bookmark function in your browser or chat tool, or a space where you temporarily store documents to be processed later. In the case of the last example, rather than meticulously creating drawers or trays, you designate some appropriate space as an inbox. In reality, there is not just one inbox; multiple inboxes may exist as needed. The goal of Inboxer is to achieve [Inbox Zero](ref#インボックスゼロ)—to process everything until the inbox is empty.

Inboxer is extremely rational and, in fact, you might not even realize that you are engaged in task management. In your work or daily routine, you simply mark items as they come along in your usual channels with minimal effort. This reflects a delicate balance: you have absolute confidence in your own mental ability, yet you know that you cannot possibly remember or properly prioritize everything, so you seek a shortcut. As a result, you simply mark items with the press of a button rather than writing lengthy memos. 

### Application 1: Differentiating from Calendarer
Inboxer is typically adopted by busy people. There is another strategy for busy people called Calendarer, and it can sometimes be challenging to distinguish between the two.

The key point is whether your calendar is part of your natural flow—i.e. a place you pass by multiple times a day. In this case, it depends on whether you naturally check your calendar repeatedly throughout the day. If you do—and if you also need to manage appointments—then Calendarer is necessary (in short, a calendar is indispensable). In such cases, you might even treat your calendar as an inbox. For example, if you add tasks that you plan to do later during a time period when you do not normally check your calendar, then that time slot acts as an inbox, which you then aim to empty.

### Application 2: Active Lazy
The foundation of Inboxer is to stick with the “existing” flow. You do not create a new inbox or a new task management system. For example, if you use Slack, X, and Discord, then your existing flow consists solely of those three, and you build your inbox using only their functions. You don’t also use a planner for task management or take notes in Notion. (Some might say, “Why not build a new system and make it your flow?” but that is not your style.) For such a person, the flow is strictly these three tools, and they will not add any new ones.

In this sense, an Inboxer can be described as “Active Lazy.” Active Lazy means that you respect your natural, delicate balance and do not wish to burden yourself with additional systems. 

### Application 3: How Much to Rely on External Forces (The Power of Place and People)
*This discussion is not directly about inboxes, but it fits well with the topic.*

An Inboxer is naturally Active Lazy and dislikes excessive task management. While it is fine to manage tasks on your own as an Inboxer, it is also acceptable to delegate them externally. You can rely on other people or on your environment to take care of things—in other words, you “outsource” your effort. (Note that this is distinct from hiring a secretary.)

How much you choose to rely on external forces is a matter of personal preference. Broadly, there are four patterns:

- **Closed Delegator:**
  - This person prefers to rely on others.
  - They delegate tasks to a trusted, small group (usually one person).
  - This is a well-known concept—delegating to a secretary, an assistant, a manager, or a partner.
- **Open Delegator:**
  - This person prefers to rely on the environment.
  - They make their information widely available within the organization, expecting that someone will pick up or intervene as necessary.
  - This approach is sometimes adopted by CEOs in modern, teal organizations.
- **Closed Dictator:**
  - This person prefers not to rely on others.
  - They gather all information themselves and make decisions independently.
  - They favor closed methods such as meetings with only the involved parties or direct messages that only selected individuals can see.
  - Although they may occasionally speak in public settings, they generally only issue directives.
- **Open Dictator:**
  - This person also prefers not to rely on others.
  - Like the Closed Dictator, they make decisions independently; however, they use open methods, such as public chat channels or mailing lists.
  - Although this might appear delegatory at first glance, in essence they decide for themselves and determine how to react.

As an Inboxer, choose the method that best suits you. Methodologically speaking, the open approach is superior; a closed approach can lead to information gaps and office politics, making it harder in the long run to attract top talent. Inevitably, there will be some struggles.

For those who interact with an Inboxer, it is best if you can operate in a manner that suits you. A closed Inboxer may be less tech-savvy and prone to endless meetings and political maneuvering. If you can win them over, it’s heaven; if not, they become a source of stress. Additionally, since closed systems tend to impose more restrictions, work-life balance may suffer. An open Inboxer is fair, transparent, and casual, but may also lead to intense debates and strong personal convictions—if you fit with that style, it can be wonderful; if not, it may feel like hell.

### Pros and Cons
**Pros:**

- It is the only strategy that truly respects the “Active Lazy” temperament—a delicate balance.

**Cons:**

- It is a people-selective strategy and may be difficult to adopt.
  - It requires someone with an Active Lazy temperament, high cognitive ability, and the capacity to stick to existing flows.
- Its responses tend to be ad hoc.

### Suitability
This strategy is most suitable for people in positions of authority—such as CEOs, organizational leaders, or decision-makers—who naturally adopt this strategy even without external prompting.

It is also suitable for freelancers or others with a high degree of discretion and few restrictions (Rapid Multitaskers). However, because it relies on ad hoc responses, such individuals may end up overburdening themselves and suffering chronic stress.

It is not suitable for those who are not Active Lazy.

It is generally not suitable for creative individuals like researchers, writers, or artists. (Though there may be exceptions if such individuals have the capacity to handle ad hoc tasks effectively.)

# Summary

- A strategy is the guiding approach or mindset regarding how you wish to manage tasks.
- It can be classified based on “what you base your approach on.”
- ===
- **Time-Based Strategies**
  - For those who want to create structure.
  - **Dailer:** A strategy that divides tasks into “today” and “everything else,” focusing on what to do today.
  - **Calendarer:** A strategy that uses a calendar to turn tasks into appointments, effectively making you a scheduling machine.
  - **Slotter:** A strategy that creates time slots (sections) and determines what to do in each.
  - Key term: [Oplan](#応用4%3A-オプラン)
- **Topic-Based Strategies**
  - For those who want to work on or “shelve” projects over the medium to long term.
  - **Issueist:** Uses a bug tracking system.
  - **Topician:** Uses Wiki or note-taking tools.
  - Key term: [Topic-Oriented](#概要-4)
- **One-Place Aggregation**
  - For those who want a low-effort approach.
  - **Richild:** A strategy that gathers object tasks in one place.
  - **Monolith:** A strategy that aggregates tasks, especially by writing everything in a single text file.
  - Key term: [Object Tasks](#前提知識%3A-物タスク)
- **Repeating Strategies**
  - For those who want to respect their own rhythm.
  - **Robot:** A strategy that creates a strict task list and follows it precisely.
  - **Tracker:** A strategy that puts tasks into a habit tracker and performs them as routine tasks.
  - Key terms: [Routine Tasks](#前提知識%3A-ルーチンタスク), [Habit Tasks](#概要-8)
- **Self-Reliance**
  - For those who prefer not to be burdened by tools or management.
  - **Inboxer:** A strategy that uses only an inbox (a place to accumulate uncompleted items) based on your existing flow.
  - Key term: [Active Lazy](#応用2%3A-アクティブレイジー)
