---
title: 📘Part 5 "Advanced Task Management"
---

We will cover some concepts and methods of advanced task management.

In particular, we will focus on text-based methods. The tasks involved in task management are "written in language," and successfully handling this—namely text—is key to success. However, as we've seen so far, you can generally get by using simple methods and existing tools. Users don't often consciously think about "text," which is a computer-centric expression, because ways and tools have been developed to avoid such concerns. On occasions when these tools aren't sufficient, you have no choice but to create your own. You'll develop your own task management, by yourself and for yourself. While it's true that non-programmers typically can't create tools, by being inventive in handling text, you can create something to a certain extent. In this chapter, we'll provide tips on how to skillfully domesticate text and create your own task management system. In the latter half, we will propose new task management approaches that transcend conventional management to realize new ways of working.

Although this chapter assumes a digital environment, the fundamental ideas are theoretically applicable to analog systems as well. For example, it could be beneficial for someone who uses a notebook and pen for task management and wants to create their own task management system. However, it would be challenging as it assumes the convenience of digital solutions. This chapter does not anticipate realization through analog means.
