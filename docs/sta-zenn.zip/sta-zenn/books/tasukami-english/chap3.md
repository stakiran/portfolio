---
title: 📘Part 3 "Things That Seem Like Tasks but Aren't"
---

There are several things that seem like tasks but aren't. A clear example of this is "schedules" or "notes." Treating them as tasks doesn't work well, and handling them requires some ingenuity.

In this book, we refer to such things as [Altasks](view_taskmanagement#Distinguishing Between Tasks and Non-Tasks). From here, we will take a closer look at the main Altasks and how to handle them.
