---
title: Interruptions and Digressions
---

One of the reasons why task management doesn’t go smoothly is that tasks are not executed in a fluid manner. There are many possible reasons for this lack of smooth execution, but it often involves what we call “warp”—the combination of interruptions and digressions. In this chapter, we will confront this phenomenon of warp.

# Overview of Warp

## Interruptions
When you are diverted from your task because of interference from the outside, that is called an **interruption**.

Although we say “external,” **interruptions are often caused by people.** For example, someone might speak to you, approach you, or impose their presence through their gaze or body language. When you are interrupted, it becomes a situation you cannot (or find it very hard to) ignore as a human being, forcing you to deal with it.

## Digressions
When you stray off course on your own, that is called a **digression**.

**Digressions occur when you give in to the temptation of “information.”** This information can be anything—from the ambiance of your surroundings, the tools and equipment nearby, or content you’re viewing on your smartphone or PC, to even something that just pops into your mind. When you let yourself be drawn away by such information, it becomes a digression.

The boundary between interruptions and digressions is blurred. For instance, if you receive a notification for a direct message (DM) in a chat, whether it counts as an interruption or a digression depends on the person. Someone who feels as if they are being spoken to face-to-face may regard it as an interruption, while someone who thinks “I can deal with that later” sees it as mere information (although if you succumb to the temptation to reply, that becomes a digression).  
Furthermore, to put it in extreme terms: if someone has the mental fortitude to ignore others even when they speak to him, then the very notion of an interruption hardly applies. However, if the interference is physical—say, a loud voice or a shoulder tap—you will undoubtedly notice it. As a rough guideline, **if you can ignore even an initial comment or response, it is a digression; if you cannot, it’s an interruption.**

## Warp
We collectively refer to both interruptions and digressions as **warp**. The term conveys the idea that while you are concentrating on a task, something else pulls you away. When you’re pulled away by external interference, it’s an interruption; when you pull yourself away, it’s a digression.

## Warp Can Be Both Beneficial and Detrimental
Warp is not inherently a bad thing. For example, if it involves an emergency response or advice from an expert, being interrupted might actually lead to better outcomes. Even in non‑urgent situations, a colleague’s interruption might help clear your head by sparking a brief discussion or shifting your focus to another task, thereby lifting your mood. Likewise, when you’re simply looking to kill time, allowing yourself to digress can stave off boredom, and during brainstorming sessions or the early stages of a discussion, digressions may even be welcomed.

That said, when you’re in the middle of executing a task, every interruption typically results in a loss proportional to the amount of interference. We refer to these situations as **conquest scenarios**. In a conquest scenario, being warped (i.e. interrupted or digressing) is problematic.

One important point is that what exactly constitutes a “conquest” can vary from person to person. In particular, whether you rely on a “conquest” approach or not is a matter of personal style (or even one’s mental model). For the same task, person A might view it as a conquest while person B might not. Let’s call person A the “conquest type” and person B the “defense type.” In a workplace dominated by defense types like person B, interruptions will likely occur frequently—making it hard for someone like person A who prefers the conquest approach. Conversely, in a workplace where conquest types are in the majority, interruptions may be rare, but defense types like person B might feel isolated; moreover, if they depend on interruptions to become energized and perform at their best, their overall productivity may suffer due to the lack of such stimuli. This may be one reason why many have experienced such challenges since the shift to remote work.

## Why Is Warp Detrimental?
As mentioned earlier, interruptions cause a loss equivalent to the time they steal from your task. More specifically, there are two major drawbacks.

The first drawback is that overall performance is reduced. For instance, if you could dedicate a full hour to a task versus only 35 minutes because of several interruptions, the full hour will yield much better performance on a simple calculation. In other words, the uninterrupted hour represents your baseline performance, while the interrupted time reflects a deficit.

The second drawback is that warp triggers context switching. (As discussed in the previous chapter on [Load Context](context#ロードコンテキスト), when you work on a task you must keep in mind the context of what you have done so far.) When warp occurs, that context becomes muddled. Even people with strong cognitive abilities may be able to hold onto their context—and thus engage in what we call multitasking—but it is still disrupted. In reality, this imposes a heavier burden than you might expect; you have to switch multiple times—from the current task to the warp task and then back again. This is surprisingly exhausting. In extreme cases, another warp may occur even before you have finished switching back. It really can become a chaotic, exhausting process.

Between the performance loss and the disruption caused by context switching, which is worse depends on the situation. However, since we are human and our cognitive resources and capacities are limited, the cost of context switching is usually the more serious issue. When warp occurs frequently and context switching happens over and over, you quickly become exhausted. Not only does the efficiency and quality of each task suffer, but you also have no spare capacity to improve or innovate—leaving you overwhelmed and constantly busy. I believe that this is why, despite long hours, productivity can remain low or why methods and thinking sometimes fail to update even in modern times. We tend to underestimate the power of warp. We are fragile creatures with limited cognitive stamina; that is why it is essential to confront warp in order to minimize our exhaustion.

Of course, this isn’t to say that productivity and constant improvement are always absolutely necessary. If you don’t need them, you might simply choose to ignore warp. But in business—and even in personal life if you repeatedly follow the same routine—there comes a point when you grow tired of it. In our VUCA (volatile, uncertain, complex, and ambiguous) world where the future is unpredictable and change is constant, it is best to free up your resources for progress and change. And the primary way to do that is by managing and preventing warp.

# The SWAP Matrix

How you handle warp can be organized in a matrix.

|                           | **Strong Postponement** | **Weak Postponement** |
|---------------------------|-------------------------|-----------------------|
| **Active (Interruption)** | 1                       | 2                     |
| **Passive (Digression)**  | 3                       | 4                     |

We call this the **SWAP Matrix**.

You might notice the term “postponement” here. In a situation where warp occurs—when task B interrupts you while you’re working on task A—you must postpone one of them. If you postpone A (the task you were originally doing), that is called **weak postponement**—expressing that you’ve “lost” to the warp. Conversely, if you postpone B (the incoming task), that is called **strong postponement**—meaning you defend task A by not yielding to task B.

In other words, the SWAP Matrix splits the ways of handling warp into two dimensions—the nature of the interruption/digression (active vs. passive) and the type of postponement (strong vs. weak)—yielding a total of four patterns.

## Coping vs. Prevention
Before discussing each pattern in detail, let’s clarify the difference between coping and prevention.

Coping means taking action when warp occurs. Specifically, you have the choice to either continue with the current task A or switch to the warp task B. Choosing to continue with A corresponds to strong postponement, while switching to B corresponds to weak postponement. In other words, coping always involves postponing one of the two tasks. (While it is not entirely impossible to multitask, the SWAP Matrix does not cover that possibility.) You must always choose one, and (at least temporarily) set the other aside.

Prevention, on the other hand, means preparing in advance so that warp either does not occur at all or occurs in a way that allows you to react immediately. For example, if you want to use strong postponement for interruptions (i.e. you want to postpone task B and avoid being interrupted), you set up measures so that interruptions are unlikely to occur. This might even involve distancing yourself from people who tend to interrupt. Conversely, if you want to use weak postponement for interruptions (i.e. you want to give priority to task B), you might encourage others to notify you immediately when something happens—even during a meeting—or set up alarms or lower thresholds so that notifications trigger more readily.

From here on, we will discuss each of the four patterns, addressing both coping and prevention for each.

## 1. Active Strong
Active Strong refers to employing strong postponement in response to interruptions. In other words, if task B interrupts you while you are engaged in task A, you say “No, I’ll continue with A” and postpone B.

Regarding coping and prevention in Active Strong:  
- **Coping:** You strive to make it as easy as possible to practice strong postponement.  
- **Prevention:** You take measures so that interruptions are less likely to occur in the first place.

In Active Strong, prevention should be prioritized because there are only limited things you can do once an interruption occurs. The simplest coping measure might be to refuse or delay the interrupter even if it upsets them, but this often involves difficult interpersonal negotiations and assertiveness—which can lead to conflict. In most cases, the person interrupting is either more powerful or at least equal to you, making it hard to say “no” both psychologically and socially. Even if you do act, the other party may not accept your refusal. Thus, if you want to cope by rejecting interruptions, you must be ready to offer an impromptu, persuasive explanation that satisfies the other party. This involves skills in communication, negotiation, and even persuasion—topics that are beyond the scope of this book (and, frankly, I’m not very good at them myself).

For prevention in Active Strong, there are three main strategies:

- **Attack:**  
    - Directly engage with the source of the interruption.  
    - ⭕ If successful, this can dramatically reduce interruptions.  
    - ❌ However, it often requires confrontational interpersonal exchanges and can quickly become contentious.
- **Escape:**  
    - Change your environment (your location or even your organizational affiliation) so that interruptions are less likely.  
    - ⭕ It is better than doing nothing.  
    - ❌ This is only a temporary fix; if it doesn’t work, you may need a more permanent change (such as a transfer, a job change, moving, or even “fleeing”).
- **Guard:**  
    - Appoint a dedicated person or set up a specific contact point to handle those who would normally interrupt you.  
    - ⭕ This way, you aren’t bothered by interruptions.  
    - ⭕ It is generally easier to implement than extreme measures like Attack or Escape.  
    - ❌ However, recruiting and setting up a guard can be challenging, and it places a heavy burden on that person.  
    - ❌ Additionally, important information may be modified or filtered by the guard (i.e. you get second‑hand information).

Typically, you might first try Escape—creating distance—and if that fails, you move to Attack, engaging directly. Although a subtle or “mild” attack (making suggestions gradually during everyday conversations or meetings) is possible, in my experience the tendency for people to interrupt rarely disappears on its own because it is often rooted in their personality or circumstances (as noted earlier in the discussion of conquest versus defense types). Thus, if you choose to attack, you should be prepared for a strong, uncompromising approach—even though doing so may cost you status or other benefits. If that is unacceptable, you might try to gather allies and mount a collective attack, but if you can easily gather allies, you likely wouldn’t have the problem in the first place. (This and other topics are beyond the scope of this book.)

If both Escape and Attack are too difficult, then Guard might be a viable option. In business, for example, it is common to divide roles or establish official contact points, which can be presented in an acceptable format. The problem then becomes whether you have the resources (time and money) to recruit someone for the role or set up the necessary system. If the interrupters are particularly troublesome, you might even consider designating someone in the team as a “barrier.” Ideally, that person should be dedicated solely to that role rather than juggling it alongside their regular duties—otherwise, they will be overburdened. In short, Guarding is an investment, and its feasibility depends on how much you are willing (and able) to invest. This judgment applies both at the individual level and at the team level.

## 2. Active Weak
Active Weak means employing weak postponement in response to interruptions. That is, if task B interrupts you while you’re working on task A, you immediately accept B—saying “Understood”—and temporarily set aside A.

For Active Weak, regarding coping and prevention:  

- **Coping:** The goal is to make it as easy as possible to adopt weak postponement.  
- **Prevention:** Rather than trying to prevent interruptions from happening, you actually set up systems that encourage interruptions to occur quickly and frequently, so that when they do arrive, you can respond without hesitation. Although this might sound counterintuitive, Active Weak is useful when you want to give priority to the interrupting task B. In such cases, it is vital that B is executed quickly and reliably. Thus, it is beneficial if interruptions come in frequently (ideally immediately) and if you are ready to act as soon as they arrive. In Active Weak, “prevention” means establishing mechanisms that make it easy for the interrupter to reach you.

### Coping in Active Weak
When coping in Active Weak, two key aspects are essential: releasing your concentration and minimizing the cost of context switching.

First, “releasing your concentration” means that when task B interrupts you, you need to be made aware of it. When you are deeply focused on task A, you might not notice minor interruptions at all. To remedy this, you can instruct those who might interrupt you to alert you in a specific way if they notice you aren’t responding—for example, “if you see that I haven’t noticed, please shake my shoulder” or “press the call button on my desk.” Also, since there are many situations in which the person who might interrupt is reluctant to do so (say, a subordinate hesitating to interrupt a “busy boss”), you should set up a means for them to interrupt you even in such cases (for instance, by sending you a direct message via chat, or by declaring that they may interrupt even during a meeting if something urgent occurs).

Next, minimizing the cost of context switching is critical. (As discussed in the previous chapter on [context switching](context#ロードコンテキスト), when you practice Active Weak your workflow typically follows this pattern:)

1. You work on task A.  
2. Task B interrupts you → you switch to task B.  
3. Once task B is completed, you return to task A.

In steps 2 and 3, you undergo context switching twice—first switching your focus from A to B, and then back from B to A. As mentioned earlier, context switching is very fatiguing. When you become tired, the switching process takes longer, thereby reducing the speed and quality of executing task B (or of resuming task A after B). In extreme cases, you may forgo the proper context switch altogether and resume work without re-establishing the context—leading to errors and further inefficiencies. To mitigate these negative effects, you have two options: either reduce the inherent cost of switching or build in a buffer (a “transition period”) that gives you extra time to switch. For example, if an unexpected meeting (task B) interrupts your work on task A, it might be better to wait for about 15 minutes before starting B rather than diving in immediately. Although it may feel as if you should start immediately because the interruption seems urgent, inserting a deliberate buffer can significantly improve the execution and quality of task B. (This is analogous to the “lumberjack’s dilemma” where a lumberjack with a dull axe should take the time to sharpen it before chopping wood—but often claims he’s too busy to do so.) Even though it seems counterintuitive, unless the situation is extremely urgent, I recommend that you consciously insert a buffer.

Another way to reduce switching cost is to preserve the context of task A. If meeting B interrupts your work on task A, take a moment to externalize what you were doing or thinking about—whether by jotting a quick note or taking a screenshot of your screen. This way, when B is finished and you return to A, you can quickly recall your progress and resume where you left off. This simple step can greatly reduce the cognitive cost of context switching compared to relying solely on your memory.

### Prevention in Active Weak
Now let’s discuss prevention for Active Weak. In this context, prevention means ensuring that the interrupting task B can be handled reliably and promptly—that is, preventing any delays or hesitations that might undermine its execution.

There are two general strategies for prevention here:

1. **Make Interruptions More Likely:**  
   You can set up mechanisms that encourage interruptions. For example, as noted above, instruct others to “speak up immediately if anything happens,” or increase the intensity of notifications if you have a system for that. If you don’t fully trust the interrupters, you might actively monitor them yourself or enlist someone else’s help. Of course, you cannot respond to every interruption, so you must eventually set priorities. The optimal balance must be found through gradual fine‑tuning; otherwise, the system becomes inflexible. A familiar example is in hierarchical organizations during emergencies, where sometimes lower‑level staff might deliberately withhold reports, or the many layers in the reporting chain can cause delays. Both situations result from a lack of fine‑tuning. Ideally, the balance of how and when to allow interruptions is unique to each person and organization—a balance that is continuously refined.

2. **Stay Nimble:**  
   Ensure that you remain agile so that when you are interrupted, you can act immediately. Although it might sound abrupt, it is said that the top leaders of yakuza groups remain unoccupied so that they can move instantly when needed (see [ref#23]). Similarly, in the manga *Left-Handed Eren*, there’s a line that goes, “Old men are free because young men are busy fumbling around.” Even among office workers, you may notice that senior executives—who often seem leisurely—spring into action immediately during an emergency. While being nimble doesn’t automatically equate to being highly effective, it is a fact that those who are more agile can respond more quickly. In situations where Active Weak is desirable, it is crucial that you arrange your schedule and habits so that you can react promptly to interruptions. (Of course, you cannot be so idle as to do nothing, because then you won’t be able to switch contexts effectively when an interruption occurs. But at the same time, if you hold too many catch‑up meetings or stop people arbitrarily to check in, it can become annoying for them. Striking the right balance is challenging.)

## 3. Passive Strong
Passive Strong means using strong postponement in response to digressions. In other words, if temptation B appears while you are working on task A, you resolutely decide “No—I won’t get sidetracked by B,” and you postpone B. This is about overcoming the lure of temptation.

Passive Strong, too, involves both coping and prevention.  

- **Coping:** Here, coping means continuing with task A without giving in to temptation B.  
- **Prevention:** This involves taking steps to ensure that temptation B does not arise in the first place. As with Active Strong, prevention is the key because there is little you can do in the moment if you succumb; the only common advice is “have a strong will.” If willpower alone were sufficient, you wouldn’t struggle—but for many, willpower isn’t enough.

Thus, it all essentially comes down to **how well you can prevent temptation.** There are two general strategies:

1. **Strengthen Your Will:**  
   This means working on your motivation and emotional resilience on a daily basis. For example, you might regularly engage in tasks that naturally inspire you, remind yourself frequently of the people who support you, or take care of your physical and mental health (what in some traditions might be called “regulating your energy”). These efforts must be persistent and unglamorous. The key points are that (a) humans are inherently emotional and responsive to non‑verbal cues, so you should surround yourself with plenty of positive influences, and (b) rather than trying only to create motivating work, you should adopt a mindset of “avoiding work that does not energize me.” In other words, **focus on avoiding negatives rather than merely gaining positives.** (This is similar to the “Minimize Negatives” concept discussed in the [Stance](stance#minimize-negatives-を地で行く) chapter.)  
   
   If you neglect this aspect, you will never build the resilience to resist temptation—those who claim willpower is useless are often simply neglecting these basic habits. Of course, some people (for example, those with ADHD or certain mental health conditions) may find it inherently more difficult to rely on willpower.

2. **Change Your Environment:**  
   Prevent temptation by modifying your surroundings. For instance, if your home is full of distractions, you might choose to study in a café; if you’re at school or work, the presence of other people and the ambient atmosphere can help you focus. (This idea was also mentioned in the [Reminders](dousen_and_remind#雰囲気リマインド) chapter.) The key is to reduce both the physical and mental “costs” of reaching for temptation. For example, consider an employee who loves alcohol and—even though they know drinking during remote work is a bad idea—struggles to resist the temptation to drink. If that person were to work in an office, the physical effort required to obtain alcohol (plus the social pressure of colleagues watching) might prevent them from indulging. On the other hand, in a startup or a self‑run restaurant with high freedom, such measures might not only be ineffective but could even backfire as colleagues join in the fun.  
   
   Because the ideal environment to reduce temptation is highly individual, you must experiment with different settings until you find one that works for you. In the early stages, you might need to try out several different environments to get a feel for what keeps you on track. This requires the vitality to explore different settings and the commitment to maintain a healthy body and mind. (This, too, is one of those down‑to‑earth conclusions that seems obvious but can be surprisingly difficult to implement.) Also note that as you age or your life circumstances change, your ideal environment may also change. Rather than finding one perfect setting and sticking with it for life, it’s better to cultivate the flexibility to seek out a new environment when needed.

## 4. Passive Weak
Passive Weak means employing weak postponement in response to digressions. That is, if temptation B appears while you’re working on task A, you immediately set aside A and follow B—essentially, you chase after the temptation.

In Passive Weak, **coping** simply means switching immediately to B.  
**Prevention** in this case involves doing things that, paradoxically, encourage temptation to occur. (This might sound confusing, but it refers to situations such as brainstorming or idle activities where you let your mind wander until you hit on “that one great idea.”)

Regarding coping in Passive Weak, there is very little you can do because if you do nothing, you naturally give in to temptation. Thus, as with the other cases, prevention is key.

There are two broad strategies for prevention here:
1. **Diminish Situations Where You Can Easily Resist Temptation:**  
   For example, if you’re so immersed in task A or if A is so important that you naturally ignore anything else, you won’t be susceptible to Passive Weak. In such cases, the advice would be “don’t be so hyper‑focused” or “don’t take on tasks that are excessively important.” Since you can’t control over‑concentration solely through willpower, you might create deliberate disruptions in your focus or work in environments that make deep concentration more difficult—in effect, imposing constraints on yourself.
   
2. **Increase Opportunities for Temptation:**  
   This can be done either passively or actively. The passive approach is simply to put yourself in places where there is plenty of distraction—such as browsing the Internet or playing games. These methods require little effort but are easy to become addicted to. The active approach, on the other hand, involves seeking out stimuli intentionally—exploring, searching for “that one thing” that sparks an idea. In artistic contexts, this might mean immersing yourself in experiences and waiting for inspiration, or in creative contexts, taking time to relax and let ideas flow naturally. The active method is much more demanding in terms of focus and skill, and it requires a strong purpose or motivation as well as considerable perseverance in the absence of a clear “correct” answer. Although challenging, if mastered it can be very powerful.

## Summary of the SWAP Matrix
How to handle warp can be categorized using the SWAP Matrix.  
Fundamentally, there are two ways to deal with warp: coping (taking action when it occurs) and prevention (preparing so that it either does not occur or occurs in a manageable, automatic way).  
The four patterns of the SWAP Matrix are as follows:

- **1: Active Strong** - employing strong postponement in response to interruptions.
- **2: Active Weak** - employing weak postponement in response to interruptions.
- **3: Passive Strong** - employing strong postponement in response to digressions.
- **4: Passive Weak** - employing weak postponement in response to digressions.

To summarize further:

- **Dealing with Warp:**  
    - There is always the concept of postponement—you must choose to discard either A (weak postponement) or B (strong postponement). One of them is always postponed.  
    - The nature of the interruption or digression, and the strength of the postponement, can be arranged along two axes. This gives rise to the SWAP Matrix—a four‑pattern classification of how to deal with warp.
- **Coping with Passive Strong (i.e. not giving in to temptation when faced with a digression) is particularly challenging:**  
    - (1) **Explicit Attention:** Maintain focus by continuously writing down your tasks and thoughts.  
    - (2) **Stabilizing Your Daily Rhythm (Rhythm Reminders):** Develop an ingrained routine so that even slight deviations are noticeable, helping you resist temptation.

# Coping with Passive Strong

In the SWAP Matrix, category 3 (Passive Strong) represents resisting digressions—overcoming temptation and staying on task. As you may have noticed, there is little you can do in terms of immediate coping beyond “have a strong will.” If willpower alone were enough, there would be no struggle. However, there are other methods available. They are not easy to practice and may not work for everyone, so I present them here as advanced topics.

The two methods are:

- **Explicit Attention (Making Your Attention Explicit)**  
- **Fixing Your Daily Rhythm**

## Explicit Attention
**Explicit Attention** is a way of working in which you write as you go. When you perform any task, you continuously write down your current tasks and thoughts and refer to what you have written as you proceed. Moreover, you update what you’ve written to reflect your progress.

### Making the Target of Your Attention Explicit by Writing
Normally, we act while thinking in our heads—or, if we’re very accustomed to something, we might even act on autopilot. However, with Explicit Attention you add an extra step: you write down your current context, refer to it continuously, and update it as needed. A common example is a shopping list. Rather than trying to remember what you need or recalling it on the fly, you refer to a written list by your side. Moreover, you don’t just look at the list—you update it by crossing off items once you’ve put them in your cart. This practice, generalized as a method to counteract digression, is what we call Explicit Attention.

### Course Correction
Explicit Attention is a means to counteract digression. By writing, you make the object of your attention visible, and by reading it, you help ensure that your focus doesn’t stray. In fact, even if you begin to digress, you can correct your course. (Once you have completely digressed, it is very hard to get back on track unless you become extremely exhausted or external stimuli force you back.) In short, the key is to catch yourself before you lose focus entirely.

Put another way, you must write and read at a high frequency to prevent digression. For example, with a shopping list you might need to glance at it within one minute; otherwise, you may end up getting sidetracked—whether by deliberating over an item not on the list, abandoning the list entirely in favor of gut feelings, or getting caught up in conversation with a store clerk and forgetting the list. If you tend to digress when you look away for more than a minute, you need to check and update your list at intervals of less than a minute. (This concept is similar to what was discussed in the previous chapter on [Neglected and Lost](dousen_and_remind#ネグレクテッドもロストも回避する), but Explicit Attention demands even more frequent checking.)

### The Required Skill
Deciding when to write, what exactly to write, and where to write it depends on the individual and the situation. Apart from the obvious advantage of having a quiet place (like a desk) where you can read and write undisturbed, you must experiment to find what works best for you.

At the very least, this method requires a certain level of skill. You need to be able to articulate your thoughts into words, actually write them down, immediately read and comprehend what you’ve written, and then update or archive your notes as needed. If you are not skilled at these operations, the extra effort of writing and reading will be too cumbersome, and the process will become a mere formality rather than a practical aid.

One benchmark might be whether you can engage in an open-ended discussion (with no clear “correct” answer) for over an hour without digressing. For example, could you discuss where you’d like to move if you had to relocate, what you’d do if you received one hundred million yen, or how you’d act if you knew you’d die from a heart attack in 30 days? You don’t have to avoid every single distraction for an entire second, but can you confidently say, “I dedicated an hour to thoroughly deliberating this issue”? (Assume that factors such as your health, fatigue, and busyness are not problems.)

Normally, unless you are under strong external pressure, this is nearly impossible. If it came easily, you’d probably be considered talented. That is why we use Explicit Attention. The medium does not matter—it could be a smartphone, a PC, a notebook, or a planner. Even if you could “keep a notebook in your head,” our minds are prone to digression, so it is best to write things down. As mentioned earlier, a calm environment is ideal, but with practice you might even be able to do this on a train or while taking a walk.

Ultimately, what you use and how you write and read to stay on track is a personal matter—you must discover what works best for you. That is the essence of Explicit Attention. It is also true that for some people this may never work perfectly. However, in many cases, the main reason Explicit Attention fails is simply that one is not skilled at reading and writing quickly and efficiently.

I wish I could provide a systematic explanation of how to implement Explicit Attention in detail, but that lies beyond the scope of this book. (In [Part 5](chap5) I propose a task management system that emphasizes the practice of writing, which may serve as a helpful reference.)

### Finding the Right Balance to Motivate Yourself
In reality, the hardest part is not merely reading your notes—it is finding the **right phrasing and atmosphere that actually prompts you to correct your course.** Even if you read your notes, if you cannot pull your attention back from the verge of digression, it is meaningless. If your notes are too complex, you may glance over them without really absorbing the information; if they are too simple, you might quickly think “I get it” but not truly internalize the message. Either way, the process becomes empty. Striking the right balance on your own is difficult.

For example, with a shopping list some people can stay on track with just a simple list of items, while others might need additional admonishing phrases written in to keep themselves focused. In the latter case, not only the content but also the design and overall atmosphere of the medium play a role. People are not as skilled with written language as one might think—and they tend to be quite lax about it. In everyday life, you often have to use every trick in the book to ensure that the tool you use for Explicit Attention (be it a notebook, planner, or app) remains engaging and doesn’t get ignored. Factors such as “everyone else is using it” or “this was recommended by someone I trust” can help, and there’s no shame in using any method that works—even if it’s more about style than pure functionality.

Furthermore, if possible, you should work on improving your overall capacity to handle written information—your vocabulary or literacy, if you will. I haven’t fully determined whether this is best described as vocabulary, language skills, or something else, but I feel it is very important to build up your basic capacity to engage with **your own** written words. For example, many people choose a crowded escalator over an empty staircase—not because of physical strength, but because they lack the basic fortitude to exert themselves solely for their own benefit. Even a student in a sports club with high physical ability might avoid taking the stairs if they lack this “basic capacity.” Conversely, if you do have that capacity, you will climb the stairs effortlessly even if you know they will eventually tire you out. I believe that this “basic capacity” also applies to reading and writing. In fact, being a good writer or a fast typist does not necessarily mean you’re skilled at Explicit Attention. One potential challenge is that training this basic capacity can be mentally taxing, as it means repeatedly facing your own, sometimes unflattering, writing—even if it’s just for yourself. This can be a brutally honest way of confronting your own limitations. In short, to prevent digression you must be willing to face yourself without running away.

## Fixing Your Daily Rhythm

Another way to cope with digression is to **fix your daily rhythm as much as possible.**

### Rhythm Reminders
This is a simple idea: if you have an ingrained daily rhythm, your schedule is roughly fixed regarding when you do things, so when you start to digress you will feel discomfort or unease that makes you resist. For example, if you know that you must start preparing dinner at 4:00 PM, you may be less tempted to get lost in endless web surfing; or if you find yourself so absorbed in reading manga during your pre-bedtime free time that you might overshoot your 10:00 PM bedtime, your ingrained rhythm will remind you, “Hey, it’s almost bedtime.” In short, your body remembers the rhythm and reminds you of it.

I call this **Rhythm Reminders.** It’s not the rhythm of music or games, but rather the physiological rhythms—your daily routine or internal clock. This might sound a bit silly, but it is well known that humans have built‑in rhythms such as the circadian and ultradian rhythms. Especially if you’ve experienced the rigors of sports training or caregiving, you likely know how your body “remembers” a routine.

### Overcoming Temptation in Secret Situations
That said, a good Rhythm Reminder does not come automatically, nor is it always 100% reliable—it varies from person to person—but it is still far better than having nothing at all.

In my experience, the strength of a Rhythm Reminder lies somewhere between the force of external pressure and the strength of your own willpower. While it is considerably more reliable than relying solely on will, it is still not as strong as the influence of external factors (such as children, pets, a team, or other people).  
Nonetheless, I believe it is worth the extra effort to cultivate a Rhythm Reminder because it is one of the very few methods that works **without you having to reveal anything or rely on anyone else.** There are moments when you want to concentrate alone or when you are doing something you prefer to keep private—secret situations in which you can’t rely on external pressures. In such cases, whether you can overcome digression depends solely on your willpower—but as we’ve seen, willpower is often unreliable. That’s why in such situations prevention (rather than mere coping) becomes paramount. As I mentioned earlier in the Passive Strong section, strategies such as “minimizing negatives” (avoiding things that detract from your focus) or changing your environment are well‑known methods. However, those external measures cannot guarantee a secret, uninterrupted situation. The Rhythm Reminder is what can break through that dilemma.

### Cultivating a Rhythm Reminder
So, how can you acquire and strengthen your Rhythm Reminder?

First, imagine that your body gives you an internal “comeback” or prompt. You might not fully understand this until you’ve experienced it, but once your rhythm is ingrained, your body will signal something like “Your next task is coming up—are you ready?” If you heed that internal prompt and hold yourself to your schedule, you won’t digress. Conversely, if you dismiss it with a “Who cares?” attitude, over time that internal signal will become numb and lose its effect. How you handle these internal prompts will determine how effective your Rhythm Reminder is.

In short, to improve the accuracy of your Rhythm Reminder, you need to accumulate experiences where you successfully heed that internal prompt and resist digression. Ultimately, it depends on how much motivation you can inject into maintaining your daily routine. For example, if you commit to waking up at 6:00 AM and going to bed at 10:00 PM every day, ask yourself: how much motivation can you generate to stick to that routine? (Of course, 6:00 and 10:00 may not be the perfect times for everyone; you may need to experiment.) If you want your Rhythm Reminder to work during the day, you must also develop a daytime routine. Merely fixing your wake-up and sleep times is not enough.

If I were to offer advice, it would be to respect whatever rhythm you already have and then fine‑tune it gradually (similar to [Habit Engineering](habit#ハビットエンジニアリング)). If you have no rhythm at all, you must start by creating one—even if that means immersing yourself in a completely new environment or even overhauling your entire lifestyle. It is very challenging to build a rhythm from scratch.

To summarize:

- **1. First, create an ingrained “rhythm.”**
    - Here, “rhythm” means the level of internal prompting (i.e. your Rhythm Reminder).  
    - If such prompts occur, you can say that a rhythm is in place; if not, then it isn’t.  
    - The problem is that many people have little or no practice in establishing a rhythm—they only develop one after spending time in a particular environment.  
    - You need evidence that you currently have, or have had in the past, an ingrained rhythm.
- **2. Once you have a rhythm (or evidence of one), fine‑tune it.**  
    - As with Habit Engineering, make small adjustments every day—adding, subtracting, or modifying elements—to create the optimal routine for yourself.  
    - For example, my current routine is as follows: I wake up at 5:00 AM, start work at 6:00 AM, have lunch at 9:30 AM, take my second cup of caffeine by noon, have a snack at 1:00 PM, dinner at 4:00 PM, finish all work and tasks by 6:00 PM, prepare for bed (brush my teeth, wash dishes, etc.) at 8:00 PM, and go to sleep at 9:00 PM. (These times can be adjusted as needed.)

### Reducing Noise as a Side Effect
When your daily rhythm becomes deeply ingrained and your Rhythm Reminder kicks in, you naturally reduce the “noise” in your life. In other words, you end up thinking about fewer extraneous things and consuming less unnecessary information. As a result, there are fewer triggers for temptation—and you’re less likely to digress.

In the book *How to Stop Worrying and Start Living*, there is a famous saying that “worrying is a result of having too much idle time.” The idea is that if you’re busy, you don’t have time to worry; therefore, if you don’t want to worry, you should keep yourself busy. Typically, we think of being busy with work or caregiving, but I believe that maintaining a daily rhythm is another effective way to stay occupied. When you have no idle time, you won’t overthink or consume excessive information.

### If You Can Stay Busy, a Fixed Daily Rhythm May Not Be Necessary
Ultimately, if you can keep yourself busy, you might overcome temptation simply by having no time to succumb to it—and you might not need to impose a rigid daily rhythm. If work or caregiving fills your schedule, that’s fine. However, as mentioned earlier, a fixed daily rhythm is the only method that protects your privacy from others and is especially valuable in secret situations where external interference is not available.

Since there’s no reason to rely on just one method to overcome temptation, the more methods you have at your disposal the better. Like work or caregiving, establishing and maintaining a daily rhythm is not something that comes easily—it requires constant maintenance and fine‑tuning—but if you struggle with temptation, I highly recommend you give it a try.

# Summary

- **What Is Warp?**  
    - It consists of interruptions and digressions.  
    - Its drawbacks are twofold: reduced performance and the occurrence of context switching.  
    - Conceptually, it is when another task (B) intrudes on the task you are currently doing (A), causing you to switch to B.
- **Dealing with Warp:**  
    - The concept of postponement is key: you must always choose to postpone either A (weak postponement) or B (strong postponement).  
    - The strength of the interruption/digression and the nature of the postponement can be organized along two axes, forming a matrix.  
    - This is the SWAP Matrix, which divides approaches to handling warp into four patterns.
- **Coping with Passive Strong (i.e. employing strong postponement in response to digressions—resisting temptation) is particularly difficult:**  
    - (1) **Explicit Attention:** Keep your focus by continuously writing down and updating your tasks and thoughts.  
    - (2) **Stabilizing Your Daily Rhythm (Rhythm Reminders):** Develop an ingrained daily routine so that even slight deviations trigger an internal reminder, making it easier to resist temptation.

Use these patterns as appropriate. If you do not want to be interrupted, use Active Strong. Conversely, if you want interruptions to help you (for instance, to prompt you when something urgent arises), use Active Weak. If there are no interruptions but you face digressions and want to stay focused on your current task, use Passive Strong. And if you seek various stimuli or hints in reactive or exploratory situations, use Passive Weak.
