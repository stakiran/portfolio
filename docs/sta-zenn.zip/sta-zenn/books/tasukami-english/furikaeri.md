---
title: Reflection(1/2)
---

When it comes to task management, we often tend to think about how to complete tasks effectively (i.e. efficiently). However, we are no longer in an era where simply “checking off” tasks is enough. There are increasing opportunities not only to complete tasks but also to analyze our current situation and consider our future. Even if not, almost everyone has experienced a time when vague anxieties prompted a flurry of thoughts.

This is where “reflection” comes in handy for such activities and anxieties. In the context of task management, you can say that you devise your strategy during reflection, and then you follow that strategy through task management. Reflection helps you determine how to follow the strategy. Of course, you could simply do as you’re told by others or by your environment, but for those who wish to think for themselves, reflection is invaluable.

In this chapter, we will explain reflection. Note that we will not cover processes such as those seen in project task management; instead, we will focus on how an individual can perform reflection in a concise way.

# Reflection

The term “reflection” is polysemous. Its meaning changes depending on context—and from person to person or organization to organization. To make it easier to handle, we will define it from the outset in this chapter. Of course, this definition is not absolute; rather, please consider it the author’s interpretation that makes it easier to work with.

## Definition of Reflection

Reflection is **the act of deliberating using past information as input and producing an output**.

There are three key points:

- **1: Input.** Specifically, using past information as the input.
- **2: Deliberation.**
- **3: Output.** (As will be explained later, the output consists of tasks, mottos, and context.)

There are many processes where you input something, process it, and produce an output—and reflection is one of them.

## About the Input

Input refers to using past information.

As “past” implies, it deals strictly with what has already occurred. At the input stage, you do not think about or imagine the future.

The information may be anything. It could be “activities” such as official work or projects, or “movements” such as simple actions, utterances, or deeds. It even includes things that can strictly be called “information”—for example, past weather, humidity, or atmospheric pressure.

## About Deliberation

We say that you deliberate on the input information, but what exactly is deliberation?

Without getting bogged down in details, the two points I want to emphasize are: **to think and decide with your own mind** and **to rely on information beyond just your subjective impressions when necessary**. People often discuss the difference between deliberation and insight, but insight tends to rely more on intuition and flashes of inspiration. However, because we also want to incorporate non‐subjective information, I have chosen the word “deliberation.”

Also, I avoid heavier words such as analysis, examination, or inspection. Since this is an individual reflection, it’s perfectly acceptable to approach it casually. To convey that nuance, I have chosen “deliberation.”

## The Output: Producing Tasks and Mottos

Finally, regarding the output, I define it as **producing tasks and mottos (and, if possible, context)**.

The reason for including output in the definition is that reflection should lead to something for the future. When we talk about reflection, we often mention “learning,” “insights,” “what went well,” or “what went poorly.” However, simply listing these does not connect to the next steps; merely listing is still only at the stage of deliberation. To move forward, you need to produce something concrete.

What is this “something”? In the context of task management, it is first and foremost tasks and mottos. You either produce a task that indicates an action or, if it is not a task, a [motto](motto) that indicates a guideline, direction, or aspiration. Once you can produce these, you can then proceed—for example, by completing tasks or by keeping the motto in mind—thus linking to your future actions.

There is one more element: context. Context is an optional, extra goal. Ideally, you should also produce context. Here, “context” refers to the circumstances or reasoning behind the judgments or decisions made during that reflection—that is, why you did what you did. (More on this later.) These outputs are used again in the future. If the context is hard to understand later, it will be difficult to make use of it, so it is best to produce context at this time. It is not mandatory, and **if producing context is so burdensome that it hinders your reflection, it is better not to produce it.** Think of it as something to provide only if you have the capacity.

## There Is No Right Answer in Reflection

So far we have described the three elements—input, deliberation, and output. How you carry these out can vary infinitely; in other words, **there is no right answer when it comes to reflection.**

That said, simply saying “do your best” leaves you high and dry, so below I will provide some hints that can help you make it work relatively well.

# The PROC of Reflection

Although we defined reflection in terms of input, deliberation, and output, there is another important aspect that has not yet been mentioned—frequency and purpose. It is smoother if you also consider when to perform reflection and why.

The factors to consider here are captured by **PROC**:

| English      | Meaning       | Explanation                                                 |
|--------------|---------------|-------------------------------------------------------------|
| **Purpose**      | Objective     | Why you reflect                                             |
| **Remembering**  | Recollection  | How you gather (or recall) the input                        |
| **Oppotunity**   | Opportunity   | When you perform the reflection                             |
| **Continuation** | Continuation  | Whether the reflection is a one-time event or a repeated practice |

### Purpose

Regarding **Purpose**, if your objective is vague, your motivation will not last; it’s better to have a clear objective. I will elaborate on this later, but reflection is a painstaking, steady practice. Without sufficient motivation, you are likely to either give up or continue it mechanically until it becomes empty ritual.

### Remembering

**Remembering** refers to how you gather or recall the input. Broadly speaking, there are three approaches:
- Recording something and then referring to it,
- Recalling from memory without any record, or
- Recalling while looking at hints that trigger your memory.

### Oppotunity

**Oppotunity** (a deliberate misspelling of “Opportunity” as used by the author) refers to when you perform reflection. There are approaches where you do it on a fixed schedule, and others where you do it spontaneously whenever you have free time or feel like it.

### Continuation

**Continuation** is a somewhat ambiguous concept. For example, suppose you decide, “Let’s reflect on my 2023 job change activities!” and you hold a three‑hour reflection session one day at the end of the year. If you then finish that reflection and never do it again, then there is no continuation. Conversely, if you think “No, I want to continue—perhaps once a week,” then continuation applies. In that case, it might be that even after the start of 2024 you spend about an hour each weekend, continuing until, say, the end of February.

When we typically think of reflection, we imagine a one‑time reflection event that ends there, but that is not the case. In situations where you intend to continue, you do not have to force everything to be finished in one session. In fact, **there is no need to force yourself to finish everything in a single session.** In the extreme, it is acceptable to take your time—even if it means a slow, meandering session. Although being too lax is not good either, sometimes taking your time lets you see things that you wouldn’t if you reflected immediately; sometimes reflecting a year later (after you have grown) yields a better output. However, since you are unlikely to remember everything from a year ago, you must devise a way to aid your recollection (see Remembering).

# Regular Reflection Is Essential

It is essential to conduct reflection on a regular basis.

For example, you might decide to reflect on work every Friday afternoon, reflect on your hobby FPS games every Sunday morning, hold a daily morning meeting in Project A to reflect on the previous day, or check your household budget at the end of every month to reflect on your expenditures. In these examples, the frequencies are weekly, weekly, daily, and monthly respectively.

## DWMY

For regularity, there are four units: Day, Week, Month, and Year. We refer to this as **DWMY**.

## Advantages of DWMY

When designing the frequency of reflection, keeping DWMY in mind makes it easier to decide. For example, if you focus on the Day, you might consider:

- Every day (once per day)
- Once every two days
- Once every three days
- Every day in the morning and evening (twice per day)

Once you decide on a frequency based on DWMY, you can schedule it using tools like calendars. Furthermore, if you find the frequency too high or too low, you can quantitatively control it—for instance, increasing from once every two days to once per day, or decreasing from once per day to once every three days.

## The DWMY Hierarchy

Sometimes reflection does not go as simply as we’d like.

Especially when the scope of reflection is broad (for example, reflecting on an entire month), gathering the input can become difficult. If you want to reflect on the whole month, you’d have to work hard to gather or recall a month’s worth of input. At the very least, recalling everything would be challenging, and merely collecting it might require a significant amount of effort.

On the other hand, if you narrow the scope and reflect only on a daily or weekly basis, it may be easier—but then you lose the bird’s‑eye view of longer periods (such as a month or a year). This may lead to a piecemeal approach, and you might miss insights that come from having a broader perspective.

The solution to this dilemma is the **DWMY Hierarchy**. This means **using the output from the previous stage as the input for the next stage**. In other words, you perform a daily reflection to produce a “Day Output”; then, during your weekly reflection, you use those Day Outputs as input; then, for your monthly reflection, you use the Week Output; and so on, in a step‑by‑step manner.

Using the DWMY hierarchy significantly reduces the amount of input you need to handle:

- **During daily reflection:** (you create outputs each day)
- **During weekly reflection:** You only need about 7 items (one per day)
- **During monthly reflection:** Approximately 4–5 items (one per week)
- **During yearly reflection:** About 12 items (one per month)

For instance, if you reflect every day, you should have 7 outputs in a week; then during your weekly reflection, you only need to consider those 7 items. (Even if each day’s output contains multiple items, you can still think of it as 7 items over 7 days.) At the very least, you avoid the labor of gathering an entire week’s worth of input from scratch. However, **you do incur the effort of diligently reviewing every day.**

It’s a trade‑off: do you accept the daily effort to make future input easier, or do you skip the daily effort and then struggle later to gather the input? There is no “right” choice; you should choose what works best for you. Personally, I do not rely on my memory but rather on keeping records, so I choose to do it daily. As GTD recommends, I conduct daily, weekly, and monthly reviews—and I can do so because I use the outputs from the lower levels of the DWMY hierarchy.

There are different “schools” or approaches to the DWMY hierarchy. For example:

- **DWMY:** Do all (daily, weekly, monthly, and yearly). For those who are diligent.
- **DM:** Do daily reflections and also a monthly overview—for those who want an overview but find weekly reflections burdensome.
- **DW:** Do only daily and weekly reflections—for those who do not need an overview beyond the week.
- **WM:** Do only weekly and monthly reflections—for those who find daily details too granular but still want some overview.
- **MY:** Do only monthly and yearly reflections—for those who emphasize an overall perspective and are confident in gathering input even when starting directly at the monthly level.

Whether you want to reflect in detail on a daily basis or have an overview with monthly or yearly reflections—and how you balance the trade-off between effort and input—is entirely up to you. Discovering your optimal method will involve trial and error, and you can trust your intuition. If you think, “Perhaps once a week is just right for me” or “Daily reflection is too burdensome to continue,” then that is probably what suits you; you might opt for a weekly (W‑only) approach. Alternatively, you might start with a DW approach and adjust as you get a feel for it.

# Treat Reflection as a Scheduled Appointment

The act of reflection is better treated as an appointment rather than as a task.

An appointment is a commitment with a set start and end time—and it requires prior preparation. On the other hand, a task tends to be something you handle on the fly without prior preparation. Reflection works better when treated like an appointment because it requires you to concentrate and deliberate carefully in order to derive tasks or mottos.

Reflection (in this chapter) is a personal practice, and because it is personal, you must decide for yourself what and how to deliberate and what to output. There is no “right” answer, and it’s not always immediately clear what you should do. In fact, words like “hypothesis testing” or “tentative” might better describe it. That is simply the nature of the practice.

When you meet someone, you schedule it and dedicate that time solely to that person. Please approach reflection with that same mindset. Without doing so, reflection won’t work properly. This is a litmus test for whether you can really reflect. To be blunt, **if you cannot even secure a scheduled appointment for reflection, you are not even at the starting line.** First, you must acquire enough time, commitment, or motivation to set aside an appointment for it.

## Rely on External Support to Get on the Starting Line

If you lack the ability to conduct reflection on your own (by setting it up as an appointment), then it might be wise to rely on external support.

That said, this isn’t about wanting to hold a project retrospective like in project task management. What you want is a reflection that is personal, by yourself, for yourself. It is indispensable that you do it alone. However, if you cannot get started on your own, then you should borrow some external support.

### 1: Go to a Place That Is Conducive to Concentration

One approach is to go to a place where you can concentrate easily. Many people work in cafes, offices, or coworking spaces—and that’s exactly the idea. Find a location suitable for holding your reflection appointment, and go there.

Bring the necessary input with you. It’s best to prepare texts, photos, or other records in advance so that when you get there you can review them on your PC or smartphone while you deliberate. If you prefer analog input (like paper), make sure to bring that along as well.

The location can be anywhere, but it depends on how much you need to worry about being observed. If you are concerned about prying eyes, or if your input or deliberation involves sensitive content, then avoid open spaces like cafes or public libraries/study rooms and opt for a private room instead. When you think of a location, you might naturally think of restaurants or rental spaces—but there are many creative options. It could even be a gazebo in a quiet park, or, as a more unconventional choice, a karaoke room or a love hotel.

Regarding love hotels: they are originally services based on a few hours of rest, so the cost is not as high as that of an overnight hotel. In recent years, there have even been examples of “love hotel girls’ meetups,” and although a companion might sometimes join later, they are perfectly suitable for solo use. Although they tend to be more expensive than karaoke, they usually offer excellent soundproofing, spacious rooms, convenient restrooms, and even the option to lie down on a bed—making for a comfortable experience. (Since prices vary widely, it’s wise to do some research in advance.)

I mention love hotels not because I expect everyone to use them, but to emphasize that you can get creative with your choice of location. I, for instance, sometimes ride my bicycle to a secluded mountain path with few people and reflect while enjoying the natural sounds as background music (although during the rainy, summer, or winter seasons that can be challenging). As mentioned earlier, reflection works best when treated as an appointment and done with full concentration. If you cannot do it at home alone, it is worth the effort to seek out a conducive location.

### 2: Silent Reflection Meetup

[Silent work meetups](https://pha.hateblo.jp/entry/20090122/1232625392) were introduced around 2008 by pha on their blog; these are gatherings where everyone works diligently on their own tasks.

Normally, when you think of a gathering, you imagine that there is some purpose and that everyone actively interacts and collaborates to achieve something. However, a silent work meetup is simply about gathering. You meet at a venue, secure a seat, and work diligently as you normally would. Sometimes, participants may not even greet one another and may leave without speaking a word. Nowadays, a search for “silent work meetup” might yield results that suggest a “study group,” but originally it was truly just a group of people getting together to work on their own tasks. The nuance is that it’s **an impromptu study room**. The idea is something like, “Let’s meet at this time and place this week and work silently together.” Since it is like a study room, talking is actually discouraged. If you really want to talk, then step outside of the main venue, or only do so among those who have already agreed beforehand that conversation is acceptable.

Now, the second approach is to conduct your reflection during such a silent work meetup. You can hold a meetup exclusively for reflection or attend a general silent work meetup and conduct your reflection there. The key is to strictly maintain the study room atmosphere. At the very least, absolutely no talking inside the study room is essential. You must preserve the sanctity of that space free from external distractions. If you can’t do that, then honestly, it’s not worth it.

You can either organize a silent work meetup yourself or rely on an existing event. However, in recent years there are few meetups that truly embody the “study room” atmosphere, and since such events are rare anyway, you might have to organize one yourself. You can recruit participants online or invite colleagues, friends, or family. Personally, I find that with close acquaintances it is difficult to enforce a strict no-talking rule (see [Familia Debuff](partner_taskmanagement#ファミリア・デバフ) in the previous chapter), so it is better to gather complete strangers.

You might wonder, “Does doing that really have any meaning?” And it does. Method 1 was to go out to a particular location—and essentially, this method is no different. The second method here is simply about creating a location by imposing the constraints of a silent work meetup. It still relies on the external environment. (As mentioned in the [Warp section](warp#3-passive-strong), being in a place different from your usual one reduces distractions and creates a sense of discipline.) 

# Designing Your Reflection

As explained above, reflection is not something you can just start on a whim. It is more effective if you plan in advance—deciding to some extent what kind of reflection you will do and how you will do it.

There is no “right” way to design your reflection. Essentially, you just need to decide your own versions of PROC and DWMY. For reference, here are a few methods:

## Enum and Assign Method

This method involves first enumerating the aspects you want to reflect on, and then assigning a time for each one.

1. **List out what you want to reflect on.**  
   For example, if you want to reflect on “work progress,” “daily health,” “performance in your hobby FPS games,” and “your current career,” that makes four subjects. These are referred to as **reflection subjects**.

2. **Schedule an appointment for reflection for each subject.**  
   Use the DWMY units to set up regular appointments. Even if a reflection is a one‑time event, schedule it. If you have six subjects, you’ll need to set up six appointments.

3. **Design the input, deliberation, and output for each reflection subject.**  
   Decide what input you will use, what you will do during deliberation, and what you will produce as output.

*Advantage:* This method is very straightforward—list, schedule, and prepare.

*Disadvantage:* It can be laborious. Since you do everything step‑by‑step, there is a lot of work involved, and the reflection you design today might not be effective forever. You will likely need to fine‑tune or experiment repeatedly.

## Reflection Hour Method

At universities, professors often have “office hours” (a set time to answer students’ questions). Think of this as the reflection version: you schedule a time in advance solely for reflection, and when that time comes, you engage in some form of reflection.

Unlike office hours, you are the only participant. Each time, you decide for yourself what and how to reflect.

This is a simple method, and if you want to try something light, it is recommended. In reality, the difficult part is not so much deciding what to do, but rather actually setting aside an appointment for a “reflection hour.” As mentioned earlier regarding the “starting line,” even securing an appointment solely for reflection is challenging. Modern life is busy, and if you don’t understand the benefits of reflection, it is psychologically hard to suddenly devote time to what may seem like a personal, troublesome practice.

That is why this method, despite its simplicity, is effective and even serves as a touchstone.

## Diary-Based DWMY

This method involves two practices: writing a diary every day and conducting reflection based on the DWMY hierarchy.

First, the diary can be in any format. It could be a business-oriented work journal, casual posts on social media (like Twitter/X), or anything else. It can be written in an analog notebook or input into a digital note‑taking app. Whatever the form, it is best to write frequently. If you try to record everything only at the end of the day, you likely won’t remember many details. In fact, **writing only at the end of the day is itself a form of reflection.** While that may work for some, it is not something everyone can do. Therefore, it is important to establish a habit or system of recording frequently (to create input).

Next, regarding the frequency of reflection, you should do it based on the DWMY hierarchy—daily, weekly, monthly, and yearly. If doing all of D, W, M, and Y is too burdensome, you can adjust (for example, DW only or WM only). In any case, use your frequently written diary as the basis for your reflection.

Finally, what you do during your reflection is up to you. However, since the expected outputs are tasks and mottos, it is a good idea to aim for at least two items: “what I want to do next” and “what I want to keep in mind from now on.” Look at your diary (or the lower‑level outputs based on the DWMY hierarchy) and let ideas flow. Sometimes flashes of insight or sudden ideas may occur—and those are the important ones, so be sure not to let them slip away.

Ultimately, what you choose to set for yourself is up to you, so set goals that are manageable. I recommend starting with just one “next thing you want to do.” If you set multiple goals right away, they may never be achieved, and even one per day will quickly add up to many items (if you output one task per day, after 7 days you have 7 tasks). The important thing is to progress gradually—one step at a time.

For example, if you output one task per day, you’ll have 7 tasks in a week (or even fewer if the same task continues). You can then decide during your weekly reflection how to handle the accumulated tasks—perhaps by choosing only the most important one to continue, or by discarding them all if they seem trivial. There is no “right” answer, but if you do it properly, you will make steady progress. Even if you only complete one task in a week, that is still progress; even if you complete none, the fact that you recorded “not even one task was completed” is itself a form of progress.

## 5‑Minute Reflecting

“Reflecting” is simply reflection with an –ing appended; it is just the act of reflecting. Given that it’s 5 minutes, you can imagine that it’s a reflection session that lasts for 5 minutes.

5‑Minute Reflecting means that at a natural break point you suddenly engage in a 5‑minute reflection. The key is to engage in an exaggerated role‑play—saying things like, “It’s 5‑Minute Reflecting time!” “Now then, what shall we reflect on this time?” “Well, today…”—essentially **acting out multiple roles (two or even more) in an exaggerated way and having a conversation with yourself.**

It may sound silly, but by acting it out, your brain starts to work differently, and you may unexpectedly come up with various ideas. In the programming world, there is a practice known as the “Teddy Bear Effect” or “Bear Programming,” where instead of consulting another person when you can’t find a bug or when you’re stuck, you **consult a stuffed animal.** Surprisingly, this sometimes leads to insights about the cause or solution. When you think alone versus when you explain something to someone else, your brain works differently—so ideas that didn’t occur to you when thinking alone might emerge when you “explain” things out loud (even if you’re just acting out multiple roles by yourself).

It has already been mentioned that reflection is a personal practice. To be frank, reflection is both a personal and creative endeavor because what you choose as input, what you deliberate, and what you output is entirely up to you. There is no right answer. However, unlike programming or other work, it is not something you can easily consult with others (see Note 1). That is precisely why it is difficult, prone to getting stuck, and why—even if it means role‑playing—you might want to rely on a method that helps you move forward.

- **Note:**
  - 1: I’m not saying that relying solely on others’ words or objective data is bad—in fact, it can make you more flexible because you are not dependent on your own trivial beliefs or pride. However, without a sense of self, you might become adrift. On the other hand, relying too much on others can make you more susceptible to deception (which is why scams and cults can be so dangerous). In any case, as this text suggests, you should focus on introspection to build “yourself.” There is no escaping the need to confront yourself, and facing yourself without evasion is one of the messages I wish to convey in this book.

# Why Reflect?

We have now assembled all the tools necessary for reflection, but we have not yet discussed the crucial aspect of motivation. Recall that the “P” in [PROC](#the-proc-of-reflection) stands for Purpose. What is the purpose of reflection, anyway? Why do we reflect?

Without a convincing purpose, reflection cannot really work. As mentioned above, reflection is a troublesome practice, and to prevent it from becoming an empty ritual, you need to have a clear motivation. Of course, what purpose resonates will vary from person to person and even for the same person depending on the situation.

In this section, I aim to prompt insights by taking a broad look at the main purposes of reflection. I believe these can be broadly categorized into three:

- **To Know**
- **To Advance**
- **To Protect**

## To Know

**To Know** simply means “to want to know.”

You might reflect simply because you want to understand what you have done in the past or what your current situation is. Under the definition in this chapter an output is required, so merely wanting to know might seem insufficient—but it is not a problem. In fact, there is no need to force yourself to produce an output right away. Since establishing reflection itself is challenging, it is important first to get it going; you can produce the output later once the habit is in place.

So, if you feel that you simply want to know, please cherish that feeling. Begin reflecting to satisfy that curiosity—even if it is just for fun. The most important thing is to start.

There is a term “curiosity,” and it applies to your past as well. On the other hand, some people might think, “I’m not interested in my own past at all—reflection is boring.” In fact, such people may be in the majority. In that case, consider a different purpose. Not every purpose will suit everyone.

## To Advance

**To Advance** means “to want to move forward.”

In order to move forward, you need to make the right efforts. You must accurately perceive your challenges and your current reality (or, if you do not know them, set them up as hypotheses) and then make adjustments to bridge the gap. If you lack any necessary tools, you must start by acquiring and learning them. In contexts such as games, sports, or intensive education and on‑the‑job training, this is clear. Unfortunately, most of life does not work that way. Often, you do not even accurately recognize your challenges or your current state. While some may rely solely on intuition, such cases are rare. Therefore, if you want to progress in most aspects of life, you need to understand your challenges and your reality.

This is where reflection comes in. You input your current situation, deliberate on it, and then output your next actions or guidelines. Then you act on that output and later reassess your situation—repeating the cycle. Such a process is often called a “cycle” or “loop”; well‑known examples include the PDCA cycle and the OODA loop.

## To Protect

**To Protect** means [Minimize Negatives](stance#minimize-negatives-を地で行く). It is about taking proactive measures—regularly spending time and effort—to avoid the chronic occurrence of small negatives or to prevent major negatives from occurring in the first place. Essentially, it is about minimizing negatives.

Reflection is very useful for this purpose, whether in the context of work, personal life, or even the progress of a long‑term hobby. By regularly reflecting on your situation, you can prepare for the worst.

For example, consider a health check-up. To prevent small issues from becoming serious, you might have a health check-up once a year and then reflect on the results. If you want to do it more frequently, you might measure your weight or monitor your sleep time daily using an app. During the pandemic, daily temperature checks even became popular—and some people may still continue this habit.

At an even higher frequency, think about the issues of forgetfulness, indecision, and laziness. Reducing these is one of the main goals of task management, and reflection can help with that. Much like memory, if you at least become conscious of or think about these issues, you are more likely to remember them. For example, if you adopt the habit of reflecting on your work for just 5 minutes every day, it is a very simple form of reflection—but even that small effort will make a significant difference compared to doing nothing. It may sound obvious, but that is precisely the case. I am simply using the term “reflection” to carefully explain something that is actually very simple. However, as mentioned earlier, it is really difficult to set aside those 5 minutes and actually perform the reflection. I must insist: if you want to protect yourself, you must get up and do it.

...
