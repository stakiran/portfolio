---
title: Stances on Task Management
---

“Stances on task management” refers to the different response patterns or approaches to handling tasks. You might also call them mental models. Whereas the previous chapter’s [strategy](strategy) was about how to “manage” tasks—that is, how to handle them—the stances in this chapter are about how to “execute” them.

# Reducing the Load
This is the stance of trying to reduce the number of tasks you are responsible for.

- **Delegator**
    - A Delegator hands off tasks to others rather than processing them personally.
- **Sprinter**
    - A Sprinter processes tasks immediately on the spot without first entering them into a task management system.
- **Skipper**
    - A Skipper postpones everything except the tasks they have decided to do today.

Each approach reduces your load in a different way. A Delegator reduces the load by entrusting tasks to others; a Skipper reduces today’s workload by postponing everything not scheduled for today; and a Sprinter prevents tasks from accumulating in your task management system by handling them immediately.

## Delegator
**Delegator**

### Overview
A Delegator seeks to delegate tasks as much as possible.

Delegation means handing tasks off to someone else. There are many familiar examples: executives often have secretaries as their right-hand aides; celebrities and athletes typically have managers; even in shared households, tasks or chores are frequently delegated to partners or parents; and in dormitories, a caretaker might manage everyday affairs. These are all very familiar examples.

### What Looks Like Delegation but Isn’t
Instruction, micromanagement, and employment are not the same as delegation.

Delegation is “handing over” responsibility—meaning the Delegator essentially waits for the delegatee to deliver the results. Checking details, offering corrections, or providing guidance is not delegation but rather management (often so detailed it is called micromanagement) or instruction. **True delegation means entrusting even the management of the task to someone else.**

Also, hiring someone—like a housekeeper or a butler—is not delegation. That is merely solving the problem with financial means and is, in effect, employment. (*Note 1*) Delegation, by contrast, is accomplished without relying on economic power; it is achieved through ingenuity or by virtue of one’s position. (Of course, this often requires high-level skills such as empathy, people skills, negotiation, persuasion—and sometimes even brainwashing—so it typically depends on the role one holds.) **Whether or not delegation is possible depends on having the position or role that allows you to delegate or be delegated to.** If you do not have that, you might create it—but getting others to follow a self-made role also requires ingenuity or authority.

- *Note*  
  1. Although you can hire someone who functions as a delegatee, that discussion can become complicated, so it is omitted here. Even if an employment relationship exists, if it is truly delegation, the delegatee should demonstrate enough trust or capability to handle the task (and its management) on their own.

## Sprinter
**Sprinter**

### Overview
A Sprinter aims to process tasks immediately as they occur.

### Conserving Cognitive Resources
The primary goal of a Sprinter is to save cognitive energy.

In [GTD](ref#gtd), there is the “Two-Minute Rule”: if a task takes two minutes or less, do it immediately rather than adding it to your task list. Similar maxims include “return the ball immediately” or “don’t hold onto it.” There’s also the technique known as front-loading, where you “go all out for a while at the beginning.” 

What these approaches have in common is that they reduce the burden of having tasks pending (since having them forces you to decide which one to tackle and when, which in turn drains cognitive energy). Cognitive resources are finite, and once depleted they only recover after sleep. While breaks, naps, or meditation can help, there is a limit. If your ability to make decisions is dulled or fails altogether, that is a serious problem—so conserving cognitive resources is sometimes even more important than saving time or money. (For example, some executives are known to wear the same outfit every day to avoid making trivial decisions.) In general, reducing the number of decisions you have to make helps conserve cognitive energy. In this way, a Sprinter conserves cognitive resources by processing tasks immediately, rather than letting them pile up.

### Progress, Even if Imperfect
Another goal of a Sprinter is simply to move forward.

The reality is that things rarely go perfectly; plans are often upended, and progress can be slower or more erratic than expected. In today’s VUCA world—where the future is unpredictable—the old adage “it doesn’t have to be perfect; just keep moving” is very relevant. Instead of spending too much time thinking or researching until you are convinced, you act. The importance of taking action is a well-worn piece of advice, and a Sprinter embodies it by processing tasks immediately as they arise. Even a small bit of progress changes the situation and leads to new opportunities.

An additional benefit is that if circumstances change, you only need to react accordingly rather than having to manage a backlog of tasks. As already mentioned, people are generally lazy; even the lazy prefer to act when prompted by an event. In effect, processing tasks immediately as a Sprinter is like creating one’s own events.

## Skipper
**Skipper**

### Overview
A Skipper tends to postpone all tasks except those that have been explicitly designated for today.

### Postponement Without Dire Consequences
At the heart of the Skipper’s philosophy is the idea that “there is rarely anything that must be done immediately.” Although this depends on the situation—in jobs with high real-time demands, for instance—it is often simply a matter of personal preference or trivial concerns (like personal interest or not wanting to be disliked). By abandoning such concerns, the Skipper decides, “I will do this tomorrow,” and postpones tasks accordingly.

However, a prerequisite is that you have already determined what you will do today (your daily tasks). It is the daily task planning that produces steady progress; by focusing on today’s tasks, you can postpone everything else. Without a daily task plan, postponement is nothing more than abandonment. It is precisely because you have a daily task plan that you can distinguish between tasks for today and those that can wait.

The philosophy of the Skipper is elaborated in [The Law of Tomorrow](ref#3).

### The Importance of Discretion
Even if you postpone tasks, they don’t simply vanish. In cases of ambiguous tasks or hectic circumstances, some tasks might indeed disappear—but counting on that is reckless. You postpone tasks in order to safeguard your daily pace. In other words, **postponement means deciding “I won’t do this today” in order to protect your own rhythm (even though you’ll likely have to tackle it later).**

For this to work, you must have enough discretion. For tasks that you can handle on your own—such as creating documents—you generally have enough discretion. However, if your work involves others (for example, if your job requires attending meetings), it is unlikely you can simply decide “I’m not doing that today” without repercussions; such a decision could be unacceptable or even cause rifts. The Skipper, therefore, is someone who can confidently postpone tasks when they have the necessary discretion.

### Overcoming the “Student Syndrome”
“Student syndrome” refers to the phenomenon where one only starts working earnestly on a task right before its deadline. Although the term is figurative, this phenomenon is often observed in business projects as well.

Skippers must overcome the student syndrome by carefully considering the true deadlines of tasks and working on them steadily day by day. Alternatively, if uncertainty makes it hard to predict deadlines (as mentioned in the Sprinter section), they might employ front-loading to expand their perspective first. In short, a Skipper is willing to bet everything on getting ahead of the game.

# Streamlining Effort
This stance aims to reduce the time and effort required to process tasks.

- **Automaton**
    - An Automaton systematizes (and if possible, automates) the processing of tasks.
- **Rejecter**
    - A Rejecter pre-establishes rules to reject certain tasks or patterns, and when such tasks appear, they are immediately declined.
- **Focusist**
    - A Focusist selects only the tasks that are immediately relevant and ignores everything else.

The Automaton reduces the processing effort itself, while the Rejecter and Focusist reduce the mental effort needed to decide what not to do.

## Automaton
**Automaton**

### Overview
An Automaton strives to standardize task processing—and if possible, to automate it—so that tasks are handled in a uniform way.

### Avoiding Cognitive Expenditure
As mentioned earlier in the [strategy chapter](strategy#inboxer) with the Inboxer—and here with the Sprinter—some people prefer to rely on their cognitive abilities, skills, or experience to process tasks on the fly. However, these individuals tend to dislike activities that slow them down, such as writing things out on paper or text and then trying to figure things out from those notes. Such processes expend cognitive resources. Even if not to an extreme degree, if your method or timing isn’t set, you can quickly become fatigued. In short, you simply do not want to expend brainpower—just as a sprinter dislikes endurance events.

So how can you avoid using your brain in that way? One solution is to control your environment so that only your predetermined methods are allowed (or so that any unforeseen methods are prevented). However, this kind of control is usually only possible for those with authority. Hence the idea of the Automaton.

An Automaton is someone who, through ingenuity, creates a system that lets them handle tasks in a standardized way—and, if possible, automates the process so that they never have to work on it manually.

### Standardization and Automation
Standardization means limiting the processes or formats you use. Automation means eliminating manual work.

A clear example is the “Calendarer” from the strategy chapter. The Calendarer puts all tasks and events into a calendar and then follows it like a machine. That is standardization, and if desired, parts of it can be automated. For instance, you could set up an integration so that when you bookmark a message in Slack, it is automatically added to your calendar at 0:00; then you only need to make minimal adjustments. This way, you no longer have to manually add tasks to your calendar.

Although “processes” and “formats” might sound grandiose, it is simply about agreeing with the relevant parties to operate in a certain way. In meetings, for example, a recurring meeting is precisely this: rather than scheduling each meeting individually, you set one up on a regular basis; if someone misses it, well—you simply refer them to the minutes. This approach standardizes the process.

This idea applies not only to interactions with others but also to your own personal routines. Especially for those who do a lot of information gathering or reflection (knowledge work), you can standardize your information sources or automate the preparatory steps for collecting information. The result may be that a process that once took 20 minutes manually is now done in 2 minutes by following a standardized method. For example, rather than casually browsing through social media or news sites, you might choose to only view information curated by trusted individuals. Projects like [Menthas](https://github.com/ytanaka-/menthas) automate the collection of information from curators. In short, standardization and automation together mean **systematizing your processes.**

### The Paradox of Systematization
For those with talent, systematization might come effortlessly through spontaneous thinking—but such people are rare (which is why those in positions of authority often impose systems on others).

Ironically, while you want to be an Automaton to avoid using your brain, you must first use your brain to devise and implement the system. We might call this **the paradox of the Automaton.**

To overcome this paradox, you need what some refer to as the three virtues of programmers: “laziness,” “impatience,” and “hubris.” Programmers, who are essentially systematizers by trade, must cultivate a mindset that is impatient and proudly lazy. It is precisely this mindset that drives them to create systems that save effort—and they continuously refine their skills in doing so.

Overcoming the paradox of the Automaton requires that level of determination. Incidentally, the more analog your method is, the less you can automate it; therefore, you often have to rely on digital tools—and that inevitably means dealing with IT or programming skills.

## Rejecter
**Rejecter**

### Overview
A Rejecter decides in advance which tasks to decline, and when those tasks appear, rejects them without hesitation.

### Practicing “Minimize Negatives”
There is the concept of a “Not-To-Do List,” which is essentially the reverse of a regular TODO list. In both work and task management, there is much discussion about prioritization, selection, and especially the importance of discarding unnecessary tasks.

Broadly speaking, there are two approaches: one that maximizes positives (Maximize Positives) and one that minimizes negatives (Minimize Negatives). While most people tend to focus on increasing positives, reducing negatives is equally important. Reducing negatives saves both time and mental energy. Of course, if you reject everything, you simply become unproductive; but in modern life, we often take on too many negatives and are generally poor at discarding them—so it is often best to lean toward a vigorous “Minimize Negatives” approach.

With the Rejecter stance, you clearly define conditions and corresponding actions in the form “if A happens, do B.” Let’s call these **rejection rules.** Simply writing down a casual “not-to-do” list won’t suffice—you need to create your own set of clear rejection rules.

### Examples of Rejection Rules
There are countless examples of rejection rules; here are a few:

**“If an unfamiliar person rings the doorbell, ignore it.”**  
People with a naturally kind or trusting nature might be inclined to respond, but unfamiliar visitors are highly likely to be salespeople or religious solicitors—and sometimes, they may even be malicious (for example, someone targeting a vulnerable individual). To protect your time and safety, you decide to reject such visits without question. If that is too difficult, you can add a rule like “If it’s important, they will call or come back later” or “A legitimate person would already know my phone number.” You might even put up a “No Sales, No Solicitations” sign on your door. Such measures are a form of systematization and fall under the [Automaton](#automaton) category.

**“If someone posts unpleasant remarks on social media, mute or block them.”**  
For example, on X (formerly Twitter), there are functions to mute specified accounts or keywords or even block users so that they cannot interact with you. In face-to-face interactions, you might have to endure minor unpleasantness because it is hard to reject someone without causing offense. However, on social media, since you are not physically present, it is easier to reject such interactions. Still, even when blocking someone, be aware that they might notice if they try to contact you—so do not be overly confident. In particular, muting is useful because you can target keywords or hashtags, meaning you can reject topics rather than individuals.

**“Ignore notifications after 5 p.m.”**  
To have a peaceful evening, you might decide not to look at any notifications after 5 p.m. Simply trying to remember this is difficult, so you need some mechanism to enforce it. For example, you could schedule an event at 16:50 each day to “turn off all notifications” and another event at 7:30 to “turn on all notifications.” Some communication apps even allow you to disable notifications during specific hours. Alternatively, for smartphones there are products like the [Time Locking Container](https://king.mineo.jp/staff_blogs/2209) that help enforce this rule. Such rejection rules work on the principle “if the target appears, act immediately.” However, to prevent the target from even appearing temporarily, you often need some form of systematization—which, again, falls under Automaton.

### The Rejection Rule Matrix
Here are three examples, but generally rejection rules can be organized into the following matrix:

|                              | **Reactive**           | **Preventative**         |
| ---------------------------- | ---------------------- | ------------------------ |
| **Ignore**                   | 1. Reactive Ignoring   | 2. Preventative Ignoring |
| **Block**                    | 3. Reactive Blocking   | 4. Preventative Blocking |

First, you decide whether to simply ignore (take no action) or to block (take active measures toward the source). In the examples above, all of them are forms of ignoring. Although posting a sign or using the mute function might sound like active measures, they are indirect safeguards designed to passively protect you and thus count as ignoring. Blocking, by contrast, might involve directly responding to the door or sending a message on social media such as, “I find your remarks unpleasant; please stop.” This is a direct action.

The general principle is to try ignoring first. If that works, that is ideal. If not, then you move on to blocking. Direct blocking is more energy-consuming, but if ignoring fails, you then create distance between yourself and the source. I refer to this sequence as the **3T of the Rejecter:** Through → Tackle → Transfer. (More precisely, there are four stages: Through [observing/enduring], Temporize [ignoring], Tackle [blocking], and Transfer [distancing yourself].) The Rejecter’s stance focuses on refining Temporize and Tackle to manage the rejection of tasks.

Furthermore, the methods of ignoring or blocking can be either reactive (responding every time the target appears) or preventative (taking measures so that the target never appears, or that it is handled automatically). Generally, preventative measures cost more upfront, but if the target appears repeatedly, a preventative approach is more efficient in the medium to long term.

Automation or documentation can help here as well—deciding when to shift to a preventative approach is a trade-off. On the other hand, features like X’s mute function can be employed immediately if you know about them. In this way, preventative measures depend on your knowledge and skill. It is advisable to explore the settings of the tools you use daily; you might be surprised by how many opportunities there are to function as a Rejecter.

## Focusist
**Focusist**

### Overview
A Focusist concentrates solely on the tasks that are immediately relevant and ignores or discards everything else.

### A Whitelist Approach
While the Rejecter sets up a blacklist (rejection list) of tasks to avoid, the Focusist does the opposite—creating an allowed list (or whitelist) and following only those tasks (and rejecting everything else). In other words, the Rejecter operates with a deny list (or block list, sometimes called a blacklist), whereas the Focusist works with an allow list (or safe list, sometimes called a whitelist).

Here is a summary of the corresponding approaches:

- **Allowed List**
    - Also known as an Allow List, Safe List, or White List.
    - This is the approach of the Focusist.
- **Denied List**
    - Also known as a Deny List, Block List, or Black List.
    - This is the approach of the Rejecter.

### The Focusist Matrix
The Focusist’s method can be classified into four types:

|                                | **Short-Term**                | **Medium-/Long-Term**              |
| ------------------------------ | ----------------------------- | ---------------------------------- |
| **Focusing on Tasks**          | 1. Short-Term Task Type       | 2. Medium-/Long-Term Task Type      |
| **Focusing on Capacity**       | 3. Short-Term Capacity Type   | 4. Medium-/Long-Term Capacity Type  |

First, decide whether you are focusing on specific tasks or on your capacity (such as time or energy). In the task type, for example, you might adopt the Ivy Lee Method—deciding “I will only do tasks A, B, C, and D” (and nothing else). In the capacity type, you limit the resources allocated to work—say, confining work to specific hours (for instance, 8–11 a.m. and 1–5 p.m.). 

Then, consider the duration: short-term versus medium-/long-term. Short-term focus might mean “I will only tackle these six tasks today” or “I will work only from 8–11 a.m. today,” without planning for the rest of the day. Medium-/long-term focus might mean “I will only deal with these six tasks every day this week.” 

In summary, the task-type focus is about boosting productivity by narrowing your task list, while the capacity-type focus is about conserving energy by limiting the resources you spend on work. It is best to experiment with short-term focus first (for example, trying it out for just one day or one part of the day) and then, once you’re comfortable, extend it to a medium-/long-term approach. However, in reality, maintaining strict focus is challenging, so it’s wise to allow some flexibility.

### Can You Truly Focus?
For example, if you decide that you will only focus on three tasks (A, B, and C), should you rigidly stick to only those three tasks and ignore all others?

The answer is yes—but in reality, it is not that simple.

First, we all have everyday lives. Even if you decide to focus solely on A, B, and C, you still have to manage meals, sleep, personal hygiene, etc. While you might be able to ignore many tasks temporarily, you cannot completely neglect daily life, or it will eventually take its toll on you. People who are well-optimized for daily living tend not to consider routine activities as “tasks” at all.

Second, there is the issue of direction. You might initially believe that A, B, and C are the correct tasks to focus on, but once you begin working, you might find that D is actually more important. In that case, rather than rigidly sticking to A, B, and C, it is better to incorporate D.

To sum up, there are three main obstacles to perfect focus:

1. Humans have physical and mental limits (and there are also limits in time, money, and other resources).
2. Some tasks may be easier for you because you’re accustomed to them, while others might not be; for example, routine daily tasks might be handled automatically.
3. The original focus might change as you gain new insights or as your perspective shifts.

For the first obstacle, you can use a capacity-type focus by understanding your limits. For the second, do not count tasks you are already used to—rather, only count those that require effort. For instance, if you have just moved and must handle many unfamiliar tasks, instead of focusing solely on A, B, and C, you might decide to include “post-move tasks” in your focus. For the third, you can choose to work with a broader (less granular) set of tasks. For example, rather than specifying “finish the first chapter of an English textbook,” “research how to get a Golden Retriever puppy,” or “resolve the conflict between X and Y on the team,” you might simply frame them as “study English,” “research getting a dog,” or “succeed in the project”—which allows for more flexibility.

# Engaging in “Off-Board Warfare”
This stance is not about how to process tasks but rather about intervening in how tasks arise or accumulate.

- **Slackist**
    - A Slackist focuses on securing and preserving extra capacity (time, mental space, etc.) and makes decisions about tasks based on that slack.
- **Contexton**
    - A Contexton devotes effort to understanding the context surrounding tasks.
- **Mixer**
    - A Mixer attempts to handle multiple tasks at once or in batches.

These approaches differ greatly—for instance, one focuses on securing “slack” (free time, mental space, etc.), another on understanding context, and yet another on processing tasks in a single burst.

## Slackist
**Slackist**

### Overview
A Slackist prioritizes securing and preserving slack above all else, and they decide whether to take on tasks based on the amount of slack they have available.

### Buffers and Slack
Slack comes in two forms: buffers and general slack. A buffer is extra time set aside for irregular events, while slack refers to the constant overall surplus in time, mental energy, money, or other resources.

### Securing Buffers
For example, if a task could normally be completed within a week, rather than setting a deadline or review one week later, you might set it for two weeks or more.

If the task is one you can complete on your own, it’s simply a matter of personal choice. The issue arises when others are involved—you must then explain or justify the extra buffer. Buffering tasks (“padding” your schedule) may invite questions such as “Isn’t that too long?” or “Can’t you finish it faster?” You must be prepared to address these questions.

Some tactics include:

- Reporting, for instance, that you’re “only 50% done” at the one-week mark (even if you expect to finish earlier).
- Making your efforts visible so that others know you are not slacking off.
  - For example, I work in an IT company and make almost all of my work (within confidentiality limits) open to others. I also participate actively in discussions, information sharing, and casual conversations. My colleagues often remark on how productive I am or how meticulous my note-taking is, and they see that I am constantly working hard.
- Explaining the circumstances or issues that are delaying progress.
  - This might involve either a logical, quantitative explanation of your workload or a personal explanation involving factors such as childcare, caregiving, or health issues.
- Initially asking for a trial period—“Just give me one week”—and then discussing the next steps.
  - Even for nontrivial tasks, you might only know what’s required after you begin. Whether the period is one week, two weeks, or longer, finding the right balance is key—too long and the task may languish; too short and the overhead of frequent check-ins becomes burdensome.
  - Ideally, you set up a cycle where you report progress and plan the next steps on a weekly basis. This not only builds in buffers but also makes it easier to control the volume of tasks scheduled for each period.

What is crucial is whether your environment allows you to build in buffers. If not, the Slackist stance may not be feasible. Sometimes it depends on the nature of the work; other times it depends on whether the organization or its leaders are understanding. In my view, the ability to build in buffers is one indicator of a healthy, supportive workplace.

### Securing Slack
To secure slack, you must work continuously on three aspects: time, mental energy, and money.

#### Time
This aspect concerns how you avoid taking on tasks that consume too much time.

In the workplace, it often comes down to the persona you project. For instance, a person known for always leaving work on time or for having caregiving responsibilities might naturally be assigned fewer tasks. You may have to present yourself in such a way that others see you as someone who is not available for extra tasks. However, this must be done carefully, as being too assertive can lead to conflict. Personally, I fall into this category—I may not be ideal as a hands-on team player, but I work autonomously without micromanagement, and I’m often given new projects or tasks that others avoid. For example, I might have only occasional progress meetings instead of daily ones. The key is to optimize both your own work style and your environment. Of course, if your efforts are consistently misunderstood or if your environment is unreceptive, you may have no choice but to consider changing roles or even organizations.

Ideally, you would have skills that allow you to choose your tasks. Since that is not always possible, it is important to continually develop skills that set you apart—such as quick output or effective task management. I write about task management partly to secure a stronger position; I want to demonstrate that I have the capability and potential to succeed.

#### Mental Energy
This concerns how you avoid tasks that impose a heavy “mental load.”

“Mental load” is a term that refers to persistent worries or nagging concerns that continuously pop up in your mind. This might range from concerns about rising prices or future pensions to small irritations like noticing that someone hasn’t replied to your message or encountering an unpleasant person on the train. Although such thoughts are often fleeting and eventually fade, some may linger stubbornly—much like an earworm.

There are three key steps to minimizing mental load: introspection, examination, and elimination.

- **Introspection** involves candid self-questioning to understand your true thoughts and nature, usually best done by writing them down. This process is draining, and particularly sensitive individuals might struggle to maintain it. Insights generally develop gradually over time through consistent journaling or note-taking.
- **Examination** involves assessing your personal characteristics. Nowadays, there are established methods to diagnose conditions such as ASD, ADHD, or borderline intelligence, or to understand aspects of sexual or gender minority identities. These traits are intrinsic or long-established and are hard to change, so knowing them can help you avoid tasks that aren’t a good match. You might use formal assessments where available, or engage in active information gathering and community involvement for traits without formal diagnostic methods.
- **Elimination** means taking action based on what you have learned through introspection and examination—essentially, discarding or avoiding the sources of mental load. This might mean stopping certain activities or even distancing yourself from relationships that drain you. Sometimes it requires setting aside pride or stubborn habits. If you find you cannot handle a burden on your own, you may need to enlist the help of friends or a partner.

Elimination—consciously choosing to discard burdens—is easier said than done. For instance, how many people could decide to give up on raising children if it were too draining? Or could intentionally change their behavior or appearance to avoid unwanted attention? For a Slackist to maintain mental slack, such tough choices are sometimes necessary. **Deep self-understanding—through introspection and examination—is essential for making these decisions.** Whether you achieve that through rational analysis or through creative expression, it is indispensable.

This may sound like a strong or extreme stance, but for a Slackist whose primary goal is to preserve slack, such measures are crucial. Ultimately, the desire is to secure free time—time that you can use as you see fit, whether for gaming, reading, sports, walking, DIY projects, spending time with family or pets, or even idly browsing on your smartphone or watching TV. More fundamentally, it is about avoiding negatives. As mentioned earlier, the idea is to [Minimize Negatives](#minimize-negatives-を地で行く). The popularity of FIRE (Financial Independence, Retire Early) largely stems from the desire to eliminate the negatives associated with work. Rather than pursuing self-actualization, growth, or ambition, the goal is to eradicate the negative aspects of life. In this vein, I call this pursuit **Flatism**—a desire for a calm, level, and peaceful life.

### Too Much Slack Can Also Be a Problem
Even Slackists, being human, can suffer if they have too much slack.

In the book [The Ethics of Leisure and Boredom](ref#14), it is argued that although humans evolved as nomadic, active beings (such as hunters and gatherers), modern sedentary life can lead to too much free time, which in turn can cause boredom and restlessness. I agree with this view. When you have too much slack, you might become susceptible to issues such as chronic loneliness, which can even place stress on your cardiovascular system. There is even a catchy saying that loneliness is equivalent to smoking 15 cigarettes a day. Thus, addressing loneliness is essential. Many successful people remain busy or even spend extravagantly—they simply can’t stand being idle.

## Contexton
**Contexton**

### Overview
A Contexton does not jump on tasks without understanding them; instead, they invest energy in gathering and understanding the context—the background, the circumstances, the surrounding information—behind each task.

### The Interpreter
“Context” refers to the background information: the assumptions, conditions, and peripheral data surrounding a task. In ordinary task management, tasks are generally considered “ready to do” and are processed without hesitation (although their priority might be evaluated). A Contexton, however, does not take tasks at face value. They believe that every task has a context that, when understood, can add real value. Knowing the context can provide clarity and help with prioritization—for example, deciding that a task need not be done immediately or that it is acceptable to experiment first and adjust later.

This might evoke the image of a detective gathering clues, but a Contexton is not merely an observer. Their goal is to use the context they have gathered to inform their actions. It is not enough to simply be curious about context; one must also act on it.

This approach is particularly useful for new business ventures or process improvements. In creative endeavors, there is often no “correct” answer. One must quickly gather context, form a provisional interpretation (a hypothesis), and then act. These provisional interpretations are temporary frameworks that guide subsequent actions. Because the cycle must run quickly for success, speed is emphasized. Although it might not seem so, a Contexton invests considerable effort into uncovering context because doing so is essential for informed action.

### Given Japan’s High-Context Culture, It’s Best to Be a “Gamer”
In Japan, communication is culturally “high-context,” meaning that people tend to rely on subtle, implicit cues and shared understandings. This can be at odds with the Contexton’s approach, which seeks to explicitly identify and analyze context. As a result, a Contexton might be seen as disruptive or as an outsider.

In practice, a Contexton might not display overt behavior; instead, they quietly gather context and subtly let it inform their actions. Their approach can be likened to that of a gamer—navigating subtle constraints and seizing opportunities stealthily. For example, you might engage in behind-the-scenes groundwork (such as “rooting” for certain outcomes) or join social gatherings to extract genuine opinions (thus collecting context). Such actions are in line with Japanese cultural norms, where success often depends on reading the room. Understanding context is like having the winning strategy in a game—but it is not the whole game; you must still act appropriately within cultural constraints.

### The Importance of Note-Taking
After gathering context for a task, you might decide not to act immediately. However, if you rely solely on your memory, you may forget both the task and its context. Even if you remember the task later, you might not recall the original context or reasoning behind your decision. This is where note-taking becomes essential.

By systematically writing down tasks along with their contexts—essentially creating your “second brain”—you ensure that nothing is lost. This process prevents tasks from becoming vague or abandoned and allows you to later review what you’ve gathered. The idea is similar to how doctors maintain detailed records and follow-ups for each patient. In the same way, a Contexton documents the context for tasks so that nothing is forgotten.

### What Is Not True Contexton
A common misconception is the “pseudo-Contexton.”

Some people might spend a lot of time in conversation or social interaction and appear to be gathering context, but that does not necessarily make them true Contextons. For instance, if someone is merely trying to gauge others’ emotions or gradually influence their behavior, that is not genuine context gathering but simply social maneuvering. Such individuals often rely on nonverbal cues and spontaneous interaction, and their approach can sometimes be exploited—for example, in cults or scams.

While emotions can be a part of context, context itself is fundamentally about information that is both linguistic and logical. A true Contexton will define and articulate what the context is and use that information to guide rational action. Merely reducing everything to emotional control is a shallow imitation of true Contexton behavior.

It is important to be cautious of pseudo-Contextons—people who claim to “gather context” but are really only engaging in superficial, emotionally driven behavior. Before trusting someone who says, “I’m trying to understand your context,” be sure that they are actually gathering and using that information effectively and not simply indulging in empty rhetoric. (*Note 1*)

- *Note*  
  1. On the other hand, there are professions (such as hosts) that effectively operate as pseudo-Contextons. While it may be acceptable in some social contexts to interact with such individuals, in the realm of task management their approach is generally counterproductive—and can even be exploitative. Exercise caution and balance when dealing with pseudo-Contextons.

## Mixer
**Mixer**

### Overview
A Mixer attempts to process multiple tasks at once or in a single batch.

### Bundling Versus Preparing
Mixers generally adopt one of two approaches.

One approach is to bundle related tasks together and then tackle them all at once. The goal here is to minimize the cost of switching between different types of work—that is, to reduce the cognitive effort required to shift focus. For example, you might plan to do creative work in the morning, handle administrative tasks and communications in the afternoon, and reserve the evening for tasks that involve interacting with people. Instead of doing things sporadically (like housework, exercise, reading, or web surfing), a Mixer would batch those activities—perhaps doing all the housework during a lunch break or on a Sunday morning.

The other approach is to actively seek out “high-reward” opportunities and invest significant effort into preparing for them. For example, if you work in a regional office and get the chance to visit the head office in Tokyo after a long interval, you might identify tasks that can only be handled in the metropolis, plan exactly when and how to tackle them, and—if time is short—extend your stay at your own expense (or adjust your vacation schedule). This is very much like planning a trip. When the potential rewards are high, you invest heavily in preparation. In some cases, you might even organize an event rather than just sharing a document, complete with planning, publicity, and pre-event coordination.

Thus, the Mixer’s philosophy can be summarized as follows:

- Minimize context switching as much as possible.
- When the time is right, tackle tasks in one big, concentrated effort (“batch processing”).

Additionally, Mixers often create “big events” in which they pour all their energy into one concentrated session. Although they may appear slow or methodical at first glance, their cumulative actions are often far more extensive than those who process tasks piecemeal. As mentioned in the discussion on the Automaton’s paradox, overcoming the challenge of systematization requires strong conviction—and Mixers often exhibit this same level of commitment.

This is analogous to how travel enthusiasts meticulously plan trips, arrange logistics, and even study foreign languages in preparation. They might not always be consciously aware of every detail, but to outsiders, their efforts are clearly impressive. Mixers operate in much the same way.

### The Desire for the Ultimate Experience
At its core, the Mixer is driven not just by the desire to complete tasks but by the desire to have exceptional experiences.

Rather than simply acquiring an outcome, a Mixer seeks the very best experience. Whether it’s spending the morning working creatively in a well-designed space with a cup of coffee, or meticulously planning a trip to maximize every moment, the Mixer values the quality of the experience as much as the end result. For example, a Mixer might plan their morning routine to include waking up early, catching the sunrise, and engaging in exercise so that they are fully “switched on” before beginning creative work—all part of orchestrating a truly rewarding experience.

# Summary
- **What Are Stances?**
    - They are about how you execute tasks.
    - While strategy deals with how to “manage” tasks, stances address the methods of “processing” them.
- **Reducing the Load**
    - Examples: Delegator (delegates tasks), Sprinter (processes tasks immediately), Skipper (postpones tasks).
    - These approaches require various abilities: the authority to delegate, the agility and capacity to process tasks on the spot, and the planning and mental resolve to confidently postpone tasks.
- **Streamlining Effort**
    - Examples: Automaton (systematizes processes), Rejecter (follows rejection rules), Focusist (concentrates solely on immediate tasks).
    - This can involve either reducing the processing effort itself or minimizing the mental effort required to decide what not to do.
    - Although “systematization” might initially require a period of intensive effort disconnected from immediate efficiency, it ultimately allows for more flexible application.
- **Engaging in “Off-Board Warfare”**
    - Examples: Slackist (protects and preserves slack), Contexton (gathers and understands context), Mixer (batch-processes tasks).
    - These approaches extend beyond mere task management into a broader life philosophy, requiring a consistent and deeply held belief system to be effective.
