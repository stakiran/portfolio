---
title: Project Task Management(2/3)
---

# Handling Shadow Tasks Effectively

Having finished the discussion on views, let us now address one of the main reasons why project task management sometimes fails: Shadow Tasks.

## Shadow Tasks

**Shadow Tasks** are tasks that are not managed in the task management tool but nevertheless exist at a level that one could reasonably call “tasks,” and which consume our resources—time, energy, money, and mental capacity. Just as unpaid overtime (often called “service overtime”) is work that is not formally recorded, Shadow Tasks exist unrecorded but can be quite burdensome (in many cases, extremely so).

Examples of Shadow Tasks include:

- **General Communication**
  - Work-related consultations and discussions
  - Meetings that occur unexpectedly on the same day (often either urgent or spur-of-the-moment)
  - On-the-spot guidance and training
  - Preliminary coordination
- **Internal Miscellaneous Duties**
  - Requests issued company-wide
  - Assisting with event management
  - Responding to equipment or system malfunctions, failures, or issues
  - Similarly, handling updates or version upgrades
- **Gap-Filling Tasks**
  - Handoffs of work (especially those unplanned or ad hoc)
- **Maintenance**
  - Preparations before or after work
  - Organizing desks, desktops, and other information
  - Lunch breaks, rest, or running errands (including travel time)
- **Catch-Up**
  - Keeping up with industry trends or customer updates
  - Reading documents or books
  - Casual interactions, attending events, or making incidental stops
- **Tool-Related Tasks**
  - Learning and operating task management tools
  - Managing emails and chat communications
  - Setting up, powering on, shutting down, or dismantling PCs
- **Process-Related Tasks**
  - Procedures
  - Formalities
  - Workflows
- **Commuting/Going to the Office**

Shadow Tasks exist everywhere—and often far more than one might expect. A striking example is commuting. In organizations that have discovered that remote work is viable (post-pandemic), some now include commuting time in the workday (see footnote [1]) or reimburse all transportation costs. They have effectively “rescued” the previously hidden task of commuting.

- *Note 1: Although officially the company may not recognize commuting time, in practice it is sometimes included as a matter of convenience. Such flexibility is common in organizational dynamics, and is necessary because if you strictly adhere to formal rules, you end up overwhelmed by Shadow Tasks. Of course, if taken to extremes, it may lead to compliance issues.*

## The Importance of Recognizing Shadow Tasks

Even the example of commuting shows that Shadow Tasks are detrimental to employees. They consume resources yet are not accounted for in task management, so the burden falls entirely on us.

One might say, “These tasks are unrelated, so why record them?” However, the key point is that Shadow Tasks consume resources significantly—and that fact must be acknowledged.

For example, imagine a person whose commute to an office in central Tokyo takes 1.5 hours one way. Suppose this person is extremely uncomfortable in crowds and needs a 30‐minute break after commuting one way. Also, assume their salary is modest, so they live in the suburbs to save on rent. Would we consider their available working time to be the standard 8 hours (or even 7.5 hours)? The answer is no. In reality, this person is effectively burdened with a “2-hour task” twice a day, meaning they are effectively doing 4 hours of “service overtime” every day. In such a state, expecting them to work a full 8-hour day is highly unrealistic—and such details are not reflected in the project task management tool.

Another example: Consider a team that requires reviews and approvals from higher management. Each review may require preparation of documents, attending meetings, and then writing and sharing minutes. Suppose each review takes an average of 45 minutes. And this is only for the review itself—not counting waiting time (for example, if the review is scheduled three days later, the waiting adds additional time). If each person undergoes 1 to 3 reviews per day, they might be spending 1 to 2 hours on reviews. Yet, these tasks are not recorded in the task management tool, leading to questions such as “Why is task progress slower than expected?” Even a simple calculation might reveal a deficit of 1–2 hours, not counting the additional mental load of switching between work and review. I feel that, overall, nearly half a day can be lost every day due to these factors.

There are countless other examples, but the point is that the information provided by task management tools is insufficient. In particular, Shadow Tasks drain our resources more than we expect. As a result, phenomena like “tasks are progressing slower than expected for unknown reasons” or “there are far too few people who can get tasks done properly” occur. This is natural if Shadow Tasks are dragging you down. Moreover, those who seem to manage well are simply the “strong” ones who are able to endure the impact of Shadow Tasks.

Let us call this phenomenon the **Shadow Effect**. In conclusion, it is important to recognize and address Shadow Tasks because doing so provides clues for reducing the Shadow Effect. Instead of being tossed about without knowing why, if you can concretely identify these Shadow Tasks and recognize their impact, you can implement constructive improvements to reduce the Shadow Effect.

The Shadow Effect must be consciously targeted and reduced, as many individuals and organizations remain unaware of it due to its subtlety. Without conscious effort, you cannot even get a foothold.

## How to Handle Shadow Tasks

In project task management, how can we reduce the Shadow Effect—that is, identify and address Shadow Tasks?

First, as a premise, there are two types of Shadow Tasks. One type is those that are directly related to the project (**Direct Shadow**), and the other is those that are not directly related (**Indirect Shadow**). In the examples above, commuting is an Indirect Shadow because the act of commuting is normally unrelated to the project. (There are exceptions, such as business trips.) On the other hand, higher-up reviews are Direct Shadows. Such reviews should be managed as part of the project. The approach to handling them will differ depending on whether they are Direct Shadows, so please keep this distinction in mind.

There are three approaches:

- **1: Use capacity-based task management that takes the impact of the Shadow Effect into account.**
- **2: Build in buffers and slack so that each person has room to handle Shadow Tasks.**
- **3: Manage Direct Shadow tasks as formal tasks.**

### 1: Capacity-Based Task Management

**Capacity** refers to the amount of work a team can process within a given period. For example, if a team can finish roughly 15 tasks in a week, then its capacity is 15. You should avoid assigning more than that. There are various detailed methods for calculating capacity precisely, but I will omit those details. The important thing is to think in terms of “work capacity” and avoid overloading the team. The Kanban method is, in essence, capacity-based.

If you adopt this approach, you can ignore the Shadow Effect. In other words, you assume that the Shadow Effect exists and incorporate it into your capacity planning. Let’s call this **Shadow Based Capacity (SBC)**. If you set a realistic capacity for the team, then naturally—even if, say, three people can only work 5 hours a day due to Shadow Tasks—the team’s capacity is adjusted to reflect that (as if those three people only work 5 hours). Rather than getting upset or forcing them to work more, you simply accept that this capacity is the realistic limit.

The concept is not theoretically complicated, but in practice implementing SBC is very challenging. First, you must achieve a certain stability in the frequency and accuracy of capacity calculations. Agile development methods deal with this, but they are typically aimed at engineers and require practice.

Another complicating factor is the presence of “strong people”—those who are accustomed to the burden of Shadow Tasks and can endure them. They often cannot adopt the SBC perspective, or if they do, they do not translate it into their work. In other words, if someone is capable of managing despite the burden of Shadow Tasks, they will not deliberately reduce their workload. (It’s like someone who can live in a messy room without cleaning it.) In fact, if you force them to reduce their work hours, productivity might drop. In such cases, those “strong people” generally do not want to reduce their workload. The more “strong people” there are, the harder it is to apply SBC. This is not a deep theoretical matter, but simply a matter of respecting each person’s natural capacity. In business, however, the pace of the “strong” often dominates—especially in Japan, where there is a strong egalitarian mindset, and business is already run by the “strong.” Those who are not as strong may have experienced this repeatedly.

### 2: Buffers and Slack

**Buffer** refers to the extra time set aside to handle irregularities. In work, even if something seems like it should be done in one week, estimates are often made for two weeks. This is described as “building in a one-week buffer.” The precise multiplier (e.g., 2×, 1.2×, or a few days extra) is not absolute. The important point is that you must build in some buffer time, because work is unpredictable and often requires additional time to adjust.

The need for buffers also applies to Shadow Tasks. With a buffer, even if unexpected Shadow Effects occur, you have time to cope. Normally, buffers are not specifically reserved for Shadow Tasks, but because Shadow Tasks are so pervasive (even if they are hidden), it is wise to assume that they will affect your work. For a one-week period, a buffer of about half a day might be a good starting point. This additional flexibility can prove very beneficial. Of course, you cannot openly say, “I will slack off for half a day,” so in practice you have to quietly build it in. Although this might feel like you are deceiving your team, it is mutual. If you openly say “Let’s build a buffer for Shadow Tasks,” then, due to strict policies or the need to please superiors, it might cause problems. In such cases, the capacity-based approach (SBC) mentioned above might suffice.

**Slack** refers to a permanent margin of spare capacity—both in terms of time and mental energy. For example, aside from your lunch break, can you secure an extra hour in your regular 7–8 hour workday? If you can, then that extra hour is your slack. Slack allows for refreshment and breaks, and it also provides space for casual conversation that can build camaraderie and sometimes even spark unexpected ideas. Although we tend to think that we must work busily without breaks under a capitalist mindset, that is not necessarily true (though some jobs do not permit slack). There are books about slack, and 1-on-1 meetings that incorporate casual conversation during work hours are now common. Some companies even operate a four-day workweek.

Having slack means you have time to address Shadow Tasks. Even for those who say “I don’t need extra time,” the reality is that Shadow Tasks exist and require attention. If there were no Shadow Tasks, you could simply work normally. The key is that **if slack exists (and can be utilized when necessary), then you have a means to handle the extra burden.** Without slack, you have no margin—but if it exists, it can be used. Even if you do not need it, its existence is important. Although there may not be any formal examples of slack being adopted yet, it is likely to become one of the attractive features of a workplace in the future. For instance, if you are told “There is one hour of slack every day,” wouldn’t that make the workplace seem attractive?

### 3: Managing Direct Shadow Tasks

If a Shadow Task is a Direct Shadow—that is, it is directly related to the project (but is not managed or visible)—then one solution is to make it visible. In other words, clearly articulate what tasks exist, formalize them, assign someone to them, and, if necessary, set deadlines, just like any other task.

The important point is to incorporate them into the regular workflow. Rather than simply having someone assigned to “handle it when they have free time,” integrate Direct Shadow Tasks into the daily work routine. For example, if you hold a morning meeting in which you review the view and decide what to do for the day, then treat the identified Direct Shadows as formal tasks just as you would any other project task. If these tasks are not even verbalized, you might need to hold a “session to list out Direct Shadows” with the entire team or assign a task to every team member to “identify Direct Shadows” (estimated at one hour). Do not simply ask people to “handle it in your spare time”; address Direct Shadows as an integral part of the project.

This is a typical example of “improvement.” When you want to address a particular Direct Shadow, you must launch an improvement initiative and convert that into a task.

Note that I am not addressing Indirect Shadows—those Shadow Tasks that are not directly related to the project—because it is problematic to manage them as part of a project. For instance, if Person A working remotely complains “I can’t concentrate because the dog next door is barking,” and to cope they spend an average of 30 minutes a day using earplugs, medication, or meditation, should that become a project task for handling the dog’s barking? The answer is no. Person A should handle that on their own. (Of course, discussing possible solutions with team members is acceptable, or you might adjust capacity planning to account for 30 minutes less of available work time.)

...
