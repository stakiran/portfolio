---
title: Context(2/2)
---

# The Five Contexts in Task Management
So far we have discussed the overview of context—its necessity and the fact that it can be dynamic or static in relation to task management. Now, let’s delve deeper into the idea of context in task management.

## The Five Contexts
Let’s begin with a table summarizing them:

| No | Name                  | Type    | Explanation                                                         | Example                                                                                                                    |
|----|-----------------------|---------|---------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|
| 1  | Task Context          | Static  | The context inherent to the task                                    | Why it is needed, why it must be done now, who is responsible for it, what triggered it, what it leads to               |
| 2  | Self Context          | Static  | The context related to the individual                               | The constraints the person faces, their position or role, lifestyle, beliefs, intentions, or schemes                        |
| 3  | Tool Context          | Static  | The context of the task management tool                               | The tool’s concept, its design or ambience and the reasons behind it, the developer’s philosophy, how the tool interprets certain terms |
| 4  | Trigger Context       | Static  | The situation in which the task can be executed                         | People, locations, times, or equipment                                                                                     |
| 5  | Load Context          | Dynamic | The “information that must be loaded into your head” when executing a task | That which you need to mentally switch to when changing contexts                                                            |

Contexts 1 through 3 refer to the task, the individual, and the tool, respectively.

For context 4—the trigger context—it is related to what we called [context tags](container#コンテキストタグ) in the “Container” chapter. For example, if you tag a task such as “reading a book” with “train,” then when you want to find tasks you can do while riding the train, you can search for the “train” tag. In effect, you are associating with the task a situational attribute such as “this can be done on a train.” **The word “trigger” means the cue or the impetus, and in task management, the trigger context indicates “when you can or should start the task.”**

For context 5—the load context—this refers to what is required to switch contexts. When you switch between different tasks or resume work after a break, you need to reload the relevant information into your mind. This is known as **context switching**. It is like completely switching the gears in your head, which can be very tiring. Especially for tasks that require a lot of concentration, if you are interrupted, all that information may be lost, and it takes considerable effort to reassemble it. We refer to the information that you need to load into your head as the **Load Context**.

## Why There Is No “On-Site” Context
Earlier, when discussing dynamic context, we mentioned the context of an “on-site” situation. However, among the five contexts listed above, we do not address that. Why is that? It is deliberate.

**The on-site context is not treated as part of the task management context.**

This is because the on-site context is so hectic that neither task management nor any structured method can properly address it. When you are in the thick of things at the site, you’re simply trying to react ad hoc to the continuously changing situation. As mentioned in the [Task Management Axiom](view_taskmanagement#タスク管理の公理), task management inherently involves language and the use of tools. In situations where there isn’t even the time to do that, task management becomes impractical.

However, this does not mean that the on-site context is completely useless. If you step back and manage tasks with enough room to breathe—whether as an individual or in a team/project setting (the latter is not extensively discussed in this document)—then the on-site context will eventually break down into the five contexts mentioned above. For example, statements like “that person said this” or “someone said that” become part of the self context, while situations like “I was told to do this, but is it really okay?” fall under task context.

> *Note:*  
> Although the axiom only explicitly states “using tools” and “tasks are defined by people,” in order to use any tool you must input language, so in effect, language is necessary. There may be some task management methods (like “object-based tasks” [物タスク](strategy#前提知識%3A-物タスク)) that do not use language, but I am not aware of any such methods at present. Without language, it is difficult to clarify a task’s content, so aside from very light uses like an inbox, I do not believe non-linguistic task management will become mainstream—even though the future is inherently unpredictable. Perhaps some genius might someday develop a task management system that does not rely on language.

## The Trade-Off of Context
It is easy to imagine that there is a cost to understanding context. As mentioned earlier, context is often held by people, and gathering information directly or indirectly from them carries the risk of damaging relationships if done inappropriately. If you misjudge the method or the degree to which you probe, you might be met with hostility, ostracism, or a refusal to open up—something we all know all too well. In that sense, it can be risky.

The act of knowing context is not only a trade-off against time and effort; it is also inherently risky. If you do too little, you won’t know the context. But if you do too much, you might expend so many resources that you end up not having enough left to act (or even become paralyzed by the risk, unable to move forward). You must constantly seek the optimal balance.

That said, in general, people tend to “not know enough” or “pay no attention” to context, so it is best to start by consciously trying to understand it.

On the other hand, in large organizations or in highly political environments, changes do not happen immediately; there are also timing issues, and often you have to begin by building trust. In such cases, a patient, gradual approach is necessary. I personally tend to take risks too readily, and this cautious approach is something I struggle with. Although it might sound like a complaint only of those at lower levels, even higher-ups who gather context from their subordinates or on the ground face the same challenges. A top-down initiative that aggressively pushes for context often ends up being superficial. This kind of cautiousness might be described as [negative capability](ref#9).

> *Note:*  
> Of course, merely knowing the context is not enough—you must also decide how to act on it. This, too, requires time and resources. Just as research in new business ventures is endless, so too is the pursuit of context, so you must balance it carefully. In other words, someone who focuses solely on knowing context without taking action risks being seen as merely “well-informed” or “nitpicky.” Some people advocate “just act!” and argue that acting immediately (or that action itself will eventually provide the context) is better—but while that may work in some situations, it is by no means universal. Ultimately, determining how much context to gather depends on the situation at hand.

## Context in Five Parts
We have discussed the overall idea of context and its importance, as well as the fact that it can be dynamic or static. Next, let’s take a closer look at the context specifically in task management.

### Task Context
Task context refers to the inherent context of a task.

There are countless ways to slice context, but let’s approach it using the 5W1H method (except for “Where” which is a bit more difficult):

- **Who**
  - Who is requiring or advocating for this task?
  - For whose benefit is this task performed?
  - Whose situation will be affected by whether the task is done or not?
- **What**
  - What are the facts or opinions surrounding this task (especially the facts)?
- **When**
  - When should this task be performed, and why?
  - What is the reason or the circumstance that makes it necessary to do it now?
  - When was the task originally defined?
- **Why**
  - Why is this task necessary?
- **How**
  - How should this task be performed? Are there any constraints regarding the method?

Knowing these aspects—or not knowing them—can make a huge difference. **Understanding your self context can help optimize the timing and efficiency of your execution, and, if you’re lucky, even boost your sense of satisfaction and overall well-being.**

There are many other ways to slice context, so it might be useful to build up your own repertoire of approaches. Here are a few hints for reference:

- 5W1H
- [Persuasion perspectives based on cross-cultural understanding](ref#16)
  - In Asia, there is a tendency toward “holistic thinking,” with a focus on knowing who is saying what.
  - In Europe, “principle-first” thinking prevails, beginning with theory and concepts.
  - In the United States, there is an “application-first” approach that starts with facts and statements.
- Distinguishing between facts and opinions
- Viewing from the perspectives of people, environment, and tools
- The Tool–Rule–Role framework
  - Tool (the tool itself), Rule (the guidelines), and Role (the position or responsibility)

### Self Context
Self context refers to the personal context that an individual holds.

As mentioned in the previous chapter on [personal task management and mood](view_personal_taskmanagement#調動脈), the “mood” and “motivation” discussed there are aspects of self context (while the context discussed earlier corresponds to task context). Self context also includes the person’s circumstances, beliefs, innate or acquired traits, and even the results of personality assessments like StrengthsFinder or the Big Five. In short, it encompasses **all the factors that explain why a person behaves in a certain way.**

For example, I enjoy “pushing things forward on my own” and “strictly following a daily routine.” These preferences stem from my personal traits, as confirmed by my career anchor assessment. For me, finishing work on time and generally not accepting overtime is only natural, and I will strongly advocate for it with my team or supervisor—and I won’t hesitate to argue or even clash if necessary. However, someone who is unaware of this self context might find my behavior puzzling.

**Knowing self context allows you to understand others’ motives and behavioral tendencies, which in turn helps you maintain your own peace of mind.** Even if you cannot fully sympathize with someone’s actions, understanding the reasons behind them can at least make them more comprehensible.

Self context is extremely complex, and there is nothing absolute that applies to everyone. Some people may choose work over family, while others (for example, devoted fans) might even celebrate a favorite character’s birthday over work commitments; some individuals may be so focused on a specific person at their workplace that they would quit immediately if that person were gone. Teachers, volunteers, and others who put something more important than their own time or money first exist, and then there are those who outwardly claim to value work-life balance while actually prioritizing their own comfort and security. There are even people who view their colleagues or clients primarily as objects for consumption or acquisition in terms of sexual or romantic interest. Truly, there is a vast diversity, and as the saying goes, “truth is stranger than fiction.”

Of course, the deeper layers of a person’s self context are usually hidden, so it isn’t easy to fully know someone. However, **you can estimate someone’s self context to a certain extent.** It is sufficient to label basic motives or characteristics that explain their actions. If you don’t like the term “self context,” you can think of it as forming and testing hypotheses about someone’s behavior.

### Tool Context
Tool context refers to the context of the task management tool itself—in other words, its design philosophy or worldview.

Task management is carried out using tools, and there are many different tools available—each with its own quirks. While a simple application might allow you to get by without much thought, task management is inherently complicated and personal, so using a tool haphazardly is not enough. In fact, I believe that about half of the people who fail at task management do so because they use the tool without really breaking away from their default habits.

So what should you do? You need to understand the tool’s context and use it accordingly. For example:

- How does the tool define the concept of a “task”?
- What kind of [strategy](strategy) or [stance](stance) does it assume?
- What terminology does it use?
- How customizable is it?
  - High customizability means you can adjust it to suit your personal preferences.
  - Low customizability means you should use it as the tool’s design intends.
- How much attention is paid to its design and overall feel?

And there are many other factors. The key is to ask yourself, “Why is this tool designed this way?” or “Why did they introduce this particular concept?” and then try to **find your own answers.** Note that the answer may not be explicitly stated. Even if the documentation is thorough, more often than not you have to interpret the information yourself. One useful approach is to follow the developers (whether individuals or teams) behind the tool. Their philosophy often comes through in the tool. This philosophy is not just an extension of their own self context; it is the passion they’ve imbued into what they create. 

On the other hand, as organizations grow larger, the differences become less pronounced aside from nuances in branding or atmosphere. For instance, although Google and Microsoft might seem very different in terms of their task management services, what one can do with one is often possible with the other. In such cases, the choice largely comes down to personal preference. Factors such as “I usually use Google, so Google Calendar integrates better,” “The company uses Microsoft across the board, so I have no choice,” or “I’m so accustomed to Outlook” may all come into play.

These preferences and circumstances can be tricky and easily misleading. In team settings, or when you are already deeply invested in a particular tool, you may have no choice but to stick with it—but please try not to be swayed solely by personal taste or circumstance. This document discusses individual task management, so it assumes that you are an individual user. However, whether task management is successful or not depends entirely on whether the tool’s design works for you or whether you can adapt to it. In order to decide whether a tool is a good match for you, you need to understand its tool context. If you can determine, “Ah, this tool has this kind of vibe,” then you can either continue using it if it suits you or move on if it doesn’t. In this sense, it’s similar to personal relationships.

One important point to note is that, up to now, we haven’t taken into account factors like personal taste or circumstance. These factors are not only unimportant but can even be harmful. As mentioned earlier, using a tool haphazardly is an anti-pattern, and similarly, choosing a tool purely based on what you like or because of certain circumstances is also an anti-pattern. I repeat: task management is inherently complicated and personal, and to counteract that complexity you need to use equally intricate concepts and systems. Task management is not as simple as it might seem—don’t be fooled by its apparent simplicity. Just as there are underlying principles in every discipline, task management has its own foundation. Yet, because it is not yet fully systematized and is ultimately personal, you must discover how to apply these fundamentals yourself. Relying solely on personal taste or circumstances is not much different from using a tool haphazardly. Instead, you must confront the design philosophy and worldview of the tool head on and determine whether you can adjust to it. **If the tool fits you, then even if you dislike it you should use it; if it doesn’t fit, then even if you like it, you should avoid it.** Ultimately, what matters is whether the tool is actually useful to you, and if you ignore its underlying principles and simply use it superficially, it is nothing more than child’s play.

> *Note:*  
> Some might argue, “Task management is simple!” or “It’s not that difficult—keep it simple.” But in my experience, those who say so tend to fall into one of the following categories:  
> 1. They are merely overwhelmed by a chaotic situation.  
> 2. They possess exceptional innate abilities and can manage without tools.  
> 3. They delegate task management to partners, subordinates, or have sufficient financial resources to do so.  
> 4. They simply don’t have many tasks to manage.  
> Conversely, if you fall into any of these categories, then task management may indeed be simple or even unnecessary (especially in case 1).

### Trigger Context
Trigger context refers to the situational conditions under which a task can be executed.

When you engage in serious personal task management, you may end up with dozens, hundreds, or even thousands of tasks, and since you can’t do them all at once, you need to “save them for later” or “tackle them one by one.” A common technique for this is filtering—extracting only the tasks that meet certain conditions. One very useful filter is the trigger context. Here are some examples:

- Tasks that can be done during your commute.
- Tasks you want to do when you are at home and alone (for example, when your partner and children are not present).
- Tasks that can be executed during a company lunch break.

If you want to extract tasks that you can do under the current circumstances, you pre-tag the task with a trigger context (for example, “commuting,” “alone,” or “lunch break”). Then, whenever that situation arises, you can quickly search for that tag to pull up the tasks you can execute at that moment. Of course, this assumes that you are continuously entering tasks and tags into your tool (which, given portability concerns, is often a smartphone or—if you’re diligent—a paper planner).

In essence, although you might be able to do this filtering purely in your head, human fallibility makes it easy to forget. When you have tens, let alone hundreds or thousands, of tasks, it is simply not feasible to manage them all in your mind. That is why we use tools. 

> *Note:*  
> For instance, in the [Ana-Kichi Notebook Method](https://techo.ana-kichi.com/), you can group sticky notes together on a pad. This is essentially the same as creating an area for a specific trigger context and placing the notes there. In analog systems, where the concept of tags may be hard to implement, you can substitute by designating an area with a name and placing the notes there.

#### Overheat
The trigger context is especially useful for those who are overwhelmed with more tasks than they can possibly process alone—a state I call **overheat**. There are two kinds of overheat: the state of having too many things you want to do (**over-want**) and the state of having too many things you must do (**over-must**). Both situations share the characteristic of being overwhelmed.

There are several ways to cope with an overheat state. The safest approaches are either to delegate tasks to others or, if that is not possible, to simply discard tasks that exceed your capacity. However, both methods are challenging. If you want to do everything yourself and you’re driven by passion, it’s natural to want to handle everything alone. Yet, your capacity is limited, and it is impossible to remember and manage every single task solely in your head.

The solution is to utilize the trigger context. Many tasks can only be executed at a particular time, so if you record them all in your tool with a tag that represents their trigger context, then when that situation occurs you can immediately pull them up. In task management terms, this means **attaching a “trigger context” tag to each task.** Once that is done, you can search or filter for tasks whenever needed.

#### Training Is Key
Managing trigger contexts is challenging.

This is because in your hectic daily life you must repeatedly “register tasks,” “add tags,” and “search using trigger contexts.” It is essential that you always have your tool at hand, and that you can add and search quickly. This is a skill that requires steady practice and training. Of course, you can begin gradually—for example, by first only using a “commuting” tag. If you can slowly add more tags without strain, that is natural.

#### The Optimal Trigger Context Is Different for Everyone
What works for one person may not work for another. For example, the tag “commuting” doesn’t apply if you don’t commute, and “when alone at home” is meaningless for a single person. Similarly, “lunch break” might not work for someone with flexible working hours, who is a night owl, or who is not employed. You must be aware of the trigger contexts in your own environment and be able to quickly convert them into actionable tags. For instance, although “commuting,” “on the train,” and “in transit” might seem similar, they can be configured differently in your tool (for example, by numbering them such as “1: Commuting” to control the order, or by assigning different colors). All of these decisions must be made gradually. Although training takes time, it is the only way forward.

#### The Four Pillars of Context
But can you immediately articulate your own trigger contexts and translate them into tags? That too is challenging. Fortunately, many predecessors have provided examples. I have distilled these into what I call the **“Four Pillars of Context”** (コンテキスト四天王). They are as follows:

- **Person**  
  - The people necessary for carrying out the task  
  - People who might be in the way when you perform the task
- **Place**  
  - The location where the task can be executed
- **Time Section**  
  - The time period during which the task can be done
- **Tool**  
  - The equipment or instrument needed to perform the task

At the very least, you should focus on the three: person, place, and time. In the examples above, “commuting” may refer to either place or time, “when family isn’t around” pertains to person, and “lunch break” refers to time. Typically, what you can or cannot do is constrained by people, places, or time—so even just thinking about these three aspects will suffice.

The aspect of tools rarely comes into play because, in practice, whether you have the necessary tool is often implied by the location or the time during which the tool is available. For example, rather than tagging a task with “requires a computer,” it is often clearer and easier to use a tag like “at home” or “during work hours.”

### Load Context
Load context refers to the contextual information that you need to keep in your head.

Whenever we perform a task, we internalize various pieces of information about the process or situation—the load context. Especially for work that does not finish in one go and must be resumed later, you keep in your mind what was done before. “Oh, I was up to here…” or “I intend to do this and that next” are examples of what you are mentally holding onto. If you forget or cannot recall these details, you may lose momentum or, worse, waste time redoing things inefficiently. While you could try to force yourself to remember everything, that is often impractical.

Many of you have probably heard of **context switching**—that is, switching the load context that is stored in your head. Imagine a manager who must switch between preparing a report for the executives, conducting team meetings, having one-on-one sessions with each subordinate, conversing with a partner at home, and interacting with their children. In that case, there are at least six different load contexts. And if each subordinate requires a different one-on-one meeting, then there are five different load contexts just for those sessions. Every time you switch between tasks, you must change your mental context. If you’re in a meeting with subordinate A but have the context of subordinate B still in your head, your communication may fall flat or even cause offense. As mentioned earlier, when dealing with people, if you ignore their context, you risk being rejected. This applies not only to interpersonal interactions but also to creative work or competitive environments—whether in hobbies or professional pursuits, the load context changes with every project, game, or match.

Needless to say, context switching is crucial. However, **context switching is very tiring.** Although it is important, it is a demanding process. The more smoothly you can switch contexts, the more tasks you can complete overall; even being able to switch with minimal mental friction can greatly reduce the risk of miscommunication or disappointment. Above all, **if you can reduce the fatigue associated with switching, your overall productivity and willingness to act will increase.** It is not a matter of physical stamina but rather mental readiness—often, our reluctance to act stems from the exhaustion of context switching. If you can switch contexts with ease, you will naturally become more active. 

So, how can you manage context switching more effectively?

### A Model for Context Switching
First, let’s understand an image of how context switching works. (Note: This is merely a conceptual model created by me to aid intuitive understanding; it is not meant as a neuroscientific explanation of the underlying mechanisms.)

![load_context](/images/taskmanagement-kamikudaku/loadcontext.png)

In the diagram above, the image represents the process of switching from Load Context A to B. The two key points are that you are “walking” through a series of areas and that you pass through a “neutral recovery zone.”

From this model, we can derive the following principles—let’s give them names:

- **The Principle of Gradual Progress**  
  Since you are “walking” through areas, the transition itself takes time.
- **The Principle of Recovery**  
  You should pass through a recovery zone.
- **The Principle of Overlapping Areas**  
  Because these are areas, they have gradations and overlaps—they are not simply binary states.
- **The Principle of Equivalent Exchange**  
  If you dive deep into a load context, you can be fully immersed, but both getting there and returning will take time.
  - (Here, “equivalent exchange” refers to a trade-off.)

Designing your context switching strategy according to this model can make it easier to adopt. With this model in mind, several strategies emerge. Let’s consider a few.

### Take Adequate Breaks
First and foremost, make sure you **schedule sufficient break time** so that you can pass through the recovery (neutral) zone.

In my experience, the restorative power of sleep is far greater than that of a nap, which in turn is more effective than meditation or simply spacing out; activities like web surfing or chatting are less restorative, and tasks such as household chores or routine work are even less so. Think of sleep as reaching the deepest part of the neutral zone. Although activities like web surfing or a walk do not put you fully in the neutral zone, they can help you get closer. Merely getting closer to the neutral zone is beneficial, and it makes switching to another context easier. 

A word of caution: that doesn’t mean you should spend all your time web surfing or taking walks. Web surfing consumes your attentional resources, and walking uses up physical energy. If you deplete these resources too much, you’ll become unable to move effectively. In that sense, it is best to diversify your recovery activities. Relying on one method exclusively (for example, only web surfing) may leave you exhausted in another way. In short, **find a variety of recovery techniques that work for you and schedule them consciously.** I personally suggest alternating—for instance, 1 hour of work on Task X, 1 hour of web surfing, 1 hour of work on Task Y, then 1 hour of walking. Although this might seem like you’re devoting a lot of time to breaks, context switching is exhausting; if you don’t take sufficient recovery breaks, your work may suffer from inconsistency or blockages. Just as a good night’s sleep is far more productive than pulling an all-nighter, proper recovery time is essential for effective context switching. You may want to experiment and measure your productivity to determine the optimal schedule. 

I will not go into further detail regarding different types of breaks here. My suggestion is simply to “incorporate a variety of recovery methods that suit you” and “avoid relying too much on one method (which might deplete a particular resource, as web surfing might deplete your attention),” and then refine your approach as you go. For further details, you might refer to the literature on this topic [19](ref#19) and [22](ref#22).

### Sprint vs. Marathon
There are different approaches to context switching: some people thrive on clear-cut on/off periods (sprint), while others prefer a more gradual, continuous transition (marathon).

In the sprint approach, you clearly separate work and breaks. When you work, you work intensively—diving deeply into the load context until you are fully immersed, then after a period of intense effort, you quickly exit and switch to something else. For example, you might work on Task A for 3 hours, then take a 2–3 hour break, and then work on Task B for another 3 hours. During Task A, you ignore any distractions or thoughts about other matters until you are fully satisfied.

In the marathon approach, you work at a steady, moderate pace and switch between tasks more fluidly—tending to work on Task A while also intermittently handling Task B. Although you may lean toward one task at a time, you never completely shut out the others. This is akin to multitasking or “working while walking.” Marathoners typically do not take long breaks (for example, they might continue to work while taking a walk, reading or listening to something on their smartphone).

Which style suits you best depends on your personal temperament. If you are a sprinter, you should actively block out interruptions and temptations. If you are a marathoner, you might find that a more open, lively environment suits you better. One indicator could be whether you tend to use your smartphone during a 30–60 minute walk. Over the long term—months or even a year—observe whether you can maintain focus; if you tend to get distracted, you may be more of a marathoner.

In modern society, the marathon approach is more common. With the influence of smartphones and social media, and the fact that work often involves long hours (with even breaks being hurried), people tend to be more susceptible to constant context switching. However, regardless of personality, your lifestyle plays a big role. Personally, I used to be a marathoner but have since shifted to a sprinter mentality—one reason why I have adopted a minimalist lifestyle (for example, I no longer carry a smartphone). Moreover, in many workplaces the marathon approach is the norm; if you are a sprinter without extraordinary ability, you may find it challenging. I mention this not to judge but so you can assess your own type rather than being swayed by prevailing trends.

### Build in Buffers
A **buffer** is extra time set aside to deal with unforeseen events. As the model suggests, context switching is like moving from one area to another—it takes time. **It is wise to account for transition time.**

Especially if you must switch between many tasks throughout the day, even an extra 5 or 10 minutes can make a significant difference. Marathoners, for example, might tend to jump right into tasks without a pause, which can be exhausting. Think of it like catching a train: rushing to catch a train with only seconds to spare is much more stressful than having a 5-minute buffer. Managers, too, often schedule a few minutes between meetings; such buffers can greatly ease the strain.

While each individual context switch may not be very taxing, the cumulative effect can be significant. By consciously building in buffers, you can mitigate the overall “cost” of multiple context switches.

### Develop a “Sense of the Land”
By this I mean that you should become familiar with the “layout” of your various load contexts—their relationships and how difficult it is to transition between them.

For example, writing two blog posts on similar topics is easier to switch between because their contexts are similar. Even if the content differs, if both posts are for the same blog the environmental context is similar, making the switch easier. Although they might differ in content, you can consider them “near” each other in terms of context. I call the presence of at least one close or “near” element a **“near” factor**. In this case, it might be the environmental aspect. The more such “near” factors exist, the easier it is to switch contexts. Ideally, try to identify at least one “near” element, and if possible, several.

What factors can these be? That is for you to determine based on what feels natural. For reference, here are some of the aspects I consider:

- **Content Feel:** If you were to categorize your tasks, which category would each belong to?
- **Deadline Sense:** For example, whether a task has a tight deadline or can be postponed.
- **Material Sense:** Whether the task requires significant effort in preparing documents for others or if it is just for your own reference.
- **Review Sense:** How much scrutiny or review will the task require from others?
- **Trigger Sense:** (Similar to trigger context) How likely is it that the task can be executed under the same situational conditions?

While these may sound complex, the idea is that tasks with similar attributes (for example, tasks with imminent deadlines) are “closer” in context, and switching between them is less taxing. Understanding these distances can help you plan your work more effectively. If you cannot keep track mentally, writing things down or mapping them out (using tools like [Miro](ref#miro)) can be very helpful.

Another important aspect is how “arduous” a transition is—that is, how draining it is. The best example is in sports. In any competitive event, the warm-up and cool-down for a single event can be quite taxing, and rarely does one perform multiple “full events” in a day. The same is true for mentally demanding work, such as brainstorming sessions which can be exhausting. The difficulty of switching between tasks depends both on the nature of the task and on the capabilities of the individual. For example, if you have a task to write the continuation of a 400,000-character novel (already three volumes’ worth), whether this task feels arduous depends on the writer. For most people who do not write novels, it might feel insurmountable; for a skilled novelist who can conceptualize and refine as they write, it might feel relatively easy. In my own experience with web novels, I find that I can only write for a few hours a day because it is so mentally taxing. For a professional writer who can update daily, it might feel as easy as walking on flat ground, but for me it feels like climbing a steep mountain.

Understanding how taxing each task is helps you decide when to tackle it. For tasks that are particularly “arduous,” you may only be able to work on them during your most alert hours—for me, writing a novel is only possible in the early morning when my mind is fresh. Consequently, if I want to write, I must wake up early and reserve several hours for it. This may even require changing your lifestyle (for instance, adopting an early-to-bed, early-to-rise routine). Just as you wouldn’t attempt a serious mountain climb in casual walking attire, you must prepare appropriately. Conversely, tasks that are “easier” can be worked on almost any time. Once you begin, progress is made. For those who struggle to start on their own, leveraging your environment or the influence of others can help. 

In summary, by understanding how taxing each task is, you can plan your work more efficiently—much like creating a map before setting out on a journey.

## Relationship with Task Management Stances
In the chapter on stances, I also covered approaches that emphasize context.

The **“Contexton”** stance places emphasis on task context. (Self context is not particularly emphasized in that stance, although it might be relevant in other situations such as managers building rapport with subordinates or navigating office politics.)

The **“Mixer”** stance, on the other hand, emphasizes load context—that is, reducing the cost of context switching by grouping tasks that are similar.

# Conclusion
- Context means the surrounding circumstances or background.
- Understanding context is crucial because:
  - 1. Without it, your communication won’t resonate—and if done poorly, it may even lead to failure.
  - 2. Opportunities (especially in interpersonal interactions) are scarce, so you need to get it right the first time.
  - Combining 1 and 2: With limited opportunities, it is essential to know the context to make the most of them.
- Context can be dynamic or static.
- In task management, there are five types of context:
  - **Task Context:** Related to the task itself.
  - **Self Context:** Related to the individual.
  - **Tool Context:** Related to the tool you use.
  - **Trigger Context:** Related to the situation in which the task can be executed.
  - **Load Context:** The information you must “load” into your head when switching contexts.
    - For task, self, and tool contexts:
      - There is a trade-off because gathering this information incurs costs.
      - The criteria you use to gather this information will vary from person to person—it is useful to have a variety of approaches at your disposal.
    - For trigger and load contexts:
      - The optimal approach differs from person to person, so you must experiment.
        - Although I have provided my own examples, they are just that—examples, and may not necessarily work for you.
  - The “Four Pillars of Context” and the context switching model are useful tools to keep in mind.
