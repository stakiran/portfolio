---
title: Motto
---

# Overview of the Motto

## What Is a Motto?
A **motto** refers to everything you should keep in mind or strive for. While its original meaning is “slogan,” in this book we use it as a term in task management to denote “all things to be mindful of.”

## Examples of Mottos
Here are some examples of mottos. They can range from guiding principles for life in general to things you plan to implement at work starting tomorrow.

- Slogan
- Personal maxim
- Adage
- Wise saying
- Philosophy of life
- New Year’s resolution
- Monthly resolution
- Things to watch out for from now on
- “Next actions” derived from a KPT (Keep, Problem, Try) review

## Application and the “Adage Problem”
There is one essential quality about mottos: they are extremely difficult to use correctly.

For instance, imagine that at work your boss reprimands you for sending a message directly to higher-ups, executives, or even the company president. In response, you adopt the motto: “Do not contact anyone above your immediate supervisor without permission.” How do you ensure you stick to this? In theory, it means that when the appropriate situation arises, you must recall this motto and act accordingly by refraining from sending the message. However, it isn’t enough to merely remember it—you must also take the correct action to refrain.

In the chapter on personal task management we discussed “forgetting, confusion, and laziness” (忘迷怠), because humans naturally forget, become confused, and tend to be lazy. Especially when it comes to doing something out of the ordinary or something you’re not enthusiastic about, it’s hard to take action. Many might say, “That’s just normal,” but for some people it is far from that simple.

With mottos, you can’t predict in advance exactly when the situation calling for them will arise, so you can’t prepare as easily as with tasks. In task management, you can incorporate clearly written tasks that you see regularly—and then all that’s left is to act when you see them. Even if simply having them in sight doesn’t guarantee action, you can structure your life so that you’re more likely to act. That is the essence of personal task management—but that approach does not translate to mottos.

Yet you also can’t expect to constantly repeat in your head, “Do not contact anyone above your immediate supervisor… do not contact anyone above your immediate supervisor… do not contact anyone above your immediate supervisor…” nor can you write it on paper and stare at it all day. In terms of task management, you might even set a daily morning task like “Recite ‘Do not contact anyone above your immediate supervisor’ 10 times,” but that too proves pointless. At best, you might eventually be able to recite it from memory, and eventually the effect will dull into a rote habit without meaning.

Mastering the use of a motto is difficult because when the relevant situation arises you must both recall it at the right moment and act accordingly. Let’s call this ability **application**. Much like “application problems” in study or exams, it’s not enough just to have the foundation—you must be able to recall and use it appropriately. **A solid foundation does not guarantee success; if you cannot recall it when needed, it is useless.** As mentioned in the previous chapter on personal task management (see [Toremment](view_personal_taskmanagement#トレメント)), task management itself is challenging, and frankly, I believe that a certain talent is required. The same holds true for using mottos: a talent for application is necessary.

Thus, mastering the use of mottos is no small feat. This very challenge is what I refer to as the **Adage Problem**. In short, it is hard to put adages into practice.

## The Athlete and the Applier
I believe there are two types of talents in task management.

One type is the talent for facing what we call [Toremment](view_personal_taskmanagement#トレメント) with unwavering determination. For example, if you decide to take a one‐hour walk every morning and you actually do it—regardless of how bothersome or difficult it might be, and regardless of whether someone tells you to or there’s any reward—you do it purely out of your own will. In self-help circles you often hear phrases like “nothing is more effective than willpower or a decision,” but those are typically the words of someone who lacks the talent for confronting Toremment. I call people of this type **Athletes**.

The other type is the ability to handle the aforementioned Adage Problem. Once you set a motto, you can recall it appropriately in various situations and act accordingly. This shows a strong capability for application. I refer to such people as **Appliers**.

In my view, the Athlete and the Applier do not coexist. I consider myself a typical Athlete—and I believe many of you reading this have sensed that. Personally, maintaining a regular daily routine doesn’t bother me; in fact, I even dislike when my routine is disrupted. I easily wake up and go to bed at the same times every day, eat three proper meals, bathe, clean, etc. I really can’t understand why some people struggle with these simple tasks—as if I were looking at aliens. On the other hand, I am not very good at handling the Adage Problem; the earlier example is, in fact, drawn from my own experience. To overcome that challenge, I had to wait until I encountered a book called [Intercultural Understanding](ref#16). That book explained, for instance, why in Japan you shouldn’t directly communicate with anyone above your immediate supervisor. Once I understood that this was simply a reflection of the culture—a hierarchical system where you are expected to deal only with your immediate superiors and subordinates—I finally came to terms with it. Incidentally, that book uses the term “hierarchism” to describe a model where you should only interact with those immediately below or above you, and reaching beyond that is considered overstepping.

That said, there are also many Appliers, and it even seems that they are more common. Work environments tend to be busy, and the concept of on-the-job training (OJT) is rooted in the Applier’s way of thinking. Because Appliers excel at application, they can readily put into practice what they’ve learned even in hectic situations. Conversely, such people often get swept up in busyness and tend to handle things in an ad hoc manner; they are not comfortable with the Athlete’s way of a regimented life. If you can apply things as needed, you feel no need to adhere to rigid routines (Toremment), and consequently, you may not feel a deep sense of conviction. In fact, because you’re so capable of adapting, you tend to pack your schedule with work and commitments, leaving little room for the kind of training that an Athlete might require.

Of course, there are exceptions. Professionals, for instance, are exceptional in that they manage to be both Athletes and Appliers—within their field they apply themselves with the precision of an Applier (since failing to do so would render them unprofessional), while still adhering to disciplined routines (often thanks to support from their environment, team, or coach). However, such professionals are rare, and in my view, these two approaches usually do not coexist; one typically leans toward one side.

# How to Handle a Motto
How you handle a motto depends on whether you’re an Athlete or an Applier. However, there are some principles that apply to both.

## Principles for Handling Mottos
These apply to both Athletes and Appliers.

First, a common-sense guideline: be careful not to overload yourself. If you have too many mottos, if you’re in an overly hectic situation, or if you’re simply tired, it becomes much harder to apply them properly. If you find that you’re adopting too many mottos (or if you’re in a situation where trivial mottos crop up all the time), it’s best to discard some. Also, when you’re busy, you rely on habitual actions and instinctive reactions, so you can’t afford to leisurely ponder your mottos—you may have to temporarily set aside their application. And if you’re exhausted, of course, you should rest.

Another key point is that you must feel convinced by your mottos. Ultimately, you cannot do something if you’re not convinced of its value. You might pretend to be convinced and adopt a motto just for the sake of it, but that won’t stick. To build true conviction, refer back to the concept of [Chodomeikyaku](view_personal_taskmanagement#調動脈)—the pursuit of rhythm, motivation, and context—as mentioned earlier. Athletes, in particular, tend to say, “I’m not really convinced, but everyone else seems to be doing it, so I’ll just go along,” but that’s an anti-pattern. If you can’t apply a motto effectively, it won’t become ingrained. Instead of merely adopting a motto, focus on understanding the underlying rhythm, motivation, and context. In particular, understanding the context—why the motto is necessary and why those who embrace it feel convinced—is the key. This requires calm introspection, discussion, or studying through books, all of which demand time and space. Knowing your own values and tendencies is crucial; without that self-understanding, a genuine sense of conviction cannot develop (you might end up being swayed by emotions or simply following others). In that sense, be very careful not to overload yourself.

In summary, avoid packing too many mottos into your life—give yourself some breathing room.

## Mottos from the Perspective of an Applier
Since Appliers have strong application skills, they usually don’t struggle with the Adage Problem.

If there is one issue, it is that a motto that is too vague can be hard to put into practice. For example, a motto like “Be an honest person” is too broad to guide specific actions. It might be better to break down what “honesty” means into its components and be more specific—say, “Always keep your promises, and if you can’t, make sure to communicate that.” If you need to allow for exceptions, you might add mottos like “If you’re facing imminent danger to your body or mind, do not hesitate to retreat without debate” or “At worst, offer a sincere apology later (though if things break down completely, even that might not be possible).” 

That said, because Appliers excel at adapting to different situations, a somewhat broader motto can actually be more useful. A broader motto is often more flexible and easier for an Applier to interpret. A common approach is to think of a specific person—real or fictional—and ask yourself, “How would this person handle it?” If you can think of someone (say, Person A) who embodies honesty, you can adopt that person as a model for your motto. It might not be fully articulated in words, but if you can apply it, that’s all that matters.

## Mottos from the Perspective of an Athlete
Athletes typically lack the natural ability to apply mottos on the fly, so they need to employ some strategies.

The simplest method is to rely on the power of your environment. Whether it’s your boss, team members, or roommates—anyone who can provide prompt and frequent feedback—working alongside such individuals means that even if you aren’t good at recalling a motto on your own, someone will remind you in the moment. (Of course, relying too heavily on others can lead to friction—common complaints might be, “They keep making the same mistake over and over”—but it is still better than struggling alone.) In fact, the key for an Athlete is learning how quickly you can depend on your environment, especially on other people.

Another approach is to take each motto one at a time and turn it into a system. Convert the motto into a concrete process, and once that system is well established, you won’t forget it. To revisit the earlier example about contacting superiors, you might create a “List of People I Am Allowed to Contact on My Own During Work.” On that list, include your immediate supervisor, team members, and even those outside your immediate circle (such as colleagues who joined at the same time or people you met at events) who have been given permission. Make it a habit to check this list before reaching out. Essentially, you stop making spontaneous decisions and instead follow a rule: you may only send messages to people on the list. And if you want to contact someone not on the list, you first check with your supervisor; if you receive permission, you add that person to the list. Once added, you can send messages freely because seeing the person on the list reassures you that it’s acceptable. Although this process is rather mechanical, it ensures that you follow a predetermined system. Once the system is ingrained, you won’t forget it—and even if you later simplify it somewhat, it will still work effectively. Then you move on to the next motto and repeat the process, cementing each one step by step.

I’m still exploring even better methods. I’ve been considering tools that randomly remind you of your mottos or even methods that visualize or narrativize the application of mottos so that you remember them as “rich information,” but these ideas are still a work in progress. I’d very much like to be able to apply mottos as effortlessly as an Applier does.

# How to Create a Motto
Mottos can come from others (**External Motto**) or be ones you create yourself (**Internal Motto**).

Both are valid, but which one suits you best depends on the individual.

## Switching Back and Forth
You can adapt an External Motto to fit your own perspective (turning it into an Internal Motto), or if you’ve created an Internal Motto that turns out to be unclear, you can modify it by drawing on an External Motto that is easier to understand—essentially converting it into an External Motto. As mentioned earlier, a sense of conviction is essential with any motto, and that conviction depends on whether you truly understand it. And understanding comes through articulating it. **It is desirable to use both External and Internal Mottos—in fact, it’s best to move back and forth between them.**

## How to Create a Motto
For External Mottos, it helps to look to a wide range of sources—not only classical works or the adages of famous figures, but also manga, tweets, or comments from people around you. The classical adages, while often excellent, tend to be too abstract, disconnected from your everyday life, and therefore hard to apply. In contrast, a tweet that’s trending on X (formerly Twitter) or a remark from someone close to you might be much easier to understand and resonate with. However, relying solely on contemporary sources can narrow your perspective, so it’s wise to compare them with classical adages and refine your understanding (for example, “In the end, isn’t this all about being honest?”).

For Internal Mottos, the key is to articulate your thoughts. Start by writing down your feelings and thoughts in a journal. Over time, you may begin to notice recurring patterns or ways of thinking and decide to label them—“Let’s call this XXX,” for instance. Some people may find this process challenging, but the important thing is to put it into words. Merely thinking about it in your head won’t change anything—even though some instinctive types can still manage to apply what they know. It all comes down to personal disposition.

Since Internal Mottos are inherently personal, there’s no need for modesty—if it resonates with you, that’s enough. Don’t hold back from articulating it; if you’re uncertain, just give it a try. You can always refine it later. However, if you become too immersed in your own internal perspective, your view may become biased, so it’s a good idea to periodically compare your Internal Motto with External Mottos and make minor adjustments. You might wonder, “Should I ask others for feedback?” But often that won’t work well and might even irritate people, so it’s better to keep your Internal Motto private while still using External Mottos as a reference for fine-tuning.

## External Mottos Are Only for Reference
External Mottos are often heavily sanitized. In reality, a person’s genuine thoughts and all the subtle exceptions behind an idea get stripped away, leaving only a neat, catchy phrase. In that sense, an External Motto by itself is not very useful. When you hear a motto, you might just think, “Hmm,” and that’s it. This is especially true of proverbs—for example, if you hear “The early bird catches the worm” (or its Japanese equivalent “早起きは三文の徳”), you might only think, “Sure, that makes sense.”

Some people might say, “But I really resonate with some of them,” but those are more like shared sentiments rather than true mottos, and they differ in nature. In today’s world—where social media draws attention and even revenue—topics on self-improvement and life remain in demand, and many phrases that appear as mottos are really just sentimentality wrapped in a catchy line. Be particularly cautious with mottos that use broad subjects such as “men,” “women,” “Japan,” “foreign countries,” “Tokyo,” “the countryside,” “youth,” or “the elderly.”

The key is to take an External Motto as a starting point and then interpret it in your own way. Even with a proverb like “The early bird catches the worm,” you can immediately investigate what “early rising” truly means, what “three mon” implies, what “virtue” is, and whether it’s really beneficial—and then compare that with your own experiences. There isn’t one single correct answer; you might establish a hypothesis, and that’s perfectly fine. You can always modify it later. For instance, a night owl might interpret it as “The time of day doesn’t matter” or “It’s important to use your refreshed mind immediately after waking up,” which can eventually evolve into an Internal Motto like “Spend the moments right after waking on what you most want to do.” Whether it’s right or not doesn’t matter—you can always change it later.

# Summary
- A motto refers to all the principles or attitudes you should keep in mind.
  - It includes not only slogans but also adages, resolutions, things to watch out for in the future, and more.
- It is difficult to use a motto properly.
  - You must remember it at the right time and act on it.
    - This ability is what we call “application.”
  - Unlike task management, where you simply act on clearly defined tasks, applying a motto is much more challenging.
  - We refer to this challenge as the “Adage Problem.”
- In fact, there are two types of talents in task management: the Athlete and the Applier.
  - The Adage Problem is a challenge primarily for Athletes.
- To address the Adage Problem:
  - First, build a genuine sense of conviction.
  - Appliers generally have no trouble.
  - For Athletes, either rely on the strength of your environment or systematize each motto step by step until it becomes second nature.
- When creating a motto, it’s best to treat it as an ongoing process.
  - Draw inspiration from external sources (External Mottos) and also develop your own (Internal Mottos).
  - Don’t just set it once and forget about it—continue to refine it over time.
