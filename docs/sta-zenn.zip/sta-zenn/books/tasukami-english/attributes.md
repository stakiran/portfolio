---
title: Task Attributes(1/2)
---

There are various *attributes* for a task. For example, “Name,” “Start Date,” “End Date,” “Priority,” “Assignee,” “Tag,” etc. are all attributes. From the perspective of task management, a task can be considered an item that has *n* attributes, and we can sort or filter tasks using these attributes. Different tools and methods use different sets of attributes.

As such, attributes and task management are, in fact, inseparable. Normally, you don’t consciously think much about it, but if you ever create your own task management system or customize an existing tool, knowledge of attributes will prove convenient.

This chapter takes a reference-like approach to the attributes tasks can hold.

# The 3 A’s of a Task
A task consists of the following three components:

- **Attribute**
- **Arrow (Relationship)**
- **Attachment (Features)**

This chapter focuses on attributes, with more details explained in the following sections. In this section, we will briefly touch on Relationships and Features. Since this is a good point to introduce the 3 A’s, we mention them here. They are not directly related to attributes, so feel free to skip if you’re not interested.

## Relationships
**Relationships (Arrow)** refer to connections with other tasks—containment, references, dependencies. The English term “Arrow” might look unusual, but it reflects the idea of arrows connecting tasks. It’s a bit forced to match the 3A acronym, but it’s easier to memorize.

Relationships can be summarized into the “3 P’s”: Parent-Child, Point, and Pre and Post.

**Parent-Child Relationship** is the most familiar type. For instance, a parent task can have child tasks hanging from it, or we might say Task A has subtasks A1, A2, A3, and so forth. We also see it when discussing granularity, for example:

 - “Move to a new place”
   - “List potential new places”
   - “Decide on one new place”
   - “List moving companies”
   - “Choose a moving company”
   - ……

Here, it’s effectively creating four child tasks under the parent. Even someone who doesn’t know about formal task management is likely to arrive at such a structure naturally. While it’s useful for ensuring comprehensiveness, it can also be quite painstaking and burdensome. Many people might find it too cumbersome to do in non-work scenarios.

Next is the **Point Relationship**, which connects tasks loosely via links. In a scenario where Task A links to Task B, A is the link source and B is the link target. You see this network-like structure in many contexts—e.g., social networks or websites on the Internet—but it’s not commonly used in typical task management. One situation where it might appear is if you manage tasks (among other things) using note-taking tools with linking features such as [Scrapbox](ref#scrapbox) or [Obsidian](ref#obsidian). For instance, you might have a page called “Move to a new place” and another called “Places I want to live in the future.” If you link from the “Move to a new place” page to the “Places I want to live in the future” page, you get a relationship like this:

```
“Move to a new place” → “Places I want to live in the future”
```

When trying to narrow down prospective locations, maybe you open the “Places I want to live in the future” page from the “Move to a new place” page. Conversely, if you happen to look at the “Places I want to live in the future” page, you might notice the backward link to “Move to a new place” and think, “Right, I really should consider moving soon,” and that changes your perspective. Point Relationships are useful for loosely connecting tasks and letting your future self stumble upon them and spark new ideas. You can’t expect the same level of comprehensiveness as Parent-Child relationships, but they are easier to begin and maintain. Actually, note-based task management can be surprisingly profound, so this book devotes a later chapter to it (“Literary” or “document-centric” task management).

Finally, we have **Dependency Relationships**, which appear in the context of [Workflows](view_personal_taskmanagement#省力化する). For example, if Task A should only begin once Tasks B and C are done, then we have B, C → A. You would use specialized tools for that. These tools can show a warning if you try to start A prematurely (“B and C aren’t finished yet!”), or if automation is possible, once B and C are finished, they can automatically trigger completion of A, and so on. For instance, suppose you want to complete “Moving to a new place” once your busy project X ends. Maybe you want “Move out” to surface right after the last task in Project X, “Hand over to Sato,” is completed. By setting a dependency, you might see something like:


```
Current task:
- Hand over to Sato

Future task to surface & condition:
- I want to move out! (Condition = “Hand over to Sato” is done)
```

This way, after completing “Hand over to Sato,” the “I want to move out!” task appears, reminding you that you wanted to move out once the project ended. As you can see, dependency relationships are even more cumbersome to set up than parent-child relationships. It’s no longer just a “setup” but something close to a full design process. However, if done well, it can be the easiest approach to maintain. It’s especially good for automating processes. You can see these kinds of features in many existing task management tools, and specialized workflow tools like [IFTTT](https://ifttt.com/) or [Zapier](https://zapier.com/) exist as well. Even chat tools nowadays often support integrations with other tools, and “low-code/no-code” solutions that let you visually “program” by puzzle-like pieces are also on the rise. Fundamentally, it’s just defining “X → Y (if X happens, then do Y),” and if the tools involved support automated operations, you can chain them together as X → Y → Z → A → B, etc. Of course, that doesn’t mean these tools will automatically do the tasks you have; they only automate the operations within each tool that supports automation. You’d still have to investigate which puzzle pieces exist and how to combine them. This is essentially the nature of programming. It’s as much about programming as it is about task management. This book won’t delve further into that.

## Features
**Features (Attachment)** are various functionalities associated with a task, such as:

- Comments
- Attachments
  - “Attachment” in English is derived from “file attachment.”
- Checklists
- Reminders
- Reactions (likes, stamps, etc.)

You often see task management tools with robust functionality, but these are just features, not the essence of task management. This book won’t discuss them in detail beyond this point.

One thing to note: Don’t get so caught up in the convenience or worldview of these features that you forget the true point: task management. Start as if you won’t use any features, try one or two that interest you or seem helpful, and see how it goes. If something doesn’t fit, you can drop it, and if it seems good, keep it. If you try to use everything right away, you’ll likely be overwhelmed.

Tools, not just task management tools, often expand functionality to capture our interest. It’s easy to get lured in, think we’re being earnest, and then realize it’s not real task management but just tinkering for fun. If that’s your hobby, then go for it, but if you truly want to manage tasks, be careful not to get lost in the features (※1). Maintaining a healthy skepticism is just about right. Focus on relationships and attributes. Think about how to handle your own tasks using them.

- ※
  - 1 This is not to say features are harmful or not useful. In some contexts, features can be central, such as in multi-person task management where [chat becomes key](partner_taskmanagement#タスクごとのやり取り). But for individual task management, be cautious about overemphasizing features at the expense of relationships and attributes.

## Attributes
We’ll go into detail in the next section, but here’s a brief explanation.

**Attributes (Attribute)** are structural elements of a task. Which attributes a task management tool or method adopts—and how it presents them—is fundamental to its design and an area where developers can show off their capabilities.

Let’s look at an example: a simple task list.

First, assume the list only has the “Name” attribute. It might look like this:


```
- Move to a new place
    - List potential new places
    - Decide on one new place
    - List moving companies
    - Choose a moving company
```

At first glance, this seems normal. But it’s actually quite inconvenient. For example, if you finish “List potential new places” and want to mark that status, you can’t. You only have a “Name” attribute, and “finished or not” doesn’t belong in the name.

So let’s add another attribute: “Status.” Let’s say `[ ]` means “not done” and `[X]` means “done.”

```
- [ ] Move to a new place
    - [X] List potential new places
    - [ ] Decide on one new place
    - [ ] List moving companies
    - [ ] Choose a moving company
```

Now you can see “List potential new places” is done.

Next, suppose you want to do the next task. One question arises: Is this list meant to be done strictly top-down, or can tasks be done in any order? There’s no way to tell, because there’s no attribute to indicate that.

So let’s add “No” (number) as an attribute. We’ll say it denotes execution order: always do smaller numbers first; tasks with the same number can be done in any order.

```
- [ ] Move to a new place
    - [X] 1 List potential new places
    - [ ] 2 Decide on one new place
    - [ ] 1 List moving companies
    - [ ] 3 Choose a moving company
```

We assigned numbers 1–3. Listing tasks are all independent, so we gave them 1. Deciding on a place requires the listing to be finished, so that’s 2. Deciding on a moving company might wait until we’ve picked a place, so that’s 3. Looking at this, it’s clear which tasks to tackle first.

We now have three attributes: “Name,” “Status,” and “No.” With just those, it’s somewhat practical as a task list. You can maintain it with pen and paper or a text file. Or you can use an existing task management tool, or even develop your own. Either way, you’d be consciously using the three attributes of Name, Status, and No.

Of course, there are many other attributes you could add. But even if you add them all, you’ll probably only end up overwhelmed. Each attribute requires maintenance—entering values, updating them—and more attributes mean higher maintenance costs (though you can do more with them). We call this the **Attribute Dilemma**. It’s a trade-off. The key is finding balance. Incorporate only the attributes you truly need, as compactly as possible.

# How to Read This Chapter
For the remainder of this chapter, we’ll cover each attribute in a reference format.

## Mixed Perspectives
We’ll mix viewpoints: one from the user’s side (someone who uses attributes) and one from the developer’s side (someone who builds task management tools or methods). We won’t explicitly separate them, so please interpret as needed.

- **User**: Reads, writes, updates attributes.  
- **Developer**: Designs and implements which attributes exist, and how they are displayed and used.

## One Paragraph per Property
Each property or characteristic is discussed in a separate paragraph. You can think of them as bullet points, each with a different property.

## Practices Along with Properties
Besides explaining each attribute’s properties, we’ll also discuss practical usage, including how to handle and differentiate them.

...