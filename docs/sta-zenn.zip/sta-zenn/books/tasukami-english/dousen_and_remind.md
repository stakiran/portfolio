---
title: Movement Paths and Reminders
---

Even in task management, action is ultimately required—but it is we humans who must carry it out. Yet especially in today’s busy, easily fatigued society, we can’t always act (or even remember to act) at the appropriate moment. Generally, we create events in a calendar and hope that simply looking at it will keep the tasks fresh in our minds—but we still end up forgetting sometimes. Even something as classic as an alarm clock shows us that human performance can be unreliable. We’re so inept that many of us can’t even wake up at the same time every day—and hardly anyone is forgiven for being that unreliable.

That is why it is extremely important to be able to act when needed—and especially to be reminded (or become able to be reminded) to act. This is where movement paths and reminders come in. In this chapter, we will cover movement paths and reminders. In truth, if all you want is to be able to take action when needed, you can “rely on your environment or other people”—but that option will not be discussed here. In this chapter, our goal is solely to achieve action by relying on movement paths and reminders by yourself—without depending on your environment or other people.

# Movement Paths

## Overview of Movement Paths
(As mentioned briefly in the chapter on Personal Task Management [see here](view_personal_taskmanagement#動線の重要性), to restate: **movement paths** refer to places you traverse frequently every day. They are not limited to physical locations such as the door of a restroom or an office desk; your computer’s desktop, your smartphone’s home screen, or even a chat tool you use daily for work can also be considered movement paths.

What qualifies as a movement path differs from person to person. Even for the same person, movement paths may change. In an extreme example, if you move to a new home, all your physical paths change. Similarly, if you adopt a new tool or change the way you use an existing one, your movement paths will change accordingly.

## Movement Paths Reduce Forgetting, Dithering, and Laziness
Because movement paths are places you pass by frequently, if you place a task there you should see it often. The more you see it, the higher the likelihood that you’ll act. For example, if you write “Shopping” on a piece of paper and place it on your front door the night before, you’re likely to remember to take out the trash—or to go shopping—when you leave for work the next day.

I’ve been using words like “should” and “I think” deliberately, because it isn’t foolproof. **It merely increases the chances of the task coming into view.** Just because something is in your sight doesn’t mean you won’t forget it, nor does it automatically eliminate hesitation or laziness. (If it were that simple, we wouldn’t have to work so hard.) Nevertheless, if a task never appears in your view, you’re almost 100% likely to forget it (if you could naturally recall everything without any external help, task management wouldn’t be necessary). Placing tasks along your movement paths to increase the frequency with which you see them—and thereby increasing the likelihood of taking action—is an extremely practical approach.

## Placing Tasks Along Movement Paths
What does it mean to place tasks along your movement paths?

Let’s start with an example. Suppose it is a weekday afternoon and you are working from home. You want to go shopping after work, so you write “Shopping” on a piece of paper. As it stands, you might not remember this after work, so you decide to place this paper somewhere along your movement paths. There are many options for where to put it:

- **1: Stick it on a door**  
  (e.g., on the refrigerator, bathroom, or front door)
- **2: Roll up the paper and put it in your shoes**
- **3: Add “Shopping” as an event to your personal calendar for after work**
- **4: Post a note saying “I’m going shopping today” on a frequently used platform (X)**
- **5: Email yourself a note that says “Shopping”**
- **6: Place the paper inside the shelf where you store your company PC**

Let’s examine these options one by one and, along the way, introduce some important concepts.

### Neglected
#### (Option 1: Sticking It on a Door)
The idea of sticking the note on a door is convenient but is also prone to becoming a meaningless habit. You likely pass by the refrigerator, bathroom, or front door at least once before finishing work—so you might see it and think, “Yes, I need to go shopping after work.” However, that doesn’t guarantee you’ll recall it after work. Moreover, you might not happen to glance at the door again at the right moment.

Furthermore, even if you do see it again, you’re likely to simply ignore it. Once you’ve seen and registered the item, later on—even without consciously deciding “nah, I’ll skip it”—you might unconsciously overlook it. This phenomenon is what I call **Neglected** (ネグレクテッド), and it is very common in personal task management.

Reducing forgetting, dithering, and laziness through movement paths is also a battle against Neglect. To prevent Neglect, you must carefully design where and what to place along your movement paths. I call this **Movement Path Design**. Designing your movement paths is your own responsibility. In the future, roles such as “movement path designers” might even emerge—but for now, that idea is too avant-garde (and difficult to monetize) to have taken hold. You cannot avoid designing your own paths; and if you dislike doing this, then you may have to give up on reducing forgetfulness, dithering, and laziness via movement paths. (I will discuss movement path design in more detail later.)

### Active Reminders
#### (Option 2: Rolling the Paper and Putting It in Your Shoes)
Option 2—placing the paper in your shoes—is set up to trigger when a specific action occurs (in this case, when you put on your shoes). In effect, it functions as a type of reminder. Although we typically think of reminders as alarms set for a specific time, more generally a reminder means “to alert you when something happens.” Here, that “something” is putting on your shoes. Although you can’t directly detect when you put on your shoes, if you put something in them, you’ll notice it when you do.

The advantage of this method is that, like any reminder, it **forces its message upon you.** Think of an alarm clock—the sound is so obtrusive that it appeals strongly to your hearing. Similarly, the note in your shoe appeals to your sense of touch (via the soles or toes). It’s much more compelling than simply reading text voluntarily. The stronger the cue, the more likely you are to act. It can jolt you into awareness.

This type of reminder—one that “pushes” its message on you from the outset—is what I call an **Active Reminder**. Those who rely heavily on digital tools are likely familiar with pop-up messages or notification dialogs that use visual cues. And even if not, everyone is aware of auditory cues like those of an alarm clock. With smartphones, you can also use vibration (haptics) as a cue; when your phone is in your pocket, the vibration serves as a tactile reminder. Placing paper in your shoes falls into this tactile category. (See note 1 below.)

- *Note 1:*  
  The other senses are smell and taste, but to my knowledge no reminder system uses these yet. They may be developed in the future, but it seems difficult to quickly release a scent or place something in your mouth on cue. Even if such methods are developed, they would likely be slow-acting—more of a gradual cue that seeps into your consciousness.

### Trap Reminders
The following options fall under what I call **Trap Reminders**:

- **3: Add “Shopping” as an event to your personal calendar for after work**
- **4: Post a note saying “I’m going shopping today” on a frequently used platform (X)**
- **5: Email yourself a note that says “Shopping”**
- **6: Place the paper inside the shelf where you store your company PC**

Option 3 uses a tool—the calendar—which you are highly likely to follow, so by inserting your task into it, you boost the chance that you will follow through. This is what I call a **Trap Reminder**. It involves pre-setting a prompt so that your future self will be reminded. Although this may sound technical, nearly everyone uses scheduling tools, so adding a task as an event is straightforward.

This method isn’t limited to calendars. For instance, if you have a to-do list that you check several times a day and you reliably complete its items, simply adding one more line to that list might suffice. However, if you have a habit of procrastination, you may be more prone to Neglect, so caution is needed.

For options 4 (posting on X) and 5 (emailing yourself), these can also work as Trap Reminders for some people. If you frequently use X and habitually review your posts (for example, to check for typos), then option 4 might remind you about shopping. Similarly, if you use a private account on X as a kind of diary or to-do list, it could serve the same purpose. Likewise, if you tend to check your personal email after work, option 5 should catch your attention then.

Option 6—placing the paper in the shelf where you store your company PC—is similar. If you have the habit of putting away your company PC in a designated shelf at the end of each workday, that shelf becomes part of your “movement path” at shutdown. By placing the note there, you design your movement path so that you see it at the appropriate time. If you don’t have such a habit or it isn’t well-established, this method won’t work.

In any case, Trap Reminders mean placing your cue where you are most likely to act. If you misjudge the placement, you might either not see the reminder in time to act (what I call **Lost**) or see it too many times before the right moment, which leads to Neglect.

For example, if it were up to me, I wouldn’t necessarily choose options 3–6—I have a to-do list that I check several times a day, so I’d simply add the task there. Option 6 might also work for me. I always store my company PC in another room at the end of the day to create a clear work–life boundary; placing a note there ensures a high likelihood of notice. (For instance, I hang my company PC—bundled in my bag—on a hook and attach a note there.)

## Movement Path Design
To reduce forgetting, dithering, and laziness by placing tasks along your movement paths, it is crucial to design your paths—that is, to carefully consider what to place and where.

For convenience, let me coin a term. Let’s call the practice of reducing forgetting, dithering, and laziness by placing tasks along your movement paths **Movement Path Reminding**. In other words, it means placing tasks along your movement paths so that you’ll later be reminded of them. In this context, designing your movement paths is essentially about how to implement movement path reminding.

### Avoiding Both Neglect and Loss
Keep in mind that movement path reminding works based on a specific execution timing. In our examples so far, the task was “I want to go shopping after work,” so there is an inherent “after work” timing.

Now, regarding the frequency of reminders: you want the timing to match naturally. If you have too many reminders, they become so routine that you start to ignore them (**Neglect**). Conversely, if there are too few, you might miss the timing altogether (**Lost**).

In other words, you need a balance—set few enough reminders to avoid Neglect but set them early enough (or frequently enough) to avoid Loss. To ensure this balance, you must carefully decide where and what to place along your movement paths.

### Differentiating Between Hubs and Joints
Next, let’s discuss the types of movement paths. There are two kinds: **Hubs** and **Joints**.

- **Hub**  
  - (Meaning “base” or “home position”)  
  - It can be thought of as your “home base.”  
  - It is a place you use as the starting point for your daily actions.  
  - It’s where you perform an action, return, perform another action, and then return again.  
  - Examples include any tool, file, or list that you use regularly and into which you can write—in other words, any screen or input area.

- **Joint**  
  - (Meaning “joint” as in a body joint)  
  - These are transit points you pass through frequently.  
  - All movement paths other than your hub can be considered joints.  
  - For example, your front door qualifies as a joint.  
  - It also includes places you check several times a day where you cannot write anything yourself (such as information-gathering sites or communication tools).

### First, Consolidate in Your Hub; Optionally Use Joints
**Movement Path Reminding is generally best achieved via a Hub.** A hub is essentially your familiar workspace—if you quickly jot down a task there, you can be confident that you’ll remember it later, giving you a sense of stability and reliability. Of course, depending on the hub, that stability might not always be present. I can manage my tasks consistently using my to-do list, but some people may not be able to do so reliably and may have to rely on a calendar—or even find that a calendar isn’t enough.

If you don’t already have a hub, you need to create one. This is essentially equivalent to developing a habit using a tool, which can be challenging. For those who already use a calendar daily, that naturally becomes your hub. In the chapter on strategy, you might find the concept of the [Daily Area](strategy#概要) relatively easy to adopt. There are other strategies as well—feel free to explore them. (In the next chapter, I discuss [Habits](habit), which you might also find useful.)

Having a hub, however, doesn’t automatically guarantee success simply by placing tasks there. As mentioned earlier, there is an optimal timing for execution—if that isn’t respected, you may experience Neglect (if the reminder is too frequent and becomes meaningless) or Loss (if the reminder comes too late). Ultimately, you have to try and test things out. The benchmark is that, **unless you’re extremely busy or something unusual happens, if you place a task there you should be almost 100% likely to complete it without forgetting.** If that’s not the case, then either your hub isn’t suitable for movement path reminding or you yourself might not be well-suited for it.

That said, it is acceptable if you can at least prevent pure forgetting. Among the phenomena of forgetting, dithering, and laziness, it’s common to hesitate or even consciously decide “I’m too tired today—I won’t go shopping.” And that’s fine. **There is a huge difference between simply forgetting and consciously deciding to skip a task after remembering it.** In the former, you just forget; in the latter, it is a deliberate decision (and decision-making is itself a kind of processing—delaying an action as a result is also a valid form of processing).

Now regarding joints: **You use joints when you either can’t effectively operate with a hub or when using a hub is too cumbersome.** In my case, to avoid forgetting to take out the trash, I place a garbage bag by the front door, or I attach sticky notes for items I need to purchase soon on a shelf by the front door. These are examples of placing tasks on a joint. Since I have a habit of taking a walk or doing some exercise before the trash collection time every morning—and I’ve ingrained the practice of checking the sticky notes when I go shopping—this method reliably works for me. There is no need to also record these tasks on my primary hub (my to-do list).

However, in general, placing tasks on joints is more troublesome and less consistent, so ideally you want to centralize your tasks in a hub. That is why I recommend using a hub. Of course, individual differences mean that if placing tasks solely on joints works for you, that’s perfectly acceptable.

Incidentally, individual differences are very real. A friend once remarked, “I put the garbage bag by the door, but I ended up just walking past it, so I don’t trust that method.” Cases like this do occur. By contrast, I’m very sensitive and alert when it comes to physical sensations and spatial awareness—if something is physically placed where I pass, I almost always notice it and act on it. However, my ability to read and process text is lax, and I often experience Neglect. Since switching to remote work, I have to report my arrival at and departure from work every day—and I’ve missed my check-ins several times. Even though I’ve written them in my to-do list, Neglect occurs, and I end up missing them (even though my other actions remain fine). This shows that what works for one person may not work for another, which is why, as stated earlier, it is important to experiment and iterate with your movement path design. It is a profound subject.

### The RSAF Cycle
When using a hub for movement path reminding, a useful mindset is the **RSAF Cycle**.

![rsaf](/images/taskmanagement-kamikudaku/rsaf.png)

RSAF stands for the following cycle:

1. **Read:** Look at your tool  
2. **Select:** Choose a task  
3. **Act:** Take action  
4. **Feedback:** Return to the tool after acting and update the status

The RSAF Cycle essentially uses a tool as your hub. This “tool” can be any task management device—a notebook, a smartphone app, a web app on your PC, or various visual formats such as lists, tables, or boards. In any case, you use some kind of tool, and you treat that tool as your hub.

That said, it’s probably difficult to immediately start using your task management tool in a strictly RSAF manner. You might not even have a tool chosen yet. The process can be broken down into the following stages:

1. **Selection Stage**  
   If you don’t already have a tool that you regularly use for task management, first choose one.
2. **Familiarization Stage**  
   Place the tool you chose in your existing movement paths (whether on a joint or a hub). By placing it there, you increase the opportunities to interact with it. Think of it like increasing the chances to meet and become acquainted with someone you don’t know well.
3. **RSAF Stage**  
   Use the chosen tool in an RSAF manner. In other words, input as many of your regular tasks as possible into the tool and constantly refer to it when deciding your next action.

Thus, you first need to select and familiarize yourself with your tool. If you keep hopping between different tools, you’ll never get used to one—so decide on one and stick with it. Then, to increase your opportunities to use it, integrate it into your existing movement paths. A simple way to do this is to write reminders like “Add task to tool” or “View task list” and place those cues along your movement paths. Of course, if you’re self-disciplined enough to use your tool frequently without these prompts, that’s fine too. (It’s much like developing a close friendship.)

It’s similar to making a best friend. To form a close friendship, you need to increase the opportunities for communication. How you do this depends on the person; some may schedule regular meetings, while others might simply meet up irregularly and chat. Of course, increasing these opportunities doesn’t guarantee you’ll become best friends—compatibility matters, and if it doesn’t work out you naturally drift apart. The same is true for tools. Use the one that best suits you.

# Reminders

## Overview of Reminders
**Reminders** are mechanisms that prompt you to recall specific tasks at designated times. If you pre-set both the timing and the cue, then when that moment arrives the cue will be presented in some form. Even if you’ve forgotten the task itself, as long as you’re alerted you can recall it, and that is what matters.

The means by which you implement reminders are called **reminder tools** (or simply “reminders”). In some cases, each individual reminder you set may also be called a reminder. Since it’s impossible to remind yourself completely on your own, you need to use some kind of tool.

## Benefits of Reminders
The benefit of reminders is singular: **they allow you to recall your schedule reliably and effortlessly.** Even though tasks have designated start times, simply keeping them in mind doesn’t guarantee you’ll stick to them. You can’t be expected to constantly check your calendar—and even if you do, you might still forget (especially when you’re busy). However, if you set a reminder, it alerts you before the task begins so that you remember it. It only needs to alert you; once you’re reminded, you can recall the task. (I write this as though it were 100% effective, though of course it isn’t—but it still greatly increases your chances compared to setting nothing.)

Moreover, once a reminder is set, you can afford to forget about it (because it will prompt you when needed). Keeping tasks constantly in your head is exhausting, but with reminders you can offload that burden.

Another key point is that reminders can be set entirely by yourself. If you have the power or resources, you might delegate to subordinates or hire a secretary or manager—but that isn’t an option for most of us, nor can you entrust everything to someone else. With reminders, you can set them up on your own.

To summarize:

- **Do nothing → You forget.**
- **Keep it always in mind → You’re less likely to forget, but it’s mentally exhausting.**
- **Rely on others → It requires power/resources, and you can’t rely on others for everything.**
- **Reminders → Even if you forget, you’ll be prompted; it’s not exhausting, and you set it up yourself.**

Reminders thus offer a well-balanced approach.

## Limitations of Reminders
A reminder can only prompt you with a cue—a pre-set “hint” to remember. It does not force you to actually recall or take action; that still depends on you.

However, you can tweak the settings of your reminder tool to make it more effective. I call this **increasing the strength of the reminder**—that is, configuring it so you’re more likely to remember and to act immediately.

For example, consider the following cases—where higher numbers indicate a stronger reminder. Assume the reminders are set for 13:50 (i.e., 10 minutes before the event):

- **1:** Display a message on the screen that simply says “14:00.”
- **2:** Display a message on the screen that says “Meeting at 14:00.”
- **3:** Display a message on the screen that says “Promotion Interview at 14:00.”
- **4:** Display the message “Promotion Interview at 14:00” and also play an alarm sound.
- **5:** Set the reminder from option 4 not only for 13:50 but also for 13:30.

Options 1–3 only display a message, but option 3 is more specific and is likely to make you recall the importance of the task more easily. Option 4 adds an auditory alert, which can jolt you into switching your mode of action. Option 5 doubles up the reminders by setting one earlier (at 13:30) as well as the usual 13:50, giving you more leeway to act. Even if you miss the 13:30 cue, you still get another reminder at 13:50.

Comparing options 1 and 5, you’ll notice that option 5 is a much stronger reminder. However, it also requires significantly more effort to set up compared to option 1. There is a trade-off between the strength of a reminder and the effort required to configure it.

## Reminders Come in Various Forms
What kinds of reminders come to mind? Most people probably think of only a few, but there are actually many different types.

### Examples of Active Reminders
The most well-known example is the alarm clock. When you set your wake-up time in advance, it alerts you with a sound (alarm) at that time. An alarm clock can be characterized as follows:

- **Alarm Clock**
  - **Timing:** Wake-up time  
  - **Task:** Wake up  
  - **Means of Notification:** Sound (alarm)

However, alarm clocks don’t allow you to specify a task in words—the tool itself is designed solely for waking you up. The task is fixed as “wake up,” and it doesn’t tell you why you should get up; you have to remember that on your own.

Next, consider the alarm function on a mobile phone such as a smartphone. Unlike a traditional alarm clock, these devices can display messages and even vibrate. Their characteristics are as follows:

- **Mobile Phone Alarm**
  - **Timing:** Wake-up time  
  - **Task:** User-specified  
  - **Means of Notification:** Sound (alarm) and vibration

This offers more features than a standard alarm clock. For example, if you tend to forget the reason for the alarm, you can write it in advance; or if you find loud sounds too jarring, you might opt for vibration only. Moreover, you can set multiple alarms—if you want to wake up at 7:00, you might set alarms for 6:30, 6:35, 6:45, etc.

Next, consider the method of a recorded alarm. This is an alarm that uses your own recorded voice as the alert sound. For instance, on the iPhone you can use your own recording (either with built-in support—[see here](https://time-space.kddi.com/mobile/20190506/2644.html)—or via an [app](https://apps.apple.com/jp/app/id1586940322)).

- **Recorded Alarm**
  - **Timing:** Wake-up time  
  - **Task:** User-specified  
  - **Means of Notification:** Sound (your recorded audio)

Although the means of notification remains sound, the actual audio used is different—and you can change it if desired. This method might help those who find standard alarm sounds ineffective or too jarring.

As mentioned earlier, these methods actively “push” their cues to you and are examples of what I call **Active Reminders**.

### Examples of Trap Reminders
While they may not be as foolproof as Active Reminders, there are other means that function as reminders—namely, **Trap Reminders**. These involve placing a cue (or an object that makes you think of the task) along your movement paths so that you naturally see it and remember. For example, if you want to make sure you don’t forget to take out the trash before leaving for work on a weekday, you might place the trash bag by your front door the night before. Since you pass the front door when leaving, you’ll see the trash bag at the right time.

Let’s describe the characteristics:

- **Placing an Object by the Front Door**
  - **Timing:** When passing through the front door  
  - **Task:** The object should trigger you to recall the task  
  - **Means of Notification:** Visual cue (it’s in your sight)

Incidentally, with some ingenuity a Trap Reminder can become an Active Reminder. For example, as mentioned earlier, placing a piece of paper with the task written on it inside your shoes appeals not only visually but also through touch. This increases its effectiveness. Here are its characteristics:

- **Placing a Task Note in Your Shoes**
  - **Timing:** When putting on your shoes  
  - **Task:** You must recall the task either by noticing the paper when you step on it or by unfolding and reading it  
  - **Means of Notification:** Tactile sensation (via the soles or toes)

Note that while this method might seem similar to simply placing a trash bag, it is quite different. If both methods work for you, you can use the simpler one; however, if you respond to only one, then use that one. And if neither works, you’ll need to find another reminder method.

### Location-Based Reminders
**Location-Based Reminders** are those that trigger when you enter or leave a specific area. For example, on the iPhone, this is a built-in feature of the Reminders app that can be activated by adding location information ([see here](https://support.apple.com/ja-jp/102484)).

There are many ways to use this. You might set one to remind you when you leave the office or when you’re approaching home so that you don’t forget a recurring task. You could also set a reminder to trigger when you near a department store you don’t usually visit—so that when you’re there, you can decide whether to buy something you’ve been considering. If you’re not confident you’ll remember, be sure to specify the task (for example, “Decide whether to buy [item]”). This type of reminder is surprisingly important because once it’s set up, you free up mental space. Instead of keeping track of reminders for, say, ten different locations in your head, you can simply let your location-based reminders handle it. (See note 1 below.)

- *Note 1:*  
  Offloading tasks from your mind is important because keeping them in your head can be tiring and drains your concentration and focus. Each individual reminder may seem trivial, but when you have to hold many of them for hours throughout the day, it becomes a significant burden. To use an analogy: compare someone who is constantly worrying about every penny they earn and spend to someone who, having enough financial cushion, doesn’t need to worry about small expenses—the latter has much more cognitive space. In other words, **reminders are a way to conserve your precious cognitive resources.**

### Human Reminders
Although at the beginning of this section I mentioned that relying on other people is not strictly a reminder, you can intentionally ask others to remind you—and I call this **Human Reminders**.

Here are some examples (listed roughly from less to more effective):

- Ask a secretary to manage your entire schedule.
- Request that your subordinates “give you a heads-up if it looks like you’re about to forget a meeting.”
- Regularly share your schedule with your housemates (hoping they will remind you if you forget).
- Ask a friend to give you a morning call.

The advantage here is that it is easier to “set up” than configuring a tool—especially for those who are not comfortable with various digital tools or find it too bothersome to manually configure them. On the downside, as you can imagine, this method is less flexible and comes with a high degree of uncertainty (excluding high-quality options like a professional secretary). Moreover, because you must share the task details with someone else, it is not suitable for highly confidential or overly private matters.

As an aside, I personally believe that if a system were created so that anyone could make use of Human Reminders, it might become very popular. Imagine, for instance, a system where devoted fans receive calls from their idols, or where friends form groups to remind one another—or even a world where reminders from strangers drift around as a kind of volunteer service. Despite reminders being extremely useful, they are not widely used, perhaps because of the hassle and lack of appeal. There is something inherently compelling about human intervention and voices that overcomes that tedium.

### Atmosphere Reminders
Although at the beginning of this chapter I stated that I would not cover relying on environmental or human power, I will briefly touch on it here.

One method that leverages the power of the environment is known as **Atmosphere Reminders**. A clear example is in schools—despite the hectic nature of moving between classes or during physical education, most people manage to keep up because the classroom environment—with classmates and teachers present—creates an atmosphere that signals “it’s time to move on.” Unless you are completely isolated from your surroundings, you will notice this cue. In group settings, schedules are often arranged so that everyone is expected to participate, making it easy to think, “Oh, I need to join in too.”

Like Human Reminders, Atmosphere Reminders are not entirely reliable but can be surprisingly strong.

The downside is that such reminders lack flexibility. They typically require you to be part of a group and physically present in the same location. With modern virtual offices, remote work is possible, and tools like [Remotty](https://ja.remotty.net/) allow you to share real-time photos of your colleagues to simulate a shared environment. However, these methods cannot provide personal reminders such as “remind me of a 14:00 meeting.” Alternatively, in an organization where casual conversation is common, someone might spontaneously announce, “Hey, I have a meeting at 14:00—I nearly forgot last time and got in trouble, haha,” thereby serving as a form of Human Reminder (with the expectation that someone will remember for you or chime in if you forget).

### Aside: Why Do We Go to the Office?
This is an aside on Atmosphere Reminders, and since the discussion is long, I’ll separate it into its own section.

Despite the fact that remote work became viable after the pandemic, there is a noticeable trend of returning to the office. Even companies like those in GAFAM have adopted hybrid work policies (e.g., requiring employees to be in the office n days a week). The reason, I believe, is that employees generally have poor task management skills. If they were good at managing tasks, they would handle both tasks and communication—including reminders to ensure they never miss their schedules—without issue. But such management requires strong self-discipline and skill, which do not develop naturally, cannot be easily taught through academic methods, and vary so widely among individuals that a one-size-fits-all system is nearly impossible. One of the reasons I wrote this book is because I am deeply concerned about this state of affairs.

Modern business, by its very nature, values being in busy situations and acting on impulse, as well as close collaboration. I believe that at its core this is rooted in an exploitative value system that prizes productivity competition ([see ref#19](ref#19))—not to mention the skewed mental models of successful people and those in power (which I will not elaborate on here).

In such a busy, high-pressure environment, neither task management systems nor reminders are particularly effective. Your next action is dictated by the atmosphere—and you are compelled to follow it. In other words, a very strong form of Atmosphere Reminder is in operation. For example, meetings might begin spontaneously with someone saying “let’s talk for a bit,” or work topics might suddenly interrupt casual conversation ([see event#2 for details on impromptu meetings](event#2-延長による割り込み的な開催)).

In summary, while this high-pressure way of operating might produce results, it is accompanied by a lack of task management skills and self-discipline. If you possess those latter qualities, you can work remotely—and enjoy a pace that respects your individuality and a higher quality of life. However, if you are effective only under high-pressure conditions and lack the ability to manage tasks and reminders on your own, pursuing remote work may not be feasible.

# Summary
- By optimizing your movement paths and reminders, you can reduce forgetting, dithering, and laziness  
  - This is especially useful for tasks where missing the start time would cause problems.
- Placing tasks along your movement paths means that you’ll see them, remember them, and then be able to act  
  - If the cue comes too early, you may ignore it (Neglected).  
  - Conversely, if it comes too late, you might miss the window to act (Lost).  
  - Striking a balance to avoid both Neglect and Loss is crucial, though designing and adjusting this balance is surprisingly challenging (Movement Path Design).
- Movement paths consist of Hubs and Joints—but if possible, it is preferable to establish a Hub.
- Although reminders are well known, there are actually a surprising number of ways to implement them  
  - Reminders only alert you; if you want them to reliably prompt action, you need to increase their strength, which comes with a trade-off in setup effort.  
  - Methods such as Human Reminders and Atmosphere Reminders exist, which—though less reliable—do not depend on a tool.  
  - Combining on-demand reminders with regularly scheduled opportunities to set them up leaves no gaps.
