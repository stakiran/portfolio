---
title: Task Source
---

# Overview of Task Source

## Summary
**Task Source** refers to something that generates tasks—especially something expressed in language. The term “source” means origin, and it is precisely the source of tasks.

In an earlier chapter, we discussed the [Axiom of Interpretation](view_taskmanagement#解釈の公理). Whether something is considered a task depends on the individual. If a person interprets something as a task, then it is a task; if not, then it isn’t. Even the same person may interpret a matter as a task in one situation and not in another.

Task Sources are similarly tied to interpretation—the decision of when and what kind of task to create (or interpret) from a source is entirely up to the individual. For example, if you have the desire “I want to move,” when and how you turn that into a task depends on you. Someone who regards it as a distant wish might not create any tasks for the time being, whereas in extreme cases—such as when facing urgent issues like a neighborhood dispute or a stalker incident—you might feel compelled to act immediately. In any case, just because there is a source like “I want to move” does not mean that a task automatically exists; it is solely our interpretation that transforms it into a task.

Now, treating something like “I want to move” as a task won’t work well. As mentioned earlier, its [granularity](container#粒度) is too coarse, making it unclear what exactly should be done. If handling such vague matters worked out easily, there would be no need for task management. However, breaking it down into detailed, concrete tasks on the spot isn’t easy unless you’re in a work context—and even then, success is not guaranteed (see [Project Task Management is Difficult](project_taskmanagement)). After all, as stated before, even for the same person, interpretations vary with the situation.

Here is where introducing the concept of Task Sources makes things considerably easier. Specifically, you list or post your sources as they are and then, as needed, create tasks from them.

## Examples of Task Sources
- **Goal Items**
  - Items that have an aspect of achievement or serve as a guide.
  - Examples: Purpose, goal, coarse-grained tasks (such as large tasks), or projects and other [containers](container).
- **Maintenance Items**
  - Things that you want to maintain permanently.
  - Examples: Daily routines, habits, and some [mottos](motto).
- **Associative Items**
  - Items used as hints to trigger the recall of something.
  - Examples: Trigger lists, outputs from brainstorming or other idea-generation methods, or any form of overview.
- **Inspirational Items**
  - Items that encourage flashes of insight or spontaneous ideas; they are the source of inspiration.
  - Examples: These vary significantly from person to person.

Note that all of these are assumed to be articulated in language. Therefore, specific people, places, [object tasks](strategy#前提知識%3A-物タスク), images, or videos are not considered Task Sources. Although such richer items can also be regarded as sources from which tasks can be generated, they will not be covered in this chapter.

Below, I will further explain some points that might be confusing.

A container can also be regarded as a Goal Item. Typically, a container is a unit that bundles together existing tasks or potential future tasks—more like capturing what already exists rather than generating tasks from a source. However, it can also be treated as a source. Even in work, it is not uncommon to act preemptively based on hypotheses or forecasts; in such cases, you are essentially considering a container as a source and generating tasks accordingly.

Maintenance Items might be the easiest to understand as Task Sources. For example, if you have a Maintenance Item like “Maintain my weight below 50kg,” you should create separate tasks for what to do daily to achieve that. A mere resolution will not change anything, and even if you write “Keep weight below 50kg” in your task management tool, you will likely do nothing. Typically, you would create a recurring task such as “Run 2 km daily.” Then, if you injure your leg, you schedule a doctor’s visit; if your shoes wear out, you plan to replace them; or if the rainy season approaches, you might add a one-off task to either change your workout routine or purchase rainwear—adjusting things with spot tasks at the appropriate time.

Associative Items and Inspirational Items may be a bit confusing, but Associative Items are more familiar. Often referred to as brainstorming or free association, they involve recalling various memories or pieces of knowledge, and Associative Items are those things you look at to trigger such associations. For example, if you create a “10 List of Things to Consider About Life,” then when you want to think about life, looking at that list can help spark associations. It’s much easier than generating ideas entirely from scratch. Also, in fiction, you often see scenes where characters’ photos or visualizations of their relationships are shown; these serve as associative hints (and by arranging them, they provide an overview).

As for Inspirational Items, unlike association, they aim to trigger sudden insights or ideas—something that seems to “appear out of nowhere.” Typically, inspiration cannot be deliberately generated in the form of a Task Source; as the “3 B’s” of idea generation (in the bath, while commuting, or when going to sleep) suggest, ideas often come when you are relaxed and not actively thinking. Deliberately aiming for this is what Inspirational Items are about, and they are sometimes referred to simply as “inspiration.” Inspirational Items are things expressed in language that help you obtain inspiration (see note 1). What qualifies as an Inspirational Item varies greatly from person to person; for some, it might be beautiful prose such as poetry, for others, proverbs or sayings, or even dictionary entries. In my case, Inspirational Items include things like “help documentation for digital tools” or posts by people whose work on task management and work techniques I personally admire—posts that are not overly complicated. From my experience, it is crucial that you can read these in a neutral state of mind, relaxed and unstrained. When an insight strikes, you often risk losing it if you do nothing, so you convert it into a task (often preceded by turning it into a [memo](memo)).

- **Note:**
  - 1 When you think of inspiration, you might recall an artistic context—and indeed, that is true. Often, non-verbal information or even personal experiences bring about inspiration more effectively than words. There is no need to be confined to verbal data. However, since this book takes the stance that tasks are things articulated in language, Task Sources in this chapter (including Inspirational Items) are defined as those that are expressed in words.

# Management of Task Sources

## Managing Goal and Maintenance Items
This follows a flow similar to the [Memo Flow](memo#メモのフロー): define the Task Source → review it → convert it into a task.

First and foremost, defining your Task Sources is the most important step. Goals continue until they are achieved, and Maintenance Items, in some cases, last a lifetime. You need something you can sustain over the long term—and that “something” is a sense of conviction or belief. If you’re an “athlete type” (see [Athlete and Apprentice](motto#アスリートとアプライア)), you might say, “I’ll just try this for half a year,” but that is the minority. Without conviction or belief, you likely won’t stick with it, so it might be better to give up from the start. Also, if you can’t develop these on your own, it may be easier to temporarily follow someone or join a group. However, be careful not to become overly dependent, as that can lead to being manipulated or trapped; maintaining a degree of detachment is important. The subsequent review also acts as a good safeguard.

After defining your Task Sources, it is necessary to review them daily. By looking at your Task Sources, reflecting on your current situation, and then considering what to do next (and converting that into a task), you keep things moving. Alternatively, if you can recall them without issue, you might not need to explicitly review the sources—but that is usually not easy, so it’s typically best to intentionally set aside time for review. On the other hand, reviewing too often can lead to desensitization and ritualization (including habitual slacking off), which is problematic. For Goal Items, it is easier to maintain motivation if you can visualize progress as nearing 100%. With Maintenance Items, that is not the case; essentially, the key becomes whether you can enjoy the daily review and tasks.

Reviewing alone is not enough; you must also convert your insights into tasks. You don’t need to do this every time, but deciding whether to do it each time can become tedious and lead to ritualization. Conversely, if you schedule something like “Run 2 km daily,” it might eventually feel too burdensome. You need to fine-tune the balance yourself. In other words, the act of fine-tuning is unavoidable. If you avoid making adjustments, the process will almost certainly become mechanical. Your willingness to make these fine-tuning efforts is an indicator. If you can’t, then—as mentioned in the section on defining Task Sources—you probably lack conviction or the necessary aptitude for detailed adjustments.

This entire process is neatly articulated and systematized in methodologies such as [GTD](ref#gtd) and the [PARA Method](ref#paraメソッド). Both advocate for listing your Task Sources and reviewing them regularly so that, if needed, you can convert them into tasks (in GTD, this is particularly referred to as a “review”).

Furthermore, in order to bolster conviction and belief, you need to have a good understanding of yourself. Whether you call it self-understanding, self-awareness, or self-analysis, it is crucial. Only by truly understanding yourself can you judge whether something suits you or not. Although this goes beyond task management, remember that we are the ones who manage tasks—and we are human, with our own wills, circumstances, and preferences. Self-understanding is extremely important; without it, you cannot make sound judgments and may end up either blindly following others or drowning in busyness (this is not to say that such a lifestyle is inherently wrong).

## Managing Associative Items
There are three approaches:

- 1: Management of an Associative List
- 2: The Process of Divergence and Convergence
- 3: Constructing an Overview

### Associative List
An **Associative List (Trigger List)** is a collection of self-questions and hints used to prompt various associations. It is similar to a checklist, but you are not required to work through every item; you can use it in a more casual, flexible manner. You might derive 10 associations from one item, or decide to skip an item if nothing comes to mind. The key is to use it as a tool to trigger associations.

How well you can assemble your Associative List determines how much you can enhance the quality of your associations on a daily basis. In our lives, unless we are engaged in extremely challenging work, the answers are basically simple—we merely struggle to arrive at them or find conviction. Associations serve as a shortcut; in other words, they help you “think thoroughly” and eliminate gaps or blind spots in your thinking. I may not be able to say with absolute certainty that this is perfect, but I want you to be confident in saying, “I’ve thought this through completely; there’s nothing more I can do.” Especially in modern times, when our perceptions have become discerning and we live in a VUCA (Volatile, Uncertain, Complex, Ambiguous) era, this becomes particularly important. However, since you cannot think through everything unaided, it is advisable to prepare an Associative List as a base from which to expand your thoughts.

Here are some examples of Associative Lists.

**Life:**

- **Bucket List (Things I Want to Do)**
  - A list of things you want to do someday, even if you don’t know when.
  - In GTD, there is also a “Someday/Maybe List.”
  - It is not uncommon for the number of items to reach hundreds or even thousands.
- **A List for Reflecting on Life**
  - This list consists of the following eight elements discussed in the book “[28歳からのリアル](https://www.amazon.co.jp/exec/obidos/ASIN/4872901460/)”:
    1. Work  
    2. Marriage  
    3. Money  
    4. Living Arrangements  
    5. Health  
    6. Parents  
    7. Hobbies  
    8. Common Sense
- **128 Life Hacks**
  - [Life Hacks: Listing 128 Tips – Taihei Yamashita’s Method of Enjoying Life](https://cocolog-nifty.hatenablog.com/entry/2018/11/30/172400)
  - This list offers 128 life hacks based on the premise of a “simple life” from the Meiji era.
  - While some tips may suit you and others may not, reading and considering them can provide useful insights.
    - For example, the author had long been troubled by the low quality of life when spending time on the road, but after reading tip 043, he decided he needed to adjust his usual routes and schedules—adding tasks accordingly.
- **Self-Improvement List**
  - [Self-Improvement – Wikipedia](https://ja.wikipedia.org/wiki/%E8%87%AA%E5%B7%B1%E5%95%93%E7%99%BA)
  - This Wikipedia page lists the main themes of self-improvement.
  - It can help spark associations when you’re looking to identify or improve upon perspectives or soft skills that you lack.

**Work:**

- **Project List**
  - A list of the projects and tasks you are currently handling.
  - Although the appropriate level of detail and review frequency can be nuanced, simply looking at this list can remind you that “it’s about time I take care of that.”
- **People List or Position List**
  - A list of names of people you regularly interact with or roles that you hold.
  - This can be useful when deciding what to do next at work or considering your future within an organization.
  - For some people, a diagram may work better for association (though this would fall outside the typical scope of an Associative List).
    - For example, projects often come with an “organizational chart.”
    - The key is to reformat it in a way that feels familiar and intuitive to you.
- **Osborn's Checklist**
  - A well-known framework used for brainstorming ideas.
  - It includes prompts such as: Adapt (Can it be repurposed for other uses?), Apply (Are there other examples?), Modify (Is there a new non-verbal aspect?), Magnify (Can it be expanded?), Minify (Can it be reduced?), Substitute (Can something else be used instead?), Rearrange (What if the components are reorganized?), Reverse (What if it is inverted?), and Combine (What if they are merged together?).

Additionally, there are books and websites that compile various types of lists, so it might be worthwhile to explore those as well:
- [Amazon.co.jp: The Magic of Lists: Changing Your Work and Yourself (Kadokawa Books) eBook – Masatake Hori](https://www.amazon.co.jp/dp/B0841T24SK)
- **Awesome List**
  - In the context of software development and IT, there are “lists of standard resources” for that genre.
  - Original repository: [https://github.com/sindresorhus/awesome](https://github.com/sindresorhus/awesome)
  - Explanation: [GitHub’s Awesome Lists Are Truly Awesome – Check It Out #GitHub (Qiita)](https://qiita.com/e99h2121/items/4b5e3ff9001ede108fa9)
  - For example, there is one for remote work topics: [awesome-remote-job](https://github.com/lukasz-madon/awesome-remote-job).

There are many people online who compile various lists, and nowadays you can even ask ChatGPT to generate one for you.

### Tips for Working with an Associative List
First and foremost, **start using it—even if it’s crude at first.** In my view, the ability to do this is everything. As mentioned above, I introduced Project Lists, People Lists, and Position Lists; the point is to actually try creating your own version. Identify and list your projects, people, and roles; then, look at your list, let your mind wander, and eventually convert the ideas you want to act on into tasks (or act immediately if possible). Through this practical experience, your Associative List will become more familiar. Lists are, after all, merely bullet points, and it’s easy to feel you understand them without truly engaging—leading to neglect or ritualization. To overcome this, actively engage both your hands and your mind in the process of association and experience a sense of “this wasn’t so bad,” “it was fun,” or “it might not solve everything immediately, but it seems manageable.”

Next, it is best to customize and maintain your Associative List as much as possible. Since your preferences may differ more than you expect, it is advisable to fine-tune the contents of your list to suit you (though perhaps not as rigorously as with Goal or Maintenance Items). Conversely, if you can use it without fine-tuning, that’s acceptable—but because lists tend to become ritualized, I recommend eliminating any discomfort or mismatches as much as possible.

Finally, I recommend that you look up any unfamiliar words. Sometimes an unknown term might appear in an item on your Associative List or among your associations. If you repeatedly encounter something you don’t understand, you may begin to ignore it—adding unnecessary noise. Over time, this noise can accumulate, and I even believe that **many people who struggle with relying on association are overwhelmed by this noise.** Rather than ignoring it, look it up one by one. That said, you don’t have to understand every detail perfectly; it is fine to think “I sort of get it, so that’s enough,” or “it seems like a hassle, so I’ll skip it.” What matters is that you make that judgment for yourself. Once you have that experience, it becomes easier to disregard the noise.

### Divergence and Convergence
The second approach is **Divergence and Convergence**.

**Divergence** is the process of generating as many ideas or pieces of information as possible. It is important to record them in a visible form. You might jot them down as bullet points, write a long free-form stream of consciousness, or use sticky notes. Visual methods such as mind mapping that capture the images in your mind are also acceptable. At this stage, do not interpret or judge the ideas—focus solely on quantity.

**Convergence** is the process of organizing or summarizing the divergent ideas. There are two methods: one is to diligently summarize them, and the other is to **distill** them—treating the divergent ideas merely as hints. Summarization emphasizes logic and narrative, whereas distillation focuses on capturing the interesting aspects or the essence of the content. Although the concept of distillation may be difficult to grasp, remember that the ideas generated during divergence are simply hints; you are free to use them or not, and you can add your own interpretations and modifications as you see fit.

Divergence and convergence typically alternate. You might partially converge some of the ideas, then add more as additional thoughts occur, then at some point perform a comprehensive convergence, and if you’re still not satisfied, diverge again—and so on. There are various idea-generation methods such as brainstorming or the KJ method, but their essence is nothing more than divergence and convergence. If you can manage these processes in your own way, the specific method does not matter.

Returning to Task Sources, if the Associative List represents static associative items, then **Divergence and Convergence can be seen as “dynamic associative items.”** They generate hints that may give rise to tasks through these processes. Whether you are diverging or converging (especially distilling), you rely heavily on association. You write down your associations during divergence, review them to spark further ideas, write more, organize, and sometimes rearrange, delete, or group them (thereby reflecting the results of convergence)—all while writing and progressing.

Ultimately, whether through summarization or distillation, you arrive at some form of conclusion (or eventually, you stop because the process is endless). If necessary, you articulate these conclusions as tasks. It is only after repeatedly engaging in dynamic association that you can confidently say, “This is good enough; there is probably nothing more, and nothing further can be done.”

I personally make extensive use of this process. Even in my daily work, after a routine meeting, I might think, “What should I do this week?” and engage in a bit of divergence and convergence. The result might be, “Okay, I’ll do these three things,” or “I have an idea I’d like to develop further, so I’ll convert it into a task,” or “Since our meetings are about to increase, I’ll block out some time now.” When I’m in doubt, I often jot things down haphazardly (diverge) and then quickly summarize them (converge). As a result, I might realize, “Ah, my real worry is that my salary is low,” “But that doesn’t require overexertion,” “So perhaps maintaining the status quo is sufficient,” “At most, I should cut back on expenses,” or “Maybe I’ll buy a book on minimalism.” These reflections often lead to action. Even if they don’t always, just the sense of relief and accomplishment from having put everything out there makes me feel better.

### Tips for Divergence and Convergence
The key to effective divergence and convergence is whether you can secure an environment in which you can focus alone—and whether you can tolerate such solitary endeavors. There are technical tips regarding idea-generation methods and the tools you use (see note 1), but you can figure those out through study or experimentation; fundamentally, you can even do it with just sticky notes, paper, and a pen.

Divergence and convergence rely entirely on association, and association is a very personal activity because the ideas that come to mind often include personal content. When others are present, you may end up spending much of your mental energy deciding whether to reveal that personal content, which hinders your concentration. Ideally, you want to be able to work 100% on your own without any interruptions. While you might use ideas, comments, or information from others, when it comes to the actual process, it must be done individually.

All too often, people tend to try doing this in groups—but that is actually a typical misstep. Unless you’re in a small team where each member is equally skilled, trusts one another, and is capable of a significant degree of divergence and convergence individually, group sessions can devolve into nothing more than a timid, fragmented attempt at idea generation influenced by group dynamics or the opinions of authority figures. Often, you might not even realize this is happening. Conducting divergence and convergence in a group should be limited to situations where each person first performs the process individually, and then you combine the results.

A clear example is seen among writers. Whether it’s manga, novels, or business books, content at the book level is generally produced by a single writer and then reviewed by an editor. They do not write together from the start; you can easily imagine that trying to do so would likely not work well. The same applies to idea generation and convergence. In other words—without fear of being misunderstood—it is a creative endeavor.

Thus, it is essential to carry out divergence and convergence alone. In other words, you must be able to endure solitude. For example, can you spend an hour without showing your work to anyone or talking to anyone, simply facing your divergent and convergent ideas alone? This largely depends on your personal traits. Some people can do it, while others won’t even try. You might hear people say, “I can do it,” but being able to work alone for long periods does not necessarily mean you can effectively engage in divergence and convergence. These processes are so exhausting that most people can only do them for a few hours a day (see note 2), and they are fundamentally different from tasks that can simply be completed given enough time. There is a greater degree of suitability or unsuitability than you might think.

One criterion is whether you can articulate in a way that communicates to others something that is too complex and voluminous to process solely in your head. Whether it’s a book of over 100,000 words or a presentation or lecture lasting more than 30 minutes (see note 3), the key point is whether you can overcome the limits of your mind. I intentionally use the term “articulate fully” to imply handling a considerable amount of content in an organized manner—something that cannot be done with makeshift or spur-of-the-moment effort. To overcome such limits, divergence and convergence are necessary, and they require solitary, focused work. Those who can fully articulate are said to have mastered this (see note 4).

- **Note:**
  - 1 The techniques and tools for divergence and convergence are extensive enough to fill several books on their own, so they are omitted here.
  - 2 I believe there are two reasons why this process is exhausting. First, the act of generating ideas itself is very draining because it involves producing ideas and making numerous judgments where there is “no correct answer.” Second, you often have to confront memories you’d rather avoid. Unfortunately, negative memories tend to trigger many associations. You need the resilience to endure the pain of facing such unpleasantness (though ideally without becoming overly numb—this resilience can almost be considered a talent).
  - 3 The abilities developed through divergence and convergence are not limited to writing books or giving lectures. They are more universally applicable—for instance, they help you develop strategies, tactics, or even exhaustively consider options. I believe these qualities relate to the “Strategic” trait in [StrengthsFinder](ref#18), and being able to endure solitude may also require an “introspective” quality. I suspect that one’s aptitude for divergence and convergence can be explained by their strengths, which is something I would like to explore further.
  - 4 There are people who can write or speak without ever reaching the limits of their minds. I believe that individuals with such exceptional abilities are what we call professionals. In reality, it is precisely because they possess such capabilities that they can operate quickly enough to make a living—even under strict constraints such as short deadlines or multitasking across several projects. Conversely, even if you aren’t a prodigy, if you use divergence and convergence, you can eventually manage (even if it takes time). In fact, this book is an example of that process.

### Constructing an Overview
The third approach is constructing an overview.

**Overview** means looking at the whole or at a specific part of it. Typically, you are not in a position to view everything at once, so you need to consciously build an overview. For example, at work, if you are managing a project and think, “I want to do a better job in the long run,” and you want to analyze things based on the key figures involved, it would be useful to have an overview of those figures. Since you cannot naturally see the big picture, you might list the names of the key figures or arrange them with their photos. Items used to create such a view are called **overview objects**. In this case, you might create an overview object in the form of a list of names or a collection of photos.

### Tips for Constructing an Overview
There are no specific tricks for the overview itself; simply look at your overview objects and capture the associations that come to mind. If you wish to further develop these associations, it is advisable to engage in divergence and convergence.

What is most important, however, is the phase before that—creating the overview objects. The key here is to **design them in a way that is easy for you to use.** Often, there is already some form of overview object available. For example, most projects come with summary materials or organizational charts, and many task management tools offer various [views](project_taskmanagement#ビューの種類). You might be tempted to use these as they are, but that is an anti-pattern. Associations work better when presented in a format that feels familiar and natural to you. Essentially, you are the only one who can create the ideal overview for yourself—so go ahead and create it.

Of course, you may not know what your ideal overview is at first, so there will be a period of trial and error. That said, you can start by creating a rough overview object and then gradually fine-tune it. The medium you use—analog or digital—is not important; choose whichever is easier for you. Generally speaking, being able to arrange items spatially offers more flexibility, so a method that excels in spatial organization might be preferable. Analog methods may be simpler, but if you are accustomed to digital tools, that works just as well. Alternatively, as in my case, if you do not feel comfortable with spatial arrangements, you might create an overview object in the form of a text list or bullet points. In any event, the optimal approach truly depends on the individual.

Creating overview objects may be tedious, but without doing so, smooth associations cannot be achieved. I believe it is best to get used to this tedium as soon as possible. Of course, if existing overview objects work well enough to spark associations, then that is fine—but if not, being able to create your own is a valuable skill.

## Managing Inspirational Items
Managing Inspirational Items is about how to find sources of inspiration expressed in language and how to work with them. However, since this process is highly personal and not easily replicable, I will omit a detailed explanation here.

# Dealing with Deadlines
Deadlines often occur in work. As a practical application of Task Sources, let’s delve into how to deal with them.

## Task Sources Do Not Mix Well with Deadlines
First, Task Sources themselves do not work well with deadlines—especially when tight deadlines are involved.

Task Sources are the origins from which you create tasks at your own discretion. As we reviewed with the Axiom of Interpretation, tasks are essentially created based on your mood. Naturally, if a deadline exists, relying solely on your mood to create tasks may lead to missing the deadline. While “athlete types” might be able to create tasks in time to meet deadlines, this approach is not suitable for everyone.

On the other hand, trying to enumerate and strictly manage every task from the start is difficult because we humans tend to be lazy. Even in work settings where you might be forced to do so (unless it’s a world reduced to simple tasks), you cannot make accurate estimates—and you’re likely to be off the mark most of the time. Not wanting to admit that, you end up covering the shortfall with overtime. In extreme cases, you might not even receive proper compensation for overtime work. It’s the worst when errors add to your exhaustion. Projects or assignments can be extremely demanding and, at the very least, tend to temporarily disrupt your work-life balance. This is because strictly adhering to a plan is inherently difficult, and the fatigue from following a plan-based management approach compounds the problem.

## Source Approach vs. Plan Approach
To summarize so far, there are two approaches to how work is done:

- **Source Approach**
  - Operate using Task Sources.
  - Convert Task Sources into tasks as needed.
  - This approach is based on subjective interpretation but does not work well with deadlines.
  - In other words, it is “exploratory.”
- **Plan Approach**
  - Create plans or schedules and operate according to them.
  - This approach is generally accepted as the norm in work.
  - Although it appears logical, plans often fail, and covering for them with overtime leads to increased exhaustion—a double whammy that makes it very harsh.
  - In other words, it is “systematic” or “planned.”

## The Critical Point between Source and Plan
Based on the above, it seems best to be able to combine both approaches. Depending on the situation, the most versatile method is to **start with the Source Approach and then switch to the Plan Approach at some point.** Relying solely on the Plan Approach can be exhausting, while using only the Source Approach might cause you to miss deadlines. The idea is to proceed comfortably using the Source Approach at first, and once you have a clearer picture, create a plan and power through. In other words, begin exploratorily and then transition to a systematic method.

Modern work is dominated by the Plan Approach, largely because it is convenient for management. When you create a plan, you can quantify it, making it easier to align with financial matters (such as budgets), and it allows even managers who are only comfortable with number-crunching to delegate tasks related to figures. By complicating numerical management or even codifying it as rules, managers can end up micromanaging employees based on numbers, or conversely, creating “work for the sake of work” to charge extra fees or extract value. This is not because the method is inherently superior (although there are, of course, jobs and situations where such management is essential).

Using the Source Approach allows you to break free from an overly plan-focused method. Instead of creating a plan from the outset, you generate tasks from your Task Sources at your own pace. Although you might work more slowly, you get things done, and insights gradually emerge. Working at a comfortable pace means you experience less exhaustion, which often leads to clearer insights and more honest discussions. Once you have gathered these insights, you can then create a plan. At the very least, before reaching what I call the “SP Critical Point” (the point at which it becomes necessary to switch approaches), it is much more realistic and manageable than trying to create a plan from a state of complete uncertainty.

By the way, in some cases the SP Critical Point is evident from the very beginning. This can occur in simple environments (such as work that reduces directly to tasks) or when you’re a professional with such exceptional ability that you immediately see the critical point. In such cases, the issue becomes whether you can simply work until the end—so the Plan Approach is feasible. However, even then, since we are human and subject to forgetfulness and idleness, it’s advisable to build some leeway into your plan (including negotiations and daily “off-board” adjustments, see [Partner Task Management – Off-board Battles](partner_taskmanagement#盤外戦)).

## Other Strategies
I have described the strategy of switching from the Source Approach to the Plan Approach, but there are other strategies as well:

- 1: Use the Source Approach exclusively.
- 2: Use the Plan Approach exclusively.
- 3: Source Approach → Plan Approach.
- 4: Plan Approach → Source Approach.

So far, the strategy requiring the SP Critical Point is number 3. I will briefly touch on the remaining strategies 1, 2, and 4.

**Strategy 1:** Use only the Source Approach. This is not recommended for tasks with deadlines. This strategy is best applied to tasks that have no deadlines and can continue indefinitely (for example, Maintenance Items). Even if you work at your own pace, the key is to keep it going—so simply converting these into tasks on your own is sufficient. However, if using the Source Approach alone leads to no progress, you may need to incorporate the Plan Approach as a boost. Alternatively, you might decide, “I don’t need to grow any further,” which is acceptable (especially for hobbies).

**Strategy 2:** Use only the Plan Approach. In business, this is currently the most common strategy. Many readers may already have experience being given plans or schedules from the start. Although I generally believe that in today’s VUCA environment this approach is suboptimal, managers often only know this method, so it tends to prevail. On the other hand, there are still many situations where it is effective. For example, in simple fields such as construction or manufacturing—where you only have to contend with physical constraints, which are much simpler than in digital domains like software—the Plan Approach works well. In large-scale projects or organizations, numerical management often becomes the only option to maintain order.

**Strategy 4:** This is less common, but it applies when a project is canceled. Although there is no longer a need to continue, you have already done some work, so you consider what to do with the remaining parts and proceed with the Source Approach. If the cancellation order is strict, proceeding on your own might result in reprimand or penalties, but completely discarding everything because of cancellation would be a waste. In such cases, struggle through it in your own way. Personally, I recommend engaging in activities that contribute to your own growth—such as codifying your know-how or reflecting on your work (within acceptable limits).

# Summary
- A **Task Source** is the origin of tasks—from which you generate tasks as needed.
  - When, what kind, and how many tasks you create depends on you; there is no single “correct” answer.
- The following exist as Task Sources:
  - Goal Items
  - Maintenance Items
  - Associative Items
  - Inspirational Items
- This concept can even be applied to common business scenarios involving deadlines:
  - While the Plan Approach is well known, a Source Approach using Task Sources is also possible.
  - It is better to begin with the Source Approach and, once things become clear, switch to the Plan Approach.

On a side note, the “exploratory approach” mentioned in this chapter will be discussed in detail in a later chapter ([Exploratory Task Management](exploratory)).
