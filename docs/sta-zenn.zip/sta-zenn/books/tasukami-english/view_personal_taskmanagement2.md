---
title: A Look at Personal Task Management(2/2)
---

# Various Strategies and Stances

“Strategy” refers to the overall approach or method you intend to use, while “stance” refers to the way you respond or act in specific situations. There are various strategies and stances in task management; here, I will outline the main ones, with details saved for later chapters.

- **Strategies**
    - Segment your tasks by “time” or “topic” and honor each segment.
    - Consolidate everything in one place instead of organizing it meticulously.
    - Use the power of repetition—such as daily routines or habits—to keep things moving.
    - Use tools as minimally as possible, relying primarily on your own mind.
- **Stances**
    - Approaches that reduce the number of tasks you hold.
    - Approaches that minimize the effort required to process tasks.
    - Approaches that influence the external environment in which tasks occur.

## Strategies

You can classify strategies based on what you choose to rely on.

### Segment by Time

The most famous method is to use a calendar and live according to your scheduled appointments. You simply act according to your plans, which is relatively straightforward—and many business managers rely on this approach.

Another well-known method is to be conscious of different time blocks. For example, decide what you’ll do in the morning, around lunchtime, at 1 PM, at 2 PM, in the evening, during your commute, at night, and before bed. There are various ways to segment time; some systems even create fixed blocks of 1 or 1.5 hours (as in classes or training sessions) into which tasks are slotted.

Then there is the approach—also seen in TaskChute—of dividing tasks into “today” versus “all other days,” focusing solely on what must be done today. You create a boundary called “today,” decide what you need to do, and once all are finished, you declare the day done. The [Mañana Principle](ref#3) uses a similar approach, where once you decide what to do today, any new tasks that come in are deferred to tomorrow—this is possible precisely because you divide your tasks into “today” and “tomorrow and beyond.”

### Segment by Topic

There is a system known as “one topic per page” that lets you generate a page’s worth of information for each task. For instance, you might create tasks like “start some form of exercise,” “read book XXXX,” “consider moving,” or “research buying a new refrigerator.” In this system, each idea generates its own task page. On each task page, you can freely add comments so that any progress or additional information can be appended. Depending on the tool, you might be able to “close” a page when the task is done or set deadlines and priorities to emphasize certain tasks.

This strategy is somewhat niche, but it tends to be popular among engineers who are familiar with such systems. Tools like [GitHub Issues](ref#github-issues) are well known for this approach. Although you could also use general note-taking tools or even basic files, the detailed operations can be cumbersome—so unless you are particularly capable or can automate the process yourself, it might not stick. It is best suited for engineers.

### Consolidate Everything in One Place

This strategy is all about throwing every necessary piece of information into one single location.

Famous examples include your garage or study, your desk (or workspace), your PC’s desktop, or your smartphone’s home screen. Many people end up with clutter if they don’t make a conscious effort to organize things, and by default, this style often emerges. If it works for you, there’s no need to force yourself into a different method. In fact, consolidating everything in one spot is a perfectly valid strategy—it is much easier than overly managing multiple compartments, and as long as you can eventually find what you need, that’s sufficient. However, to be effective, you must be smart enough to remember where everything is. People often say that geniuses are messy, but that’s because their intellect allows them to retrieve things quickly even in disarray.

In terms of task management, this strategy means that instead of writing out tasks in words, you might have some physical object (like a document, file, or item) that represents the task, and you simply leave these items scattered about. For example, if you receive an envelope or notification about an application that needs to be submitted, instead of adding a task like “submit application” to your tool, you might leave the envelope on your desk, or file away the notification (such as by saving the email text or a URL) on your desktop. Alternatively, you might maintain a single giant note file (like “note.txt”) and write everything in it.

### Leverage the Power of Repetition

This strategy involves relying on habits, routines, or making small daily efforts to gradually accomplish tasks.

You might use a habit tracker or a tool like TaskChute that is designed to handle recurring tasks easily. With this strategy, your daily tasks will appear as a neat list such as “Today, do this, do that, do this, do that, do this…” For example, if you want to read a book titled “XXXX,” you might schedule a daily routine of “read for 10 minutes.” If daily is too frequent, perhaps every other day will do, or if you can manage more, maybe 30 minutes a day is better. Of course, you decide whether it’s in the morning, in the evening, at a fixed time every day, or whenever you happen to have a spare moment—the specifics vary by person. In any case, the idea is to make it a consistent habit.

This strategy may seem daunting and is not without its difficulties. You have to manage which tasks to do, when, and how often, and doing this manually is challenging—so you typically rely on dedicated tools. It is perhaps better suited for people who have many things they want to accomplish, though it is not entirely straightforward. There is often a big gap between the tasks as suggested by the tool and whether you can actually execute them, so you may struggle with motivation or concentration.

### “My Own Brain is Supreme”

Some people find that they can manage everything in their head, but they still can’t remember every task. These people prefer to save tasks (or the underlying communications or objects that represent tasks) and review them later. For example, they might use the bookmark function in their browser, chat tool, or on social media to mark items for later. In the context of information gathering, the “read-it-later” tag or category is exactly this strategy. Sorting emails or marking them as important follows the same logic; rather than categorizing in great detail, it’s essentially a binary decision: either mark something as important or not. In other words, it comes down to “mark it or don’t mark it.” Items that are marked are considered important, and you review and process them later. If this small amount of effort is acceptable, then it’s a viable strategy. Of course, this method also requires that you have a strong enough mental capacity—after all, if it were that simple, you wouldn’t struggle with task management in the first place. But if it works for you, then that’s lucky; if not, that’s perfectly understandable.

Incidentally, this strategy works best for “work-like” tasks. Work-like tasks are those that, if you simply invest enough time, can be completed. They might be a bit tedious, but they are essentially simple tasks. However, there is a limit: even for work-like tasks, if there are too many, you won’t be able to handle them all. And for tasks that are not work-like—say, creative work with no single “correct” answer or research tasks that require long-term investment—this method is insufficient.

## Stances

There are several perspectives from which you can adopt a stance.

### Reducing the Number of Tasks You Hold

This means aiming to reduce the volume of tasks you are responsible for.

The simplest example is “delegating tasks to others.” Even though you might still need to follow up or manage them, delegating is often more effective than trying to handle everything yourself. Once tasks reach a certain scale, an individual simply cannot handle everything alone—so at some point, this approach becomes essential. This isn’t a privilege reserved for CEOs or managers; even in everyday life, you might choose to hire a housekeeping service. Although it sounds simple, people tend to want to hold onto tasks themselves (see footnote [1]), so this approach is often overlooked.

Another common method is “not holding onto tasks.” This might mean, for example, replying to emails or chat messages immediately or making decisions on the spot during meetings or consultations rather than postponing them. The famous “ball” analogy is often used here. Additionally, advice such as “finish tedious tasks immediately” or “if something takes less than 2 minutes, do it right away” is also well known.

Yet another approach is “procrastination” in the sense of deliberately postponing tasks. For example, you might decide, “I won’t do this today—I’ll do it tomorrow,” thereby ensuring that today’s workload isn’t overwhelmed by tasks spilling over. Similarly, when a popular store runs out of an item, you might decide not to wait in line any longer; or with certain web services or internet connections, if you overuse them, limits are imposed. While procrastination might not immediately seem like a good idea, by decisively cutting off tasks, you prevent yourself from taking on too many. In simple terms, it sounds straightforward, but the criteria for cutting off—and more importantly, the decision to do so—can be challenging.

- *(1) People tend to want to keep tasks to themselves for reasons of privacy (秘匿性) and exclusivity (排他性). In terms of privacy, tasks often contain personal information or background that you might not want to share with others. For example, even if you want help with cleaning your room, you may have to first deal with the fact that there are things you’d rather not have others see. Because of this hassle, you might decide “I’ll just do it myself.” As for exclusivity, it’s essentially the “don’t let outsiders interfere” mentality. People have their own preferences and pride, and this often extends to how they handle tasks. If you delegate a task indiscriminately, you run the risk of having your personal standards violated. Imagine if a stranger were to clean your room and then comment, “It’s messy,” or “You could clean it better—just so you know…” That would be infuriating. The possibility of such an invasion makes many prefer to handle tasks themselves.*

### Streamlining (Reducing the Effort)

This involves reducing the amount of effort required for task management—especially the operations, integrations, and filtering processes.

For operations and integrations, you can reduce effort through automation. Many modern project task management tools now support automation features. For example, tools like [Asana](ref#asana), [ClickUp](ref#clickup), [monday.com (Work Management)](ref#monday.com), and [Trello](ref#trello) allow you to set up “if XXX happens, then execute YYY” rules. For instance, if you tag a task with “design needed,” it might automatically assign designer A as the responsible party, or if a deadline is near, it might automatically post a comment mentioning the responsible person. With some ingenuity, many such automated workflows can be created.

Additionally, some tools have features that send task information to chat tools or other platforms. Many personal task management tools—such as [Todoist](ref#todoist)—incorporate such features. Integration with workflow tools like Zapier or IFTTT is also commonly anticipated. In the context of personal task management, streamlining is roughly equivalent to workflow integration, which in turn supports effective task management. At first glance, the benefits of streamlining may not be immediately obvious, but because trigger-based actions can occur quite frequently (even at the personal level), effective implementation can save a significant amount of time—perhaps even 30 minutes a day for someone who otherwise spends a lot of time on manual processes.

When it comes to filtering tasks, there are two approaches: permissive and exclusionary.

- **Permissive filtering** means “discard everything that wasn’t preapproved.” This aligns with deep task management—you decide in advance on a few tasks to keep, and everything else is discarded (at least temporarily). As mentioned earlier, this requires clear criteria and strong decision-making ability.
- **Exclusionary filtering** means “automatically discard tasks that meet certain criteria.” The “segment by time” strategy is a clear example. The Mañana Principle defers all tasks that come in today to tomorrow (i.e., it discards today’s tasks), and there is also a method called [Timeboxing](ref#Timebox) where you set a time limit and only address tasks within that period (discarding tasks outside of that time frame). The concept of fixed working hours is exactly like that: by strictly defining your work hours, you create clear boundaries.

In any case, by decisively setting criteria and making firm decisions, you eliminate the extra mental effort required for further judgment—this is the essence of streamlining.

### Engaging in “Off-Board” Strategies

“Off-board strategies” involve addressing issues at a higher level than the tasks themselves. For example, you might intervene at the source of task generation, or work on improving your own mind, techniques, and physical state so that you can execute tasks more effectively. Instead of fighting battles solely on the “board” of task management, you turn your attention to the battles off the board. I will discuss off-board strategies in more detail in a later chapter; for now, I will simply introduce a few stances that emphasize off-board approaches.

For instance, maintaining leisure and preventing its erosion is one off-board strategy. The debate over work-life balance is well known—in recent years, the term “work-in-life” is sometimes used to emphasize that one should not let work completely consume life. The previously mentioned Timeboxing, which forces you to work only during a set period, is, in a sense, an off-board strategy—it prevents work from encroaching on your life.

Another off-board strategy is to place importance on the pulse of Choudoumyaku—namely, understanding the context. Instead of confronting tasks head-on, you examine their context—the background, premises, and true intentions—in order to either find shortcuts or address the root of the problem. However, this approach requires a lot of gritty, hands-on effort and can be time-consuming. Context often exists solely within someone’s mind, and drawing it out may require building trust and investing significant time, which in turn can drain your energy and emotional resources. In a way, this approach can be at odds with maintaining leisure. However, if you work hard to thoroughly understand the context early on, you can later avoid being squeezed by overwhelming demands. By considering context, you can often minimize your actions to only what is necessary—or even proactively prevent tasks from arising. As counterintuitive as it may seem, in the long run it helps secure your leisure. This style is particularly required in new business development, where one scrambles to uncover hidden contexts and the true needs of customers. Without that, you might “never reach the answer” in your life.

One more off-board strategy is to process tasks all at once. For example, if someone living in the countryside takes a week-long trip to Tokyo after a long time, they will likely want to complete all the tasks that can be done in Tokyo during that week—and they will spare no effort in preparing for it. Applied to task management in general, this means always being on the lookout for opportunities to “batch process” tasks. At first glance, this might seem like an overly laborious approach, but the process of preparing efficiently amidst many constraints can be enjoyable (much like planning a trip is enjoyable), and through that preparation, you may also gain a better understanding of context. It is, in hindsight, a very logical approach. It might sound grandiose, but it is well suited for those who relish that kind of planning.

# Summary

In this chapter, we looked at personal task management from several perspectives. For summaries of each viewpoint, please refer to the beginning of each section.

- **People Who Manage Tasks vs. Those Who Don’t**
    - It depends on your traits and circumstances.
    - Those who can handle Trement (the inherent “training” aspect) will manage tasks—they can do it.
    - It is not a black-and-white matter but a gradient; you must explore your own balance.
- **Boumietai, Choudoumyaku, and Netsumushuu**
    - Boumietai: reducing forgetting, confusion, and slacking to reliably complete tasks.
    - Choudoumyaku: taking your condition, motivation, and context into account to work with conviction.
    - Netsumushuu: managing your passion, concentration, and absorption so that you can work comfortably.
- **Shallow vs. Deep Management**
    - Shallow: if you want to get by with minimal effort, manage everything with various means and tools; this requires a certain level of meticulousness.
    - Deep: if you want to break through and move forward, discard the majority of tasks and focus on a few; you need strong decision-making skills (especially the ability to discard tasks) on a regular basis.
- **Tools: Analog vs. Digital**
    - Analog tools require strong mental processing.
    - Digital tools require skills and study.
- **Various Strategies and Stances**
    - There are many different approaches and attitudes for managing tasks.

This concludes our overview of personal task management.
