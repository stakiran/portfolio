---
title: Exploratory Task Management(2/4)
---

# Getting Started with ETM Part 2 – Learning How to Develop Topics

In Part 1, we clarified the concept of a topic. In this Part 2, we discuss how to “cultivate” your topics.

## Expanding, Detailing, and Distilling

Broadly speaking, there are three operations you can perform on a topic:

- **Expand (Spread)**
- **Detail (Detailize)**
- **Distill (Summarize and Distill)**

In ETM, you nurture your topics by moving back and forth between these operations. It is also common for these operations to span multiple topics.

A typical scenario might be as follows. Suppose you are deliberating over a “Moving House” topic and are in the process of detailing it, when you suddenly recall that your bookshelf is overcrowded. This makes you wonder whether you should seriously adopt e-books. Assuming that your discussion on moving is coming to a natural pause and the timing is right, you might create a new topic titled “Adopt e-books?” and write down your thoughts (expand). Since there is no immediate rush, you might take several days and work leisurely. After about two weeks, feeling that you’ve stretched the process long enough, you decide it’s time to conclude (distill). You read back your notes to reflect on what you truly desire and, through further contemplation, realize, “I want to enjoy reading in a spacious area like a library or a writer’s study” (distill). Still feeling some residual hesitation, you then revisit the “Moving House” topic to jot down additional insights (expand).

How does that sound? In short, you move between expanding, detailing, and distilling as necessary. (Note that these operations may also span across multiple topics.) Although it may seem freewheeling, the core process is simply the three operations above.

Let’s now look at each operation in detail.

## Expand

**Expand (Spread)** means to diverge—to write down everything that comes to mind, or to list all possible ideas. For example, if you set a theme like “Moving House” or “I’ve been wanting to move for a long time (say, before 2024/08/20) so let’s expand on it,” you would write down all the ideas that come to mind. The theme need not be perfectly defined; you might even title it “Feeling a bit fuzzy” and simply jot down your stream of thoughts. Methods such as idea generation, free writing, or solo brainstorming are all examples of this divergent activity. Since ETM is topic-based, you will actually create a note titled “Moving House” or “Feeling Fuzzy” (or use any note you prefer), and later you will transform the content into a proper topic—at least into blocks. In practice, due to the limitations of some note-taking tools (for example, overlapping note names), you might add numbers or dates (e.g., “Moving House 1” or “Moving House 2024/08/20”) to distinguish them. If naming is too bothersome, you may simply use “untitled,” “no title,” or even “a” or “aaaaaa.” Alternatively, you might prepare a generic memo note (e.g., “Memo 1” or “Memo 2”) and use that repeatedly.

## Detail

**Detail (Detailize)** means to flesh out the content. It involves investigating things you do not understand, reflecting on them yourself, gathering others’ opinions, compiling link collections, or arranging your workflow. It is the process of “filling in” the content. We will explain in more detail later what to detail and how.

What you detail can generally be divided into two types: facts and subjectivity. It is best to distinguish between the two, especially when working with a group, because the balance between factual information and subjective impressions may vary between individuals or organizations and can lead to conflicts. There is no one correct answer regarding how much to rely on one or the other (see Note 1), and you will have to experiment with the balance. However, if you cannot tell the difference, you will not be able to use them appropriately.

> *Note 1: Relying solely on facts may turn you into a dispassionate scholar, while relying solely on subjectivity may turn you into an unfounded critic. Depending on the situation, one side may be more important than the other—but there is usually no definitive answer (or one that can be pursued without end). You must continuously experiment with the balance. In practice, however, in ETM the balance is determined by the values of the individual or small group, and the topics chosen tend to reflect those values.*

## Distill

**Distill (Summarize and Distill)** means to derive something from the expanded and detailed content.

There are two related approaches:

- **Summarization:** This means deriving a conclusion from the existing components faithfully. In summarization, you use all the components (unless you intentionally omit some that are not useful). The rigor of the derivation can vary—it might be logical, narrative and emotional, or heavily interwoven with personal reflections. In any case, as long as you are able to create something plausible according to your own reasoning, it is acceptable.
- **Distillation:** This means treating the components as hints. You do not have to use all of them as they are; you can rearrange them or pick only certain parts to use. You are allowed to introduce new ideas or personal subjectivity in the derivation. In a laudatory sense, such a bold leap—especially one that results in a positive, radical breakthrough—is called a **breakthrough.** This breakthrough achieved through distillation is the very charm of ETM. Ultimately, if everything could be done through summarization, then a traditional directional approach would be sufficient. It is only when that approach fails, or when it does not suffice, that we resort to an exploratory approach—in other words, ETM. In such situations there is no single correct answer; it is entirely up to your decision-making, and the possibilities are infinite. In these cases your own subjectivity is the only recourse. You fully leverage your subjectivity by treating all elements as hints and drawing out the essence. Even if nothing emerges, the very experience of having attempted it imparts a sense of ownership and acceptance.

This may sound somewhat technical, but the essential point is to aim for a creative solution. That is why ETM is based on the process of taking notes in a linguistic form (the topics). It is also why ETM is designed to be free of constraints such as the No ABCD principle.

## (Note) ETM Is Merely a Form of Intellectual Production Using Topics

Although we have described the operations as expanding, detailing, and distilling, these activities are already known by other names and are often discussed together. Expanding is known in business as brainstorming or in creative writing as free writing. In GTD (Getting Things Done), the initial step is to capture “what is bothering you,” which is also a form of divergence. Similarly, in recreational settings, games such as word association are common.

Detailing is often paired with expansion rather than done on its own. The concepts of divergence and convergence, induction and deduction, or bottom-up and top-down processes are well known. In all cases, alternating between the two operations helps you find insights and remove gaps in your thinking.

Distilling, which is the final step of drawing out a conclusion, corresponds in work contexts to decision-making. For example, when preparing a presentation or outlining a story, you are distilling the content. In more technical fields, software development methodologies such as Domain-Driven Design involve using a glossary and design model to engage with the customer and extract the core domain (i.e. the conceptual essence that constitutes the business asset). This process is called distillation, and ETM borrows its terminology from it.

If we regard this type of activity as intellectual production, then ETM is simply one method among many. ETM is built upon the foundation of Literary Task Management and reconfigures it with concepts such as topics and blocks to support an exploratory approach where conventional task management falls short. For those familiar with intellectual production, recalling these existing methods may help clarify ETM; for those who are not, studying and experimenting with the aforementioned methods will also help.

---

# Getting Started with ETM Part 3 – Learning How to Manage Tasks

In Part 1 we clarified the concept of a topic, and in Part 2 we discussed how to develop topics. In this Part 3 we address task management in ETM—that is, what it means in ETM and the methods and ideas behind managing tasks.

## Task Management in ETM

Task management in ETM consists of the following components:

- **Management Before Task Management:**
  1. **Load Management:** Managing what you intend to prioritize in the near term.
  2. **Target Management:** Managing which topics you will focus on next.
  3. **Resource Management:** Managing your resources, such as energy and motivation.
  4. **Context Management:** Organizing things so that you can easily resume work later.
- **Task Management:**
  5. **Task Management:** (As in Literary Task Management)

In reality, the management that precedes task management is the main focus. Because ETM takes an exploratory approach, a large emphasis is placed on managing the aspects that enable exploration (items 1–4: Load, Target, Resource, and Context). If you try to force the traditional notion of “task management” (i.e. simply listing and executing tasks with a clear end state), it won’t work in ETM. Instead, you must focus on self-regulation—deciding what to do and how much to do.

As you explore, tasks may begin to appear. Alternatively, even if they are not immediately visible, you may decide to “commit” by choosing, “I’ll do this and that,” and then convert them into tasks. At that point, you can begin using traditional task management. Since the method here still relies on note-taking, we refer to it as Literary Task Management (LTM). To summarize briefly, the approach is as follows:

- Use your home note as the starting point for continually developing your notes.
- Distinguish between a note dedicated to detailed tasks (task note) and a view that provides an overview of multiple tasks (task view).
- For those aspects that Literary Task Management cannot cover (the “uncovered” parts), simply rely on existing tools.

In other words, items 1–4 deal with issues that are optional or subject to frequent decision-making (i.e. “should I do this or not, and to what extent?”), rather than simply listing and completing tasks. These aspects require management tailored to exploratory work—which in ETM is organized into Load, Target, Resource, and Context. Once exploration has proceeded far enough that tasks (in the conventional sense of “what must be done” or “what you have committed to do”) become apparent, you then use traditional task management. The means to do so is again through note-taking, as in Literary Task Management.

We now explain each type of management in further detail.

## Load Management

In ETM, you dynamically decide what to work on next. For example, on a given day you might decide that you have five items (your load) such as “Moving House,” “Considering a Job Change,” “Figuring out how to deal with Generative AI,” etc. Then, perhaps next week you might decide to work on items F and G, putting items A and C on hold. This is called **Load Management**.

### What Is a Load?

While the literal meaning of “load” is cargo, burden, or weight, in ETM it refers to the items that you are currently prioritizing in the near term—that is, the things you have “loaded.”

There are several characteristics of a load:

- **Load Capacity:**
  - The number of items you can hold varies by person.
  - It might be 5 items, or 3 or 7—but it will likely be a single-digit number.
  - Even for the same person, when feeling under par the number might drop (e.g., from 5 to 3), and you are free to adjust it.
- **Granularity:**
  - The items in a load are much coarser than tasks.
  - For example:
    - ✅ “Moving House”, “Considering a Job Change”, “Thinking about how to deal with Generative AI”
    - ❌ “Selecting a moving company for the new house”, “Checking a major company’s recruitment page”, “Trying ChatGPT Plus”
  - A load can encompass various tasks.
    - In that sense, a load is similar to a “task source” (see [Task Source](source)); goals or maintenance items can also be part of a load.
- **Indeterminacy:**
  - A load is an area to explore; it often has no visible endpoint, or even if an endpoint is visible, it remains subject to change.
  - How far to go or where to stop is entirely up to your decision.
  - Once you decide “this is the end” or “I’ll stop here,” then it ends—but if you do not decide, it goes on indefinitely.

The nuance is that a load is like a burden you continuously carry. As long as it is not finished, you carry it, and a single person can only handle so many items. Also, since it is constantly with you, you have daily opportunities to refer to it (making it more accessible), though you do not necessarily have to work on it every day.

### The Single-Digit Principle

For load capacity, if you want to remain agile and flexible, you should keep the number low. Even if you want to prioritize many things, there is a limit, and the number of items should ideally remain a single digit (i.e. no more than 9). This is called the **Single-Digit Principle**.

In my experience, even 9 items may be too many—perhaps 5 is just right, or even 5 might be slightly excessive. If you can exceed the single-digit limit, it may simply mean that you are not capturing your load precisely enough. For example, you might be listing things that are clearly defined or that can be done quickly as load items. Alternatively, if you are exceptionally capable (i.e. if you can handle what most would consider a load as a task), then ETM might not be necessary. ETM is designed for those who cannot do that.

### Visualizing Load Capacity

If you are working with multiple people, it is best if everyone’s load is visible to each other. You might create a “load note” or a “load page,” or even display it on your home note. However, there may be personal load items that you do not wish to show publicly—for example, if you are secretly prioritizing personal matters such as “I really want to get married soon, so I’m seriously working on matchmaking or marriage activities.” In such cases, you need not show the details; it is enough for others to know that a load exists. Conversely, if something does not need to be captured as a load, then you simply do not write it down.

The key point is to **visualize load capacity.** In ETM, because you do not manage others, visualizing loads does not lead to any direct interference, but it does help everyone see the overall “atmosphere” and status, which in turn influences your own actions. Moreover, seeing what others are prioritizing can be a source of motivation.

## Target Management

In ETM you create many topics. The number of topics may be enormous—dozens, hundreds, or even thousands over time. It is impossible to work on every topic equally or to delve deeply into each one, so you must select the ones you wish to prioritize.

### Filtering Topics with the 3T Model

One method to filter topics is the **3T Model.** In this model, topics are viewed in three states—Topic, Target, and Task—and the ones you wish to prioritize are promoted from Topic → Target → Task.

These states are defined as follows:

- **1: Topic**
  - A mere topic.
  - Anyone can freely read and write.
  - It is optional whether you work on it.
- **2: Target**
  - A topic that has an “owner” (a person who takes responsibility).
  - The owner assumes responsibility, leads the process, and holds the decision-making authority.
  - Everyone else is an “advisor” who may offer input but does not have decision-making power.
- **3: Task**
  - A topic that has an owner and for which it is acceptable to prompt the owner.

By default, a topic is simply a Topic. It is just a topic, and how you read or write it is up to you. You might ignore it, or you might casually decide “I’m not interested in this” and leave it. It is completely free. Of course, you may also work on it with enthusiasm.

Among topics, those that you want to prioritize further are promoted to Target. When someone volunteers to become the owner of a topic, that topic is elevated to Target. As a Target, the owner leads the work and holds the decision-making authority. Others become advisors (see Note 1) and do not have decision-making power.

Among Targets, those that you wish to actively prompt (i.e. follow up on) are promoted to Task. In ETM, because we do not manage (meaning that no notifications are sent, and meetings or mentions are not expected), if a Target seems to be languishing, you promote it to Task. In a Task-state topic, it is acceptable to prompt the owner. **Prompting means following up on issues of procrastination or forgetfulness.** (Since notifications are not sent, you might create a new note or use your home note or other channels to ask, “How is this progressing?” or “It’s been three days with no update—what’s happening?”)

This 3T Model is very important and its content is deep, so we will provide additional clarification later.

> *Note 1: This section draws on the advisory model found in Teal organizations.*

### Targets as Declarations

When someone volunteers to take ownership of a topic, it is tantamount to a declaration: “I am now going to prioritize this topic.” When a Target is declared, everyone understands, “Ah, this person is now taking charge of that topic.”

However, this is not a binding promise. As we have emphasized repeatedly, ETM does not impose any coercion or strict management; it simply expresses the intention to prioritize.

### Owner Capacity Versus Load Capacity

Everyone practicing ETM has two types of capacity:

- The aforementioned **load capacity,** which is the number of items you are currently prioritizing.
- The capacity for taking on topics as an owner, which we call **owner capacity.**

It is important to note that these are different. Load capacity reflects your overall, high-level priorities (your load), while owner capacity reflects your ability to take on specific topics at a more granular level.

Even for owner capacity, the Single-Digit Principle applies. Although because it is a more fine-grained measure you might conceivably have more than 10 Targets, if you have too many, the system becomes ineffective; therefore, a single-digit number is ideal. That said, you do not have to consciously count them—if there are too many, signs such as rarely updated targets or an increase in Tasks (as opposed to Targets) will become apparent, and then you should pare them down.

There is no need to visualize owner capacity. How each person reads their topics is left up to the individual, and active topics are likely to stand out in the note-taking tool. However, it is useful to be able to see at least the recent activity of each owner. For example, if you wish to take ownership of Topic A, you might tag it with “[Owner]” or use a link like `[[Owner]]`, so that when you check the “Owner” note, Topic A appears via backlinks.

### Ownership Is Dynamic

Ownership of topics is fluid. For example, suppose Person A initially volunteers to be the owner but then, due to lack of ability or motivation, quickly withdraws. Does that mean the topic is left without an owner? Not at all—it simply means that Person B may then step forward to take ownership. That Person B might later conclude their work and, feeling that things could be improved further, allow Person C to take over and refine it even more. If things are not working out, simply remove the owner; advisors can always offer support. Do not raise the bar unnecessarily—simply add or remove ownership lightly.

If discussions become overly detailed, it is advisable to branch off the topic. In other words, once Topic A is sufficiently concluded, consider it finalized and no longer subject to ownership. If you have more to say or need to refine things further, create a derivative Topic B from Topic A and take ownership there. Essentially, if convergence (a clear conclusion) is too distant, it is better to remain in the Topic state.

### It Is Acceptable for There to Be Multiple Owners, but Ideally Only One

While a topic may have multiple owners, you should not add additional owners unless all current owners agree. Typically, the first person to volunteer becomes the owner; a second person may join only with the first person’s agreement, and a third only with the agreement of the first two, and so on.

That said, if there are too many owners, the point of having a dedicated owner is lost. Usually, you should aim for **a single owner per topic** (this is called the Single Owner Principle). If you feel that having two or three owners is preferable, it may indicate that the topic’s granularity is too coarse. In such cases, you should consider breaking Topic A into separate topics (B, C, D, etc.), each with one owner.

ETM is an exploratory process that is ideally conducted individually. The best analogy is that of an author; a work is created by a single author. Although there may be collaboration or review, a work is not typically created by multiple people simultaneously. Because there is no single “correct” answer, waiting for consensus would be counterproductive. Therefore, one person should take responsibility for detailing the topic and then share the result with others for feedback. Of course, it is advisable to receive advice during the process, but the responsibility for detailing should remain with the owner.

If you find it difficult to have just one owner per topic, there is likely a structural problem at hand—either an organizational culture that does not support delegation of authority or a situation where exploration is not effective. (In such cases, corrective measures are necessary, which we will address in the next section.)

### Dealing with Issues That Prevent the Single Owner Principle

First, regarding the difficulty of delegating authority: in traditional hierarchical organizations, it is very hard to resolve. In particular, managers or those with authority tend to become bottlenecks. Even if roles are assigned appropriately, all members must be treated as equals in terms of decision-making authority. You cannot have someone insisting, “I must check everything” or “Wait until I review,” but rather you need to have a mutual understanding of “Okay, I’ll trust you.”

This is extremely challenging—it requires not only that decision-makers relinquish their control but also that each team member demonstrates autonomy and self-reliance. If a person is unable to assert themselves, ETM is not likely to work for them. Whether it is achievable depends entirely on the abilities and personalities (and their compatibility) of all members. If you need a reproducible method, the advisory model in Teal organizations (see [ref#5]) is currently the best solution.

Next, regarding situations where exploration is not effective: first, check whether you can apply the No ABCD principle. In ETM, if you cannot operate under No ABCD conditions, then nothing will work. Two common obstacles are “an unchangeable, overly tight schedule” and “a budget so limited that no one can engage in continuous exploration.” However, if you look closer, you may find room for maneuver. For instance, what appears to be a rigid schedule may simply be the result of higher-ups or mid-level managers issuing arbitrary directives. Especially in modern corporate environments, managers are still steeped in a directional approach and insist on detailed scheduling, so you must consciously resist. I will discuss strategies for this in Part 4. Regarding budget, even if you can carve out only one hour per day, ETM is feasible—and if you incorporate ETM into your routine communication, it can become part of your daily life.

Another point to keep in mind is that **topics act as boosters.** A **booster** is any piece of information that you can use when it comes time to take action—that is, “well-considered” input that boosts your actions. In ETM, what you do is not to act immediately but to compile enough information (thoughts and decisions refined through exploration and discussion) so that when it is time to act, you have everything you need. (Once you actually act, real-world constraints come into play and the exploratory mode often fails. ETM is solely about preparing and organizing, not about execution.) In short, ETM is about “refining topics to compile boosters that then lead to a goal.”

That is, attempting to fully execute an action during ETM is not appropriate. ETM is meant to cover only the preparation and organization up until the point of action. (Of course, if it is easy to take action, you may do so, but be careful not to disrupt the exploratory nature by mixing in too much action.)

For example, consider a large corporation in which a small team is using ETM for a new business venture. Suppose that, based on convenience and security considerations, a topic emerges that “every member should have a corporate iPhone.” This is proposed as a Target, with Person A taking ownership and arriving at a conclusion. The scope of ETM is only to arrive at that conclusion. The actual actions—obtaining iPhones, establishing a procurement system, adjusting the budget or accounting—are not part of ETM (or may be done later if feasible). The topic “Every member should have a corporate iPhone” is valuable as a booster because it is a conclusion reached after thorough exploration and discussion. **Whether or not to actually implement it is another matter.** (I will discuss this further in Part 4.) In ETM, actions are taken only after a goal is reached—they are not taken during ETM.

---

# Getting Started with ETM Part 4 – Learning the Workflow

In Parts 1 and 2, we introduced the topic-based worldview. In Part 3, we explained how to manage tasks in an exploratory way—specifically, what to manage and how. In this Part 4, we explain the overall flow needed to actually begin and operate ETM.

## The Overall Flow

The flow of ETM is simple:

- **Step 1: Setup**
  - Define the scope and duration, select participants, and create a venue.
- **Step 2: Conduct ETM**
  - Perform ETM based on what was set up in Step 1.
- **Step 3: Goal Evaluation**
  - At the end of the period set in Step 1, hold a review to decide the next actions.
  - If you have gathered enough input, switch to a directional approach; if not, restart ETM from Step 1.

## Step 1: Setup

Before starting ETM, you must make some preparations.

### Defining the Scope and Exploration Period

First, decide on the scope (i.e. what kind of goal you want to derive using ETM) and the period (how long you will conduct ETM).

For the scope, the subject must be one in which an exploratory approach is effective. In addition to being able to operate under No ABCD, please ensure it meets the following three conditions:

- There is no mission that absolutely must be accomplished.
- It does not include quantitative indicators.
- Even if it is not achieved, the entity can continue to exist.

Also, the goal you aim to derive does not have to be fully formed; it can be provisional. In fact, a scope as rough as “create a new business” is acceptable. In such a case, you are likely to generate many perspectives (such as “What exactly is a new business?”, “What is our current situation?”, “Why do we want to create one?”, “What cards and resources do we have?”). The scope is merely an initial direction. In fact, being a little abstract is preferable for generating diverse ideas—but if it is so abstract that nothing emerges, then choose something a bit more concrete as a provisional scope.

Next, decide on the duration—that is, when you will stop ETM. For example, “for two weeks starting today” or “from August 14 for one month.” This period, during which ETM is continuously carried out, is called the **exploration period**. The exploration period should be taken full-time, and any directional approaches that you normally engage in must be completely stopped during this period. **During the exploration period, you must devote yourself solely to exploration (i.e. operate under No ABCD).** This point is extremely important; if you cannot secure such a period, then ETM is not feasible. If you wish to use ETM, you must ensure full commitment from all members during the exploration period. As a compromise, you might allocate only the morning or only the afternoon exclusively for exploration (a “half‐period”), but be careful that your exploration is not compromised. For example, if you only conduct exploration in the morning (ensuring No ABCD), but revert to your usual methods in the afternoon, then your exploration period will soon be eroded.

The exploration period is like a long vacation—just as you avoid work during vacation, you must refrain from any directional approaches during the exploration period. Because ETM requires you to fully commit to exploration, it demands that every member be autonomous. In addition, those who oversee the team must also refrain from interfering during the exploration period. It is common, for example, for managers of teams engaged in ETM to schedule meetings during the exploration period (“please set up a meeting so we can check progress”), but this violates No ABCD. If managers want to know what is happening, they must go to the ETM venue themselves and collect information or communicate in accordance with the No ABCD method. **The exploration period is a sacred zone that must never be invaded.**

Note that this does not mean that during the exploration period you must refrain from all activities—only from those associated with work. It is acceptable to handle work outside the scope or personal matters; however, ETM requires that you fully commit to exploration, so make sure that you have sufficient absolute resources (time and money). For example, if you work 6 hours a day (say, 3 hours in the morning and 3 in the afternoon), you should allocate no more than half (i.e. 3 hours) to ETM. Moreover, because exploration is inherently an activity that requires sustained time, **make sure to secure at least 3 hours.**

This block of time—i.e. the “exploration time” each day during the exploration period—is called **Exploration Time.** It should be at least 3 hours. More is acceptable depending on your circumstances. In companies where you work 8 hours a day, you might allocate all 8 hours (or 4 hours if doing a half‐period), whereas in more flexible settings or for individuals it might be anywhere between 3 to 10 hours.

### Participants

Select the members who will participate in ETM.

Since ETM is a specialized method, it has its own required aptitudes. It is not intended to cover or support people who are unsuited; therefore, do not include such people. Although it is difficult to articulate all the necessary qualities, here are four examples:

- The autonomy to work independently through reading and writing.
- Sufficient literacy in Literary Task Management (such as the ability to articulate ideas, fast typing, and familiarity with the necessary tools).
- The ability to candidly offer comments or opinions even without close personal relationships.
  - It does not matter whether this comes from one’s sensitivity, personality, acting ability, or mental fortitude.
  - ETM is a process of reading and writing; since it is hard to form close interpersonal bonds in this context, being able to work on your own is essential.
- The tolerance to spend time without relying on conversation or meetings, or the ability to resolve matters independently without involving others.

If you are missing even one of these qualities, then ETM is unlikely to work well for you.

If you are unsure whether you have these aptitudes, it is recommended that you practice first.

I recommend an exercise called a **Mute Day.** This means spending an entire day without speaking to anyone and without engaging in any activities that require notifications (such as mentions). Once you have successfully completed a Mute Day, try a **Mute Week.** These might seem very challenging, but as you work through the hints provided in this chapter, you will see that these exercises are within reach. (A Mute Day or Mute Week is a short-term exercise and does not require the long-term maintenance that ETM does.)

For a step-by-step approach, you might proceed as follows:

1. Do a Mute Day by yourself.
2. Do a Mute Week by yourself.
3. Do a Mute Day with all team members.
4. Do a Mute Week with all team members.

When doing it alone, you must overcome boredom and loneliness. In a group, you must resist the temptation of conversation or meetings. Both are necessary. If you plan to perform ETM alone, only the individual exercises are needed; if in a group, all members must be able to handle both. Without the former, you may feel depressed; without the latter, those who lack it will drag down the ETM process.

Mute Day and Mute Week are good exercises, and by repeating them you will gradually strengthen your abilities.

### Venue

Conducting ETM means using some kind of note-taking tool—especially a [network-based editor](literate#⚠-ltm-≒-ネットワーク)—to read and write topics. In your tool, you will create a workspace or project that serves as the **venue.**

As part of your preparation, you need to select the tool and create the venue. You also need to become familiar with the tool, but I will not go into detail about that here.

For tool selection, please refer to the section on [tools that can support Literary Task Management](literate#ltm-を回せるツール).

As for creating the venue, if you are working alone, simply create a home note. If you are working in a group, you will need to create a venue where all members are invited and set up the appropriate permissions. For example, in Scrapbox you might create a project, invite all members, and (if necessary) assign administrator permissions. (I have discussed the introduction and practice of Scrapboxing in my work [Scrapboxing](ref#17), although some of the content may be dated. For more up-to-date information, please consult the official website or related materials.) The [official support documents](https://scrapbox.io/support-doc-jp/) and [help pages](https://scrapbox.io/help-jp/) are also very useful.

## Step 2: Begin ETM

Once you have set up your venue in Step 1, all that remains is to actually begin ETM.

If your venue is properly prepared, each person can freely create and edit notes as they please. In a group setting, maintaining order is a matter to be solved, but since there is no one correct method, each group should experiment. Explaining that in full detail would fill many pages, so I will leave it at that. (For best practices regarding network-based note-taking, please refer to Scrapbox materials and community discussions; I have also covered this in my own writings.)

Regarding ETM itself, please operate according to what has been outlined so far in this chapter. To begin, refer back to Part 1 where you learn to create topics as notes (with each topic being comprised of blocks), and that you can derive topics from blocks (or vice versa). Part 2 explained that topics can be expanded, detailed, and distilled. Part 3 discussed managing aspects such as Load, Target, Resource, and Context (some of which you may manage individually rather than within the venue). Further detailed techniques are addressed in Part 5, so please refer to those hints as needed.

An important note: **Please create the goal during this step.** The goal should be derived in Step 2, not at the Goal Evaluation step. This is because a goal is not something that is finalized only at the end; rather, it is something that emerges along the way. Goals, like hypotheses, are subject to revision—you might rewrite, add, or remove parts as needed.

## Step 3: Goal Evaluation

When the exploration period ends, ETM is finished. At that point, based on the insights gathered, you hold a meeting (or similar review) to decide what to do next. This process is called **Goal Evaluation.** In this evaluation, you decide:

- Whether to continue ETM.
- What to do next.

If you decide to continue, simply restart ETM from Step 1.

Next, decide what to do going forward. Within ETM, you only set a general direction or policy—the plan need not be highly detailed or binding. More precise plans or commitments can be made later using traditional (directional) methods. Goal Evaluation itself is part of ETM, and its outcome is also a kind of booster. (In other words, if your ETM process has gone well, a goal should already have emerged. Use that goal to guide the two decisions above.) In some cases, the conclusion might be “I’m not really sure yet” or “I’ll refine this gradually”—this is perfectly acceptable. The fact that you have already assembled boosters means that ETM has been successful.

That said, if Goal Evaluation becomes chaotic or overly prolonged, it indicates that either ETM has not been effective or that you simply need to restart ETM to gather more insights. In the latter case, simply reinitiate ETM from Step 1.

You might wonder: if the Goal Evaluation can be done so quickly that the meeting might take only a few minutes, why do we recommend a meeting lasting half a day or even a full day? The answer is that **people naturally appreciate having a milestone.** It is important to mark the transition between exploration and action. If you have been exploring continuously without a break, it can become stifling, and when it comes time to take action, you might find that you are unprepared. The exploration period must be recognized as having ended. To that end, you should schedule a milestone event—spanning, say, half a day to a full day—during which you formally review and decide on next steps. (If the Goal Evaluation itself is straightforward, you may then choose to use any remaining time for other purposes. There are two possible approaches:)

- **1. A Wrap-Up Event**
- **2. Free Time**

For the wrap-up event, much like a project celebration, it is acceptable if the event extends over several days. Exploration is very draining, and it may be difficult to quickly regain energy and switch modes; for example, you might take a few days off to travel. (If you plan to travel, you should have prepared a “travel” topic during the exploration period.) I will discuss such playful or casual approaches further in Part 5.

For free time, you simply disband the meeting and let each person spend their time as they wish. During free time, however, no work should be done. Whether you rest or engage in leisure is up to you—each person may do as they please. The idea is simply to allow an interval between exploration and the next phase.

Which approach (wrap-up event or free time) you choose depends on the team. Typically, some members will want a celebration while others will prefer to spend time individually. It is best to accommodate both—for example, by making the wrap-up event optionally participatory and allowing people to join or leave as desired.

## Dynamic ETM

Thus far the ETM workflow has been described in three steps—implying a clear beginning and end. However, ETM can also be integrated dynamically into your daily work. 

When you are in **exploratory mode**, you conduct ETM. Under this mode, the No ABCD conditions apply and no formal management is in place. When you are in **directional mode**, you do not conduct ETM; instead, you use conventional communication and management methods.

The key is to avoid doing both simultaneously. ETM works only when everyone is free to explore (under No ABCD). If even one person operates in directional mode during ETM, it disrupts the order. If directional mode is necessary for a given situation, then that person should exit ETM. Alternatively, if you are in ETM, you must commit fully to the exploratory process. In ETM, you are expected to “dedicate your working time entirely to ETM (exploration).” Phrases like “I’m too busy to participate” or “I have an important meeting, so please include me” are not acceptable—and should not be allowed.

There are several strategies for switching modes:

- **Team-Based Mode Switching**
  - The entire team is either in exploratory mode or directional mode.
  - It is unacceptable for only one person to be in directional mode.
- **Individual Mode Switching**
  - For example, in a team of five, it might be that two are in exploratory mode while three are in directional mode.
  - It is possible that someone who was in exploratory mode (say, Person A) may switch to directional mode.
- **Fixed Mode per Person**
  - Some people may always operate in exploratory mode (thus always participating in ETM) while others may always operate in directional mode.
    - Incidentally, the traditional approach used before modern methods was 100% directional.
  - People in directional mode must not force those in exploratory mode to conform to their style.
    - For example, someone in directional mode cannot say, “I need to hold a meeting so you can explain your exploratory results.” Instead, those in directional mode should read the ETM venue or interact there themselves.

There is no one correct answer; some methods will suit certain teams better than others—choose the approach that works best for you. In any case, switching modes can be tiring, so try to minimize the frequency of mode changes.

## Summary

- In order to successfully carry out exploration, various forms of management are required.
- **Load Management:**
  - Clearly articulate what you intend to prioritize in the near term (the load).
  - Keep the number of items within a single-digit limit (the Single-Digit Principle).
  - The number of items you can handle depends on you (your load capacity).
  - Visualizing everyone’s load can be useful to gauge the overall “atmosphere.”
- **Target Management:**
  - Clearly indicate which topics you intend to prioritize.
  - Promote topics using the 3T Model (Topic → Target → Task) through volunteer ownership.
  - Although there is a capacity for owners, it is personal and does not need to be visualized.
    - However, it is important to be able to see which topics have owners.
  - Ideally, there should be only one owner per topic (the Single Owner Principle).
    - If this is not met, it may indicate a structural problem.
  - An important point is that ETM is fundamentally about gathering boosters (i.e. “well-considered” input to be used when taking action).
    - Do not confuse the process of gathering boosters with actually taking action; the two should remain separate. (Of course, if action is simple, you may take it immediately, but be careful not to compromise the exploratory spirit governed by No ABCD.)
- **Resource Management:**
  - Measure the factors that affect your ideal state (Management 2.0).
  - Although factors can be positive or negative, measuring negative factors is particularly important.
  - The measurement results will indicate what you need to do.
    - In other words, once you have identified which factors push you away from or draw you toward your ideal state, you can work on those factors.
  - Having measurements does not automatically lead to action, but simply being aware of the factors is valuable.
- **Context Management:**
  - Reduce the burden of context switching.
  - This involves two approaches: **Context Maintenance** (continually engaging with a topic so as not to forget its context) and **Context Driven Work** (recording the context when you finish a session so that you can quickly recall it later).
  - Although it is ideal to employ both methods, do not attempt to do both simultaneously.
    - In particular, avoid doing context-driven work while in the middle of context maintenance.

---

# Getting Started with ETM Part 5 – A Collection of Hints on Methods and Approaches

Due to space limitations, please refer to [the next chapter](exploratory3) for further details.

---

# In Conclusion

We have introduced advanced methods of task management including [Plain Text Task Management (PTTM)](plaintext#pttm-の基礎) and [Literary Task Management (LTM)](literate), and in this chapter we have presented Exploratory Task Management (ETM).

We began by discussing directional versus exploratory approaches and then laid out an entirely different way of organizing tasks compared to traditional methods. Of course, ETM is not the only possible method for exploratory situations; there are other ways and approaches. In particular, this chapter has set forth bold principles such as No ABCD, which may not be easy or immediately convenient for everyone to adopt.

Even so, I hope that ETM offers a new possibility for the realm of exploration—a realm in which conventional methods have often failed.
