---
title: 📘Part 1 "Overview of Task Management"
---

What is task management? Let's take a look at the big picture.
