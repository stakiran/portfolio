---
title: A Look at Personal Task Management(1/2)
---

In the previous chapter, we took a look at task management as a whole. We learned that there are three types of task management: Project, Partner, and Personal (individual). In this chapter, I will focus on “personal task management.”

Personal task management can be approached and thought about in various ways. Ultimately, you must explore and find the method that works best for you. At the same time, certain overall patterns are becoming apparent. In this chapter, I will introduce the main patterns. By comparing them with your own methods and ideas, you may be able to get a sense of what effective task management looks like.

# To Manage Tasks or Not?

At the very beginning, there is the question of whether or not to engage in task management.

In short, I will address the following points:

- It depends greatly on your traits and circumstances.
    - **Traits**
        - If you can process things entirely in your head, you don’t need task management; but if you can’t, it becomes very useful.
        - It has an element of exercise or training—the key is whether you can commit to it consistently. It suits those who are willing to face that challenge.
    - **Circumstances**
        - In hectic situations, it can be cumbersome (in environments where you simply improvise and handle things on the fly).
        - It is very valuable for people who are meticulous and want to live according to their own rhythm and pace; it can even greatly enhance your quality of life.
- Just because task management might not seem ideal for you doesn’t mean you can’t do it—if you can incorporate even parts of it in your own way, that’s fine.

## People Who Don’t Need Task Management

As discussed in the previous chapter with the axioms, task management requires both a tool and an active interpretation of what constitutes a “task.” **If you can process everything in your head without using a tool, then you don’t need task management.** Likewise, if you have plenty of free time or live a sort of “hermit-like” lifestyle, or if you simply do exactly what you’re told without needing to decide for yourself, then task management is unnecessary—in other words, if you don’t need to interpret for yourself what counts as a task, you don’t need it. Chances are you wouldn’t even think of starting. Whether you use a tool or actively interpret your tasks, it is a bothersome endeavor. For someone who isn’t familiar with it, diving in immediately is difficult; and if you don’t really need it, there’s no motivation to begin.

Conversely, for those who are extremely busy and can’t handle everything mentally, or for those who are self-motivated rather than simply following orders—and even for those who must decide not only what to do but also in which order—task management becomes essential. Without it, you’ll end up being pulled around and confused, and your situation will not improve. On the other hand, one might argue that since circumstances are limited and cannot really be controlled, you should simply live in the moment without management. In fact, many people live in a very headlong, improvisational way—and you’ve probably heard such motivational talk at least once.

## Traits of People Who Don’t Need Task Management

Some of you may have a vague sense or a clear realization that **people who can manage without task management share certain traits.** They are typically full of vitality and must have a rather thick skin. A good example is people whose rooms or (PC) desktops are in a state of chaos. Although terms like “messy room” or “sloppy” are used, such individuals tend to have high mental processing abilities and thick resilience, so they optimistically assume, “It’ll work out somehow” (and indeed, they have the ability to make it work). Because they can manage on their own, they have little motivation to take on the cumbersome chore of task management.

To borrow a phrase from self-help literature, Dale Carnegie’s classic *How to Stop Worrying and Start Living* teaches that “worrying is a luxury.” When you are busy and working hard, you have no time to worry (or even the luxury to worry). In hectic circumstances, rather than spending time on task management, you rely on flexible decision-making and spontaneous conversation; at most, a calendar might serve simply as a visual reminder or record of what was done later. There is no need to engage in the elaborate business of task management.

Conversely, there are those for whom task management is inseparable from their daily lives. People with lower mental processing capacity are compelled to externalize information as tasks and maintain them. Also, those who are very meticulous might build rigid routines—either way, if you can’t simply “swim” through a hectic day, you develop a system to stick to your own pace. For such people, task management (or something very similar) becomes essential, and by learning more about task management, they can further enhance their quality of life.

## Guidelines for Whether to Manage Tasks or Not

In short, the decision to manage tasks or not can be summed up as follows:

**Are you already, in your personal life, actively engaging in task management—both by using a tool and by actively deciding what qualifies as a task?**

I say “in your personal life” to refer to situations where you are free to choose whether to use it, not when you are forced or required to by work. If you already do so, then task management is necessary—even if you may be struggling with it. This book is full of hints, so please browse through and see what suits you best.

If you don’t do it, then task management is probably unnecessary. Perhaps you never even consider doing it, or maybe, influenced by those around you or common wisdom, you think “maybe I should,” but deep down you feel you really don’t need it. Task management is a demanding undertaking that requires a certain level of motivation. If you truly feel “I don’t need it,” “it’s trivial,” or “I can’t do it,” then you probably won’t stick with it—and you shouldn’t force yourself. Even if you start, you’ll likely not continue; many people have either given up or struggle to persist.

## Trement

**Task management is, in many ways, like exercise.** Whether it’s weight training, playing sports, or engaging in lighter activities, moving your body always comes with its own inherent “hassle.” I will refer to this “hassle” as **Trement (Training Element)**.

Whether you come to like Trement—or even if you don’t like it but can nonetheless persist—is important. The guidelines above are essentially asking whether you can handle Trement. Now, one might wonder:

> If you cannot face Trement, does that mean you cannot do task management?

The answer is: “It’s definitely a disadvantage, but it is not impossible.” Fortunately, there are various methods and approaches to task management, and there are also systems designed for those who are weak in Trement.

One example is the well-known [Pomodoro Technique](ref#Pomodoro-Technique). This technique involves rigorously repeating 25 minutes of focused work followed by 5 minutes of rest (using, say, a kitchen timer) to build a rhythm of concentration. People who are naturally strong in Trement might say, “I can concentrate without such measures,” but that is because they are naturally strong. For those who struggle with concentration, relying on such constraints is necessary. The Pomodoro Technique works effectively even for those who find it hard to concentrate.

There are also other tools that incorporate gamification elements, such as [Habitica](ref#Habitica) and [Chill Pulse](ref#Chill-Pulse), which allow you to manage your tasks with the fun of progressing in a game.

In the first place, you do not have to adopt every method—using just a little is perfectly fine. It’s like cooking at home; you don’t need to be a chef. Even if you just chop vegetables and meat and throw them into a pot or frying pan, you can make something decent. In extreme cases, you might even get by with “rough-and-ready pot cooking” for all your meals—or you could opt for 100% dining out. Just because you’re weak in Trement doesn’t mean you can’t do anything.

Moreover, how far you can go and what suits you varies from person to person, and it is up to you to explore how deeply you want to engage with Trement. I emphasize once again that task management is a personal matter—you must explore it on your own.

# Certainty, Conviction, or Performance?

Task management encompasses many aspects, but I believe it can be roughly summarized into three categories:

- **Boumietai (Not Forgetting, Not Hesitating, Not Slacking)**
    - This means not forgetting, not getting confused, and not being lazy.
    - “I want to get things done for sure.”
- **Choudoumyaku (Condition, Motivation, Context)**
    - “I want to do only what I truly believe in (I don’t want to do things I’m not convinced of).”
- **Netsumushuu (Passion, Absorption, Concentration)**
    - “I want to maximize my performance.”

Below, let’s take a closer look at each.

## Boumietai

**Boumietai** is a collective term for forgetting, hesitating (or being confused), and slacking. In this book, the term may refer either to the state of forgetting, hesitating, and slacking itself or to the prevention or reduction of these tendencies. Please interpret it as you see fit.

When you think of task management, the first idea that probably comes to mind is preventing Boumietai. By recording your tasks, you ensure you won’t forget them (or at least, you can recall them when you see the record) and you know what to do, so you won’t be confused about what to do next. As you complete a task, you check it off, then move on to those that haven’t been done, and if you get into that rhythm, you can prevent slacking off.

“You might think, ‘That won’t work perfectly, will it?’” And you’re right. We are intentional slackers with our own will—we are not machines—so even if we record our tasks, we don’t always act exactly as planned. There are plenty of cases where we “saw the task, understood it, and planned to do it next,” yet didn’t actually follow through. Even so, having something visible is much better than having nothing at all. Without any record, everything depends entirely on one’s mood and mental capacity—but by externalizing it, you have something to rely on.

### The Role of Task Management Tools

This is precisely why task management tools exist. By incorporating attributes such as priority, category, status (not started, in progress, completed), deadlines, start dates, etc., and by assigning values to each task, many conveniences become available. For example, you can filter to “display only tasks that are not yet finished,” “show only high-priority tasks,” or “display tasks with impending deadlines,” and you can sort them by specific criteria to get a clear overview. This is far superior to simply having a list of tasks.

However, for a tool to work effectively, you must consistently update each task and its attributes. In a work setting, this is often done as part of project task management (often because you are forced to do so), but in your personal life, it doesn’t always happen. As mentioned earlier with Trement, unless you are the kind of person who can act as if you are training every day, it is difficult to keep up with this routine. To prompt even a small action, tools have evolved over time—for example, with beautiful design, rich customization, and even gamification features. Occasionally, some people even build their own task management tools; this DIY approach can be very motivating, as it lets you use something you created yourself.

### The Importance of “Movement Paths”

In other words, Boumietai essentially means that by looking at the tasks stored in your tool, you can, to some extent, prevent forgetting, confusion, and slacking. It won’t work 100%—your own will, aptitude, and skill are still required—but it is far better than not using any tool at all.

Now, what can you do to improve the “quality” of Boumietai? I will mention one very important thing: **the movement path (動線).**

Not “guide path” but “movement path.” Often referred to as “the flow of daily life,” the idea is simply “places you pass by frequently every day.” Although “passing by” might sound like it refers only to physical locations, it isn’t limited to that. For example, your home toilet, the door of your home toilet, your refrigerator at home, your smartphone’s home screen, your PC desktop, and your social media timeline are all movement paths. (Of course, movement paths differ by person—for instance, I don’t even have a personal smartphone, so I don’t have a home screen that serves this purpose, and people who are frequently on long trips or business trips may not have a “home” to serve as such.)

Returning to task management tools, to ensure that Boumietai is upheld, we need a cycle: look at the tool (Read) → select a task (Select) → act (Act) → return to the tool to update the status (Feedback). Once one cycle is complete, you start again with “Read.” I will refer to this as the **RSAF cycle**.

So, how can you keep the RSAF cycle going? You already know: **you must incorporate your tool into your movement path.** For example, it must be something you check dozens of times a day. If it is built into your movement path, you’ll see it many times during the day (even if you might not follow the exact behavior as prescribed), and at the very least it will catch your eye. And if it never catches your eye, then it’s pointless.

### Alternatives to a Movement Path

Is a movement path absolutely essential for preventing Boumietai? Not necessarily. There are other methods as well. Relying on a calendar or the power of your surroundings is well known. In fact, for many people, a calendar already functions as a movement path because they look at it several times a day (see footnote [1]). Alternatively, if you have a partner or family, they can help remind you, which helps prevent Boumietai. Especially for children, unless they are exceptionally responsible, they will typically rely on parental reminders.

In reality, the best approach is to combine various methods. For example, in my case, I primarily use a self-made tool on my PC as my movement path, but I also use a calendar, and for household tasks the refrigerator, entrance, or area in front of the bathroom also act as movement paths. For instance, if after finishing remote work I think, “Maybe I should clean the bathroom,” I leave a cleaning kit in front of the bathroom. Then, as I approach the bathroom before taking a bath, I see the kit and remember, “Oh, I need to clean.” The same happens when I go to the sink or toilet—so I see it several times a day. If you see it repeatedly, you’re more likely to eventually think, “Maybe I should clean.” This method can be more effective than simply writing “clean the bathroom” as a task in your tool. This is just my example. I am fortunate enough to be able to handle Trement, so it works for me; but the proper balance is entirely individual.

- *(1) I think calendars are really excellent tools. You don’t need to update past schedules (they can simply be left as is), which is subtly convenient. In terms of the RSAF cycle, the final “Feedback” step is unnecessary. This “minimal effort” is one of the reasons calendars are so popular.*

## Choudoumyaku

**Choudoumyaku** is a collective term for your condition, motivation, and context. “Condition” refers to your physical state or condition—whether you are doing well or not. “Motivation” refers to your drive or enthusiasm (your “get-up-and-go”). **“Context” (or Context) refers to the premise, situation, background, or inherent nature that a task possesses.** I emphasize this in bold because it is both important and profound; I will cover it in more detail in a later chapter.

The perspective of Choudoumyaku is often neglected but is very important. When you think of task management, it might not be the first thing that comes to mind; in a narrow sense it might be overlooked, but in the broader sense it is vital. It is so valuable that overlooking it would be a mistake. In simple terms, if you hear “your physical condition and motivation are important,” you can understand it. It may seem obvious, but when you’re mentally or physically exhausted, everything feels burdensome. To enhance your sense of conviction (納得感), you must improve your condition and motivation—even though “improving” is easier said than done. More often than not, it requires you to maintain your condition on a day-to-day basis or in the long term, and to understand what makes you feel good (or not) so you can act accordingly.

Regarding motivation, since it’s simply your “get-up-and-go,” it’s fairly straightforward. If you’re motivated, you’ll feel convinced about what you’re doing; if not, you won’t. To boost your motivation, ask yourself: How do you get motivated? I won’t delve deeply into psychology, neuroscience, or philosophy here. The key is not so much to understand the mechanism but to learn what actions increase your motivation and then to take those actions. To put it succinctly:

- **Clarify things**
    - Break down tasks that you don’t know how to do.
    - If you’re not even sure what you don’t know, just start.
    - Link tasks to your goals so that a sense of progress or purpose becomes visible, etc.
- **Let it permeate**
    - Turn tasks into habits, routines, or passions that you can do effortlessly.
    - Build up your physical and mental skills so as to reduce resistance or depletion.
    - Systematize, automate, or simplify things to make them as seamless as possible (eliminating barriers), so that it’s easier to get started, etc.
- **Just get started (by setting up a conducive environment)**
    - Create an environment that makes it easy to begin.
    - Find such an environment and go there.
    - Reduce distractions, etc.

Finally, regarding context: knowing the context of a task can increase your sense of conviction. For example, compare a task A, whose purpose is unclear, with a task B that is clearly explained as necessary for a specific purpose—the latter will give you more conviction because you understand its context. So if you want to enhance your sense of conviction by focusing on context, you should go out and learn more about it. This might involve researching, listening, talking with yourself, self-analyzing your current situation and aptitudes, etc. People vary in how they do this—some prefer to think quietly on their own, some like talking with others, some seem talkative but are really just observant (in other words, they love to observe), and some enjoy gathering information from case studies, documents, or academic papers.

### Maximizing Your Sense of Conviction

Taking Choudoumyaku into account is essentially all about maximizing your sense of conviction. If you’re convinced, then all is well; if not, then nothing will work. For your condition, being in good physical shape or in a good state naturally increases your conviction. Conversely, if your condition is poor, your conviction will also be low. Particularly when you’re mentally worn down, negative thoughts can dominate, and when you’re physically exhausted, everything feels like a hassle. To boost your sense of conviction, you need to improve your condition—and while that sounds simple, actually achieving it is not easy. More often than not, it means maintaining your condition on a daily basis or over the long term, and understanding when and how you feel your best (or worst), and then acting accordingly.

For motivation, since it is simply your enthusiasm, the answer is similar. When you are motivated, you feel convinced about what you’re doing; when you’re not, you simply can’t do it. The key is to figure out what actions boost your motivation and then take those actions. In short:
- Break down tasks that seem vague.
- Just start, even if you’re not sure where to begin.
- Connect tasks to clear goals so that you see progress and meaning.
- Make the process habitual so that it eventually becomes second nature.
- Create an environment that reduces friction and distractions.
- And so on.

Finally, context: if you understand the background or true meaning behind a task, you will feel more convinced about it. For example, if you know exactly why you’re doing something, you’re more likely to be committed. Thus, if you wish to enhance your conviction via context, you must take the time to uncover that context.

### Practice Makes Perfect

There is a proverb that says, “What is loved is done well.” In order to get good at something, you have to continue doing it—and if you don’t enjoy it, you won’t be able to stick with it.

This is also true for enhancing your sense of conviction via Choudoumyaku. As I’ve introduced Choudoumyaku briefly, note that it requires proactive and continuous effort. This is where personal interests, curiosity, likes and dislikes, and individual beliefs come into play. Things you dislike or are indifferent to simply won’t last.

Some may say, “Money makes no difference,” but I am skeptical. People who say they’re motivated by money often have work that aligns with their interests (see footnote [1]). “It’s for my family, so it doesn’t matter” is similar. Those who persist in such endeavors tend to have interests that match the work.

- *(1) External rewards such as money are called “extrinsic motivation.” It is well known that extrinsic motivation tends to be less sustaining than intrinsic motivation based on personal interest or belief. In reality, however, many people do maintain their motivation through money. In my view, those who work for money often have underlying intrinsic motivation as well. Their work may be enjoyable or tied to a belief that “if I can save this much money, I can do X,” or they may derive pleasure from the “game-like” nature of steadily working through tasks. In short, they have intrinsic motivation, and money only adds to it. Conversely, people who cannot find intrinsic motivation are unlikely to persist.*

## Netsumushuu

**Netsumushuu** is a collective term for passion, absorption, and concentration.

While Boumietai focuses on certainty (getting tasks done reliably) and Choudoumyaku on conviction (feeling convinced about what you do), Netsumushuu focuses on continuity—that is, the ability to persist. “Passion” means keeping your enthusiasm and interest from waning. “Absorption” means cultivating and seeking a state of deep involvement, and “concentration” means starting and getting into a state of flow. In short, (though the order might be switched, with passion as the engine, concentration as the operation, and absorption as the maintenance and refinement of that engine or operation) these elements work together. Essentially, it is about using both your engine and the method of driving it to get yourself moving. No matter how well you record your tasks (Boumietai) or cultivate conviction (Choudoumyaku), if you can’t actually execute the tasks, it means nothing. And whether you can complete them depends on whether you can continue until they are done. Moreover, even if you do manage to persist, it is more efficient to finish quickly rather than drag things out for hours. The concept of concentration needs no elaborate explanation—it is well known.

- *(1) I wanted to make the term “Netsumushuu” (especially the “absorption” part) clearer, but I must admit it is a bit forced. It is, in fact, completely contrived.*

### Maximizing Performance

What Netsumushuu helps to enhance is **performance**. Here, “performance” means how well you can draw out your inherent capabilities—not necessarily productivity or output. **High performance means you can extract the best of your abilities.** It does not automatically translate to high productivity (see footnote [1]).

To boost performance, you need to raise your Netsumushuu. So, how can you improve each aspect of Netsumushuu?

- *(1) In general, performance and productivity are proportional. Particularly in fields like manufacturing or knowledge work, where one needs a method and focus that suits the individual, “undisturbed time” and “high discretion” are required. When these are misunderstood or when methods are overly restricted, micromanaged, or filled with frequent meetings and interruptions, it becomes counterproductive. That is why, in such work, a two-step approach is often taken: giving full autonomy to the individual and then reviewing the results. A good example is writers or cartoonists.*

### Passion

Passion is largely supported by the previously discussed Choudoumyaku. If you manage your condition, spark your motivation, and understand the context, you can maintain your enthusiasm. A good example is sports, where people prepare diligently for days, weeks, or months in order to perform at their best. However, if you keep pushing without rest, you will eventually burn out; therefore, switching between work and rest or taking breaks is also important.

### Concentration

Next, let’s discuss concentration. Concentration requires you to understand and tame your own habits. For example, I find that I can concentrate best in a completely undisturbed, quiet environment. On the other hand, some people prefer having the TV on or working while listening to music, or even enjoy random stimuli or the comfort of a pet cat. Even the same person might change their approach depending on the situation—for instance, working in silence when generating new ideas, but needing some background noise to get through monotonous tasks. In other words, concentration depends on how cleverly you can impose constraints on yourself. I recently saw an excellent video—for example, [a behind-the-scenes video of Darom On, the artist for Ken Ga On Ashura](https://www.youtube.com/watch?v=WGBd-SzPgls)—where he uses the Pomodoro Technique, vocal exercises, and even eats rice balls to maintain concentration during his drawing sessions. This is an example of dealing with monotonous work. Monotonous work is boring and can leave your mind wandering; controlling that wandering is crucial. In my view, professionals are both parallel and speedy; they can accomplish in short time what others take much longer to do, and even handle multiple tasks simultaneously. That is why, in work, the proportion of monotonous tasks inevitably increases, and managing your wandering thoughts becomes a key issue. (This example is more applicable to monotonous work; for more complex tasks, the basic idea is the same, though the difficulty of devising strategies increases significantly.)

### Absorption

Finally, when it comes to absorption, you should actively experiment with ways to enhance both passion and concentration (remember, absorption was defined as the maintenance and refinement of the engine/operation). You can research various work techniques or task management methods, watch the video mentioned above, or talk with colleagues or friends about it. Of course, you can also experiment on your own, but when you’re new to it, it may be difficult. It’s often more effective to first learn about the various methods and examples that already exist.

Ultimately, whether you can set aside time to experiment is key. For example, consider whether you can secure 30 minutes a day. This might be challenging for busy people—but if you cannot make that kind of time investment, then nothing will work.

# Shallow or Deep Management?

How deeply you manage your tasks differs greatly from person to person.

Broadly speaking, you can divide task management into two categories: shallow management or deep management.

- **Shallow Task Management**
    - This involves managing the multitude of tasks that surround you.
    - Its purpose is “to get as close as possible to the ideal rate of execution,” making it suitable for those who want to prevent forgetting, confusion, and slacking.
    - As mentioned in the Boumietai section, having a good movement path is important, and it is common to use several different tools.
- **Deep Task Management**
    - This involves managing only a few important tasks.
    - Its purpose is “to break through and make progress,” making it especially suitable for busy people.
    - Ultimately, it comes down to decision-making—particularly the ability to discard tasks—and you need to hone that skill continually.

## Shallow Task Management

**Shallow task management** is an approach in which you capture and manage the myriad tasks surrounding you—be it your main work and miscellaneous chores, household tasks, daily routines and habits, hobbies, study, training, and other investments. The idea is to capture as many of these as possible and manage them.

The goal is the Boumietai we discussed earlier. If you simply go about your day haphazardly, you will forget, get confused, or slack off. But if you capture and manage them, you can complete them more efficiently. Moreover, if you schedule them according to your own pace and rhythm, your overall quality of life can improve. Additionally, by eliminating forgotten tasks, you prevent the “cascading damage” that might occur later.

The total amount of tasks does not change. For example, even if you have 20 tasks to complete today that would normally take 6 hours, whether or not you manage them, the tasks still add up to 20 and 6 hours. However, without management you might end up taking 9 hours due to forgetting, confusion, and slacking—or you might not finish at all. Conversely, if you manage them effectively and execute appropriately, you can get closer to that theoretical ideal of 6 hours for 20 tasks. In that sense, **shallow task management is about getting as close as possible to the theoretical ideal of task execution.**

There are various methods to do this, and generally people use multiple approaches. For instance, you might use a calendar for appointments, and set reminders or alarms for tasks you don’t want to forget. Wake-up alarms or even a 3-minute timer for instant noodles are famous examples. For regular, recurring chores (like taking out the trash), you might set recurring settings in your task management tool or simply post a schedule somewhere for reference.

Another bold tool is [TaskChute](ref#TaskChute). This tool strongly encourages you to act exactly as your task list prescribes—it is, in essence, a system that lists everything you will do in a day (and gradually trains you to follow it). I believe that most people have between 20 and 60 tasks in a day, and it is even possible to manage all of them. Incidentally, TaskChute also functions as a movement path (as mentioned in the Boumietai section) and is designed with that in mind.

## Deep Task Management

**Deep task management** is the approach of managing only a few important tasks. For example, you might decide, “Today, I will only do these 7 tasks!”—focusing solely on those 7. Although in work or daily life you might have many tasks, you deliberately focus on only a few.

Shallow task management involves bold elimination. To focus only on what is essential, you must discard the details. As mentioned earlier in the Interpretation Axiom, decision-making is required—something that is often assumed in self-help or work efficiency methods. For example, the [Ivy Lee Method](ref#Ivy-Lee-Method) prescribes only 6 tasks per day, and the [Time Management Matrix](ref#Time-Management-Matrix) uses the criteria of importance and urgency to set priorities boldly.

Because of this nature, deep management is suited for busy people. Busy people often face far more tasks than can possibly fit into 24 hours a day, and they are easily swayed by circumstances. That is precisely why, even amid overwhelming demands, there is value in decisively choosing what to do now. Of course, even if you decide, it doesn’t mean you will actually accomplish those tasks—often, the reality is that you can’t. Deep management means that even after deciding, the actual busy reality doesn’t change. It requires multifaceted and continuous efforts—from learning to give up tasks, to delegating, to changing your methods and ideas. In particular, you must have the courage (or the ability and power) to discard tasks.

In short, making these tough decisions is precisely because **the goal of deep task management is to break through and make progress.** When you are overwhelmed by tasks yet still decide, “I will do this,” you must actually do it. It’s easy to say, but when you’re busy, you have little room to maneuver, and you might even be met with resistance like “Shut up—everything is important!” Therefore, you cannot arbitrarily choose—you must rely on the aforementioned Choudoumyaku (condition, motivation, context). In short, if you haven’t done your research and thought about it beforehand, it won’t help you when it matters. A phrase like “Okay, I’ll narrow 20 tasks down to 3 in 2 days—give me a couple of days” is generally not acceptable. You need to have the kind of Choudoumyaku that lets you decide quickly, “Alright, let’s go with these 3.”

# Tools: Analog or Digital?

When it comes to task management tools, they can be broadly divided into two categories:

- **Analog**
    - Tools that do not use digital devices.
    - **Advantages:** They are approachable and easy to start with, and offer a rich experience (just as the tactile experience of paper books contrasts with e-books).
    - **Disadvantages:** They do not allow for rapid operations, are limited by physical space, and generally require you to process a fair amount in your head.
- **Digital**
    - Tools that use digital devices.
    - **Advantages:** They allow for fast operation and data synchronization. You can manage a large number of tasks and access them from anywhere.
    - **Disadvantages:** They require a certain level of skill and study for each tool, and there is a risk of being distracted by too many options (the means can become the end).

## Analog Tools

Analog tools refer to those that do not use digital devices.

Examples include writing on paper, in a planner, on sticky notes that are then pasted up, on a doodle board affixed to a refrigerator, on a whiteboard, on an entire wall turned into a whiteboard (a “whiteboard wall”), and even writing on chocolate wrappers (see [this article](https://nlab.itmedia.co.jp/nl/articles/1910/13/news021.html)). There are many such methods, and even within the act of writing on paper there are various variations—what kind of paper, in what format, with what kind of pen, etc. Moreover, it is not only about “writing” down tasks but also about “drawing” diagrams, creating mind maps with connecting lines, or even including pictures to boost your mood.

The advantages of analog tools are their ease of use and the rich experience they provide. Since you don’t need digital knowledge or skills to get started, they are very accessible and easily customizable. While certain aptitudes—such as manual dexterity, visual memory, and spatial recognition—may make them more or less suitable, they do not require any specialized knowledge or skills (aside from task management itself). Another undeniable advantage is the amount of sensory input you get when you write something down. Many say that handwriting is easier to remember than typing on a keyboard or touchscreen; the act of handwriting stimulates more of your senses, uses more neural resources, and, though slower, forces you to engage with the material deeply—making it easier to remember. In the world of writing, there is even the practice of copying texts (which is a form of training). Just as physical books still retain a strong following even with the advent of e-books, handwriting retains its appeal. In short, analog tools provide a rich experience that can add color to the sometimes monotonous process of task management—in other words, they can **lift your spirits.** Since continuity is key in task management, anything that helps you stay motivated is a major plus.

Of course, there are disadvantages. When you make a mistake, it is not as easy to correct quickly, and your speed of writing may be limited, meaning you can’t handle as many tasks (furthermore, there are physical limitations such as the amount of available paper). In essence, you must first process things in your head before externalizing them. Moreover, analog tools are not well suited for those who struggle with internal processing. Another drawback is that they are vulnerable to being lost or seen by others. Digital tools can save your work to the cloud and protect your devices with security measures so that no one else can read them, but with analog tools you can physically lose them or have them looked at by others. Although careful management can mitigate this, it does require additional effort. Since personal task management may include highly private information, this lack of security can be a significant concern.

Overall, analog tools are **very useful for people with strong mental processing abilities.** They are ideal for those who can manage things in their head but still want to externalize them as a supplement. Despite their physical limitations, just as paper books have an enduring appeal compared to e-books, the mood-lifting effect of analog tools should not be overlooked.

## Digital Tools

Digital tools are those that use digital devices.

Examples include smartphone apps, desktop tools for PCs, command-line tools, text files or editors, web services accessed via a browser, and even digital devices that are neither smartphones nor PCs. Many of these tools are marketed specifically for task management, but with a little ingenuity, you can repurpose general-purpose tools for managing tasks. For instance, you might create a file called task.txt and operate it according to your own rules—this is a form of tool, and indeed there are text file–based tools (such as [todo.txt](ref#todo.txt)), with some even claiming that plain text management is the ultimate method (see [this blog post](https://kirimin.hatenablog.com/entry/2019/08/06/190809)). I will discuss plain text methods in more detail in a later chapter.

The advantages of digital tools are their speed and data synchronization capabilities. You can type quickly (using a keyboard or swipe input), easily copy and paste, duplicate, edit, rearrange, insert, and search—all very quickly. You can even tag tasks and filter them by tag. Depending on the tool and your skills, you can manage hundreds or even thousands of tasks. Furthermore, if you use a web service–based tool, your data can be synchronized so that you can access it from anywhere. You might access it from your PC at home and then from your smartphone when you’re out—the benefits unique to digital are clear.

Of course, there are also disadvantages. First, there is the issue of skill. Whether on a smartphone or a PC, a certain level of digital literacy is required, and each tool has its own methods and functions, meaning that **you generally need to study each tool.** Some people who are naturally efficient or even a bit lazy might try to “wing it” by using the tool and learning as they go, but digital tools can be surprisingly inflexible and hard to understand. Ultimately, you will need to read documentation or engage in experimental trial and error. It can take time for a tool to become second nature, so a degree of patience is required—this is related to Trement. If you can’t handle that, you might quickly jump to another tool. Many people end up in this cycle, and this phenomenon itself is a disadvantage because **the means can easily become the end.** You might end up trying and playing with different tools just for the sake of it. In a troublesome twist, task management tool vendors intentionally encourage this behavior with attractive slogans, cool interfaces, and glowing testimonials—it can be very hard to resist.

Overall, digital tools are **ideal for those who value fast operations and high accessibility.** While analog tools are mainly about externalizing what you’ve already processed in your head, digital tools (depending on the tool) allow you to do that quickly and efficiently—but they do require the necessary skills and study. And because there are so many options, if you let yourself get distracted, you risk losing sight of the goal as the means become the end.

...
