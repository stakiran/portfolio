---
title: Events
---

# Overview of Events

## Overview
An **event** refers to any matter that imposes constraints on at least one of the start time or start location, and also requires that the end time be either specified or coordinated. In other words, it is what we commonly call an “appointment.” Put differently, it is something that inherently involves participation.

Because events impose significant constraints, they should generally be coordinated in advance—you might even say you “make an appointment.” On the other hand, events can also occur unexpectedly, such as when an interruption happens or a casual conversation drags on. Incidentally, even a casual chat can be considered an event. Although there may be no constraints at the beginning, there is often an unspoken effort to figure out how to end it (an implicit constraint).

At its core, an event is a kind of ritual. In essence, it is a collective decision—“We are now going to start this activity here”—to which everyone agrees and participates. Participation itself incurs a certain cost (for example, gathering at a specified time and place), you remain constrained while the event is in progress, and when it comes to ending, you must either wait until the predetermined end time or gauge the appropriate moment yourself. In short, events are simply **a hassle**.

# Types of Events and How to Handle Them
Events can be classified based on which part of the process is constrained. Items that do not qualify as events are marked with ❌.

| No  | Start is constrained | Constrained during | End is constrained | Example                                      |
| --- | -------------------- | ------------------ | ------------------ | -------------------------------------------- |
| 1   | y                    | y                  | y                  | General appointments                         |
| 2   |                      | y                  | y                  | A meeting that emerges from a prolonged chat |
| 3   | y                    |                    | y                  | Remote work                                  |
| 4   |                      |                    | y                  | Locations with a fixed closing time          |
| 5   | y                    | y                  |                    | Death march, confinement                     |
| 6   |                      | y                  |                    | Casual conversations/discussions             |
| ❌7 | y                    |                    |                    | -                                            |
| ❌8 |                      |                    |                    | -                                            |

In the following sections, we explain an overview of each type and discuss how to approach them in terms of task management.

*Note: Types 7 and 8 are not considered events. Type 7—the idea of something where only the start is constrained—is hard to conceptualize and is therefore omitted. Type 8 involves matters with no constraints at all (in other words, non-events), so we do not address them.*

## 1. General Appointments
| No  | Start is constrained | Constrained during | End is constrained | Example              |
| --- | -------------------- | ------------------ | ------------------ | -------------------- |
| 1   | y                    | y                  | y                  | General appointments |

In most cases, type 1 is what we usually mean by “appointments.” There is a specified start time, and once begun, you remain constrained until the designated end time.

**Because managing these as tasks is difficult, you should use a calendar.** Remembering when to start is paramount, and to do that you need to have a bird’s-eye view of your schedule. You can use reminders or simply be in an environment where someone or something will prompt you. In other words, it’s perfectly acceptable if **even if you forget, someone or something reminds you.**

In fact, the very purpose of gathering in the same place as a group is to provide this kind of external reminder—even if you aren’t personally disciplined enough to stick to your schedule, watching others or having someone prompt you will help. This is as common in switching classes at school as it is in moving to a meeting room at work.

## 2. Impromptu Meetings Arising from Extended Chit-Chat
| No  | Start is constrained | Constrained during | End is constrained | Example                                          |
| --- | -------------------- | ------------------ | ------------------ | ------------------------------------------------ |
| 2   |                      | y                  | y                  | A meeting that emerges from a prolonged chat     |

Type 2 refers to cases where only the beginning is not prearranged. For example, when you’re in the middle of a casual conversation and suddenly a meeting is initiated. Rather than showing up at a predetermined time or place, the meeting starts on the spot with remarks like “Shall we begin now?” or “Alright, let’s do it.” Sometimes it even begins unnoticed or without any explicit agreement.

In terms of task management, this is an unplanned event—a so-called **interruption.** Ideally, you should immediately decide whether to join or decline and communicate your decision. If that proves difficult, you might take a brief pause (choosing your words carefully to maintain decorum) and temporarily step away. However, some people or teams may view such behavior as “not reading the room.” It’s a delicate balancing act. Of course, in workplaces where psychological safety is guaranteed and trust is strong, you might not have to worry as much—but such environments are rare. Often one party may believe there is trust while the other does not.

The worst approach is simply accepting the interruption without question. If you do so, all your subsequent plans will be thrown off, and you’ll have no idea when this impromptu event will end. Moreover, because it began so suddenly, you’re unlikely to be fully focused. This scenario is undesirable not only for productivity but also for your overall quality of life. In my view, workplaces or teams where type 2 events are frequent should be approached with caution—simply put, too many interruptions are not ideal.

As an exception, if there is a mutual understanding that casual conversations may naturally lead to work-related events (such as meetings) and this is encouraged, then it is acceptable. For example, [GitLab’s Coffee Chat](https://handbook.gitlab.com/handbook/company/culture/all-remote/informal-communication/#coffee-chats) allows any employee to request a casual meeting with anyone at any time. As of 2024/06/11, the handbook recommends “a few hours per week” and notes that “because work talk is common, casual chats and sharing are encouraged.” The notion that anyone can initiate a casual chat is broadly applicable. A company might decide, “Everyone is welcome to have a chat at any time—even in the smoking or break room, feel free to chat multiple times a day or for an hour, since these chats often lead to work discussions.” However, if not carefully managed, this can lead to the formation of cliques or dynamics that become overly politicized.

## 3. Remote Work
| No  | Start is constrained | Constrained during | End is constrained | Example     |
| --- | -------------------- | ------------------ | ------------------ | ----------- |
| 3   | y                    |                    | y                  | Remote work |

Type 3 is characterized by a constraint on the start and end only—there is no constraint during the work period. Although it might seem counterintuitive, remote work sometimes falls into this category.

In some remote work arrangements, you are expected to check in only at the beginning and the end of your workday, while the intervening time is free for you to use as you wish. Of course, you are still expected to work diligently, but you are not tied to a specific workplace. You might work from home, or even enjoy a “workation” at a resort or tourist spot.

This mode of working is not uncommon nowadays and is feasible in jobs or teams that offer significant autonomy. However, merely working remotely or being fully remote does not automatically mean you fall under type 3. For instance, if you have many online meetings, then you likely do not. A good indicator is the presence of a **mute day**—a day on which no meetings are scheduled at all. Casual chats or brief consultations are acceptable, but if you intend to have a day where you speak with no one at all, you should be able to do so. If you cannot confidently say yes to that, then you aren’t truly experiencing type 3.

Now, regarding task management: to support such autonomous work, you must be capable of managing your own tasks sufficiently. I was once told by a colleague, “Kiran-san replies to every chat message—it's impressive,” but if you are to truly embrace type 3, you must be able to do at least that. Essentially, it means you are managing your own tasks to the extent that you can understand every message and respond within a realistic timeframe.

Furthermore, and perhaps even more importantly, you must adjust not only your work but also your work style to enable autonomous working. For example, you might decide to document discussion points on a Wiki, agree that each topic gets its own page where everyone must contribute an opinion (or note if they have none), or decide that if someone is prone to organizing unnecessary meetings out of loneliness, such meetings should be avoided—or only held if everyone explicitly consents. You might even compile strategies for those who find isolation hard to bear, and offer training if necessary. These are all matters of approach, and sometimes require coordination or negotiation with stakeholders. As I have mentioned several times in discussions of [non-task management battles](partner_taskmanagement#盤外戦), to achieve your desired way of working, you must address the root causes that stand in your way.

## 4. Locations with a Fixed Closing Time
| No  | Start is constrained | Constrained during | End is constrained | Example                               |
| --- | -------------------- | ------------------ | ------------------ | ------------------------------------- |
| 4   |                      |                    | y                  | Locations with a fixed closing time    |

Type 4 applies to situations where only the end is constrained. This may seem a bit counterintuitive, but it describes places that have a designated closing time or a “closing” concept. It might be a store or any other venue where you can come at any time and spend your time as you please—but because there is an ending time, you cannot stay indefinitely.

From a task management perspective, such places can be viewed as resources that you can use until their closing time. You should think about how to maximize your use of them before they close. For example, if you know that a venue is more comfortable during off-peak hours, then you need to figure out how to secure that time—and that might involve breaking down your tasks to free up the necessary time.

For instance, I personally dislike crowds and am a morning person. I usually wake up at 5:00 AM, go to bed at 9:00 PM, and work roughly from 6:00 AM to 3:00 PM. With this rhythm, my lunch break is around 9–10 AM and my post-work dinner is around 3–4 PM, so the restaurants are relatively empty. To maintain this lifestyle, I fully rely on task management. This means I cannot take on jobs that impose heavy constraints—in other words, I’m generally not suited for extensive team play, and I have to be quite selective about the work I take on. Still, I work hard at planning and training (using task management) to secure work, and it’s no small feat.

Thus, to successfully handle type 4 events, you need to both adjust your lifestyle so that you can operate during the desired time frame, and manage yourself well enough to actually stick to that schedule.

As a simple example, suppose you want to visit your usual lunch spot before it gets crowded. If you wait until your normal 12:00 break, you won’t make it in time. If you figure out that leaving about 15 minutes earlier secures you a seat before the rush, then to actually do this you might need to finish your morning work by around 11:45, or communicate with your team or supervisor to get approval for leaving 15 minutes early. If you have a lot of discretion, you might be able to do this openly; if the rules allow it but the workplace culture makes it difficult, you might have to do it discreetly. Incidentally, the concept of a closing time applies here too—for example, the restaurant might close at 13:00 or the lunch break might officially end at 12:59. In the context of type 4, these constraints must be adhered to.

## 5. Endless (No Defined End)
| No  | Start is constrained | Constrained during | End is constrained | Example                          |
| --- | -------------------- | ------------------ | ------------------ | -------------------------------- |
| 5   | y                    | y                  |                    | Death march, confinement         |

What could be a situation where both the start and the duration are constrained, yet the end is not? The idea of “You may leave whenever you like” is hard to imagine—and if you truly could leave at will, there would be no problem. In reality, it is a harsh situation where you cannot leave until the event is forcibly ended.

Examples include a death march (chronic overwork), projects that spiral out of control, working on critical tasks with inefficient or indecisive team members or clients, or situations where an overbearing authority controls the end time according to their whims—amounting to harassment or brainwashing. In any case, such scenarios are characteristic of exploitative (“black”) companies, and in an even more extreme form, may even resemble confinement.

Type 5 events are nothing short of hell, and they cannot be remedied by task management alone. They require addressing the root causes—what I refer to as [non-task management battles](partner_taskmanagement#盤外戦)—by taking actions to avoid falling into such situations in the first place, steering clear of them, or if you do end up in one, escaping as soon as possible or fighting back by any means necessary. Sometimes they might end by chance, but that is akin to leaving it entirely to fate, and in the meantime, they can seriously damage your mental and physical health. The ability to engage in these “non-task management battles” is crucial. In fact, it is precisely because people know escape is possible that exploitative companies, cults, multi-level marketing schemes, host clubs (and certain other client-based businesses) design their environments to prevent you from leaving. They block information, disallow you from relying on others, create a closed environment where rewards are controlled by alternating incentives and penalties, and impose quotas or mandatory attendance to wear you down—all to prevent you from thinking for yourself. They often bombard you with nonverbal cues that play on your emotions, and because physical presence is required, spatial constraints are also imposed.

## 6. Unclear Ending
| No  | Start is constrained | Constrained during | End is constrained | Example                                  |
| --- | -------------------- | ------------------ | ------------------ | ---------------------------------------- |
| 6   |                      | y                  |                    | Casual conversations/discussions          |

There are events in which neither the start nor the end is constrained—only the duration is. Casual conversations and similar discussions fall into this category. They can start suddenly and may drag on indefinitely without a clear conclusion.

In terms of task management, the challenge is how to control both the beginning and the end. There are roughly three approaches:

1. **Structured Boundaries:** Set aside specific time periods when conversation is allowed (good times) and periods when it is not (bad times), thus creating clear distinctions.
2. **Explicit Proposals:** Clearly state when you intend to start and when you want to end the conversation.
3. **Dummy Events:** Insert a fictitious appointment into your schedule to force an end.

The Structured Boundaries approach involves establishing “good times” when conversation is acceptable and “bad times” when it isn’t. With friends or close acquaintances, you’ll often arrange explicit meetings or set aside time to chat. Conversely, if you can’t secure these “good times” (i.e., opportunities for conversation), relationships may suffer. Carving out time is precisely what task management is for—and while that is the whole point of managing tasks, it isn’t something everyone can do effectively. In such cases, transitional rituals become especially valuable. Milestone ceremonies—like birthdays or New Year’s celebrations—are typical examples of “good times.” People favor such rituals because they crave these designated periods, and many find it difficult to secure them on their own. In fact, I believe that those who deliberately design and secure good times tend to be more successful in their relationships.

The Explicit Proposals approach means that when you want to start or end a conversation, you say so clearly. It might come off as bland or overly businesslike, but chronic, drawn-out conversations can be incredibly stressful. Moreover, there are times when you want a conversation to linger and times when you want it to end—it is best to be able to do both. Using explicit proposals requires a certain level of trust and the ability to communicate clearly—qualities I discussed in the [Partner Task Management chapter on Tocability](partner_taskmanagement#トーカビリティ). When you have that “tocability,” you can discuss whether and when to use explicit proposals. Often, elements of the Structured Boundaries approach will also come into play during this process.

Finally, the Dummy Event approach is a method to prompt an end by fabricating a dummy appointment to excuse yourself from the conversation. For instance, you might say that you’ve just received a phone call or suddenly remembered another commitment—excuses commonly seen both in real life and in fiction. As an advanced technique, if you consistently portray yourself as someone who is busy, it becomes easier to use dummy events. You might say, “My parents/partner enforce a strict curfew,” “There’s a dormitory curfew,” “I adhere to a strict lifestyle” (as I, the author, do), or “I have a pet to take care of…” The variations are endless.

# Summary
- **An event is a matter that constrains the start, the duration, and the end.**
  - It can be classified into several types depending on which part is constrained.
- **There is a wide variety of event types, each with a different nature and requiring different approaches in task management:**
  - **Appointments:** The top priority is to adhere to the specified start time and place. Use a calendar.
  - **Transitions from casual chat to meetings:** Essentially, these are interruptions. Either take a moment to handle them calmly or cultivate a culture that accepts such transitions from the start.
  - **Remote Work:** This requires the ability to work autonomously and to be granted the freedom that comes with it—although this level of autonomy is beyond most people.
  - **Locations with Fixed Closing Times:** You need to adjust your own schedule to determine when and how to use these resources.
  - **Endless Events:** In short, these are exploitative situations (“black” environments) that you should avoid as much as possible.
  - **Unclear Endings in Conversations:** There are measures to handle these, such as establishing clear boundaries, stating your intentions explicitly, or fabricating dummy events.
