---
title: Exploratory Task Management(4/4)
---

# Useful Topics

**Answer:** Here are some examples of topics that are handy to create.

There are many useful topics aside from those discussed here, and you may invent new ones as needed. Those who master the use of topics essentially master ETM. At the same time, be careful not to be too rigid in your usage—maintaining a balance is important.

## Date Topics

**Answer:** A shared daily diary topic is very useful.

In the [Literary Task Management chapter](literate#date-notes) I introduced “date notes,” which are also useful when multiple people work together on ETM. Each person may create their own personal space and jot down thoughts or diary entries. For example, if today is 2024/09/02, then there is a note called “2024/09/02,” and tomorrow a note called “2024/09/03,” and everyone writes in them.

Date topics make it easy to see who is doing what, and they foster casual conversation and consultation. They also make it easier to share information. Since date notes are often the “home base” where everyone frequently visits, try to use them as your main hub during ETM.

You can use either a daily or weekly unit. Since there is likely to be a good amount of writing each day, daily notes are recommended. If there is clearly very little content, weekly notes might work. However, someone needs to create the note each time. If this is too tedious, automate it. If you expect someone else to create them and nothing appears, the lack of topics will quickly cause ETM to lose momentum.

## Mention Topics and Post Topics

**Answer:** When you want a particular person to see something, create a topic for that purpose.

ETM is “No ABCD,” so unlike traditional methods you can’t rely on direct mentions or notifications to ensure someone sees your note—and that’s by design. However, sometimes you really need someone’s attention. In such cases, you can use a Mention Topic or a Post Topic.

A **Mention Topic** is a note whose title directly addresses someone. For example, if you have an idea X for a business contest in three days and want expert A to see it, you might create a topic named “@A Please check out Idea X.” Even if the content of the note is not read immediately, the title makes it clear that the note is directed toward A, so A is likely to notice it.

The other method is a **Post Topic.** Named after a mailbox or postbox, this is a note that serves as person A’s “inbox.” Others write their requests or messages there. For example, you might have a note called “inbox @A” where anyone who wants to send A a request writes their message. In this case, A is expected to check their Post Topic. Alternatively, if A doesn’t regularly check it, that is acceptable. ETM does not impose strict obligations on anyone.

Using both Mention Topics and Post Topics can be noisy if overdone, so it is best to choose one. I personally recommend Mention Topics because Post Topics place a heavier burden on the owner. The recipient does not know what is inside until they open it, which is akin to receiving unsolicited flyers in a mailbox. This burden can detract from the free, exploratory spirit of ETM. Mention Topics, on the other hand, feel more natural as they are tied to individual topics.

Either way, if you use these methods too frequently, it becomes noisy. **It is better if you only use them when absolutely necessary—ideally, no more than once a day.** In fact, relying on such methods runs counter to the spirit of ETM. In most cases you should be able to simply write a short note in the daily topic or in person A’s personal space. If you find yourself having to use mentions or post topics repeatedly, it may be that your setup does not truly meet the spirit of ETM. (See the [Setup: Scope and Exploration Period](exploratory#scope-and-exploration-period) for further details.)

## Salvage Topics

**Answer:** When you want to see how a particular subject is being discussed in the venue, search for it and create a summary note.

The ETM venue itself is a source of information. However, because the venue consists of many topics created individually and in a scattered fashion, it is not as organized as an article or book. As a result, the insights are scattered and no clear “answer” is provided, which makes it difficult to absorb the ideas merely by reading. It is important to add your own interpretation—for example, “Based on these points, here is my understanding.” That is the purpose of a Salvage Topic.

When you perform salvage, you create a note that collects links and adds a few comments. For instance, if you want to explore the subject of “remote work,” you might create a note called “Salvage: Remote Work.” In that note you would list the links you found along with a short comment for each:

```
Salvage: Remote Work
 [Link 1]. (A brief comment.)
 [Link 2]. (A brief comment.)
 [Link 3]. (A brief comment.)
 …
```

Or, you could structure it as:

```
Salvage: Remote Work
 [Link 1]
  (A brief comment.)
  …
 [Link 2]
  (A brief comment.)
  …
 [Link 3]
  (A brief comment.)
  …
 …
```

For example, if you were to salvage information on remote work, you might write:

```
Salvage: Remote Work
 [Remotty]
  A virtual office tool by Sonic Garden that displays a camera image of each person every 2 minutes so you can see everyone’s status.
  🐰 has generalized this as [Social Presence].
 [Desk Bomb]
  > Refers to the phenomenon where, in an office setting, someone suddenly appears at your desk without warning to engage in endless chitchat or work consultations.
  Although described as a term from Generation Z, it seems to be one of the phenomena that emerged with the spread of remote work.
 [Rasen Group on Remote Work]
  A case study from a company making FGO about creative approaches to remote work.
  The company’s concept was “anywhere,” so they focused on tools and awareness.
 …
```

In this example three topics were listed, but there is no strict rule on the number. You might search for five promising topics and then decide to read only three, for example. What you include and how you write it is entirely up to you.

Salvaging can reveal various insights on a topic (provided that there is enough content in the venue) and help you see perspectives you hadn’t known before. It is especially useful if you are doing ETM on your own.

Even when working with multiple people, if a certain term appears frequently with different interpretations, creating a Salvage Topic can help visualize those differences.

The demerits are twofold: it can be exhausting if overused, and because the contents are heavily filtered through your personal perspective, the result may be biased.

## Station Topics

**Answer:** When you want to explore a topic T in depth, create a “station” that acts as a forward base for T.

In ETM, topics tend to become scattered. If you create a “desk” or base of operations dedicated to one subject, the work becomes easier. Such a topic is called a **Station Topic** and its title always contains the word “Station.” For example, if you want to have an in-depth discussion on bicycles, you might create a topic called “Bicycle Station” where all related discussions and information are linked. The inclusion of “Station” in the title makes it clear that this is the base for bicycle-related topics.

A station typically functions as a link collection. When you start deep diving into a subject from a station, be careful not to let the discussion become too scattered; instead, create separate topics for the detailed considerations and only link them from the station. It is also helpful to include overall status or context (for example, a context block from Block Writing) as needed. The ideal station is essentially a link collection: in other words, if you want to know about topic T, the fastest way is to navigate via the T station (i.e. link collection).

In the language of Literary Task Management, a station is like the “trunk” (of a tree) that consists only of links.

---

# Summary

- We have introduced hints that are useful for ETM.
  - Some apply only when you’re working alone, some only when you’re collaborating, and some are useful in both contexts.
- ————
- **Literary Task Management**
  - Since ETM is based on Literary Task Management, if you’re in trouble, review that material first.
- **Squeeze Out**
  - The act of giving your all (squeezing out 100% at that moment) leads to a sense of satisfaction and accelerates decision-making.
- **Block Writing**
  - A method of writing blocks using a 1‑space indented bullet list.
  - You alternate between divergence (brainstorming or considerations), developing concepts/direction, listing tasks, and summarizing—that constitutes one cycle. This cycle is repeated.
  - Blocks come in various types, and you indicate the type by a single letter.
- **Boundaries Between the Individual and Collaboration**
  - Topics should be created by an individual and then shared for others to review.
  - Use personal spaces and public spaces appropriately.
- **Balancing the Individual and the Collective**
  - Keep in mind concepts such as being interest-driven, allowing others to “pass over” (not forcing responses), and being cautious about excessive “otaku dumping.”
  - Although ETM is “No ABCD,” sometimes you do have to wait for responses (a “wait”), which you should try to minimize.
    - One main cause of waiting is that negative responses are hard to give; if needed, express negative feedback explicitly.
  - Also, be mindful of roles. Clearly defining them in language helps communication.
    - Roles tend to be dynamic.
    - Think of it as borrowing a “hat” to role-play for a period.
- **Useful Topics**
  - Date topics serve as the daily hub.
  - If you want to get a particular member’s attention, use Mention Topics or Post Topics.
  - If there are common terms that haven’t yet been organized into topics, consider creating a Salvage Topic to gather insights.
  - Creating a Station Topic (i.e. a link collection) is also very useful.
