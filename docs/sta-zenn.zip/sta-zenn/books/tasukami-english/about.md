---
title: About this book
---

This book is the English translation of the online book ["Breaking Down Task Management"](https://zenn.dev/sta/books/taskmanagement-kamikudaku).

- The translation has been done using generative AI
    - There may be inaccuracies in the links or expressions
- The platform's specifications do not support more than 50,000 characters, so a single chapter may be divided into multiple pages.

# Update History
- 2025/02/08 Released the English version
