---
title: Exploratory Task Management(1/4)
---

Task management can be seen as a “directional” activity. There are many ways to describe it—planning, designing, setting goals, procedures—but it essentially involves establishing criteria in advance and then acting accordingly. Since it is assumed that one will follow these criteria, some form of observation or management is required to ensure that one is indeed acting “by the book.” Although this may sound entirely natural, it is merely one way of thinking—and it comes with its own limitations and unsuitabilities.

In this chapter, we focus on another approach: an “exploratory” activity. Instead of relying on predetermined criteria, you move freely and see where your actions take you, thereby broadening your perspective. Without the need to set rigid criteria or manage every step, you can proceed in a free and enjoyable manner. Of course, having nothing at all can leave you feeling lost, so you can dynamically create small guiding criteria—a sort of personal compass. While this may appear haphazard or arbitrary from the perspective of the directional approach, it is highly effective in many situations. It is especially useful when you either lack the necessary criteria for a directional approach or find it impossible to create them; it helps you gather hints. In short, it is a hybrid strategy: you start with exploration, and once you’ve gained enough insight, you switch to a directional approach (this hybrid strategy was also briefly mentioned in the [Task Source chapter](source#ソースとプランの臨界点)).

This chapter, titled Exploratory Task Management (ETM), organizes methods and ideas for an “exploratory” approach that can serve as a precursor to a “directional” one. **It is assumed that you have an understanding of the previous chapter on [Literate Task Management](literate)**—meaning that a significant amount of reading and writing is involved.

# Overview of Exploratory Task Management

## Exploratory Task Management
**Exploratory Task Management (ETM)** refers to managing tasks in an exploratory manner.

### Exploratory = No ABCD
To be exploratory means to embody “No ABCD.” That is, the following elements (ABCD) are absent:

- **Assign**
  - No assignments
  - You do not formally decide “what must be done” and assign either someone or yourself to it.
- **Ball**
  - No “ball” passing or holding
  - In fact, no ball is used at all.
- **Consensus**
  - No consensus
  - Everyone is free to do whatever they like; there is no need to obtain agreement.
- **Deadline**
  - No deadlines
  - There is no situation where you’re chased by deadlines.

In other words, the characteristics of a directional approach are excluded. There is neither a “correct answer” nor pre-set criteria; how you proceed is entirely up to you. You act on your own will, in your own way. This is exploration.

### Designed for Small Groups, but Also Applicable to Individuals
ETM is designed to be conducted with a small group (around 2 to 5 people), and this chapter assumes such a setting. That is why the aforementioned ABCD includes elements involving communication with others.

However, ETM can also be practiced individually, so please adjust the concepts accordingly.

## ETM Represents a Paradigm Shift
ETM employs an **exploratory approach**. This is markedly different from the conventional way of thinking, so let’s begin by examining the traditional method.

Traditionally, task management is **directional**—as mentioned at the outset, you set criteria first and then act in accordance with them. This approach is intuitive, straightforward, and easy to manage, which is why it is widely used in both business and personal contexts. It is so ubiquitous that it often goes unnamed. However, for the sake of discussion, we have chosen to call it “directional” (a so-called [retronym](https://ja.wikipedia.org/wiki/%E3%83%AC%E3%83%88%E3%83%AD%E3%83%8B%E3%83%A0%E4%B8%80%E8%A6%A7)).

The directional approach has two inherent structural flaws.

The first flaw is the lack of “play.” Once you commit to a set of criteria, you allow nothing beyond them. There is no room for flexibility, leisure, or improvisation. In practice, criteria are often treated as mere guidelines to allow some flexibility, but the fact remains that you cannot escape being bound by them. While criteria are useful in contexts where they are needed, they can be overly restrictive in others. Yet, because the directional approach is the only method many people know, they force themselves to set criteria and justify this as simply “how things are done.” Nowadays, due to management requirements or company rules that enshrine such methods, it is very hard to even conceive of an alternative.

What is the problem with the lack of play? Primarily, it limits flexibility. Even if there are, say, 20 possible methods to try, a directional approach might only allow a few of them. Even if trying all 20 isn’t feasible, you simply can’t experiment with a wide variety of approaches. This stifles individual creativity and makes it hard for people to act autonomously. In the end, it reduces to a model where everyone simply follows orders under someone’s supervision. While this might be effective for making progress—and if the manager is sufficiently competent, some flexibility might be allowed—such competent managers are rare. Typically, the manager becomes a bottleneck, and overall flexibility is greatly reduced. In extreme cases, the situation becomes a one-man show or something very close to it.

Moreover, even if you have a competent “one-man” manager, those who follow the orders do not enjoy themselves. Excessive management (micromanagement) is particularly terrible: it forces continuity either by instilling fear (a kind of terror management), offering primitive rewards such as income or status, or even by inducing a kind of religious zeal (which I refer to as “koe”). Without such motivators, people will not persist; some will even collapse from stress or overwork. When we talk about excessive management, we often think of constant surveillance or strict rules, but even without those, simply being overburdened can have the same effect. In reality, nearly all overly busy people rely on some combination of sticks, carrots, or buzzwords to justify the system—they become dependent on these “carrots.”

The second flaw is that the pace of trial and error is slow. A directional approach tends to firmly establish criteria, and once they are set, they are difficult to change. Moreover, because the roles of setting/managing the criteria and following them are divided, there is a high communication cost in conveying feedback from one group to the other. When working in groups or even individually with medium- to long-term goals, criteria are indeed important (without them, your activities can become erratic), but this very necessity slows down the pace of experimentation. Even though there are methods to accelerate hypothesis testing—such as lean startup and agile development—these too remain within the realm of a directional approach.

In summary, the directional approach has the following flaws (*1):

- **Lack of Play**
  - Inflexibility: the established criteria and the presence of a manager enforcing them become a bottleneck.
  - Dependency on “carrots”: a one-man approach is unenjoyable and stressful.
- **Slow Pace of Trial and Error**
  - The separation between those who set criteria and those who follow them incurs high communication costs.
  - It is inherently unsuitable for situations where the future is uncertain.
  - Although methods to speed up hypothesis testing exist, they still operate within a directional framework.

Please note that this does not imply that the directional approach is unnecessary. It is extremely useful (indeed, one could manage life solely with it), but due to the aforementioned limitations, another tool is needed. That tool is the **exploratory approach**.

Since this book is about task management, we will integrate these ideas with task management—this is what ETM is about. It is a method of task management that introduces play and aims to accelerate the pace of trial and error.

- *Note:*
  - (*1) There is an additional flaw that has not been detailed because it is ancillary: the “management cost.” Even if you have 100 units of resources, you might end up spending 10–20 on management alone. As is well known, managers are necessary precisely because management incurs significant costs. And having a manager also means additional communication costs. In reality, it is not uncommon for as much as half of your resources—say, 50—to be consumed this way. With an exploratory approach, you can eliminate this management cost (including the communication cost, of course). You don’t need a manager. If you have 100 resources available, you might end up using around 90. Still, some degree of support and exchange is necessary, so you can never use the full 100.

## The Merits: Freedom and Enjoyment
The merits of ETM are freedom and enjoyment.

Without any predetermined criteria to follow, everyone is free to explore as they wish. This freedom generates power.

In particular, freedom is fun. Adopting an exploratory approach makes you realize just how constrained you are by rigid criteria. This realization is creative and is reminiscent of the process of crafting a story. Conversely, those who do not find enjoyment in such unfettered exploration might not be well suited to ETM—they might prefer a directional approach where strict criteria are set and followed with full force. Although “fun” might sound somewhat trivial, it is important (*1). As repeatedly noted in this book, we are inherently lazy creatures. We are so prone to laziness that we either need task management or are unable to rely on it at all. That is why fun is such a valuable source of motivation. Just as children wander around aimlessly and play with toys for the sheer joy of it, there is a fundamental pleasure in exploration.

Another significant benefit born from freedom is the sense of ownership and satisfaction. It is often said that freedom comes with responsibility, and indeed, you are responsible for deciding what to delve into, in what order, and to what extent. This continuous process of decision-making can be quite exhausting (which is why techniques to ease this burden in ETM are important), but it also gives you the undeniable feeling that “you did it all yourself.” In other words, you gain a strong sense of personal investment. Because you are directly involved, even if the results are not outstanding or are imperfect, you still derive a deep sense of satisfaction.

There may be other forms of empowerment through freedom, but the primary ones are enjoyment and the sense of ownership/satisfaction. These benefits help to compensate for the “lack of play” that is a flaw in the directional approach.

## The Objective: To Broaden Your Perspective
The objective of ETM is simple and clear: to broaden your perspective.

In modern times, it is common to encounter situations where there is neither a clear answer nor any concrete examples to follow—in some cases, you might not even know what it is that you don’t know. By using ETM, you can illuminate that darkness in your own way. Although “your way” may not be the objectively correct one, it at least provides you with a semblance of clarity. And once you see the way forward, you can act on it—in fact, once things become clear, you can revert to the usual directional approach and tackle things step by step.

However, a solely directional approach is insufficient in such uncertain scenarios. That is precisely why ETM is employed: to explore first and broaden your perspective.

## The Applicable Scenario: Unknown Unknowns
ETM is particularly well suited for situations where you can truly say “I don’t know anything.” It is not so much that the constraints are so tight you can do nothing, but rather that the lack of information leaves you clueless—or, conversely, that the constraints are so loose that anything seems possible. In particular, the state of “not even knowing what you don’t know” (the Unknown Unknown) is common, and this is exactly where ETM shines.

By exploring freely with ETM, you gradually illuminate your surroundings. As your perspective expands, you start noticing more details and can generate and recognize new ideas. Eventually, you will reach a point where “most of it is clear.” At that stage, you can then switch to the traditional directional approach and task management to handle the rest.

It may sound obvious when explained in words, but the initial phase of exploring to broaden your perspective is challenging. ETM is one methodology designed specifically to address that phase.

## The History of ETM
Since ETM is a proposal by the author, it has no historical background.

There are many influences behind it. In particular, ETM draws heavily on note-taking methods used in [Literate Task Management](literate) as well as on ideas from intellectual production (see *1), such as brainstorming. Of course, since ETM is also about task management, it incorporates aspects of that field too—but as mentioned earlier, because it does not adhere to a directional approach, its method of “management” differs.

- *Note:*
  - (*1) The term “intellectual production” is polysemous, but here it is based particularly on the book *[The Art of Intellectual Production](ref#26)*. To quote: “Simply put, intellectual production is the process of using your mind to create something new—information—that is presented in a form understandable to others.” I interpret it as the act of creating new information (knowledge or insights) in your own way and organizing it so that others can understand it. The key points are that it is original to you, new for you, and verbalized in a way that others can grasp.

## The Metaphor: Exploring Dungeons or Landscapes
So, what are the concepts and methods of ETM? How does one actually manage tasks using this approach?

The idea is akin to exploring a dungeon or an unfamiliar landscape and collecting items along the way. You explore this vast, uncertain territory in your own way, gradually mapping it out so you don’t get lost later. Ideally, you would want to completely conquer it, but you never know how vast it is—and issues like fatigue, motivation, and your own capabilities (HP, attack power, magic, equipment, etc.) come into play. Moreover, to extend the metaphor, even the dungeon or terrain might change over time, so there is no definitive end. At some point, you decide to call it a day. The items you collect become your loot, which you can then use to tackle the next dungeon or area where a directional approach applies.

How far you go is entirely up to you, but there are two key points to keep in mind. First, as stated at the beginning, always adhere to the principle of No ABCD. Even during exploration, you will have some self-management, but you won’t engage in the rigid management implied by ABCD. Second, aim to give it your all—strive to reach as close to 100% as possible so that you can confidently say, “This is the best I can do at this moment.” It might sound extreme, but the idea is simply to articulate in your own words, “Well, this is as good as it gets.”

As for the practical methods: you decide on a plan for where and how to explore, how to map out your journey, monitor your own status, and manage factors such as fatigue, motivation, and other resources. ETM is still a form of task management—it just manages things in a different way. Essentially, you use a notebook as your primary tool and write things down in words (rather than drawing diagrams or pictures). You might review what you’ve written to expand upon it, or, if you find something unnecessary, discard it entirely and start anew. This aspect is very much in line with literate task management.

# Getting Started with ETM Part 1 – Understanding Information Units

In this part, we introduce the units of information that will be used in ETM (Exploratory Task Management).

## The Units That Appear

- Goal
- Card
- Topic
- Block

### The Relationships Among the Units

![](/images/taskmanagement-kamikudaku/etm_cardmodel.png)

**Explanation:**

- In ETM, you collect **cards** to derive a **goal**.
  - A **goal** is “what becomes visible.”
  - A **card** is a “topic that is useful for deriving a goal.”
- In ETM, you create **topics**.
  - A **topic** is a unit that represents a single subject.
  - Each topic is expressed in its own note.
  - There is no one correct way to express a topic.
- A topic is composed of **blocks**.
  - A **block** is a chunk of information grouped by a certain perspective.
  - A topic is composed of _n_ blocks.
    - They are not necessarily derived in a strictly logical manner.
    - Sometimes you may derive a topic from blocks (bottom-up), and other times you may list out blocks based on a predetermined topic (top-down).

## Increasing Your Hand of Cards

Another way to state the purpose of ETM is as follows:

> “To expand the hand of cards that will lead to what becomes visible.”

A **card** represents a single piece of knowledge, a viewpoint, a decision, an idea, or a hypothesis. Sometimes it is enough simply to understand and import knowledge from an information source (input), but that is usually insufficient. You typically need to process it further—by combining different pieces to create new knowledge or by settling on one interpretation among many—and so some transformation is required.

There is no single correct answer regarding the granularity of a card (i.e. how much should be grouped into one card) or the number of cards to have, but generally cards are best if they are fine-grained and it is not unusual for the total number of cards to be in the hundreds.

In other words, you are “assembling the parts” or “building up from the bottom” much like the Linux KISS (“Keep It Simple, Stupid”) principle, which advocates combining small, versatile tools. (The difference is that cards are not necessarily designed to be general-purpose.)

## What Is a Goal? – “What Has Become Visible”

Once you have collected cards, what do you do with them? You want to derive something from them—and that something is what we call a **goal**.

A goal is not something that is already visible beforehand, nor is it something you preset as a hypothesis. It is something that naturally “becomes visible” as you collect cards. Alternatively, it may be teased out with persistence. If you are used to a directional approach, this idea may be hard to grasp, but please understand that this is how it is meant to be.

In other words, you could say that **the goal that becomes visible depends on which cards you use**; or that **even with the same cards, different people may see different goals**; or even that **the same cards may yield different goals for the same person at different times.** On the other hand, even if the cards or the people are different, often a similar goal appears. The point is, the goal is inherently indeterminate.

Moreover, there isn’t necessarily only one goal. From 30 cards you might derive a single goal, or you might derive six goals.

## What Is a Card? – “A Particularly Useful Topic”

Cards and topics are essentially the same thing; however, a card is a topic that is particularly useful—that is, one that can be used repeatedly or by many people.

Even though you might create many topics, some will be useful and others less so. If you were to treat every topic as a card, you would end up with a lot of “junk.” Therefore, you collect only the topics that are truly usable as cards.

## Topics and Blocks

In ETM, the actual unit that you create is the **topic**. Furthermore, a topic is composed of **blocks**. Since this is a fundamental concept in ETM, we will explain it in detail.

### Topics

A **topic** corresponds roughly to what was previously called “topic‐oriented” in [Literate Task Management](literate#ネットワークベース); it represents a single subject.

Each topic has its own note. For example, if you have 20 topics, you should have 20 separate notes (the actual unit—file or page—depends on your tool). You would not write all 20 topics in a single note; such a state does not constitute a proper topic. You need to create it so that there is one note per topic. That said, a messy note that compiles various pieces of information can itself be regarded as a topic, although such a topic may be less useful as a card. Ultimately, because your goal is to increase the number of cards for deriving a goal, you should be mindful of the idea that **each topic should represent one subject.** This is the notion behind being “topic-oriented.”

For example, suppose a venture company wants to hire several IT engineers and begins by asking, “What is an IT engineer? What kind of engineer do we need?” In this case, you want to think about what an IT engineer is. The following could all become topics:

- “IT Engineer”
- “What is an IT Engineer?”
- “IT Engineer = Systems, Software, Networks, Infrastructure, Site Reliability”
- “IT Engineer ≒ Systems, Software, Networks, Infrastructure, Site Reliability”

Topics such as “IT Engineer” or “What is an IT Engineer?” are not particularly good topics by themselves—they are merely terms and are less useful as cards. If you open a note titled “IT Engineer” or “What is an IT Engineer?”, you might find various definitions and opinions written inside. They might be scattered like a messy desk. Alternatively, if you restrict it to merely the definition, that is acceptable.

On the other hand, “IT Engineer = Systems, Software, Networks, Infrastructure, Site Reliability” is succinctly stated and expresses understanding clearly—this is a good topic. In fact, using a symbol like “≈” (approximately equal) shows that the definition is not meant to be overly strict.

In practice, both abstract and concrete topics appear. For example, you might create a note for “IT Engineer” and then later extract a portion (a process known as [cutting out](literate#切り出し)) to form a note titled “IT Engineer ≒ Systems, Software, Networks, Infrastructure, Site Reliability.” There will be abstract topics as well as specific ones; you may start by jotting down a messy, unsorted topic and later distill its essence into a clean, neat topic.

### Blocks

A **block** is a component that exists within a topic. In terms of their relationship, it is one topic containing many blocks (1-topic → N-blocks).

Because the relationship between topics and blocks can be unclear, here are a few points:

- **They Are Not Necessarily Logical**
  - Even if a topic contains four blocks, it does not necessarily mean that the topic is logically derived from those four blocks. Some blocks may be used while others may not.
  - There is no single way of grouping them. The same four blocks might lead person A and person B to derive different topics.
- **Both Bottom-Up and Top-Down Approaches Are Possible**
  - *Bottom-Up:* Deriving a topic from _n_ blocks.
  - *Top-Down:* Extracting _n_ blocks from a given topic.
  - In ETM, both approaches are possible. It is easy to see the bottom-up approach when deriving a goal from cards, but the top-down approach is also possible. A common top-down method is to set a theme as the topic and then write down whatever comes to mind. This occurs often in idea generation.

Now, regarding blocks: They are not simply the raw contents written into a topic. Just having text in a note does not mean that blocks are present. A block is a chunk—a group of information that has been consolidated based on a particular viewpoint. The way you group them may be rough, but you must consolidate the information. Ultimately, you want to have the structure “a topic is composed of _n_ blocks.”

ETM encourages you to think in terms of components. You use cards as components to derive a goal, and you handle information in daily reading and writing by dealing with topics as units. And topics themselves are composed of blocks. By thinking of things as components, you can more easily combine them, discard unnecessary parts, etc.

Also, there is no one correct way to form blocks. That said, there are several relatively user-friendly methods that we will introduce later.

For example, take the earlier “IT Engineer ≒ Systems, Software, Networks, Infrastructure, Site Reliability” topic. It might contain blocks such as:

- An excerpt of a definition from a dictionary.
- Person A’s initial impression.
- Person B’s initial impression.
- A log of a discussion between Person A and Person B.
- A list of examples of engineers compiled by everyone (listing “Systems,” “Software,” etc.).
- “What is a Systems Engineer?”
- “What is a Staff Engineer?” etc.

After writing several blocks like these, you might decide, “There are five types of IT engineers: Systems, Software, Network, Infrastructure, and SRE (Site Reliability Engineer).” That decision becomes the topic, and when expressed in a note, it might be titled “IT Engineer = Systems, Software, Networks, Infrastructure, Site Reliability.” Of course, depending on how you decide, you might exclude certain roles—for example, not including Staff Engineer. Alternatively, you might split the original “IT Engineer” note into “Traditional IT Engineer” and “Modern IT Engineer,” with the latter including Staff Engineer. This is just one example; there are countless possible methods.

### A Card Is “A Particularly Useful Topic”

Cards and topics are essentially synonymous; however, a card emphasizes usability—that is, its ability to be used, especially repeatedly or by multiple people.

...
