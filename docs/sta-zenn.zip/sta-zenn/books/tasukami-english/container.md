---
title: Container
---

# Overview of Containers

## Overview
A **Container** is something that categorizes tasks, or it can refer to an individual element within a classification.

Just as we sort documents into clear file folders, books onto bookshelves or dividers, and computer files into folders, tasks too can be organized into various classifications. It’s less about physically separating items and more about logically distinguishing them by meaning.

Also, while classification might evoke the idea of strict, precise divisions, that isn’t always necessary. In fact, task management is about designing a classification system that fits the individual or organization, so rough categorizations are often perfectly acceptable.

## Examples of Containers
In task management, containers go by many names, and their usage can vary depending on the tool, method, or the person. Common names include:

- Folder
- Category
- Group
- Tag
- Label
- Workspace
- Project

Some of these terms may sound intimidating, but in the end, they’re simply ways to classify (at least tasks). The detailed meanings of each term will be discussed later.

## Rich Containers
There are containers that serve solely to classify tasks, and there are those that, in addition to classification, also include other information or functions. Let’s call the latter **Rich Containers**. When we specifically refer to the former, we can call them **Plain Containers**.

Based on my intuitive sense, the common container names above can generally be divided as follows:

- **Plain Containers**
    - Folder
    - Category
    - Tag
- **Rich Containers**
    - Group
    - Label
    - Workspace
    - Project

Folders and categories are clear examples of plain containers.

On the other hand, larger units such as workspaces or groups not only classify tasks but also contain additional information (like member details or uploaded files). Labels, which are essentially colored tags, include the extra attribute of color and are thus treated as rich containers.

## Box Model and Connection Model
When we think of a container, we often picture a “box” into which something is placed—but that’s not the only way to think about it.

Besides the worldview of putting things into a box (the **box model**), there is also the perspective of linking or connecting things (the **connection model**). Folders and categories tend to belong to the former, whereas tags and labels are more often examples of the latter.

![](/images/taskmanagement-kamikudaku/hako_setsuzoku.png)

The box model implies that an item can be placed in only one box at a time. It guarantees that every item is in exactly one container (if it isn’t in any container, it can’t be found), which is simple, but as you get more particular, it can become difficult to maintain consistency. Problems such as “this item fits both categories, so which one should it go into?” are common (see note 1).

In contrast, the connection model works by affixing markers to items. In the diagram above, a marker indicates ownership. Because you’re merely attaching a marker, one classification (in this case “Who”) can be applied to multiple items, and a single item can have markers from different classification categories (such as “boku” and “watashi”). Although the connection model is more flexible than the box model, overusing it can render the markers meaningless.

- ※  
    - 1 This is often referred to as the “bat problem.” Since bats are mammals, they could be classified as animals, but because they have wings, they might also be classified as birds—so which is it? Eliminating the bat problem is generally very difficult. Systems like the Dewey Decimal Classification in libraries took experts a long time to create, and even then the resulting classification is complex and challenging to manage. In personal task management, it’s unlikely that one could establish such a comprehensive system. I couldn’t, and frankly, I believe it’s beyond what humanity can reasonably attempt. Of course, this applies only when you become overly fixated on classification. For casual categorization, even a single “dump everything here” container is acceptable—and often more practical than no classification at all. Still, done carelessly it can also lead to confusion.

# How to Handle Containers

## Do Not Treat Containers as Tasks
First and foremost, containers should not be treated as tasks.

Even if you try to treat them as tasks, it almost never works out. Containers are about classification, and because classification is coarse-grained, it often isn’t clear what specific actions to take, or you may feel paralyzed by having to do everything at once. In contrast, tasks are fine-grained, with clear actions that can be managed effectively.

## Granularity
The term **granularity** refers to the level of detail. You often hear advice like “break vague tasks down into more specific actions” or “divide large tasks into medium or small tasks.” This is essentially saying that coarse-grained items should be refined into finer details because if something is too broad, it becomes difficult to understand or act upon.

In other words, you can think of a **container as a coarse-grained task**. However, because it’s coarse, it is hard to treat directly as a task—hence its role as a means of classification.

## Four Ways to Handle Containers
How should one handle containers? There are essentially four approaches:

1. **Use the tool’s container functionality exactly as prescribed.**
2. **Use the tool’s container functionality, but in your own customized way.**
3. **Don’t use the tool’s container functionality at all, but still use some form of container.**
4. **Don’t use any container at all.**

The higher the number, the fewer the constraints. In practice, most people tend to follow option 2. Tools often come with built-in features like categories, folders, and tags, but what kinds of categories, folders, or tags to create is up to you. While default options may be provided as a starting point, it’s usually best to modify or even remove them in favor of your own system.

The most restrictive option, 1, is rarely seen. One example would be [GTD](ref#gtd). Although GTD is a method rather than a tool, it defines specific containers—like the inbox, project, someday/maybe, waiting for, and next actions—with precise rules for their use. Users must study and adhere strictly to these guidelines; if you decide on your own to skip some containers or add new ones, you won’t achieve the full benefits of GTD (see note 1).

If you already have a clear idea of how containers should function, you’ll likely fall into option 3. That is, you won’t use the tool’s built-in functionality but instead manage your containers independently. For example, if you primarily rely on your calendar, you might add tasks directly to your calendar even if you use another tool for task management. In that case, you are still using a container—the calendar, which classifies tasks by day or week—even though you’re not using the tool’s specific container features.

Of course, some people don’t want to classify things at all—in which case they’d choose option 4. However, even those people tend to use at least a rough classification. In the strategy section, we discussed the idea of [gathering everything in one place](strategy#一箇所にまとめる), which can be seen as creating one container into which everything is dumped. In that sense, it’s a variant of option 3.

- ※  
    - 1 As an aside, in software development there is a saying “convention over configuration.” Typically, tools are designed to be generic and let developers decide how to use them through many settings. Conversely, some tools take a more prescriptive approach: “There is no room for customization—use this tool exactly as I’ve designed it. Learn the method, and it will serve you well.” Option 1 is like that: no room for customization, just follow the prescribed method.

## Is It a Task or a Container?
How do you distinguish between a task and a container?

Ultimately, it depends on the individual and how one perceives granularity.

Here’s one way I personally make the distinction: A task is something specific, actionable, that can be completed within a few days once started, and whose completion is clearly verifiable. Anything broader than that is a container—a unit that groups multiple tasks. For example, “moving house” would likely be a container rather than a single task. The tasks might include “create an overall schedule,” “list moving companies,” “request quotes from each moving company,” “compare all quotes and decide on one,” etc. Some people might break it down even further; in my case, I break it down into tasks like “Request quote from Company A” and “Request quote from Company B.”

Below is a hierarchical outline using bullet points. I use 📦 for containers, 📝 for tasks, and ❓ for items that are ambiguous.

- 📦 Moving House
    - ❓ Scheduling
        - 📝 Try it out
    - 📦 Selecting a Moving Company
        - 📝 Create a list
        - 📝 Request quote from Company A
        - 📝 Request quote from Company B
        - …
        - 📝 Make a decision
    - 📦 Packing
        - ❓ Closet-related items
            - 📝 Try it out
        - …
    - 📦 Disposal
        - …
    - 📦 Finding a New Home
        - …

This is just my personal system. I tend to break everything down into very detailed tasks because I’m not great at processing things mentally. The items marked with ❓ indicate that while they seem simple at first glance, I suspect that breaking them down further will reveal additional tasks. In such cases, I label them as uncertain (❓) and create a “try it out” task.

Similarly, when you want to classify tasks by attributes or properties, that classification itself becomes a container. For example, if you want to tag tasks that you perform at your home desk as “research,” then “research” should be implemented as a tag rather than as a task. Managing a “research” task won’t help you effectively manage all research-related tasks, but using a tag allows you to filter and follow them—provided you consistently tag the relevant tasks.

The key point is to **immediately place (or tag) a task into its appropriate container as soon as you recognize it as a task.** Doing this later in batches tends to be inefficient and often leads to neglect. This doesn’t mean you need to sort every notification as it arrives; rather, set aside specific times (for example, morning, noon, and evening) to process and sort items all at once.

This careful sorting of tasks versus information is a deep topic. For information, which is usually far more abundant, the key is to streamline the process so that you can quickly extract and process just the task-related elements. In email management, for example, tools like [HEY](https://www.hey.com/) have been developed with enhanced sorting mechanisms specifically for this purpose.

# On Classification
A container is essentially a means to classify tasks. But what exactly is classification?

Let’s examine the general concept of classification—with some reflections on task management.

## Benefits of Classification
**The benefit of classification is cost reduction.** Specifically, it reduces both the cost of searching for items and the cost of switching contexts.

For searching, think of a library where items are grouped by category so that you know exactly where to look for something. If you know that items related to “Topic A” are in Category A, it’s much easier to find what you need. While one might imagine that classification must be strict and meticulous, even a rough classification—such as putting everything into one box—can be effective.

Regarding context switching, it’s about reducing the mental effort needed to switch gears. Keeping similar items together allows you to maintain a consistent “mindset.” Conversely, if unrelated items are mixed together, switching contexts can become mentally exhausting. In extreme cases, think of the difficulty of a remote manager trying to be strict with employees while also playing the role of a nurturing parent during the same meeting. Typically, both roles require separate time blocks and breaks in between. While fiction sometimes portrays characters who switch contexts instantly, that isn’t realistic.

## The Subjects and Methods of Classification Vary
Even though the benefits of classification may seem obvious, in task management it’s often an overlooked aspect. In fact, there is a surprisingly wide scope for applying classification creatively.

We’ve already mentioned that classification can be rough and that it helps in mentally compartmentalizing tasks. While many people might think of classification simply as dividing tasks into “work,” “home,” and “hobbies,” there are many other ways to categorize. Both what you classify (the subject) and where you classify it (the destination or category) can vary widely.

## Create Your Own Classification
Classification is not something handed down by a higher authority—you create your own classifications every day in life.

Task management is similar: you often end up devising your own classification system. Of course, there are tried-and-true examples and patterns you can reference to help guide you, but ultimately it’s most important to develop a system that works for you.

Conversely, if you’re not interested in creating your own classification or following a set system, a rough, minimal classification is perfectly acceptable. Although many tools and methods emphasize hierarchical organization, you don’t have to conform strictly to these ideas. (Incidentally, [Scrapbox](ref#scrapbox) is an example of a tool that eschews hierarchical organization—instead, it uses links to connect pages much like the network structure of the human brain. I personally have over 23,000 pages on Scrapbox and it has continued to work perfectly. I was so impressed by this approach that I even wrote a guide to Scrapbox [Scrapbox’s Guide](ref#17).)

# Examples and Nuances of Containers

We have mentioned several container types such as projects and folders; here, I will summarize their general nuances.

## Folder
A **Folder** is a concept primarily used to organize files or notes, but it also appears in task management.

For example, in [Wrike](https://help.wrike.com/hc/ja/articles/1500005120861-Wrike%E3%81%AE%E3%83%95%E3%82%A9%E3%83%AB%E3%83%80%E3%83%BC), it is stated:

> Adding tasks to a folder brings related information together in one place. It also helps construct the organizational structure of the workspace, making information easier to search for and share. Folders differ from tasks or projects in that they are not actionable items. Additionally, folders themselves do not have a set of attributes. They are used on a smaller, more detailed level than spaces that cover entire teams or departments.

Although the term “folder” might evoke a box model, it is actually more akin to the connection model. For instance, if you have a task such as “find a new home for moving,” you might place it in both a “Moving” folder and a “Things to Do in Downtime” folder. Essentially, it works much like attaching multiple tags such as “Moving” and “Downtime.” The reason for using the term “folder” is to imply a hierarchical structure. Many systems even refer to [subfolders](https://help.wrike.com/hc/ja/articles/209603649-%E3%82%B5%E3%83%96%E3%83%95%E3%82%A9%E3%83%AB%E3%83%80%E3%83%BC%E3%81%AE%E4%BD%9C%E6%88%90), and ultimately it becomes equivalent to a tag.

Thus, you can think of the word “folder” as implying a hierarchical method of classification.

## Category
A **Category** is another common term used as a container. Literally, it means “a classification, class, or type.”

The nuance here is that it follows the box model. If a task is placed in Category A, it cannot simultaneously belong to Category B (or if it does, it must be removed from A). It is designed for strict one-to-one classification. Like folders, categories can have a hierarchical structure, though sometimes they do not.

## Group
A **Group** generally conveys the idea of bundling people together. In task management, you might sometimes hear the term “task group,” though there aren’t many examples. [Yahoo! Calendar](https://support.yahoo-net.jp/PccCalendar/s/article/H000005660) is one instance where this concept is used.

In terms of meaning, it is largely synonymous with “category.” In other words, it adheres more to the box model rather than the connection model.

## Tag
A **Tag** is another common container. The literal meaning of tag is “a label,” and tags are used to indicate that a task possesses a certain attribute or property (e.g., property A).

The model here is the connection model, which allows one task to have multiple tags. Because it’s easy to create many tags, careless usage can quickly result in tens or even hundreds of tags. Managing such an excess can be nearly impossible, often leading to them becoming meaningless—or in the best case, only a few frequently used tags remain.

In digital tools, hashtags (such as those on X, formerly known as Twitter) are a very common example. Here, a tag not only classifies but also publicly signals the nature of a post. For example, if a post contains `#TaskManagement`, it’s essentially declaring that the post is about task management, making it searchable.

Thus, it might be more helpful to think of tags as a means of expressing attributes rather than as strict classifications.

## Label
A **Label** is essentially equivalent to a tag, but typically comes with the option to assign a color.

For example, in [GitHub Issues](ref#github-issues), you can attach labels to issues (which serve as tasks), where each label has both a name and a color. This allows you to highlight important labels in red or denote discontinued or paused tasks in gray, thereby enhancing visibility. However, overusing labels can clutter the interface.

## Project
**Project** is perhaps the most multifaceted term in task management.

Broadly speaking, it refers to a collection of tasks that is not immediately finished and represents a well-defined series of activities. In everyday life, “moving house” is a prime example of what might be considered a project. In a business context, however, projects can be quite expansive. For instance, a major initiative that spans several years could also be termed a project.

Some methods or frameworks impose additional constraints. For example, in PMBOK the definition of a project includes being temporary (not ongoing indefinitely) and producing unique outcomes, meaning that routine, continuous operations wouldn’t be classified as projects. While GTD also uses the term project, its definition differs significantly from that of PMBOK.

So, for task management, it’s often simplest to think of a project as just an “activity” or “endeavor.” However, certain tools (and their underlying methods or frameworks) might imply additional nuances. For instance, a tool designed for small-scale projects might not handle large projects well. Knowing these limitations can help set realistic expectations.

## Workspace
A **Workspace** is akin to a work area or environment and is a typical example of a rich container. That is, it not only groups tasks together but also aggregates various other types of information. It literally represents a “place,” and it’s common for people to gather in a workspace during work hours.

Even with regard to tasks, rather than attaching tasks directly to the workspace, they are usually organized within another container. For example:

- Workspace
    - Project
        - Task
        - Task
        - …

# Various Classification Targets and Items

Earlier, I mentioned that both the subjects of classification and the methods used can vary widely. Here are some examples of commonly used classifications as containers.

## Large, Medium, and Small Tasks
It’s common to break down a large task into smaller tasks. As mentioned in the moving example, the degree of breakdown is flexible, but it’s generally best not to have too many levels—three tiers or at most four is ideal—to keep the overall picture clear. A three-tier (large, medium, small) structure is often easiest to understand. Many books also organize their contents hierarchically (e.g., chapters, sections, subsections). The [PARA Method](ref#paraメソッド) even emphasizes note-taking tools that support up to four levels (referred to as “4 Based”), citing various studies including those on human working memory.

Whether you use three or four levels, the key in a hierarchical system is to maintain a consistent meaning at each level. For example, you might define small tasks as concrete actions that can be completed within a day, medium tasks as collections of small tasks that represent a specific goal, and large tasks as collections of medium tasks that indicate a general direction. This way, it’s easier to decide which small tasks fulfill a medium task and which medium tasks contribute to a large task.

## Sorting Tasks and Information
A clear example is email: you sort incoming messages into various folders. Most emails are informational, but occasionally a task is embedded within an email. For emails that represent tasks, you might create a dedicated “Task” folder (following the box model) or, alternatively, you might not file them but rather tag or mark them (following the connection model).

Since tasks are typically fewer in number than general information, it makes sense to treat task-related emails as a special category. Whether you prefer the box model or the connection model is entirely up to you. Some people find the box model works best, while others thrive by simply tagging items. The key is to experiment and see which method suits you best.

The most important point is to **immediately place the item into its appropriate container (or tag it) as soon as you recognize it as a task.** Waiting to do this in batches is inefficient and often leads to neglect. For instance, in email management, rather than sorting every message as it comes in, you might designate specific times (such as morning, noon, and evening) to sort through everything at once.

## Context Tags
I refer to these as **Context Tags**—tags that you attach to tasks to indicate when they can be executed or what kind of task they are.

For example, tasks that can be done during your commute (say, on a train or bus) might be tagged with “Commuting.” Then, when you’re on the train using your smartphone, you can view the list of tasks under the “Commuting” tag. Another simple example is an “Read Later” tag. More specific examples might include tags like “when spouse is away” or “when the boss is present.” For busy people with many interpersonal interactions, these context tags can be very useful for managing tasks during available pockets of time.

## Section
As mentioned briefly in the strategy section (strategy#概要-2), I refer to periods of time as **Sections**. People tend to have certain activities they perform during specific times of the day, so thinking of these periods as containers can help you decide which tasks belong to which time segments.

In my own routine, I know that I’m most productive and creative in the morning, so I allocate my most important tasks to that section. In fact, I divide my day into three sections: “1: From waking up until leaving home,” “2: After arriving at work but before everyone else gets there,” and “3: The remainder of the morning once everyone has arrived.” I reserve Section 1 for the tasks I most want to tackle, Section 2 for focused work tasks, and Section 3 for handling interruptions or meetings.

## The PAPIPUPEPO of Containers
The “PAPIPUPEPO” of containers is a mnemonic to help organize common uses of containers:

| One Character | Kana            | English      | Meaning |
| ------------- | --------------- | ------------ | ------- |
| パ            | パーパス        | Purpose      | The objective or goal. Corresponds to large or medium tasks. |
| ピ            | ピープル        | People       | People. Who should be responsible for what or be informed about what. |
| プ            | プレイグラウンド  | Playground   | A space for play. A container for various ideas or things you want to try—a sort of toy box. |
| ペ            | ペンディング      | Pending      | Pending items. Tasks that are on hold due to certain circumstances (similar to GTD’s “Waiting For”). |
| ポ            | ポスト          | Post         | An inbox/outbox. A temporary holding area for incoming items or drafts that are to be sent out (e.g., posts, submissions). |

While some of these—like Purpose, Post, or Pending—are for serious matters, others like Playground might appear more casual.

The “People” element might feel a bit forced, but it involves considering people as containers—for instance, deciding who should handle which task or who should be informed. Although people are not tools and therefore introduce some uncertainty, they’re often easier to remember and more relatable than abstract tools. I refer to this as “Communication 1.0,” meaning that people naturally think in terms of specific individuals. From an information-sharing perspective, it’s important that information is visible to everyone, but many struggle with this because the Communication 1.0 mindset isn’t well suited for it. Therefore, you might as well think of it in terms of “who needs to be told what,” or if you prefer using a tool, create a tag (e.g., “Person A”) and attach it to tasks that involve that individual. For those used to Communication 1.0, the People container may actually be quite intuitive.

In short, there is no one “right” way to handle containers—whether you prefer a serious or casual, strict or loose approach, choose the method that works best for you.

# Summary
- A container is something that categorizes tasks, or the result of such categorization.
- Essentially, it’s based on the concept of classification, but in the context of task management it has additional nuances:
  - There are containers that classify only tasks and rich containers that also include other information.
  - There is the box model (placing items into a container) and the connection model (attaching properties).
  - The distinction between “Is this a task or a container?” depends on the individual and the situation—there is no absolute answer.
  - You are free to create your own classification system, even a rough one.
- There are many established terms and examples that can serve as inspiration:
  - Terms such as Folder, Category, and Project.
  - Concepts like Context Tags and Sections.
  - The PAPIPUPEPO of Containers.
