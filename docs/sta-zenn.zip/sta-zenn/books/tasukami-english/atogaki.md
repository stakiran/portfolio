---
title: Afterword
---

I have long wanted to systematize task management. Not in the sense of project management or teamwork tools, but rather to neatly organize the various elements that help an individual manage their own tasks. Since I believe that task management—especially personal task management—is inherently a personal matter, a genuine systematization might be challenging. However, the current state is far too disorganized and, above all, scarcely used at all. After all, it was merely a hobby, and I had intended it as such. People are free to work and live as they please, so it really doesn’t matter—but lately I can no longer remain indifferent.

The pandemic accelerated remote work, yet now that things have settled down, society is once again returning to the office. We increasingly see hybrid work arrangements—where one might go in _n_ times a week—and I was taken aback by articles like [“Remote Work: ‘The Worst Mistake’? Former Google CEOs Weigh In”](https://xtech.nikkei.com/atcl/nxt/column/18/01111/090400058/). For a long time, I kept thinking to myself, “No, that’s not it. That isn’t right.”

Audrey Tang once said, [“Broadband is a human right”](https://www.youtube.com/watch?v=O89cDhGfXAg&t=196s), but I want to proclaim that “Remote work is a human right.” Thanks to remote work, we have been liberated from constraints—such as commuting—and individual lifestyles are now respected. Of course, this does not apply in every case, but its feasibility has been clearly demonstrated. Respect for one’s personal life has become a new standard. Once this standard has been raised, it cannot—and should not—be lowered. And yet, as we return to the office, that very standard is in danger of being eroded...

Given my interest in studying work methodologies, I have been making a modest effort to resist this trend. I am not trying to impose an extreme ideology that insists we must always work remotely. Rather, I want both the office-goers and the remote workers to coexist. I wish to establish remote work as one among a diverse array of choices. Currently, the former is dominating. Even hybrid work, which might have you in the office _n_ times a week, is, in effect, being imposed on us. I used to believe that if someone truly wanted full remote work, they should be able to have it—after all, technology is sufficiently advanced. But I have come to realize that the road ahead is far steeper than I had imagined.

What I have come to understand anew is that technology alone is not enough. With each passing day, it has become ever clearer that, alongside technology (the tools), a methodology (an approach) is also needed. In the realm of remote work, for example, the ability to autonomously document and share information has become an essential literacy—and yet, only a small minority possess it. Perhaps with further technological advances, we could overcome this without such literacy, but that day still seems far off. That I am even able to discuss these issues is simply because I have devoted time to studying them. In reality, we are dealing with “Unknown Unknowns” (we don’t even know what we don’t know), and the fact that human beings are inherently social creatures—wired to crave face-to-face interaction and non-verbal cues—only adds to the challenge. To overcome these hurdles, we must continue to pioneer new methodologies. I realize I’ve written at length, but one such endeavor is task management, and the writing of this book is itself part of that exploration.

That said, let’s set aside these formalities.

How did you find this book? I hope it has served as a catalyst for you to reflect on your own approach to task management. Moreover, if this book can serve as a starting point from which even more ideas are born, nothing would make me happier as an author.

<br><br>

2024/09/11  
Suta Kirano (listening to the chirping of suzumushi at home)
