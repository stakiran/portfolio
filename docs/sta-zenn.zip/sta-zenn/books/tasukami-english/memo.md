---
title: Memo
---

# Memo Overview

## Overview
A **memo** is a temporary note intended for later processing.

You may not be able to deal with something immediately, but if you do nothing, you’ll forget it—so you quickly jot it down. Of course, merely writing it down is meaningless; you must review it later. And simply reviewing it isn’t enough either—you should also follow through with the actions the memo implies. Finally, since having memos lingering indefinitely can be a nuisance, they need to be disposed of (or left alone if that’s acceptable). It may sound a bit dramatic when you put it into words, but understanding this flow is essential for managing your memos properly.

## The Flow of Memos
Below is a diagram that illustrates the flow of memos.

![memoflow](/images/taskmanagement-kamikudaku/memoflow.png)

There are three stages: **Writing → Reviewing → Action and Processing**.

When reviewing, ideally you would move on after a single pass, but that isn’t always possible. In other words, you might end up reviewing the same memo multiple times—for example, deciding, “I read it, but I didn’t quite understand, so I’ll postpone it until tomorrow.”

Regarding action and processing:  
- **Action** means engaging with the content the memo represents.  
- **Processing** refers to what you do with the memo itself (whether you discard it, delete it, leave it, etc.).  

For instance, if you have a memo titled “water bottle” because you want to buy a new one, “action” might involve searching for water bottles on Amazon and bookmarking them, heading out immediately to a nearby store, or setting a reminder to purchase one after work. “Processing” would then involve deciding whether to delete the memo or leave it. If it’s written on a sticky note, you’d likely throw it away; if it’s in a journal, you might simply leave it or strike it through.

## Memos Are Optional
What’s important in the memo flow is that sometimes you may process (i.e., dispose of) a memo without taking action, and sometimes you may take action without processing it. In other words, while it’s ideal to both act on and process a memo, it’s perfectly fine if you only manage one of these—as long as you maintain a “lucky if you can” mindset.

Memos and tasks are different. Tasks often require action, whereas memos do not. If you have a memo that absolutely must be acted on, then it should be treated as a task.

In general, you end up creating a lot of memos. People who aren’t used to it—or who don’t need them—might write very few, but once you get accustomed, the more you write, the more useful it becomes, and your memos will multiply. For instance, if you come up with an average of 10 things a day that you’d like to do later, proper memo management means you can **capture them all**—amounting to 3,650 memos in a year. Of course, you won’t take action on every single one, but you’re still handling 3,650 memos. The difference in quality of life (QoL) between someone who manages their memos and someone who doesn’t is obvious. As the number 3,650 suggests, it’s virtually impossible to process every memo meticulously. So, you must adopt a “lucky if you can” attitude rather than beating yourself up over what you couldn’t complete. Otherwise, you may feel inadequate, which isn’t good for your mental well-being. Perfectionists are especially prone to giving up—but the key is to let go of perfectionism from the start.

# How to Handle Memos
So, how should you manage your memos? And how can task management help? Let’s break down each step of the flow.

## When Writing Memos
The most important factor is speed. It’s best to start writing as quickly as possible—even if it’s just one second—and finish writing just as fast. Ideally, you want to hone your process down to fractions of a second. With that mindset, aim to capture your memos as swiftly as you can.

First, consider the tool. It might be a notebook and pen, sticky notes or paper with a pen, a memo app on your smartphone, a text editor on your PC, or some sort of web application. In digital cases, there are various input methods (flick input vs. typing, romaji vs. kana input, etc.). You might even use a voice recorder or continuously record your work process (for instance, explicitly saying “I’m going to dictate a memo now” or speaking while holding up your index finger so that you can understand it later). The optimal method depends on the person and the situation, so you’ll need to experiment to find what works best for you.

Next is the extent to which you verbalize your thoughts. In general, the more thoroughly you write, the easier it is to recall later—but that also means more effort at the time of writing. Conversely, if you only jot down a few keywords, it might be easier to write, but you may later have trouble remembering what you meant. How much you need to write to recall the information later depends on you, so learn your own habits. There’s also the question of whether to verbalize at all. The essence of a memo is to help you remember what you intend to do later. While you might consider taking a photo, marking something, or quickly sketching an illustration, these methods fall outside the scope of what a memo is and will not be discussed here. **A memo is fundamentally about putting your thoughts into words.** Drawing does not count. This means that if you’re not comfortable with verbalizing or writing, you may naturally struggle with memo-taking. Either give up on the memo process or work on reducing your aversion to writing.

Where should you write your memos? It’s advisable to have multiple environments. For example, if you have three contexts—home, when you’re out, and at work—it would be beneficial to have a memo system for each context. The priority is to write quickly; what you do with the memo afterward can be addressed later. So, focus on setting up a system that allows you to capture your memos rapidly. **Prepare as many environments as there are contexts in which you find yourself.** Alternatively, if you always carry your smartphone and can reliably use it for memos, that’s perfectly fine. In fact, using a tool you’re familiar with is best. In practice, however, you might not be allowed to use your personal smartphone at work, or you might not have the space to open your notebook on a crowded train, or you might feel self-conscious about taking notes in public. Since relying on a single tool can be limiting, establishing different memo methods for different contexts is often the quicker solution. (When I say “prepare an environment,” you can also interpret it as “prepare an [inbox](ref#インボックスゼロ).")

## When Reviewing Memos
The biggest hurdle in memo management is often the reviewing phase. Specifically, there are two main challenges.

### The Timing Challenge
One challenge is determining **when** to review your memos—the **timing challenge**. While you’re writing, your motivation is at its peak, but once you’re done, you lose the context and your motivation to review dwindles. Moreover, what you’ve written might not be immediately understandable, requiring you to laboriously decipher it—which can be daunting. Even if you schedule something like “review all today’s memos at 6:00 PM every day,” more often than not it won’t work. For those who are naturally driven (see [Athlete-type people](motto#アスリートとアプライア)), it might be somewhat easier, but even then, it’s common to be too tired after work to decipher and translate the memo into action.

To overcome the timing challenge, you need two things:
1. **Regular, motivation-independent review sessions** (i.e., review your memos consistently regardless of your mood).
2. **The ability to decipher and convert them into actionable steps during the review.**

In essence, you must **secure time to review your memos during periods when you are not exhausted** (see note 1). For example, can you set aside 15 minutes every morning (or every other day) to review your memos? More importantly, do you believe that the act of reviewing your memos is valuable enough to justify the effort? Ultimately, it all comes down to whether you feel that your memos are worth managing.

That said, even if you initially feel that reviewing memos isn’t valuable, there are contexts—especially at work—where forgetting what needs to be done is not acceptable, and most people will resolve to make an effort to review them. For instance, if you only need to spend 5 minutes checking your memos before or after lunch, that might be an easy habit to adopt. Setting aside time immediately before or after a proper break is natural and recommended. However, if you’re constantly swamped with meetings, you might be overwhelmed, so it’s advisable to secure about 10 minutes of downtime after a substantial break. Alternatively, you might even choose to cut 10 minutes off your break time.

- ※  
  - 1 You might think, “Why not just review them when things settle down?” Of course, if that works for you, then by all means do so. However, it often isn’t that simple. If you’re simply plowing through tasks as they arrive—and only jotting down memos because you have too many tasks—this method might work. More generally, you can divide your day into “task processing time” and “brief organizational review time” for your current tasks. In the processing time you quickly jot down memos, and during the brief review time you go over them. In other words, you can split your day from two parts (“Work” and “Rest” in a WR Life) into three parts: “Work,” “Rest,” and a brief organization phase (or “Reread”). I call this **WRR Life**—Work, Rest, Reread. The concept of rest is well known, and you naturally take breaks, but think of “brief organization” as an additional component. It’s not work, and it’s not rest—it’s a middle phase for a quick review.

### The Deciphering Challenge
Another challenge is the **deciphering challenge**. If you can’t understand what’s written, you can’t act on it, so you must persevere until you do—but this is often very difficult. As mentioned earlier, when reviewing your memos, your motivation is usually low, so it’s hard to muster the effort to really dig into them. To be even more blunt, even if you try hard, you may still find parts that you just can’t decipher. This can lead to self-blame and a negative spiral. It’s a formidable obstacle.

The only real way to overcome the deciphering challenge is to **write your memos in a way that you can immediately understand them later.** In other words, write them so clearly that no deciphering is necessary. This isn’t about putting extra effort into reviewing; it’s about how you write in the first place. Find a balance where you include enough detail for yourself to understand later while still keeping it minimal to write quickly. Only you can discover what works best for you. **Memo-taking is a skill.** It’s something you develop gradually through experience. Those who can’t accept this reality will never manage their memos effectively, and the practice will become merely a rote ritual.

That said, there are alternative approaches. You can choose to stop trying to decipher the memo exactly as written and instead reinterpret it. Rather than insisting on accurately decoding the original content, ask yourself what you can glean from it in the present moment. You might end up understanding it in a different way than when you first wrote it, or you might decide it still doesn’t make sense and discard it. In any case, you’re taking a pragmatic approach by reinterpreting it. This method is particularly well-suited for creators dealing with ideas that have no single correct interpretation.

## When Taking Action and Processing
Once you’ve reviewed your memo and understand it, the next steps are action and processing.

### Act First, Manage Second
When it comes to action, the principle **Act first, Manage second (if possible, act immediately; if not, delegate it to your task management system)** is advisable.

As introduced in the strategy section with the [Sprinter](stance#スプリンター), if a task can be completed quickly, you should take action immediately. For example, if something takes two minutes to finish, just do it, or if the ball is in your court, quickly pass it on. There are many actions you can take on the spot. However, since not everything can be done immediately, in most cases you’ll need to add the task to your task management system—whether by adding it to a task list, scheduling it on your calendar, or placing it somewhere you only check occasionally if it doesn’t require immediate attention.

The key here is to decide as quickly as possible how to manage the “action” derived from your memos. Just as with writing, if you hesitate here, the entire memo process can quickly become a burdensome, mechanical ritual. A common pitfall is the reflex of acting on everything immediately—like those who check and reply to every notification as soon as it appears. With proper memo management, reviewing and taking action should be separate. When you check your memos, simply note them down, and then later review and decide what to do. Those who can’t separate these tend to act on everything as soon as they see it.

In other words, **action essentially means adding the task to your task management tool.** However, if you add everything, it will become overwhelming later, so for tasks that can be completed immediately, do them on the spot rather than adding them to your system. It might seem like this contradicts the usual meaning of “action,” but that’s perfectly fine. The reflex to complete everything immediately is what causes the problem. Instead, aim to first record the task in your task management system, then calmly process it later. Of course, there are times when you simply can’t afford that luxury and must act immediately, but in such cases, task management isn’t very effective anyway. Alternatively, you might consider engaging in [off-the-board battles](partner_taskmanagement#盤外戦) to address the overall busyness of your situation.

### Processing ≒ Discarding
Next, let’s discuss processing—that is, what to do with the remnants of a memo after you’ve taken action. It’s best to decide on a processing method in advance. Deciding on the spot whether to keep a memo, copy it somewhere, or discard it can be mentally exhausting. Instead, decide from the beginning, “Memos written in this space will be processed this way.”

Furthermore, once you’ve taken action, the memo is essentially just trash, so it’s best to discard it without hesitation. If it’s on a sticky note, crumple it up and throw it away. If it’s a paper memo, strike through the relevant parts. If it’s digital, delete the corresponding text. We tend to have a sense of attachment—especially in Japan, where cultural influences (such as beliefs in myriad gods or tsukumogami) encourage us to cherish and keep things—so it’s wise to consciously counteract that tendency.

You want the processing phase to require as little mental effort as possible while enabling you to discard items quickly. Otherwise, the cognitive load of deciding what to do with each memo can accumulate and become overwhelming. This is especially true in digital contexts, where people often think, “It doesn’t take up any space if I keep it,” but keeping it means that every time you see it later, you must make a decision, which drains your cognitive resources. Even if each instance seems trivial, the cumulative effect is significant. For example, with used sticky notes, you naturally decide “I should just throw it away”—and that mindset is exactly what you need to cultivate. Whether it’s a sticky note, a paper memo, or digital text, once you’ve taken action, the memo is just trash, so discard it promptly. However, if there are situations where it’s acceptable not to discard a memo, you may leave it, but that’s a more advanced approach (see note 1).

- ※  
  - 1 I believe there are mainly three situations in which you might not need to discard a memo:
    - **First:** In digital contexts, when there’s almost no chance you’ll see the memo again. For example, if you organize your memo space by date, you probably won’t look at memos from past dates (except during a designated review). If you only review the current week’s memos every Sunday, then after that day, you’re unlikely to see them again. In such cases, you can leave them rather than actively deleting them.
    - **Second:** For creators. For creative individuals, generating ideas is crucial, and it helps to have various hints available. Sometimes, however, you might want to rethink something from scratch. In such cases, instead of looking at the improved output (perhaps clearer keywords or sentences), you refer back to the original memo to reinterpret it. To do that, you need to keep the original memo, so you deliberately hold onto it. That said, because the total amount of information is usually vast, you typically won’t have the time or energy to review every memo you acted upon—so this is a rare exception.
    - **Third:** Generative AI. The practice of discarding memos after taking action is essentially a human concern, born from our limited processing capacity. We discard things to save mental resources—but this doesn’t apply to AI. AI can easily process millions or tens of millions of texts, and there are already services like [NotebookLM](https://notebooklm.google.com/) and [Claude](https://claude.ai/) that ingest vast amounts of text to generate responses. Currently, inputs might be limited to PDFs with only a few hundred thousand characters, but that is likely to increase. In the future, you might be able to hand over all your written information—including your memos—and have the AI provide responses based on it. Right now, ChatGPT gives only general answers, but if you feed it all your personal data, it could provide personalized responses tailored just for you. In a sense, an AI assistant that knows you better than you know yourself is on the horizon—though this is purely speculative on my part, and generative AI services deliberately limit the amount of data to avoid issues with personalization. Nonetheless, it’s an exciting prospect.

# Summary
- A memo is a temporary note intended to be reviewed later to prompt action.
- Two main principles:
  - **Let go of perfectionism.**
    - Memos tend to accumulate in large numbers, making it impossible to manage every single one.
    - If you strive for perfection or become overly meticulous, you’ll miss out on the benefits of memo-taking.
    - It’s okay to manage your memos without having to handle every single detail.
  - **Write as quickly as possible while still ensuring that you can understand them when reviewing later.**
    - If you find yourself having to decipher your memos during review, it likely means you didn’t include enough detail—so you should write more clearly.
- The flow of memos:
  - It consists of the steps: **Writing → Reviewing → Action and Processing**.
  - 1. When writing, speed is key—optimize your process so you can jot things down as quickly as possible, even in a fraction of a second.
  - 2. Timing is crucial when reviewing, but ultimately it depends on your conviction that the memo system is worthwhile.
  - 3. For action, follow the principle “Act first, Manage second” (if possible, take action immediately; if not, delegate it to your task management system). As for processing—that is, what to do with a memo after taking action—the only option is to discard it.
