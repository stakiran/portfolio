---
title: References
---

# References

## 1
2016, D. Carnegie

[Amazon.co.jp: *How to Stop Worrying and Start Living* (Paperback Edition, eBook) – D. Carnegie, Akira Kayama: Kindle Store](https://www.amazon.co.jp/dp/B01ASX3A14/)

## 2
2013, Stephen R. Covey (Author), Franklin Covey Japan (Translator)

[Amazon.co.jp: *The 7 Habits of Highly Effective People: Restoring the Character Ethic* | Stephen R. Covey, Franklin Covey Japan | Business Skills | Kindle Store | Amazon](https://www.amazon.co.jp/dp/B00KFB5DJC)

## 3
2024, Mark Foster (Author), Takao Aoki (Editor)

[Amazon.co.jp: *The Manana Rule – Complete Edition: Work Without Being Chased by Work* | Mark Foster, Takao Aoki | Book | Online Shop | Amazon](https://www.amazon.co.jp/dp/4799319809)

## 4
2013, Naoki Kugihara

[Amazon.co.jp: *Why Do People Become Lazy in Groups? The Psychology of Social Loafing* (Chuko Shinsho) | Naoki Kugihara | Philosophy & Thought | Kindle Store | Amazon](https://www.amazon.co.jp/dp/B00IE7LI5W/)

## 5
2018, Frédéric Laloux (Author), Kenshū Kamura (Author), Tateya Suzuki (Translator)

[Amazon.co.jp: *Teal Organizations – The Emergence of Next-Generation Organizations that Overturn Conventional Management* (eBook) | Frédéric Laloux, Kenshū Kamura, Tateya Suzuki: Kindle Store](https://www.amazon.co.jp/dp/B078YJV9ZW)

## 6
[DX White Paper 2021 | Books & Publications | Information-Technology Promotion Agency (IPA)](https://www.ipa.go.jp/publish/wp-dx/dx-2021.html)

## 7
2021, *McKinsey Urgent Proposals: The Essence of the Digital Revolution – A Message to Japan’s Leaders*

https://www.mckinsey.com/jp/~/media/McKinsey/Locations/Asia/Japan/Our%20Work/Digital/Accelerating_digital_transformation_under_covid19-an_urgent_message_to_leaders_in_Japan-jp.pdf

## 8
2015, Senthil Mullainathan (Author), Eldar Shafir (Author), Naoto Ota (Translator)

[Amazon.co.jp: *For Those Who Always Say “I Don’t Have Time”: The Behavioral Economics of Scarcity* (Hayakawa Shobo) eBook – Senthil Mullainathan, Eldar Shafir, Naoto Ota: Book](https://www.amazon.co.jp/dp/B012LXVDM2)

## 9
2017, Yobiyuki Hoshiki

[Amazon.co.jp: *Negative Capability – The Power to Endure Uncertain Situations* (Asahi Sensho) eBook – Yobiyuki Hoshiki: Book](https://www.amazon.co.jp/dp/B0772WGXFS)

## 10
2021, Takuya Oikawa (Author), Kumiko Kojima (Author), Haruki Sonehara (Author)

[Amazon.co.jp: *All About Product Management: From Business Strategy, IT Development, UX Design, and Marketing to Team and Organizational Management* eBook – Takuya Oikawa, Kumiko Kojima, Haruki Sonehara: Kindle Store](https://www.amazon.co.jp/dp/B08W51KLQJ)

## 11
2019, Hiroshi Maruyama

[*A Message to Aspiring Corporate Researchers* | Hiroshi Maruyama | Practical Management & Leadership | Kindle Store | Amazon](https://www.amazon.co.jp/dp/B0845QVWH5)

## 12
2018, James Clear

[Amazon | *Atomic Habits: An Easy & Proven Way to Build Good Habits & Break Bad Ones* (English Edition) [Kindle edition] by James Clear | Business Management | Kindle Store](https://www.amazon.co.jp/dp/B07D23CFGR)

## 13
2003, Eliyahu M. Goldratt (Author), Ryo Mitsumoto (Translator), Koji Tsuda (Contributor)

[Amazon.co.jp: *Critical Chain* | Eliyahu M. Goldratt, Ryo Mitsumoto, Koji Tsuda | American & British Fiction and Literature | Kindle Store | Amazon](https://www.amazon.co.jp/dp/B0081M7YT4)

## 14
2021, Koichiro Kokubu

[Amazon.co.jp: *The Ethics of Leisure and Boredom* (Shincho Bunko) eBook – Koichiro Kokubu: Kindle Store](https://www.amazon.co.jp/gp/product/B09MT5GQC4/)

## 15
2018, John T. Cassiope (Author), William Patrick (Author), Hiroyuki Shibata (Translator)

[Amazon.co.jp: *The Science of Solitude: Why People Become Lonely* (Kawade Bunko) eBook – John T. Cassiope, William Patrick, Hiroyuki Shibata: Book](https://www.amazon.co.jp/dp/B07BBFR2GG)

## 16
2015, Erin Meyer (Author), Kei Tadaoka (Author), Takeshi Higuchi (Translator)

[Amazon.co.jp: *Intercultural Competence – Essential Knowledge for Business Professionals to Understand the True Intentions of Others and Themselves* eBook – Erin Meyer, Kei Tadaoka, Takeshi Higuchi: Kindle Store](https://www.amazon.co.jp/dp/B013WB5BJS/)

## 17
2022, Kiranosuta

[Scrapboxing | Kiranosuta | Engineering | Kindle Store | Amazon](https://www.amazon.co.jp/dp/B09YLFQZ29)

## 18
2023, Jim Clifton (Author), Gallup (Author), Hiroko Furuya (Translator)

[Amazon.co.jp: *Awaken Your Talent: Latest Edition StrengthsFinder 2.0* | Jim Clifton, Gallup, Hiroko Furuya | Book | Online Shop | Amazon](https://www.amazon.co.jp/dp/4296118307)

## 19
2024, Devon Price (Author), Hiroko Sasaki (Translator)

[Amazon.co.jp: *“There Is No Such Thing as Laziness”: A Philosophy of Happiness for Escaping the Endless Productivity Race* eBook – Devon Price, Hiroko Sasaki: Kindle Store](https://www.amazon.co.jp/gp/product/B0CZ7KG8BN/)

## 20
1999, Amy Edmondson

*Psychological Safety and Learning Behavior in Work Teams*

## 21
2019, Kiranosuta

[Amazon.co.jp: *The Underestimated Power of Routine Tasks: Mechanisms and Practices to Eliminate Oversights and Stress* | Kiranosuta | Home & Lifestyle Knowledge | Kindle Store | Amazon](https://www.amazon.co.jp/dp/B07MJW8MVD)

## 22
2024, Hideki Katano

[Amazon.co.jp: *Rest and Recovery Studies – How to Save Yourself from Exhaustion* eBook – Hideki Katano: Kindle Store](https://www.amazon.co.jp/dp/B0CNXJYPTD)

## 23
2021, Atsushi Mizoguchi (Author), Tomohiko Suzuki (Author)

[Amazon.co.jp: *Yakuza as a Profession* (Shogakukan Shinsho) eBook – Atsushi Mizoguchi, Tomohiko Suzuki: Kindle Store](https://www.amazon.co.jp/dp/B091CMY2WB/)

## 24
2019, Rider Carroll (Author), Satsuki Kuriki (Translator)

[Amazon.co.jp: *Bullet Journal – Note-Taking Techniques That Transform Your Life* | Rider Carroll, Satsuki Kuriki | Book | Online Shop | Amazon](https://www.amazon.co.jp/dp/4478102678)

## 25
2019, Kiranosuta

[Amazon.co.jp: *A Practical Guide to Using Hidemaru Editor for Efficient Writing* | Kiranosuta | Engineering | Kindle Store | Amazon](https://www.amazon.co.jp/dp/B07R6FTSMT)

## 26
1969, Tadao Umesao

[Amazon.co.jp: *The Techniques of Intellectual Production* (Iwanami Shinsho) eBook – Tadao Umesao: Book](https://www.amazon.co.jp/dp/B014R3S71E/)

# Tools

## Habitica
[Habitica – Gamify Your Life](https://habitica.com/static/home)

> Get motivated and achieve your goals.
> 
> Tackle your tasks while having fun! Join over 4 million adventurers on Habitica and improve your life and tasks all at once.

## Chill Pulse
[Steam: Chill Pulse](https://store.steampowered.com/app/2826180/Chill_Pulse/?l=japanese)

> Chill Pulse combines productivity tools with a soothing environment. Use the Pomodoro timer and ToDo list to boost your concentration while ambient sounds—from cyberpunk cities to ancient landscapes—enhance your relaxation.

## todo.txt
[Todo.txt: Future-proof task tracking in a file you control](http://todotxt.org/)

I previously wrote an article about this task management method: [Todo.txt Task Management Method Seems Interesting #TaskManagement – Qiita](https://qiita.com/sta/items/0f72c9c956cf05df8141)

> A task management method devised by Gina Trapani of Lifehacker. It’s essentially a ToDo list, but because it operates solely through a single text file, it’s simple, lightweight, and easy to manage. You can edit it manually with any text editor, or use one of the many available tools—from command-line utilities to smartphone apps.

## GitHub Issues
GitHub is a platform for managing source code socially via repositories that house your code and related documentation. Although it’s designed for social collaboration among engineers—allowing for distributed work, comments, and reviews—it also features an “Issues” system. Here, each issue corresponds to a ticket (and a dedicated page), so every discussion is treated as its own page. Since GitHub Issues also offers task management features, its clean interface makes it suitable for personal task management. However, as it’s primarily designed for software engineers, non-engineers might find it a bit challenging at first.

**Links:**

- Official:
  - [GitHub Issues Documentation – GitHub Docs](https://docs.github.com/ja/issues)
- Reference Article:
  - [Turn GitHub into the Ultimate ToDo Management Tool #GitHub – Qiita](https://qiita.com/o_ob/items/fd45fba2a9af0ce963c3)

## Asana
[Asana – Manage your team’s work, projects, and tasks online](https://asana.com/ja)

## ClickUp
[ClickUp™ | One app to replace them all](https://clickup.com/)

## monday.com
[monday.com Official | Taking Your Business Management to the Next Level](https://monday.com/lang/ja)

*Note:* The “Work Management” product here corresponds to project task management.

## Trello
[Trello – Manage your team’s projects from anywhere](https://trello.com/ja)

## Todoist
[Todoist – Organize your work and life with a ToDo list](https://todoist.com/ja)

## TimeTree
[TimeTree – A Communication App for Easily Sharing and Discussing Schedules](https://timetreeapp.com/intl/ja)

## Cross
[Cross – A ToDo sharing app for couples](https://cross-app.jp/)

## Toggl
[Toggl Track – Time Tracking Software for Any Workflow](https://toggl.com/)

## Redmine
[Redmine.JP — Open Source Project Management Software | Japanese Information Site](https://redmine.jp/)

## Backlog
[Backlog – Project and Task Management Tool for Teams](https://backlog.com/ja/)

## hown
[howm – A Hitori Otegaru Wiki Modoki](https://kaorahi.github.io/howm/index-j.html)

## Scrapbox
[Cosense – Share Experience, Make Co-sense, and Go!](https://scrapbox.io/)

*Note:* As of 2024/05/21, the name has changed to HelpFeel Cosense; however, this book continues to refer to it as Scrapbox.

## Obsidian
[Obsidian – Sharpen your thinking](https://obsidian.md/)

## Tana
[Tana](https://tana.inc/)

*Note:* As of 2024/08/03, participation is currently available via a waiting list.

## Miro
[Miro – A Visual Workspace for Innovation](https://miro.com/ja/)

## Routam
[Routam – An App to Record and Improve Your Daily Task Time](https://routam.app/)

## Routinery
[Routinery | 루티너리](https://routinery.app/)

# Methods

## Ivy Lee Method
[100-Year-Old Productivity Method “Ivy Lee Method”: How Does It Work? | Business Insider Japan](https://www.businessinsider.jp/post-174867)

> In this method, every night before bed you write down the six most important tasks you must accomplish the next day—in order of importance. Then, the next day, you work on them one at a time in that exact order.
> 
> This approach forces you to narrow your focus to just six tasks—a bold act of prioritization. (ChatGPT even refers to it as the origin of the ToDo list, a list originally limited to six items.) In contrast to conventional ToDo lists—which might have one task per line, processed from top to bottom, with completed tasks marked off—the Ivy Lee Method strips everything down to its essentials. After over 100 years, it’s still regarded as a foundational productivity technique.

## Time Management Matrix
As mentioned in [The 7 Habits of Highly Effective People](#2), this matrix categorizes tasks into four quadrants to aid in prioritization.

|                | Urgent         | Not Urgent     |
| -------------- | -------------- | -------------- |
| **Important**  | 1              | 2              |
| **Not Important** | 3          | 4              |

The idea is to invest time in quadrant 2 (important but not urgent, e.g., studying, training, health maintenance), work to reduce quadrant 3 (not important yet urgent tasks), and eliminate quadrant 4 (neither important nor urgent). (Entertainment typically falls into quadrant 4, which reflects a high level of prioritization.)
  
Determining what is “important” is subjective, but the original book is rooted in the character ethic. For example, a mindset that “I’m an otaku, so my otaku activities are important” isn’t assumed here (such activities would actually fall into quadrant 4 and be candidates for elimination). Nonetheless, the two-axis classification of importance and urgency remains versatile and applicable today.

## TaskChute
TaskChute is a task management tool devised by Etsuo Ohashi. It involves listing tasks sequentially and checking them off in order while rigorously recording their start and end times. Tasks can also include an estimated duration, so with careful use you end up with records of both your estimates and the actual time spent. Over time, these records help you see the gaps between estimated and actual times, leading to increasingly accurate estimates.

Originally an Excel-based tool, TaskChute has evolved into smartphone apps and cloud-based tools. It has also become recognized as a productivity method. By logging every action, you can quantify your daily rhythm—and once you understand your true patterns, you can design a lifestyle that avoids burnout. The tool also allows you to schedule recurring tasks or set tasks for future dates, so it can manage nearly every aspect of your day. With heavy use, you might even optimize tasks as granular as “using the restroom after waking,” “brushing your teeth,” “trimming your nails,” or “taking out the trash.”

**Links:**

- [TaskChute2 (Original Excel Version by Etsuo Ohashi)](https://cyblog.biz/pro/taskchute2/index2.php)
- [TaskChute Cloud](https://taskchute.cloud/users/top)
  - A SaaS version of TaskChute (currently the reference tool as of 2024).
- [TaskChute Association](https://blog.taskchute.cloud/)
  - Established in November 2022 with the motto “Pursue your own time-richness.”

## Timeboxing
Timeboxing is the practice of predefining a time frame during which you work—and only within that frame.

For example, you might decide: “I’ll work only from 8:30–11:30 in the morning and from 1:00–5:00 in the afternoon.” This creates a morning timebox of 3 hours and an afternoon timebox of 4 hours, without specifying exactly which tasks to perform within those windows.

In agile development, a similar concept is the sprint—a timebox of one to two weeks during which a set list of tasks is tackled. At the end of a sprint, a meeting is held to review progress and plan the next timebox. This cycle repeats, steadily advancing progress.

The core idea is to set a time boundary and avoid extending work past that limit—helping you build a disciplined routine. While some naturally work in a focused manner, many find that timeboxing introduces the necessary structure and balance.

**Links:**

- [Timeboxing – Wikipedia](https://en.wikipedia.org/wiki/Timeboxing)
- [Boost Your Productivity by Leaving Work on Time | Tsuyoshi Ushio (Note)](https://note.com/simplearchitect/n/n1b0263219060)

## Kanban
Kanban is a method originally developed for software (and even manufacturing) that visualizes tasks as cards. These cards are moved across columns that represent different stages—such as Not Started, In Progress, and Completed. A key element is capacity management; a team should only have as many tasks in progress as it can realistically handle.

For instance, if tasks are measured in “points” and your team can handle 30 points per week, there shouldn’t be more than 30 points’ worth of tasks on the board at any one time. If you have already completed 20 points but still have 15 points of work “in progress” with only 2 days left in the week, you’re clearly overloading the team. In such cases, tasks must be retracted to stay within capacity.

Kanban originated in the 1950s at Toyota, where it was used as part of the Just-In-Time (JIT) manufacturing process—ensuring that only the necessary parts, in the right quantity, were available exactly when needed. Physical cards with key information were attached to parts or containers on the assembly line.

**Links:**

- [Kanban – Overview | Atlassian](https://www.atlassian.com/ja/agile/kanban)
- [What is Kanban? – Azure DevOps | Microsoft Learn](https://learn.microsoft.com/ja-jp/devops/plan/what-is-kanban)
- [Kanban – Toyota Production System Guide | Toyota UK Magazine](https://mag.toyota.co.uk/kanban-toyota-production-system/)

## Mission Statement
A mission statement is a concept introduced in *The 7 Habits of Highly Effective People*. It involves articulating the guiding principles, purpose, and long-term goals of an individual or organization—much like a personal or corporate constitution.

According to GPT-4:

> *The 7 Habits of Highly Effective People* by Stephen R. Covey is a self-help and business book outlining principles for achieving success. In it, the “Mission Statement” is defined as a declaration of an individual’s or organization’s purpose, values, and long-term goals. It clarifies why one exists, the principles behind decision-making, and the overarching mission or contribution to society.
> 
> For individuals, a mission statement reflects one’s ideals, goals, and values—serving as a consistent foundation for decision-making. For organizations, it outlines the company’s purpose, the value it provides, and the concrete objectives it seeks to achieve—helping employees and stakeholders rally around a shared vision.
> 
> Crafting a mission statement requires deep introspection and honest self-examination. Because it may include very personal insights, it’s often best kept private. When made public, there’s a risk of “polishing” the statement rather than confronting uncomfortable truths, which diminishes its value. In organizations, while it’s similar to a corporate philosophy, it’s wise to draft and refine it within a small group to avoid endless debate.
> 
> In short, a mission statement is a constitutional element of your life or organization—vital, yet not easily changed. It should be revisited periodically as you evolve.

## Pomodoro Technique
Developed in the late 1980s by Francesco Cirillo, the Pomodoro Technique is a time management method based on cycles of focused work and short breaks.

Key points include:
- **The Pomodoro Cycle:** Work for 25 minutes, then take a 5‑minute break.
- **Single-Task Focus:** Decide on one task at the beginning of the cycle and focus solely on it.
- **Strict Timer Usage:** Use a timer (such as a kitchen timer) to enforce the intervals without deviation.
- **Longer Breaks:** After four Pomodoros, take a longer break (around 30 minutes) to recharge.

The technique is designed to build concentration. By working intently for a set period, you gain a sense of progress and clarity—even if the task isn’t inherently interesting. While some people might naturally concentrate without constraints, many find that the structured nature of the Pomodoro Technique makes it easier to overcome procrastination and maintain focus.

**Links:**

- [Pomodoro® Technique – Time Management Method](https://www.pomodorotechnique.com/)

## Inbox Zero
Inbox Zero is the practice of maintaining your “inbox” (or any collection point for unprocessed items) at zero by applying two main rules:
- Continue to accumulate tasks in the inbox.
- Process every item so that, eventually, the inbox is completely empty.

This “zero” state creates clarity and relief. Whether it’s your email inbox, chat notifications, or even a physical tray for incoming documents, reaching zero signals that nothing is pending. For example, some systems include a daily task list where, once all tasks are completed, the day is considered finished. Similarly, the author maintains a physical inbox by the door for sorting mail and a “sticky note zone” for shopping reminders. When these areas are cleared, it brings a sense of calm and motivates prompt action.

## Habit Tracker
Also known as a habit tracker, this method involves monitoring your habits on a daily basis.

The idea is simple: list your chosen habits alongside a daily calendar (with habits on one axis and dates on the other) and mark each day when you successfully complete the habit. A quick image search will show you many examples of such trackers. While you can use digital tools, many find that an analog planner works best.

The challenge lies in choosing habits that are sustainable and truly meaningful to you. Beginners often add too many habits at once, but if everything were easy, there’d be no struggle. Motivation varies from person to person—and even from day to day—so it’s important to tailor your tracker to your personal rhythm. (As noted in the [Toremment](view_personal_taskmanagement#トレメント) section, individuals strong in self-discipline tend to have an advantage.)

Although the precise origin of habit trackers is unclear, ChatGPT notes that the concept became widely popular after being featured in *Atomic Habits* (see reference [12]). As of May 30, 2024, Amazon reviews for habit trackers have exceeded 160,000.

Habit trackers can also serve broader purposes—for instance, self-monitoring your health. By tracking daily actions (such as taking medication, getting sunlight, or scheduling appointments), you can later identify patterns or omissions when issues arise.

## GTD (Getting Things Done)
GTD, short for Getting Things Done, is a life management system developed by David Allen.

The core steps are:
1. **Capture:** Get everything out of your head—every task, idea, or worry—and write it down.
2. **Clarify & Organize:** Process these items through a workflow that categorizes them (e.g., next actions, projects, someday/maybe lists, inboxes for unprocessed items, and waiting-for items).
3. **Review:** Conduct regular reviews—daily, weekly, monthly (and ideally yearly)—to ensure your system stays current.
4. **Reflect:** Maintain a higher-level list of your core beliefs, long-term goals, and constraints to ensure your daily actions align with your life’s vision.

In summary:
- Dump all thoughts and tasks from your head.
- Process and categorize them appropriately.
- Review them on a daily, weekly, monthly, and yearly basis.
- Maintain a guiding list to align your overall goals.

GTD provides a framework rather than prescribing specific tools. For example, how you implement “next actions” in your daily routine is left up to you—whether it’s through a dedicated app like Dailer, a custom Robot system, or simply blocking time in your calendar. The review process is especially challenging: initial brain dumps might take hours, daily reviews 10 minutes, weekly reviews an hour, and monthly reviews one to two hours. Missing these reviews can cause the whole system to falter. This emphasis on regular review is at the heart of what we call [Toremment](view_personal_taskmanagement#トレメント).

## PARA Method
The PARA Method is an information management system developed after GTD—but with comparable versatility. (Note that it is a paid method.)

As the name implies, PARA organizes information into four categories:
- **Projects:** A series of tasks with a specific goal and deadline.
- **Areas of Responsibility (AoR):** Ongoing areas that require regular attention (for example, “maintaining good health”).
- **Resources:** Information that you are currently interested in or might need later.
- **Archives:** Items that don’t fit into the above categories and can be stored for reference.

Essentially, PARA divides everything into projects, information, and “everything else” (with AoR serving as a bridge between tasks and broader responsibilities). AoR items, which might be too abstract to manage as individual tasks, are maintained on a separate list. You can then periodically review them and turn relevant items into actionable projects.

You can use any note-taking tool for PARA. Whether you choose OneNote for work or Evernote for personal use doesn’t matter—the key is to maintain a consistent structure across tools. The recommended hierarchy is four levels deep; for example, OneNote uses notebook > section > section group > page, and Evernote uses application > stack > notebook > note. The top level is fixed to the four PARA categories, and while you have flexibility within each, it’s best to keep it to four levels maximum.

The author finds the AoR concept particularly groundbreaking. Furthermore, the PARA Method emphasizes commitment—stating that a project without a goal is just a hobby, and a goal without a project is merely a dream. Although detailed operational guidelines are not fully covered (or may be part of the paid content), the method itself is both versatile and succinct.

**Link:**

- [The PARA Method: The Simple System for Organizing Your Digital Life in Seconds](https://fortelabs.com/blog/para/)
  - (As of 2021, extensive explanations were available. However, as of June 2024 [last updated April 2023], the content may no longer be accessible.)
