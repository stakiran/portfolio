---
title: Task Management with Plain Text(2/2)
---

# Tools for Handling Plain Text
Next, let’s discuss the tools you use to handle plain text. If you’re already familiar with these, feel free to skip this section. Note that we won’t be discussing hardware like displays or keyboards.

The tools can be broadly divided into the following five categories:

- **1: Text Input Engines (IME)**
- **2: Editing Tools**
- **3: File Formats and Markup**
- **4: Information Management Tools (i.e., file management)**
- **5: Helpers**

## 1: Text Input Engines
Known as the IME (Input Method Editor), this is the program that runs in the background when you input text. Without it, you couldn’t input characters, especially when conversion is involved.

The major IMEs are:
- MS-IME (default)
- Google Japanese Input
- ATOK

Normally, you don’t need to worry about it; the default IME is used unless you change it. On Windows, it’s MS-IME, and on macOS it’s the “Japanese Input Program” (formerly “Kotoeri”). If you’re dissatisfied with the default, you can install Google Japanese Input or ATOK. In the past, the default IME was less capable, while Google Japanese Input was known for its vocabulary and speed and ATOK for its conversion accuracy. Nowadays, the differences have mostly diminished. The default IME is generally fine.

When do you need to pay attention to it? Mainly when you want to adjust settings or customize it—for example, dictionary registration is a common use. For instance, when you convert “じしょ” you get the kanji “辞書” because it has been registered in advance. This dictionary registration feature allows you to register frequently used words, which is very handy.

Some examples from my own usage:
- Typing “だん” to produce “✅”
    - I often use ✅ as a completion mark.
    - It is registered with the reading “だん” (from “Done”).
- Typing “ぼうめいたい” to produce “忘迷怠”
    - [I have already explained 忘迷怠](view_personal_taskmanagement#忘迷怠); it’s a term I coined.
    - If you use your own terms, they might not normally appear during conversion, so registering them is very convenient.
- Preventing “になって” from converting to “担って”
    - **Google Japanese Input has** a function to suppress words from appearing during conversion.
    - Since the phrase “～になって” is used frequently, having “担って” appear every time is annoying, so I suppress it.

## 2: Editing Tools
This refers to the tool where you input your text, known as an editor.

### Three Main Types
They are:
- Text Editors
- IDEs
- Web Apps

**Text Editors** are specialized for editing plain text. They are lightweight and work offline. Their performance is important, so if you plan to manage tasks using plain text, this is the first option to consider. The downside is that they are limited to handling only plain text, which can be inconvenient for other tasks (for example, they usually lack file management functions). Another drawback is that their appearance is often plain, which might not suit those who care about aesthetics.

**IDEs (Integrated Development Environments)** were originally designed as all-in-one tools for programming (with built-in editors) but are also excellent for managing plain text. Some people (myself included, on macOS) use them for task management. In the past, they had trouble handling Japanese text, but now they are advanced enough to even write books. Their advantages include high customizability and robust features such as search and file management. Their downside is that they require time to master (since they were originally built for programmers). Typically, IDEs run offline on a PC, though recently there are some online IDEs available.

**Web Apps** are online tools that offer editing capabilities. Many services for writing diaries or blogs work this way, and even social networking services like X, as well as business chat tools like Slack or Teams, can function as editors. These are primarily designed for collaboration or public sharing, but if you use them privately, they can work as editors. Their advantage is that most modern people are familiar with them (and many work on smartphones too, though we won’t cover that here). Their disadvantage is that, since they are not dedicated editors, they are not as convenient as text editors or IDEs. Additionally, because they require an internet connection, you might encounter delays or disconnections. Data is stored on the provider’s servers, so if your account is suspended or the service shuts down, you could lose your data.

### Comparison of the Three Types
Here’s a table summarizing their characteristics:

| Method           | Lightweight | Offline | Editor Potential | Ease of Learning | Customizability |
| ---------------- | ----------- | ------- | ---------------- | ---------------- | --------------- |
| Text Editor      | ✔           | ✔       | ✔                | △                | ✔               |
| IDE              | △           | △       | ✔                | ✖                | ✔               |
| Web App          | △           | ✖       | ✖                | ✔                | ✖               |

So, which do you choose for plain text–based task management? The answer is: **Start by considering a text editor. IDEs are fine if you’re comfortable with them, but do not use web apps.**

Web apps should be ruled out first. They are inadequate for handling plain text and, above all, require online connectivity—a major drawback. Even if a web app is well designed and your internet connection is good, any delay or disconnection can be extremely frustrating when you’re working intensively with plain text. Even a few seconds of lag can be annoying, much like a car suddenly slowing down in traffic. Web apps might be great for task management in general, but **they are unsuited for plain text–based task management.** Eliminate them from your options.

That leaves you with text editors or IDEs—either is acceptable. Choose whichever works best for you. However, the built-in editors might eventually feel limiting, so I recommend using a popular free editor or a paid one. Of course, you can start with the standard one and switch later if it feels inadequate. To use an analogy, a text editor is like a house in the countryside (DIY and agile), whereas an IDE is like a city apartment (equipped with many tools and conveniences but less flexible). Which is best depends on your personal preference.

### Examples of Editors
Below are some examples of currently available editors.

*Note: I will omit editors familiar to programmers (such as Vim or Emacs).*

- **Text Editors:**
    - Standard:
        - Notepad on Windows
        - TextEdit on macOS (make sure to set it to “Plain Text” via preferences)
    - Free:
        - [SAKURA Editor](https://sakura-editor.github.io/) for Windows
        - [mi](https://www.mimikaki.net/), [CotEditor](https://coteditor.com/) for macOS
    - Paid:
        - [Hidemaru Editor](https://hide.maruo.co.jp/software/hidemaru.html) for Windows
            - I typically use this.
- **IDEs:**
    - Free:
        - [Visual Studio Code](https://code.visualstudio.com/)
            - Commonly abbreviated as VSCode; it is the de facto standard IDE.
- **Web Apps:**
    - Chat:
        - LINE, Teams, Slack
    - Note-taking:
        - Notion, Google Docs, OneNote
    - Wiki:
        - Scrapbox, esa
    - Blogs:
        - note, Hatena Blog
    - SNS:
        - X (formerly Twitter)
    - Bug Tracking Systems:
        - GitHub

Whether you choose a text editor or an IDE, the options are relatively limited. The field of editors has a long history and isn’t easy to enter; especially IDEs, as of 2024, are largely dominated by VSCode.

If you want to try an IDE, give VSCode a try. If you struggle with it, perhaps an IDE isn’t for you—then switch to a text editor.

## 3: File Formats and Markup
Just as natural languages include “English” or “Japanese,” and even within Japanese there are various styles (colloquial vs. literary, fiction vs. technical, lists vs. prose), plain text also comes in various forms. Specifically, there are **file formats** and **syntax**.

**File format** refers to the type of file in which you store your plain text information. Examples include:
- task.txt (plain text format)
- task.md (Markdown format)
- task.json (JSON format)

The first option, .txt, is a generic format—like a natural language that can be written in any language. The last, .json, is a generic format intended for machine data—similar to a programming language. Just as people rarely communicate using a programming language, we typically don’t use JSON for everyday text. JSON is purely for data handled by programs and is not used for plain text–based task management.

The middle option, .md, is the Markdown format—a markup language designed to express certain formats. For example, you write `# Header` for a heading (Note 1). The rule is to use the half-width hash; the program then interprets it and displays it as a large heading (or includes it in a table of contents, etc.). In other words, by writing in plain text according to predefined rules, you get formatted output.

So when managing tasks, you’ll be using one of the following:
- A generic format → .txt
- A markup language → for example, Markdown

Next, **syntax**: as mentioned, Markdown and JSON each have their own syntax. They are designed to create specific expressions. That is, Markdown is “Markdown syntax” and JSON is “JSON syntax.”

The relationship between file format and syntax is that the syntax is expressed through the file format. When using Markdown, you indicate this by using the .md extension (task.md). The extension signals to your editor how to format the display. For instance, a .md file might have specific settings that highlight `# Header` or automatically generate a table of contents. This is because the editor has built-in settings based on the file extension. Therefore, even if you devise your own syntax (say, sta syntax), you can assign it your own extension (e.g., task.sta) and—if you’re willing to customize your editor’s display settings—you can have it rendered in your own way. However, such customizations are advanced and beyond the scope of this guide.

To summarize:
- Plain text can be written in various syntaxes, each indicated by a file format (extension).
- File formats exist so that editors can apply different display settings based on the extension.
- The main syntaxes are:
    - Plain text format (.txt): generic
    - Markdown format (.md): a markup language
- You can even create your own syntax if you wish.

When managing tasks, you’ll choose one of these syntaxes. You can write freely in your own style using .txt, or adhere to Markdown. Since Markdown is the de facto standard for writing text, it’s useful to know. Alternatively, you can invent your own syntax—but note that customizing the display settings in your editor might be advanced. If you’re only writing and reading for yourself, using your own syntax in a .txt file is perfectly acceptable.

- ※
    - 1 A well-known markup language is HTML. Websites are written in HTML, which browsers interpret to add formatting. In HTML, you write `<h1>Header</h1>` for a large heading. This is cumbersome for human writing, so Markdown, which only requires a `# `, is considerably easier. In that sense, Markdown is called a lightweight markup language because it is simpler and quicker for humans to write.

## 4: Information Management Tools
We call the management of saving units (such as files) “information management.” When working with plain text, this perspective is inherently required.

There are several approaches:
- **1:** Not using any additional management tool.
- **2:** Using a file manager.
- **3:** Using a web app.

Approach **1** means structuring everything within one saving unit. For example, if you want to have a daily task list, instead of creating separate files like 2024-07-30.txt, you might simply write a section in task.txt like `■2024/07/30`. As mentioned in the strategy section (see “Monolith” in strategy#monolith), this approach is optimal for plain text–based task management. **The cost of moving between saving units (for example, between files) is high, so it’s best to minimize it.** With a bit of skill in formatting and using your editor, you can reduce this overhead.

The file manager (approach **2**) refers to tools that manage files—like Windows Explorer or macOS Finder. These programs display folders and their contents. In task management, a standard file manager is usually sufficient, but you must establish rules and perform regular maintenance to keep everything organized.

For example, if you decide to create one file per day, on 2024/07/30 you’d create a file named 2024-07-30.txt and perhaps copy tasks from the previous day. You must perform these actions yourself. Moreover, once files start accumulating, you may want to organize them. With the file manager approach, you cannot avoid the chore of organization. However, if you establish a simple rule (such as keeping all files in one folder), even if you create one file per day, that’s only a maximum of 365 files a year, so organization might not be necessary. On the contrary, we tend to want to organize things, so it becomes a battle against that impulse.

There are also alternative file managers. For example, VSCode, mentioned earlier, includes a file manager that lets you add or delete files from within its interface (and search through them). Additionally, there are advanced tools like [Tablacus Explorer](https://tablacus.github.io/explorer.html) that offer more features and customization than the standard file manager. In fact, seasoned PC users (especially engineers) often do not use graphical file managers at all, opting instead for command-line tools that provide equivalent functionality. The point is, as long as you can effectively manage your files, the method is up to you.

Approach **3** (using web apps) refers to saving your information not on your PC but in the cloud. Here, the saving units might be pages, notes, documents, or even higher-level units like projects or workspaces.

## 5: Helpers
There are tools and mechanisms that help you write plain text. As mentioned earlier, dictionary registration in the IME is one example, but there are others.

- [Text Expansion](https://qiita.com/sta/items/11dd0dba4b85052b4405)
    - For example, typing `d[[` might automatically insert the current date (such as 2024/07/30).
    - This method uses “abbreviations” to insert “snippets.”
        - `d[[` is the abbreviation, and 2024/07/30 is the snippet.
        - Snippets can consist of multiple lines or include dynamic information such as the date.
- Clipboard History:
    - This retains multiple items that you’ve copied so you can reuse them later.
    - In the past, you needed a dedicated tool, but Windows 10 now has this built in (accessed via Win + V).
- Outlines:
    - A feature in text editors that detects headings and generates a table of contents.
    - This helps you get an overview of your document or jump quickly to a specific heading.
    - To use this effectively, you may need to customize your editor, which is an advanced topic.
        - However, if you use an existing syntax, you might be able to use built-in settings.
        - For instance, using Markdown in VSCode can automatically generate a table of contents based on headings.
- OCR (Optical Character Recognition):
    - This technology converts images of text into plain text.
    - It allows you to capture text from images without having to type it out manually.
        - This is particularly useful if you want to create tasks from images.
    - Tools such as [Gyazo Pro](https://gyazo.com/pro?lang=ja) and [PowerToys](https://learn.microsoft.com/ja-jp/windows/powertoys/)’s Text Extractor are examples.

There are many other helpers. The idea is to **reduce the amount of manual typing, tedious scrolling, and searching**.

## Recommended Tool Setup
Based on everything above, here is my recommended tool setup for plain text–based task management.

For the text input engine (IME), any will do. The key is to use dictionary registration so that frequently used words—especially symbols used for emphasis (like ✅ or “[X]”)—can be entered quickly.

For the editing tool, choose either a text editor or an IDE. Avoid web apps—they are not suited for plain text and tend to be stressful. Use the editor you’re most comfortable with. Plain text can be edited with any editor. If you need to, you can switch editors later, so don’t get too attached; simply choose one that seems easy to use.

For file formats and syntax, start with the generic .txt. The syntax is something you can develop on your own. Task management is inherently personal—as is the message of this book—and most people naturally develop their own preferred style. With .txt, you can write however you want, so start with .txt. Once you become accustomed and find it limiting (for instance, if you want more visual differentiation or to generate a table of contents), then consider switching to Markdown. Markdown’s syntax can be a bit challenging to learn, but it offers significant benefits and many editors support it. However, in the early stages, it’s best to stick with .txt. I won’t cover Markdown here (refer to [my book](ref#25) or other independent resources).

For information management, I recommend starting with a “monolithic” approach—writing everything in a single file. Only once it becomes cumbersome should you consider splitting it into multiple files. Jumping directly into complex file management can be difficult; it’s best to start small.

Helpers are optional but can be very convenient if you have the capacity to learn and implement them gradually.

**Summary:**
- Any IME will do.
    - More important is dictionary registration—register symbols for emphasis so that you can input them quickly.
- For the editor, choose either a text editor or an IDE.
    - The editor itself isn’t critical; any editor can handle plain text.
    - Use one that best suits your needs.
- For file formats and syntax, start with .txt.
    - You will likely develop your own personal style, so feel free to let it reflect your habits.
    - Once you feel constrained, consider switching to Markdown.
- For file management, initially, don’t worry about it—write everything in a single file.
    - Only consider file management when the number of files becomes overwhelming.
- Helpers are not essential but are very convenient if available.

# Fundamentals of PTTM
With the basics of handling plain text covered, we now move on to **Plain Text–Based Task Management (PTTM)**.

## The Goal of PTTM Is to Achieve Complete Flexibility
PTTM is the process of managing tasks using plain text and an editor.

Its goal is to allow you to manage tasks **completely flexibly**. People who manage tasks with analog methods use pen and paper to handle tasks (whether they are words, sentences, symbols, or even drawings) with complete freedom. We want to replicate that freedom digitally.

Task management in digital environments often involves complex screens, transitions, network communications, and processing delays—all of which can be stressful. Such complexity is common in business-oriented project task management designed for multiple users, but for personal task management, it is usually unnecessary. In fact, it is more important to design a system that fits your own needs rather than force yourself to adapt to standardized business tools. Creating your own task management tool from scratch might be unrealistic unless you’re an engineer, and even then it can be very costly.

So, how can you manage personal tasks flexibly? As mentioned earlier, using an editor to handle plain text allows you to design various methods for writing and rearranging your tasks.

## PTTM ≒ Operating a Task List
How do you manage tasks with PTTM?

Quite simply, it comes down to how you operate your task list. The key is to use [attributes](attributes) to add structure and flexibility.

The most well-known task list is the **TODO list**, which supports only two elements: the task “name” and its “status.” However, this method is prone to collapse over time. Let’s look at an example to see how attributes can improve the system.

Here’s an example TODO list:

```
Trash disposal
Research new refrigerator
✅Electronics retail store
Online shopping
✅Talk to the boss since they mentioned they replaced theirs before
Want to deal with the annoying gnats
```

Two tasks are marked as completed. Perhaps, as part of the “research new refrigerator” task, the tasks “visit the electronics store” and “ask your boss (who mentioned replacing his own)” are now done. While this might be manageable in a short-term list, over time the list will quickly become chaotic and collapse.

To avoid this, you can introduce attributes to manage tasks more effectively. For example, you might introduce a [Starting Date attribute](attributes#実行日%2Fstarting-date) and adopt a rule such as “complete only the tasks listed for today” (a daily task list). It might then look like this:

```
■Today: 2024/07/29
Take out the garbage
Research new refrigerator
✅Electronics retail store
✅Listen to my boss's experience as he mentioned buying a new one before
Online shopping

■2024/07/30

■2024/07/31
Want to deal with the noisy gnats

■2024/08/01
```

In this example, you can see that the “コバエ対策” (fly control) task has been postponed until two days later, and if you meant to take out the trash today but haven’t, it remains on today’s list. For “通販” (online research), if you prefer to handle it after work, you can postpone it by moving it to 7/30 or 7/31. Similarly, for “ごみ捨て” (taking out the trash), if you’re worried about forgetting it, you can add a reminder or move it as needed. This simple addition of a timeline makes your system much more flexible.

Of course, this method isn’t perfect. For instance, what should you do tomorrow, on 7/30? You might end up modifying the list like this:

```
■Today: 2024/07/30
Take out the trash
Research new refrigerator
Online shopping

■2024/07/31
Dealing with annoying fruit flies

■2024/08/01
```

Manually adjusting the list every day is tedious. How you reduce this burden is up to your ingenuity. Accepting some level of inconvenience might be necessary (just as mundane household chores eventually become bearable).


Also, what should be done with completed tasks like “✅Electronics retail store” and “✅Listen to my boss's experience as he mentioned buying a new one before
” from 7/29? Should you delete them or keep them as a record? If you choose to retain them, you might move them to another file. For example, you might have one file, tasks.txt, for active tasks and another file, tasks_old.txt, for records of completed tasks, as shown here:

```
[task.txt]
■Today: 2024/07/30
Take out the trash
Research new refrigerator
Online shopping

■2024/07/31
Want to deal with pesky gnats

■2024/08/01
```

```
[tasks_old.txt]
■2024/07/29
✅ Electronics retailer
✅ Listen to the story because my boss said they replaced it before
```

This separates the files, which is part of information management (discussed earlier in section 4). Although I recommend starting with a single file, records of completed tasks that clutter the active list should be moved to a separate file.

Alternatively, if you prefer to focus solely on today’s tasks and avoid being distracted by future tasks, you might split tasks.txt into today.txt and tomorrow.txt, with today.txt always containing just the tasks for the current day, and rename tasks_old.txt to yesterday.txt. That would look like this:

```
[today.txt]
■Today: 2024/07/30
Take out the trash
Research new refrigerator
Online shopping
```

```
[tomorrow.txt]

■2024/07/31
Flies are annoying, so I want to deal with them

■2024/08/01
```

```
[yesterday.txt]
■2024/07/29
✅Electronics store
✅Listened to the boss who mentioned buying a new one before
```

This three-file structure clearly delineates today’s tasks, future tasks, and records of past tasks. However, switching between files can be tedious. Thus, many prefer to keep everything in one file. There are various formatting methods—for example, using lines to separate sections:

```
■================
■Today
■================


■2024/07/30
Take out the trash
Research new refrigerator
Online shopping


●================
●Beyond Tomorrow
●================


■2024/07/31
I want to handle the noisy gnats

■2024/08/01


★================
★Before Yesterday
★================


■2024/07/27
...

■2024/07/28
...

■2024/07/29
✅ Electronics retail store
✅ Listen to the story because my boss said he had previously replaced it
```

How does that sound? Being in one file makes navigation easier (depending on your cursor skills). It may seem cluttered at first and require frequent scrolling. In the above example, small techniques are used so that if you want to see future tasks, you can search for “●” and for past records, search for “★” (using your editor’s search functionality).

Alternatively, you might try writing one task per line:

```
2024/07/30 Take out the garbage
2024/07/30 Research new refrigerator
2024/07/30 Online shopping

2024/07/31 Want to deal with annoying gnats
2024/08/01 

2024/07/29 ✅ Electronics store
2024/07/29 ✅ Talk to boss as they mentioned upgrading before
```

This looks much cleaner, but because each task includes a date, postponing a task becomes very tedious—you have to manually type the date (e.g., “2024/07/30”). In contrast, the previous method allowed you to simply move the task line to a different section to change its date. As a compromise, you might use a helper such as Text Expansion so that, for example, typing `d[[` automatically inserts the current date (e.g., 2024/07/30).

That is enough for now.

The essence is that by cleverly using attributes and file organization, you can design a system that suits you. This is what PTTM is all about.

As mentioned at the beginning, PTTM is ultimately just a way of operating a task list. However, by cleverly employing attributes and organizing your files, you can make it work effectively. There is no one correct solution—only the method that suits you best. In other words, only you can determine what works for you. If you can’t bear the process of trial and error, then you might want to steer clear of PTTM.

## Examples from Early Adopters
For reference, here are a few articles and pages from people who appear to be practicing PTTM. Since “PTTM” is a term I coined, finding examples might be challenging, but searching for “プレーンテキスト タスク管理” (plain text task management) should yield some results.

- [Why I Still Love Plain Text – The Reason I Continue to Use It | Lifehacker Japan](https://www.lifehacker.jp/article/160304plain_text/)
- [I Asked AI How to Create a Schedule in a Text Editor | Every Day AI Life](https://ameblo.jp/oto6oto/entry-12846719425.html)
- [10 Clever Ways to Use Plain Text Files to Boost Productivity | Lifehacker Japan](https://www.lifehacker.jp/article/141209ten_clever_uses/)
- [I Completely Agree: Plain Text Is the Best | Todo’s Diary 2.0](https://www.saoyagi2.net/diary/post_262.html)
- [After Trying Various TODO Apps and Task Management Methods, I Ultimately Settled on Plain Text – From Kirimin’s Blog](https://kirimin.hatenablog.com/entry/2019/08/06/190809)
- [Implementing Task Management and Memos in a Text File – j3iiifn’s Blog](https://j3iiifn.hatenablog.com/entry/2019/08/12/003000)

- [For Those Who Can’t Find a Tool That Feels Right: The Benefits of Todo.txt for Task Management | 3-Minute LifeHacking - ITmedia Enterprise](https://www.itmedia.co.jp/bizid/articles/1102/02/news084.html)
- [Todo.txt - wkpmm](https://scrapbox.io/wkpmm/Todo.txt)

Looking at these examples, it’s clear that everyone develops their own system. Some use frameworks based on todo.txt, others use simple notations like “-” and “x,” and some rely on Markdown.

## Conclusion
This concludes the fundamentals section. With this information, you should be able to start your own PTTM.

That said, PTTM incorporates the wisdom of many predecessors. In the next section, titled “Design,” I will introduce well-known techniques and ideas that will help you design your own PTTM.

# Designing Your PTTM

Here are some hints to help you design your own PTTM system.

## Principles

### Define the Scope of Your PTTM Management
**Answer:** Decide what exactly you will manage with PTTM.

You don’t have to manage every aspect of your life (although you can if you wish). For example, you might choose to manage only one project (say, Project A) with PTTM as a small start.

If you don’t define the scope, you might become confused, so decide quickly. Essentially, there are two options: manage only specific targets, or manage everything in your life. Personally, I recommend the latter, since personal task management often involves juggling multiple roles and contexts. For example, you might need to adjust your personal tasks while at work (or vice versa). Of course, if your workplace requires strict confidentiality, you might have to separate work and personal tasks, but try to manage them together as much as possible. In modern work-life balance discussions, it is increasingly argued that separating work and life is difficult, and that a more integrated approach is preferable (as seen in ideas like “work in life” or “work as life”). Task management is similar. Because the boundaries are blurry, managing everything together provides more flexibility. Most workers (especially those in organizations) are subject to confidentiality rules, so you might end up running two separate PTTM systems—one for work and one for personal matters.

### Establish a Workflow (動線化する)
**Answer:** Place the plain text file used for PTTM in a location you visit frequently every day.

As explained in the previous chapter on workflow (動線), having a location you pass by frequently means that you’ll see it often, which helps you remember to check or maintain it. Even if you forget, just seeing it will remind you.

Since PTTM involves reading and writing text frequently, creating a workflow is essential. I recommend incorporating the RSAF cycle (refer to dousen_and_remind#rsaf-サイクル). Instead of thinking of it as a chore, practice it until it feels as natural as breathing. Frankly, whether your PTTM system succeeds may well depend on how well you integrate it into your daily routine.

### Keep It Private
**Answer:** The contents of your PTTM are personal, so never let anyone else see them.

One major reason personal task management systems fail is due to embarrassment. If someone sees your tasks—or even if there’s a possibility they might—you may subconsciously start omitting certain tasks. For instance, tasks related to intimate matters, surgeries related to gender or health issues, or job-hunting activities that you wish to keep secret may not get recorded. The more you deliberate over what to include and what not to, the more your task management system suffers. Deciding whether to write something down or not uses cognitive energy, and since people are naturally inclined to avoid extra work, you might end up not writing down tasks, leading to system failure.

This risk of embarrassment should be eliminated. I refer to a state where this risk is minimized as **managerial safety**. You must ensure managerial safety as much as possible. Not only should you keep your system hidden from others, but also eliminate any possibility of accidental exposure. If you’re in an environment where that isn’t possible, take measures to create one. This is especially relevant in workplaces where colleagues might ask, “What are you doing?” Such scrutiny undermines managerial safety. In the beginning, you might need to obscure your activities until you’re accustomed to the system, after which your habits will protect your privacy.

### Decide What PTTM Will Manage
**Answer:** Although PTTM is based on text and can theoretically handle almost anything, you should decide what it will (or will not) manage.

Because PTTM is just about writing text, you could try to manage almost anything, but some things may not be well-suited for it. For example, calendars might be better managed with dedicated calendar apps, and if you write lengthy diaries or unstructured thoughts, it might not only be unproductive but also clutter your system and make it hard to review. Without regular review, your task management system will degrade. In short, if you try to handle everything, your system will eventually collapse.

If things aren’t working well, consider whether you might be trying to manage too much. Although plain text lets you write endlessly, our cognitive capacity is limited, so focus on managing only what is truly necessary.

I will later discuss what should not be managed using PTTM.

### Conduct Regular Reviews
**Answer:** Since PTTM is all about reading, writing, and maintaining text, it’s crucial to develop the habit of reviewing.

In PTTM, you frequently check pending tasks, review tasks for future days, mark tasks as completed, and make minor adjustments—all of which increase during transitions from day to day or week to week. You should also periodically review your tasks (daily, weekly, monthly, and yearly) to reflect on what’s been accomplished and plan for the future. If you don’t set aside regular review time, maintenance will fall by the wayside, and your system will eventually become a meaningless formality.

Just as a cluttered room or desk eventually becomes unmanageable and needs cleaning, your plain text files used for PTTM need regular upkeep. Use your review sessions to maintain them.

(For details, see the [Review Chapter](furikaeri).)

### Overcome the 3-Second Barrier
**Answer:** When adding a new task, aim to complete the addition within 3 seconds.

Imagine you’re busy and a new task arises that isn’t immediately urgent but needs to be done later. What should you do? In a PTTM system, the answer is to jot down the task immediately. By writing it down, you can process it later when you review your tasks. We often overestimate our memory and might skip writing something down, thinking “I’ll remember it,” but you will forget. To prevent that, you must add the task immediately (the target here is to start the writing process within 3 seconds).

I propose 3 seconds as a guideline. If you can begin to add a task within 3 seconds, your PTTM system is well integrated. If it takes longer, you’re not yet accustomed, and if the process feels too burdensome, you may eventually abandon the system. Task management—especially PTTM—is prone to neglecting even small tasks, so being able to jot them down “in a flash” is a key indicator of success. Do whatever you can to break through that 3-second barrier.

- ※
    - 1 This quickness is especially important for knowledge workers and creative types who need to capture ideas on the fly. Ideas can strike at any moment, and if you don’t record them immediately, you might lose something important forever. (For more on note-taking, see the [Memo Chapter](memo).)

## What Not to Manage

### Do Not Manage Altasks
**Answer:** [Altasks](chap3) should not be managed directly in PTTM; handle them with separate tools.

In Part 3, I introduced things that resemble tasks but aren’t actually tasks (such as containers, events, mottos, memos, and task sources). Trying to manage these using PTTM is counterproductive. Use the specialized methods or tools for those, as explained in their respective chapters.

That said, within PTTM you can handle containers to a limited extent—for example, by using headings to divide sections. For instance, using a date like `■2024/07/30` can serve as a chronological divider. You can also use indentation to express hierarchy. Here are some examples:

```
■Moving Area (Indented with 2 spaces)
Moving
  Consideration of Moving Destination
    Research Hokkaido
    Research Local Area
    Want to research again areas with cheap rent in Tokyo
  Overall Schedule
    Packing and bulky waste, etc.
    Don't need the bicycle, want to dispose of it
  Want to replace the refrigerator
  (Still in the process of listing...)
```

```
■Moving Area (Indented with 2 spaces + '・' at the beginning)
・Moving
  ・Consideration of Moving Destination
    ・Research Hokkaido
    ・Research Local Area
    ・Want to research again areas with cheap rent in Tokyo
  ・Overall Schedule
    ・Packing and bulky waste, etc.
    ・Don't need the bicycle, want to dispose of it
  ・Want to replace the refrigerator
  ・(Still in the process of listing...)
```

```
■Moving Area (Markdown List Notation)
- Moving
    - Consideration of Moving Destination
        - Research Hokkaido
        - Research Local Area
        - Want to research again areas with cheap rent in Tokyo
    - Overall Schedule
        - Packing and bulky waste, etc.
        - Don't need the bicycle, want to dispose of it
    - Want to replace the refrigerator
    - (Still in the process of listing...)
```

Regarding memos, it is natural to write them directly in your PTTM file. However, if memos accumulate, they become hard to manage, so review them frequently (daily or on a longer cycle) and process them (by moving them to another tool or rewriting them as tasks). If you find yourself in a situation where PTTM isn’t feasible (for example, if you’re away from your PC and only have your smartphone), use an alternative method for memos. Later, add a task in PTTM to incorporate the memos from your smartphone.

### Do Not Manage Routine Tasks
**Answer:** Routine tasks (【ルーチンタスク】 as described in habit#ルーチンタスク) should also be managed using a separate tool.

For instance, if you need to take out combustible trash every Tuesday and Friday, you would have to check every day (or at the end of the previous day) if it’s Tuesday or Friday, and if so, add the “take out trash” task (or delete it on other days). This is exceedingly tedious. Routine tasks should be handled with a dedicated tool.

## Concepts

### Introduce a Daily Task List
**Answer:** You should definitely introduce a daily task list (a “today’s tasks” list).

As described in the strategy section regarding the “Dailer” (strategy#dailer), dividing your task list by day is highly recommended. For example, if today is 2024/07/31, create a section labeled `■2024/07/31` for today’s tasks, and once you complete the tasks in that section, you’re done for the day. Tomorrow, move the section for 2024/08/01 to be today’s section. This establishes a clear endpoint for each day, which is important because people need a sense of closure to avoid burnout.

### Introduce an “Ambiguous Sense of Dates”
**Answer:** Instead of dividing tasks strictly by dates like 2024/07/31, 2024/08/01, use categories like “Today” and “Future.”

When dividing your tasks by day, you might struggle with how to segment them. There are primarily two approaches:
- Dividing by exact dates: 2024/07/31, 2024/08/01, 2024/08/02, etc.
- Dividing by meaning: categories such as Today, Future, Next Week, etc.

Using exact dates is visually clear but can be labor-intensive to maintain. You might have to create separators for dates that haven’t occurred yet (e.g., writing out `■2024/08/25`), and you might also need to move today’s section to the top each day.

Using semantic categories reduces maintenance but can lead to ambiguity about the exact execution date (i.e., the “starting date”), which might cause tasks to be postponed indefinitely.

If possible, I recommend the date-based approach, but if maintenance becomes too onerous and discourages you, a semantic approach is acceptable. For example, using “Today” versus “Future” may be preferable. The vague nature of dates might make you more likely to procrastinate.

Below are examples of both methods (the examples were generated by ChatGPT). Compare them:

```
Date-based

■2024/07/31
- Presentation preparation
- Development environment setup
- Progress report

■2024/08/01
- User testing
- Bug fixing
- Specification update
- Team meeting
- Brainstorming new feature ideas

■2024/08/02
- Project plan review
- Team brainstorming
- Presentation delivery
- Client feedback review
- Bug fixing
```

```
Meaning-based (with vague date sense)

■Today
- Presentation preparation
- Development environment setup
- Progress report

■From tomorrow onward
- User testing
- Bug fixing
- Specification update
- Team meeting
- Brainstorming new feature ideas

- Project plan review
- Team brainstorming
- Presentation delivery
- Client feedback review
- Bug fixing
```

With the date-based approach, you might also group tasks by week or month instead of by day. This reduces maintenance but sacrifices daily precision.

With the semantic approach, you can use blank lines or separator lines to indicate a broader time span. For example, more blank lines might indicate a longer interval:

```
■ From Tomorrow Onwards
- User Testing
- Bug Fixes

- Specification Update
- Team Meeting


- Brainstorming New Features
- Project Plan Review
- Team Brainstorming



- Presentation Delivery

- Reviewing Client Feedback
- Bug Fixes
```

Alternatively, if you prefer not to have a very tall layout, you can use separator lines (using `|`, `-`, or `=`) to indicate intervals:

```
■ From Tomorrow Onwards
- User Testing
- Bug Fixes
|
- Update Specifications
- Team Meeting
||
- Brainstorm New Features
- Review Project Plan
- Team Brainstorming
|||
- Presentation Delivery
|
- Review Client Feedback
- Bug Fixes
```

### Standardize Your Format
**Answer:** In PTTM, visual clarity is crucial, and that clarity comes from a consistent format.

Since PTTM uses only plain text—i.e., only characters—it lacks the visual aids of images or diagrams. Even if you are a fan of reading, text related to tasks can seem bland and unengaging. Facing such unappealing text every day might cause you to give up. Therefore, it is important to standardize your format to reduce visual strain and workload.

Decide on a layout (for example, using `■2024/07/31` for date sections, writing one task per line, and using symbols like `- ` or `・` for tasks) and stick with it. Although it might be challenging at first, eventually your eyes will adapt, and you will be able to read the text quickly. Standardizing your format is an investment that will help ensure the longevity of your PTTM system.

By the way, you don’t have to create your own format from scratch. You can use an existing syntax like Markdown or even borrow someone else’s method. If you’re not entirely satisfied and want to experiment, that’s fine too. The process of trial and error will eventually make you attached to your system, which can be a great motivator when the system feels like a chore.

### Use Half-Width Spaces Exclusively
**Answer:** When inserting spaces for indentation or visual separation, always use half-width spaces.

There are many occasions when you’ll use spaces to indent tasks or adjust layout, and there are two types: half-width spaces (" ") and full-width spaces ("　"). I recommend using half-width spaces exclusively. Full-width spaces tend to cause various issues in digital contexts and offer little benefit. For instance, if there are two types of spaces, searching can become more complicated, and operations like adjusting the indentation of multiple lines in your editor might not work correctly if full-width spaces are used.

If you need wider gaps, you can simply use multiple half-width spaces. And if you absolutely need a full-width space (for instance, in some literary contexts), you can usually insert one by pressing Shift + Space (in Google Japanese Input, for example).

To ensure that only half-width spaces are used, check your IME settings. They should provide an option for this. (Note: the standard IME on macOS might not offer a simple way to do this.)

# Summary
- **PTTM**
    - Plain text–based task management.
    - The goal is to manage tasks as flexibly as if you were writing freely on paper.
    - To achieve that, you must embrace the digital convention of “plain text.”
- **Tools to Use**
    - There are five key categories: IME, Editor, File Format/Markup, Information Management (i.e., file management), and Helpers.
    - Start with the default IME, a text editor or IDE, .txt files, and ideally a single file.
    - Helpers aren’t essential but can greatly enhance convenience if available.
- **Designing Your PTTM**
    - Use the principles and examples provided in this chapter as a guide to experiment and design your own system.
    - You cannot escape the need for experimentation and regular maintenance.
        - Plain text reading and writing is a lifelong activity.
        - You should become so adept at it that it feels as natural as breathing.
        - Once it becomes second nature, your system will endure; if not, it will likely be abandoned.
