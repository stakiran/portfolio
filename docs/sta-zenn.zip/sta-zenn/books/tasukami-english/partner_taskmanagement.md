---
title: Partner Task Management
---

In this book we will briefly touch on partner task management. As in the previous chapter, the aim is to help readers gain insights or hints by organizing the material from my own perspective.

# Partner Task Management

**Partner task management** refers to the management of tasks carried out in collaboration with a partner. I will not delve too deeply into defining “partner,” but the general nuance is that of a spouse or parent–child relationship. In other words, it is task management used among those who live together continuously, are intimate, or form a small group. I personally picture “family”—especially couples or pairs—but it might also apply to cohabiting roommates, situations that include children, or even polyamorous groups of three or more. In this chapter, I will use the term “partner” with the nuance of a two-person unit; please interpret accordingly.

The tasks addressed in partner task management cover all aspects of daily life. Household chores and childcare are typical tasks, and when it comes to events like moving or traveling, partners often decide together who will do what and by when. There may even be cases where partners work at the same company or run a business together, but that falls under project task management and is not the focus here. Partner task management strictly concerns the management of tasks as an extension of everyday life.

## Familial Debuff

Partner task management is inherently difficult to implement.

As we have seen so far, task management is a burdensome activity that demands a range of skills and literacies—whether it is the method, the mindset, or the tools required. Not everyone is capable of it, and even those who are capable often simply do not want to do it. On the other hand, when it comes to a partner, laziness is often tolerated. There is no need for formality, and it is precisely because of that very nature of the relationship that one becomes a partner.

Consequently, the “cumbersome activities” required for task management tend to be neglected when dealing with a partner, making effective management difficult to achieve in the first place. Many people prefer not to expose their work or expertise to their partner because, on an intuitive level, they understand that highly specialized topics or complicated matters are not easily conveyed between close individuals. I refer to this phenomenon as **Familial Debuff**—a debuff (or weakening effect) that arises specifically in intimate relationships.

# Evolution of Tools

How have the means—the tools—used for partner task management evolved? While I am not aware of any definitive research on this topic, I will share my own observations.

Originally, communication was conducted face-to-face and by telephone. In essence, when together in the same space, requirements were conveyed verbally, and when apart, spot phone calls were made. This is a primitive style that everyone naturally adopted, but it was merely a form of communication rather than task management. Naturally, the scope for actual management was extremely limited. Disputes often arose over “who said what,” and if everything were communicated verbally, it would become tedious—leading either to quarrels or to the speaker having to endure everything.

Later, methods such as beepers and emails—exchanging text messages—came into use, but in essence they were no different from telephone calls. After all, for those who are not tech-savvy, the inability to input text renders these methods ineffective.

I believe the game changer was the advent of LINE and smartphones. With LINE, messages could be exchanged much more rapidly than by email, and one could use stickers to deliver fast and diverse reactions. Moreover, the widespread adoption of smartphones increased the number of people capable of using IT, and these methods began to permeate everyday life. By using LINE, exchanges regarding tasks became much easier to carry out—although limitations remain. For example, there are surprisingly few people who can use LINE in an asynchronous manner (i.e. sending messages at their own pace and replying when convenient); most tend to respond immediately to notifications. Modern users, influenced by social media, are predisposed to react quickly to notifications, and as noted earlier regarding [exclusive ownership](project_taskmanagement#専有の管理), adopting an asynchronous mindset requires a high level of sophistication. Ultimately, these methods still do not transcend the basic level of what can be achieved by face-to-face conversation or telephone calls.

Face-to-face conversation, telephone calls, email, and LINE—these are all communication tools. It is difficult to manage tasks using only communication tools. So what is the solution?

Couples with high-level skills—such as life hackers, engineers, or designers—began to experiment. I believe that Slack was the first tool to really capture attention in this space. Slack is a type of “business chat” similar to Microsoft Teams, but it was launched before Teams and was originally designed as a lightweight, highly customizable chat tool for engineers. Unlike LINE, Slack allows you to create dedicated channels for different purposes and makes searching for messages much easier (after all, SLACK stands for Searchable Log of All Conversation and Knowledge). Its integration features also enable you to pull in information from various services, turning it into an information hub. It offers features such as reminders and bookmarks. Slack shows considerable potential for task management. It is especially convenient for storing and exchanging information; for instance, if you want to plan a trip, you can create a travel planning channel to share research and ideas. This mode of operation has been referred to as **Couples Slack** or **Partner Slack**. There was even a version known as **Solo Slack** for individual use. A similar approach is possible with Discord—the differences with Slack reportedly lie in the quality of voice chat and more refined notification features.

Before long, dedicated apps also began to appear:

- [TimeTree](ref#timetree)  
  - An app that allows you to create, share, and communicate about schedules.
- [Cross](ref#cross)  
  - A ToDo-sharing app designed for couples.

These apps capture the essence of partner task management. For example, they offer a calendar view for a holistic overview, provide access to individual tasks, and allow you to chat about individual tasks. They are designed for ease of use and include an element of communication—a core part of a partnership. Moreover, because communication occurs on a per-task basis, topics do not get mixed together (as they might with LINE, which has only a single channel). Even those who are not familiar with task management tend to find these apps relatively easy to use and useful.

# The 3Cs of Partner Task Management

By now, you may have gleaned a vague idea of the essence of partner task management. Let’s summarize it once again.

The essence can be captured by the 3Cs:

| Name           | Explanation                           |
| -------------- | ------------------------------------- |
| Chat per Task  | Task-specific chat (communication)    |
| Calendar View  | A holistic view via a calendar         |
| Concept        | Differentiation through a detailed concept |

## Task-Specific Communication

As mentioned earlier, partner task management is characterized by a subtle dynamic: because you are partners, you can communicate casually, yet communication alone does not equate to effective task management—and since it is not work, there is no need for formality, so most people are fundamentally reluctant to engage in burdensome task management.

**Chat per Task** addresses this by establishing a dedicated chat (or similar space) for each task.

The level of granularity—that is, the detail of the tasks—should be determined between partners. For example, if you need your partner to pick up a repaired watch:

- In the case of fine granularity:  
  - Create a new task called “Pick up the watch.”
- In the case of coarser granularity:  
  - Create a task for the week of 2024/05/20 and, within that context, send a chat message like “It seems the watch is ready—could you go pick it up?”

The coarsest approach is using a tool like LINE, where there is only a single channel. However, this makes it difficult to manage multiple daily tasks and to search for past information. On the other hand, creating a new task for every single request might also be cumbersome. The optimal level of granularity should be determined through dialogue.

## Holistic View via Calendar

Even those who are unfamiliar with task management will likely be familiar with calendars. It is a very familiar concept—precisely because of that, it is both easy to understand and use.

Many people already use digital calendars for work, and the same applies to partner task management. A shared calendar between partners allows both to input plans collaboratively. Accessible from smartphones at any time, it lets you see not only your own schedule but also your partner’s. If you both know what the other is doing (or planning to do), you can plan ahead and be considerate. **Visualizing tasks is important for showing consideration.** You might even establish rules such as “if there is an unmovable appointment, put it on the calendar,” or “if it’s not on the calendar, assume it’s available for interruption.” While this might feel very businesslike, as the saying goes, “Even among close friends, courtesy matters.” The simplest way to ensure courtesy is to establish clear rules.

## Differentiation through Detailed Concept

There is no single “correct” approach to partner task management. Ideally, you would explore what works best for you, but since it is not work-related, many people may not put in that level of effort. This is where partner task management tools come into play. Developers promote their tools by emphasizing their unique concepts, attracting users by appealing to a particular approach. As a user, it is best if you find a tool that suits you.

For example, [TimeTree](ref#timetree) emphasizes “sharing and discussing schedules” with a focus on the calendar, which can be very helpful for partners with many appointments or those comfortable with calendars. [Cross](ref#cross) is a ToDo-sharing app that offers robust task management features such as categories, reminders, and deadlines, and even provides “to-do sets” for major life events (it also includes a calendar). This app is likely easier for those who prefer to manage tasks on an individual basis. There are also apps like [Housework Name](https://donikatachi.github.io/housework_lp/) and [Yieto](https://yieto.jp/) that visualize household chores, making it easier to tackle domestic tasks.

There are many other apps as well. Although a formal genre of partner task management does not currently exist, apps for sharing or dividing household chores are already common. There appears to be considerable latent demand, and there is ample room for growth. I believe that if designers can create user-friendly designs that even non-enthusiasts can easily use, such apps could quickly gain widespread adoption.

# The Importance of Off-Board Actions

## Off-Board Actions

**Off-board actions** refer to efforts undertaken in the periphery—outside of formal task management—to address issues.

For example, you might ask yourself, “Why are there so many tasks in the first place?” or take steps to eliminate the causes that generate an excess of tasks. In partner task management, the simplest example is to set aside time for discussion. In other words, rather than accepting the tasks right in front of you as the only priority, you should question the very nature of the tasks.

## Partner Task Management Involves Off-Board Actions

In fact, partner task management—in fact, task management in general—is subject to off-board actions. Without off-board actions, you will be completely overwhelmed by daily tasks. While a fortunate turn of events might sometimes rescue you, if not, everything will eventually collapse. In the past, mental toughness and grit were hailed as virtues, but those days are long gone.

However, as human beings we are naturally lazy and tend to think, “It’s easier just to deal with the tasks in front of me,” falling into a state of mental inertia. With a partner, there is no need for reservation, and since it is not work, laziness is more readily justified. As discussed earlier, Familial Debuff is also a factor. Of course, both partners are mature and busy in their own right—but situations in which one is overwhelmed occur very frequently. **They really do occur all too often.** In the previous chapter, I discussed aspects of this under the heading of [Reactive Situations](project_taskmanagement#adjust%2F調整). That is why it is essential to consciously engage in off-board actions.

## How to Incorporate Off-Board Actions

So how can you begin to implement off-board actions?

The answer is simple: **manage tasks specifically for off-board actions.** The simplest method is to schedule time for thinking or dialogue—securing “alone time” in which you are not interrupted by your partner (and vice versa), or to set aside time for both of you to have discussions. If you have already identified the root causes of the issues, you might even create tasks aimed at addressing them. The important thing is to clearly define these tasks or appointments without being overly casual or half-hearted. We tend to promptly handle tasks that are assigned externally, but when it comes to initiatives that we must take on ourselves, we often become resistant. However, if you do not muster the effort, you cannot implement off-board actions. In short, this is where you must start.

Now, please look at the following matrix. To get started, you need to carve out some time. For those of you who want to or already engage in partner task management, consider which of these types of time you can secure—or would like to secure.

|                           | Time Alone for Thinking | Time for Discussions as a Couple |
| ------------------------- | ----------------------- | -------------------------------- |
| 1 hour per week           | 1                       | 2                                |
| 1 hour every few days     | 3                       | 4                                |

The minimum is 1 hour per week. Aim for at least that. If you cannot secure even this, then your situation—whether due to extreme busyness or an inability to coordinate with your partner—is simply untenable, and you must find a way to carve out that time. It all comes down to whether you can create that time.

Whether you choose to have time for individual reflection or for couple discussions depends on your partner. In modern times, many people value egalitarian relationships, so you might aim for more discussion. On the other hand, it might work just as well if one partner does most of the thinking while the other provides feedback. It also depends on the nature of the off-board issues you are addressing.

Think of it like a date or a meeting. For an individual, it might be like going to karaoke alone, attending a concert, or regularly visiting a gym, spa, or massage parlor—activities where you get time to yourself. The same applies to off-board actions. Whether you adopt a casual or a businesslike approach depends on the individuals involved. If it is too casual, meaningful discussion may be neglected; if it is too formal, the off-board tasks themselves may become a burden. The goal is to develop a balance that allows these activities to be both enjoyable and sustainable over the long term.

## Talkability

Up to this point in this chapter, you may have thought, “If we could really have such in-depth discussions, then it wouldn’t be so hard.” And that is true—in all honesty, **very few people possess the aptitude necessary to effectively engage in partner task management.**

One measure is whether you can regularly set aside time for meaningful dialogue. It also depends on whether you have the intrinsic capacity to engage in such conversations. I will refer to this as **Talkability.** If Talkability is high, then partner task management is feasible; if it is low, then it will be difficult. In that sense, if you want to engage in partner task management, it is a prerequisite that you have a partner with high Talkability.

Talkability tends to be higher in work environments and lower in personal life. Many people switch between “on” and “off” modes. This means that someone whose Talkability appears low at home might actually have high inherent Talkability. In such cases, intentionally adopting a more businesslike approach in your personal life might help draw out that potential.

Additionally, even if Talkability is not an issue, there may be cases where you are simply too busy to have discussions. In that case, you might overcome the challenge by reducing your partner’s burden and creating opportunities for conversation. Alternatively, you can start by engaging in off-board actions on your own. Essentially, if you want to make your partner more Talkable, then you must undertake off-board actions to that end.

That said, as mentioned earlier, Familial Debuff is a factor, so be prepared for this to be more challenging than you might expect. Frankly, if you manage to do it, consider yourself lucky; if not, it is likely due to the inherently low probability.

# Summary

- There is a delicate balance in task management between partners.
- The essence can be captured by the 3Cs:
  - **Chat per Task:** Task-specific chat (communication)
  - **Calendar View:** A holistic view provided by a calendar
  - **Concept:** Differentiation through a detailed concept
    - In particular, while the “Concept” category is currently mostly used by enthusiasts, a killer app might emerge in the future.
- In reality, off-board actions are even more important than the task management itself,
  - because without them, you will be overwhelmed by daily tasks.
- Partner task management is inherently a challenging endeavor,
  - partly due to Familial Debuff, which makes even basic communication difficult.
  - The key is Talkability—i.e., having the capacity for meaningful dialogue.
    - Without high Talkability, partner task management is unlikely to succeed.
    - However, there may be cases where a partner’s intrinsic Talkability is high but appears low in a personal context; in such cases, with some ingenuity, it might be improved.
