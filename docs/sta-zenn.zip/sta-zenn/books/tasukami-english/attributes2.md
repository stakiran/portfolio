---
title: Task Attributes(2/2)
---

# ===

# **Descriptive Attributes**
These attributes express the content of a task.

They are expressed through language. In other words, if a task isn’t put into words, it can’t be reflected in a tool. Many have likely experienced difficulty managing “non-linguistic tasks” with digital tools. For example, [physical tasks](strategy#前提知識%3A-物タスク)—ones not clearly expressed in words—are not well handled by current tools. Perhaps in the future, we’ll see image-based task management tools that visualize such tasks, but then the attribute might become “image-based attributes.” This book doesn’t cover such topics.

## Name
The task’s name. Also called the “title.”

“Name” can take many forms: “Move,” “Move to a new place,” “List future housing options,” “Research Hokkaido,” “Ask A about city vs. countryside.” Single words or full sentences are both fine, and more explicit names can make tasks easier to tackle.

Sometimes other attributes are embedded in the name. For instance, [todo.txt](ref#todo.txt) is, in theory, “one line per task with the name,” but you might write a task as `Call client to say thanks` or as `(A) 2017-07-14 Call client to say thanks @phone +HogeProj`. In the latter, priority, execution date, and tags are embedded in the name. Philosophically, there’s no single correct line between “Is it an attribute?” or “Is it part of the name (containing attribute info)?” A clear definition is this: if the tool can do attribute-specific operations (sorting, filtering) with that data, then it’s an attribute. If it cannot—if the data is only read by humans—then it’s not an attribute but part of the name.

Usually, a name is a single line of text, up to about 100 characters. (The 100-character figure isn’t that strict.) If you need more than that, use a “description” attribute.

## Description
Task details. Also called “task notes.”

While the “Name” is usually a single line of text, the “Description” may span multiple lines. You see this more often in robust project-level tools, but it can be overkill for personal task management.

You could embed more attributes in a multi-line Description, but it’s not recommended. Humans can easily miss or ignore attributes buried in paragraphs. For example, if a deadline is July 22, 2024, writing “Please finish by 2024/07/22” in the description is unwise. If you want to treat due dates as an attribute, you should store them as an attribute so the tool can handle them properly.

Note that comments or notes are *features* (Attachments) in the 3A model, not attributes (Attributes). Because features are less tightly bound to tasks, they’re often overlooked in daily task management. If you want them not to be overlooked, consider using the “Description” attribute, which is more tightly integrated with the task. But the flipside is that multi-line text can quickly become lengthy and unreadable. Best practices might be not to use the Description attribute at all, or if you do, keep it minimal or templated so it’s consistent and doesn’t become a burden.

# **Status Attributes**
These attributes express the state of a task.

“Status” typically means something like “Not Started,” “In Progress,” “Complete,” etc.

## Status
The task’s status. In English, it may sometimes appear as “Completion” or “Done,” focusing on the completion aspect.

The set of possible statuses is predefined. A two-status system might be “Open/Closed,” a three-status system might be “Not Started/In Progress/Done,” four might add “Pending,” five might add “Cancelled,” etc. There’s no single right definition, but theoretically, tasks pass through four phases: “Before Start,” “After Start,” “Before End,” “After End.” It can be tricky to interpret, but for instance, “In Progress” is “After Start,” and “Pending” is “Before End” in that framework. “Before End” is ambiguous—it could mean “there is some sign that progress might be stalled or something might fail”—but capturing that as a status is tricky. The best-known example is “Pending,” like “on hold,” “under review,” or “awaiting approval.”

You should at least distinguish between unfinished and finished. Particularly, once a task is done, it’s no longer needed. You should remove or archive it so that your list remains uncluttered. Otherwise, if your list contains both finished and unfinished tasks, every time you look at it you waste cognitive effort deciding which is which. It’s like leaving unused items or trash lying around a room instead of putting them away.

Because updating status is one of the most frequent operations, keep it as low-friction as possible. In a graphical interface, you’d want a single click or tap to change status. In a text-based system, you’d want it done in at most a few keystrokes—for example, changing `[ ]` to `[X]` by typing an “X,” or removing a “!” from “!”-marked tasks to indicate completion. Or you might move tasks from one place to another, but typically we want to see progress (the ratio of done vs. not done), so it’s better not to move tasks the moment you finish them. Doing so at the end of the day or week is more standard.

# **Identification Attributes**
These let you uniquely identify tasks.

## ID
A unique identifier for a task.

Having an ID allows multiple tasks with the same name. For example, you can have Task #1 “Move to a new place” and Task #13 “Move to a new place.” They share the same name but differ in ID. Changing #13’s name to “Help my sister move” won’t affect #1. They are distinct. However, in practice, needing multiple tasks with identical names is rare in task management. IDs are mostly useful if you want to give each task its own dedicated page. If your method is simply listing tasks in a file (like task.txt) for personal use, an ID isn’t necessary.

IDs are represented differently in each tool. Often they’re unreadable strings to avoid collision and to facilitate programmatic handling. Typically, end users rarely see them, though they might appear in URLs. Or you might see a simpler approach like “#1,” “#152,” etc.

## Number
A number assigned to a task.

A number is essentially a type of ID with an ordinal nature (a “sequence”), meaning smaller numbers typically imply earlier execution. So the key difference is that an ID is simply unique, whereas a “number” implies an order.

A typical example is [TaskChute](ref#タスクシュート) (the Excel version, in simplified form). There, tasks are frequently sorted by name or ID to maintain order. To reorder tasks the way you want, you simply modify the leading text to `001`, `002`, etc. With ascending sorting, tasks with smaller numbers appear on top. By padding with zeros (`001`, `002`, etc.), sorting is consistent. TaskChute automatically assigns numbers to tasks, but if a user wants a certain task to appear earlier, they can change its number to `001`, ensuring it sorts to the top. This is a technical case, but a simpler one could be the example in the [Attributes](#属性) section, where you assign numbers manually.

You should decide how to handle collisions if two tasks share the same number. In TaskChute, the tool looks at another attribute next, while in the simpler example earlier, tasks with the same number can be done in any order.

# **Date Attributes**
These tie a specific date to the task.

Date formats vary—240722, 20240722, 2024/07/22, 2024-07-22, 2024/07/22 (Mon), July 22, 2024 (Mon), etc. They all represent the same date. In tools, the system might automatically format them for readability, but if you’re writing dates manually, a simple numeric format is usually easier. Some digital platforms will auto-insert the current date for you.

We usually omit weekdays. Once you have year/month/day, you can calculate the weekday, but sometimes seeing the weekday is helpful for orientation. Yet showing the weekday all the time can waste space, especially in a one-line-per-task format or on small mobile screens. In many cases, it’s omitted.

*(Note: We won’t cover time zones or other advanced topics here. This book assumes JST (Japan Standard Time).)*

## Starting Date
The date to start the task. Also referred to as the “Execution Date.”

For example, if a task has 2024/07/22 as its Starting Date, it indicates the task is scheduled to start on that date.

This attribute helps with two things: planning and postponing. In planning, you might break a larger goal into smaller tasks—Task A on July 22, Task B on July 23, Task C on July 24—and arrange them accordingly. In that sense, it conveys an order, much like a “No.” attribute. Also, consider postponing in the [Dailer](strategy#dailer) approach: each day has a list of tasks for that day, and if you decide to move Task D from July 22 to July 24, you change the Starting Date to 7/24, so it reappears on your July 24 task list when that day arrives.

A calendar is basically a grid-based way of displaying tasks that have a Starting Date (and often a Start Time). Obviously, it’s very convenient to see a weekly or monthly overview of tasks. This is only possible because the concept of “Execution Date” is established. There are other ways to get an overview—like maintaining a sorted list by date or ignoring order entirely—but ultimately, it’s about whether you can keep it up. Rational approaches don’t necessarily mean you’ll stick to them. If you can’t maintain it, it’s pointless. So, ironically, sometimes a slightly irrational method that you personally find comfortable is better. If we’re strictly discussing efficiency, though, calendars (or at least ordered views by date) remain the best for overviews. Nothing has surpassed them so far. If your tool doesn’t include a calendar view and you still want an overview, you’ll need to build or link one (via an API, for example). 

## Creation Date
The date the task was created.

For personal task management, you typically don’t need this. It might seem useful—by seeing creation date, you know how long a task has lingered. Then you could raise its priority or discard it if it’s getting stale. But checking each time is cognitively expensive, so the cost might outweigh the benefit.

That said, if you automate it, it can be helpful in certain scenarios. If the tool automatically timestamps tasks and calculates how many days have passed since creation, you could incorporate that into a workflow: “If it’s been X days with no progress, then follow up or remove.” That’s handy if you’re dealing with a large volume of tasks that often sit idle. For most personal task lists, though, it’s not necessary. In bigger projects, it’s more common. For example, in open-source projects on GitHub, new issues pour in daily. Maintainers don’t have time to check them all, so they create bots that automatically close issues with no response after 14 days, etc.

## Due Date
The task’s deadline or completion target date.

What “deadline” means is up to the user. It could be just a guideline or a strict date that you must not miss without reporting.

For personal task management, due dates often become meaningless. You can just use Starting Date for the same purpose. For instance, if Task A has a due date of July 22, 2024, you might assume you’ll do it on July 22, 2024, anyway. If the task is too large to finish in a single day, break it down further. For example, A might become A1, A2, A3, each taking one day: July 19, 20, 22. If done right, you don’t need a separate due date attribute. People often add a due date only to find it’s easily ignored if they lack external pressure.

Due Date is crucial in professional or project-level settings. You typically define deadlines for each task to manage overall schedules. Then you can see that Task B has only two days left, so you’d better follow up. This is easier when tasks are well-defined with a set due date, and it’s common in traditional project management. Modern agile approaches don’t rely as much on rigid planning, so you might skip due dates altogether. Instead, you might plan in weekly or biweekly sprints, effectively needing a “Execution Week” attribute (though that’s rarely found in any tool). Something like [GitHub Issues’ Milestone feature](ref#github-issues) approximates that concept.

## Completion Date
When the task was finished.

Knowing the Completion Date helps with [retrospectives](furikaeri). If you operate in cycles (like weekly sprints), each cycle’s retrospective can examine tasks completed during that period. This can be compared to the due date to see if you met deadlines, or to the creation date to see how long it took. Or, you could compare it to the execution date to see if it was done on time. Still, these metrics are only rough guides—if you had one tough task or a day you felt ill, your pace can fluctuate. Nonetheless, if your tasks are mostly “work-like” and you want to measure productivity, the Completion Date might be useful. If you don’t need it or your tool doesn’t help you analyze it, ignore it.

The Completion Date can replace a status attribute. For instance, in [todo.txt](ref#todo.txt), you can write something like:


```
YYYY-MM-DD YYYY-MM-DD Buy a box of tissues
```

The first date is the completion date, the second is the addition date. For example, `2024-07-22 2024-07-18 Buy a box of tissues` means you added the “Buy tissues” task on the 18th and finished it on the 22nd.

# **Time Attributes**
These attributes involve *times* rather than just dates.

They are used to manage tasks at finer granularity than days—down to hours, minutes, seconds.

## Section
Represents the time slot for executing a task.

A Section is basically a “time-of-day” version of a Starting Date. A Starting Date groups tasks by day; a Section goes a step further, grouping tasks by time segments within the day. If you want even finer granularity, you’d use a Start Time. We have three levels: day, time block, or exact times. Section is the second level. It’s less common, but people do live according to certain rhythms, often segmented by time blocks. See the [Containers chapter](container#セクション) for more.

There’s no single right set of Sections. Maybe just “Morning,” “Afternoon,” “Evening,” “Night,” though that might be too coarse. If you work in a company, you might define them as “Before Commute,” “Commute In,” “Work (AM),” “Lunch Break,” “Work (PM1),” “Work (PM2),” “Commute Out,” “After Work,” “Before Bed.” Weekend patterns might differ. Traveling or business trips could break the pattern entirely. If you want simpler labeling, you could lump all working hours into a single “Work” section. It’s all customizable, so your tool should let you define them freely.

[TaskChute](ref#タスクシュート) is a tool that uses the concept of Sections.

## Starting Time
When you start a task.

*(This section will also cover time-tracking.)*

Paired with an End Time, a Start Time lets you calculate how long the task took. Doing so manually is possible (End Time minus Start Time), but frequently recording them by hand is tedious and prone to “tool fatigue.” Automation is key. The best current practice is to start a timer with one click or tap. (Voice commands might become practical soon, letting you start tasks hands-free.)

Having Start and End Times reveals “time spent,” but that alone is meaningless unless you review or visualize it later. That’s also best handled by the tool. Specialized solutions exist—[Toggl](ref#toggl), for instance—and some general task managers incorporate time-tracking ([TaskChute](ref#タスクシュート) etc.). Another approach is a simple timer that doesn’t label tasks, such as those used for the [Pomodoro Technique](ref#ポモドーロ・テクニック).

You should decide how to handle parallel tasks. Many systems do not allow or recommend overlapping tasks because it complicates calculations. For instance, if you run tasks A and B simultaneously from 9:00 to 12:00, you have 3 hours total, but naive tracking might sum them to 6 hours. That could be intentionally used to measure your multitasking level, but realistically it’s too much trouble to meticulously track every parallel task’s start and end times (especially since parallel tasks often occur in busier moments when you have even less time or mental bandwidth to track them). 

It’s best to measure in seconds internally, because tasks can sometimes last under a minute. If you only track minutes, short tasks might get recorded as 0 or 1 minute, introducing up to 1 minute of inaccuracy each time. If you often have 15 sub-minute tasks, that could be a 15-minute discrepancy. Internally counting seconds is more precise, though you might want to display total time in minutes. Some users do like second-level detail, so ideally you could toggle between seconds and minutes.

## End Time
When you finish a task.

If tasks are done sequentially, you could automatically set a task’s end time to the next task’s start time, eliminating the need for an explicit “end” operation. For example, if you start Task A at 10:37 and start Task B at 11:03, the system can mark A’s end time as 11:03.

You can also decide whether to prompt additional actions upon finishing a task. For example, [TaskChute](ref#タスクシュート) uses a “do” concept, letting you briefly reflect or note your impressions upon finishing. Time-tracking tools often focus purely on capturing start/end times without reflection. If you need quantitative data for analysis, you might not want to distract yourself with extra input; if you want a more qualitative approach, you might want a small reflection each time. 

There are more possible design optimizations. For instance, you might add a “Restart this task” button to quickly begin the same task again, or a feature to pick a recently finished task and start it again. The end time marks the moment you transition to the next task, so any support features that seamlessly let you pick or start the next task can greatly improve the experience. This is a place for developers to show ingenuity.

You should also decide how to handle canceled tasks—that is, tasks that started but didn’t continue. Do you delete the start time, or keep an end time to mark it as quickly aborted? It’s helpful to track canceled tasks as part of your data. If you want to preserve that info, you could add a special cancellation mark. Alternatively, if your system prompts a note upon finishing, you can just note “canceled.” 

## Estimation Time
Your estimate of how long the task will take. Sometimes called “Expected Time.”

By estimating how long tasks will take, you can do better planning. If each task has an estimated duration, you can see whether they fit into your schedule. For example, if you plan tasks A (30 minutes), B (45 minutes), and C (45 minutes) sequentially, you assume a total of two hours. If A actually takes 40 minutes and B 50, then you’ve used 1.5 hours already, leaving only 30 minutes for C (but you estimated 45). That signals possible trouble. Estimating is a deep topic, beyond the scope of this book. But to do it at the task level, you need this “Estimation Time” attribute.

When using a “daily task list,” if you estimate the duration of every task, you know roughly when you’ll finish for the day. That’s psychologically beneficial (“the end is in sight!”). But you only get that benefit if you estimate *all* tasks. Doing just one or two is pointless. So it’s basically “All or Nothing.” The [Excel version of TaskChute](ref#タスクシュート) historically promoted this concept, though the current web version might differ.

## Actual Time
The time actually spent on a task.

You can calculate it from your Start Time and End Time. Strictly speaking, it depends on accurate logging. If you forget to stop the timer until 14:00, even though you finished at 13:10, your recorded time is off by 50 minutes. Of course, you can fix it if you remember.

# **Recurring Attributes**
These define how a task repeats.

In task management, tasks that repeat on a schedule are called [routine tasks](habit#ルーチンタスク). A routine task has special logic about when to show up—like “every two days” or “every Wednesday.”

To clarify, you typically need a “Daily Task” concept. ([Starting Date](#実行日%2Fstarting-date) can do this if you create a new list each day.) Then the question is, on which day(s) should a repeating task appear? That’s what recurring attributes handle.

In practice, there are different ways to “generate” or “place” these repeating tasks. The simplest is the “Set all firstly” approach, common in calendars: once you set a recurring rule, the event is placed on all future applicable dates. If you see a date you don’t need, you can delete that instance. Another approach, “End and Set,” used by [TaskChute](ref#タスクシュート), creates the next instance only upon finishing the current one. If your tool can’t handle infinite future recurrences, you do it one at a time. There’s also a “Counter” approach seen in [Habitica](ref#habitica) or habit trackers, which basically show the routine every day and let you decide whether you do it. That’s simpler but also more cognitively demanding and less effective at sophisticated routine scheduling.

Here’s a quick summary:

- **Set all firstly**  
  - Based on the recurring attribute, place the task on *all* future applicable dates.  
  - Works when your system can handle abstract recurrences (like a calendar).  

- **End and Set**  
  - When you mark a task complete, generate the next instance based on the recurring settings.  
  - Use this if you can’t do “Set all firstly.”  

- **Counter**  
  - Always display the task daily, and rely on the user to decide each day.  
  - Doesn’t truly leverage recurring attributes, simpler but not robust for routine tasks.

If you want Task A to appear on day D, you set its Starting Date to D. For instance, if today is Wednesday, July 24, 2024, and you have a routine task “Take out burnable trash (@Monday & Friday),” the next instance should appear on Friday, July 26, 2024. Conceptually, the routine logic sets A’s Starting Date to 2024/07/26. This perspective helps you manage tasks precisely. For example, if you want to skip trash day this Friday, you just delete the instance for 7/26. 

## Repeat Frequency
How often the task recurs.

You can express it like “every n days, repeated x times.” For example, “once a day (every day),” “once every 2 days,” “once a week,” etc. Typically, x=1 is all you need, meaning “one instance every n days.” If you want “twice a day,” just make two separate tasks with the same daily frequency, each assigned to different time segments if needed. Try to keep daily-and-beyond frequency out of this attribute so it doesn’t become complicated.

Still, some real-world patterns are tough to express: “every weekend,” “the 30th of every month,” “the last day of the month,” “the second Wednesday.” You might need a more advanced approach with [Repeat Condition](#繰り返し条件) for that.

## Repeat Condition
Conditions to determine on which days a task repeats.

The Repeat Condition attribute handles subtler patterns that Repeat Frequency alone cannot. For example, a weekly frequency might not capture “Every Wednesday and Friday,” or “Every last day of the month,” or “Every second Wednesday,” or “Company holidays,” etc.

For users, the tool must provide a user-friendly interface (like a calendar or a set of checkboxes for Mon/Tue/Wed/Thu/Fri/Sat/Sun). For developers, it’s challenging, especially if you allow for localized or custom rules. If you do want a fully-featured solution, you must handle date calculations robustly, ensure no missed recurrences, and thoroughly test it. Recurring tasks in a precise manner can be a bit of a “Japanese cultural phenomenon” (like ultra-punctual trains), so its global demand may be smaller, but if you want to do it, you’ll need to implement it carefully.

A handy trick is **Manual Listup**—letting the user manually pick the dates on which the task should appear, maybe by selecting from a calendar. You can combine it with standard rules as a baseline, letting the user add or remove exceptions. This can get complicated if you do it every week or month, so you might schedule a weekly or monthly reminder to confirm the routine.

# **Classification Attributes**
These indicate certain characteristics of a task and allow filtering.

The key purpose is to enable filtering. If Task A has classification item X, you can display tasks with “X.” This is crucial when you have dozens, hundreds, or even thousands of tasks.

Keep in mind that we’re *not* talking about [Relationships](#関係) here. For instance, “Category” might look like a container structure, but that’s a different concept. In a Relationship (like parent-child), you have tasks containing tasks. In a Classification Attribute (like category), you have a taxonomy or label system. Parent-child is about visual structure and flow, whereas classification is about filtering.

You can also use other attributes (like date attributes) as classification for searching or sorting. But classification attributes are more flexible than time-based ones. The downside is that they are easy to misuse or overcomplicate.

Even analog tools can use classification attributes. [Bullet Journals](ref#24) place icons at the start of an entry (“rapid logging”), and [Ana-Kichi Techo](https://techo.ana-kichi.com/) might have an area for “Things you can do when your spouse isn’t around,” where you stick relevant Post-it tasks. Using icons or separate areas is effectively classification.

See also the [Containers chapter](container) for more detail.

## Category
A classification attribute that allows exactly one choice per task.

A Category is basically a single-choice Tag. Deleting a category doesn’t delete the tasks inside it (like a parent node would). Instead, the tasks just lose that category label. If you actually want to delete tasks within a container, that’s a [Relationship](#関係), not a classification attribute.

Typically, you want easy CRUD (create, read, update, delete) for categories so the user can manage them. However, categories shouldn’t be used as casually as tags. They’re meant for more formal classification. Because only one category can be assigned to each task, you must carefully decide which category a task belongs to. This strictness can be either good or bad, depending on your style—some people prefer the freedom of multiple tags.

## Tag
A classification attribute allowing one or more choices per task.

You can attach multiple tags to a task, similar to how you might use #hashtags in social media. Each tag is like a label describing some facet of the task.

In typical social media contexts, “the more tags, the better” might be true for discoverability, but in personal task management, that’s not necessarily so. Here, the main point is filtering. You want to be able to recall, “What was that tag again?” or quickly find it in a short list. If you assign too many tags, you might forget them or clutter your display. Unlike categories, tags don’t require rigorous design, but you still need some restraint. One rule of thumb: imagine you had to pay a small fee (10¢, 20¢, etc.) every time you create, rename, or delete a tag—this might make you more deliberate, which is beneficial.

In theory, you can represent any other attribute as a tag. For example, if your tool doesn’t support an Execution Month attribute, you could create tags like “2024/07,” “2024/08,” etc. Then tasks with “2024/07” are those you plan for July 2024. Filtering is possible but limited. If you wanted “All tasks for July 2024 or earlier,” you’d need to specify multiple tags (2024/07, 2024/06, 2024/05, etc.). It’s cumbersome and often leads to neglect. Generally, if you want a real attribute, find or build a tool that supports it rather than hacking tags for it.

## Label
A classification attribute (single or multiple) with color-coding.

A Label is like a colored tag, combining a name and a color, making it visually easier to spot. [GitHub Issues](ref#github-issues) is a typical example in bug-tracking systems. You might mark severe bugs with a red label, duplicates or unneeded issues in gray, etc., quickly scanning by color.

Labels are great for quick visual identification. Emergency triage uses four colors (black, red, yellow, green), letting responders see at a glance the patient’s status. Language would take longer to read. People generally parse colors faster than text. However, in personal task management, that kind of real-time speed is rarely needed. It’s more relevant in a busy project environment with hundreds of tasks, or in life-critical contexts like triage.

Ideally, you use Labels specifically for a quick visual. While you can also filter by label, that can become confusing if you treat them just like ordinary tags. If your tool offers both standard tags (without color) and colored labels, a good approach is:
- Use tags for filtering.
- Use labels for quick visual scanning.

If your tool only has labels, you can repurpose white or neutral-colored labels to mimic tags.  

## Star
A simple classification attribute you can toggle on or off. Also seen as “favorite” or “bookmark.”

Unlike categories or tags, you typically can’t create custom “star types.” It’s just one attribute, on or off. That means you can filter tasks to show only “Starred” ones. Its ability is strictly narrower than categories or tags, but it’s extremely simple—no CRUD overhead.

You often see this in simpler tools (not necessarily for tasks). Slack, for instance, lets you bookmark a message. Then you can see a list of your bookmarks. It’s basically the same concept. This star-like feature is convenient but not as flexible as tags or categories.

Commonly, you might use a star for “inbox” or “to read later.” Email or chat often has a concept like “unread.” Under the hood, that’s just a star that gets automatically turned off once you open it, or turned on if you mark it unread. That’s the essence of the star attribute.

The star is easy but can easily become meaningless if you never turn it off. For example, if you mark a task “will do later,” you have to unmark it once done, which might be too much trouble. Even a single click can feel burdensome. So email clients often remove the star automatically when you open an unread message. If you truly want to keep it, you re-mark it manually. This may seem counterintuitive—some people want to control it themselves. But in practice, that leads to a buildup of starred tasks that are no longer relevant, a path to neglect and confusion. If you’re developing a star attribute, consider the user experience around turning it off. Email apps are instructive: an email is basically a “task,” and toggling unread is basically a star. They implement a variety of advanced settings. Chat tools and social media can also be references for star or bookmark design, but email clients are closer to the concept of tasks. They’re just not displayed in a super refined way.

You *could* replicate a star with categories or tags, but that typically defeats the star’s simplicity and speed. For instance, part of the star’s power is automatically unstar or automatically mark read. That’s not easy with manual tags. As mentioned in the tags section, if your current tool lacks a star feature but you really want it, you might consider using a different tool that supports it properly, rather than forcing a pseudo-star solution. This is the **paradox of tools**: ironically, using multiple specialized tools is often more sustainable than a forced compromise in a single tool. Just like in a kitchen, using both a knife *and* scissors (rather than just one tool for every job) is more efficient.

## Priority
A classification attribute where one value can be assigned to each task.

Priority is used to set an order of importance—e.g., “High, Medium, Low,” or “Critical, Important, Normal,” etc. This allows you to filter or highlight tasks by urgency.

Priority has many possible value sets: High/Medium/Low, or 5/4/3/2/1, or in bug tracking, “Emergency/Alert/Critical/Error/Warning/Notice,” etc. There’s no one right approach.

For **personal** task management, we usually don’t use a formal “Priority” attribute. It’s more suitable in a **project** context with multiple people. That’s because priority labeling benefits from consistent criteria—like “High if it meets these conditions,” “If you mark High, you must assign an owner and alert the group in chat.” You need that level of operational clarity. If you’re by yourself, that’s overkill. Many people set priority subjectively, but it often drifts (one day a task is “High,” the next day they forget and mark a different way). If you want a quick indicator of something important, a star might suffice.

## Trigger Context
A classification attribute (single or multiple) indicating the situation in which the task can be triggered.

See the [Contexts chapter](context#トリガーコンテキスト) for details.

Tools rarely offer a dedicated “Trigger Context” attribute. Often you’d just use tags or labels named “Traveling,” “Partner is out,” etc. Tools like [OmniFocus](https://support.omnigroup.com/doc-assets/OmniFocus-iOS/OmniFocus-iOS-v2.6.0.0/ja/EPUB/xhtml/08_contexts.xhtml) (GTD-based) call them “Contexts,” and [TaskChute](ref#タスクシュート) might call them “Modes,” but the core idea is the same.

While you *can* assign multiple contexts to a single task, you might want to limit it to one. Because if you have two contexts—say “Traveling” and “Partner Out”—then every time you’re traveling or your partner’s out, that task will appear in the filtered list, forcing you to reconsider it repeatedly (increasing mental load). If you have many tasks with multiple contexts each, your filtered lists balloon in size, leading to a classic “long to-do list meltdown.” So it’s best to be conservative.

# **Subjective Attributes**
These express personal feelings or impressions about a task.

They aren’t “objectively correct” or “strictly consistent.” They’re meant to capture how you *feel* about tasks at the time. They aren’t particularly reliable records, but they can still be valuable references for yourself.

They should be **quantitative**. If you start letting people type sentences or phrases as “impressions,” that’s more of a [descriptive](#記述系属性) or [feature-based](#機能) approach. (※1) If you have a fixed set of words or emojis, effectively you’re picking from a numeric or enumerated scale. Why emphasize numbers over free text? Because we want to keep reading and writing overhead minimal. If you rely heavily on text, you risk higher cognitive costs, often leading to burnout.

- ※
  - 1 If you want to store textual impressions, you might create an extra “Notes” attribute. As long as you keep it minimal or well-structured so it’s not too demanding, that’s fine.

## Importance
The importance level of the task.

Importance aims to highlight what’s most meaningful to *you*, prompting you to give it extra attention. People often lose track of what’s important or fail to realize it. This attribute forcibly surfaces importance.

In practice, you might define importance in the same manner as “priority.” Indeed, “Importance” is effectively “priority based on subjective judgment.”

The yardstick is personal. It might change day to day. Yesterday you labeled a task “low,” but today you see it as “high.” That’s okay. Resist the urge to define rigid criteria. It’s intentionally subjective—if you want consistency, use the “Priority” attribute and formal rules.

There’s no absolute definition of “important.” The well-known [Time Management Matrix](ref#時間管理マトリクス) offers no universal standard for “important.” It depends on the individual.

“Important” shouldn’t be conflated with “urgent,” “profitable,” “rare,” etc. Those are different considerations. You may feel a task is important even if it’s not urgent, or you might sense it’s urgent but not personally important.

Even if a task is “important,” what you actually do about it varies. Some might prefer to handle it immediately, but that’s more about urgency. If it’s important but you can’t take action yet, you might simply note or plan it for later. Usually in task management, you want to ensure you do *something*—like schedule the next step, set a personal rule, or keep it in a special list—rather than let it vanish.

## Difficulty
How difficult you perceive the task to be.

Marking a task’s difficulty can help plan your approach. If it’s hard, you might allocate extra focus or resources; if it’s easy, you might handle it whenever. Some people prefer doing easy tasks first, while others tackle hard ones first. At least you have the option to filter or group tasks by perceived difficulty. Also, “difficulty” can correlate with how many relevant context factors you have in mind. Sometimes you might do a “batch approach” ([Mixer](stance#ミキサー)) for tasks with similar difficulty levels.

Defining difficulty is similar to defining priority or importance. “Difficulty” is basically “priority labeled by perceived hardness.”

No single correct definition of difficulty exists. It might be about uncertainty, technical challenge, time constraints, emotional preference (like/dislike), the complexity of required recall ([Road Context](context#ロードコンテキスト)), or external constraints (location/time restrictions). Each person will interpret “difficulty” differently.

Note that difficulty is intended as a *beforehand* rating, not a reflection after finishing. You typically wouldn’t wait until a task is done to say “it was actually easy.” Difficulty is about your expectation going in (※2).

- ※
  - 1 People differ on how personal likes/dislikes affect difficulty. Sometimes you dislike something, so you do the bare minimum, ironically making it “easy.” Or you love something so much you over-invest time, making it “hard.” It’s subjective.
  - 2 In principle, you could track a “predicted difficulty” *and* a “post difficulty.” Then you could compare them, a form of estimation. People usually do time-based estimation, but you could theoretically do difficulty-based. That’s speculative, though, and there’s no known tool that does this. If I invented one, maybe I’d call it “Difficulty Driven Work-style,” but we’ll leave that as a thought experiment.

# **Collaboration Attributes**
These define who’s involved in the task.

These are more relevant in multi-person [project task management](project_taskmanagement). We only cover them briefly since this book primarily addresses personal task management.

## Assignee
Who is responsible for executing the task.

The “Assignee” attribute ensures you know who is in charge of completing it (changing its status to done). It also allows each person to filter tasks assigned to themselves. In a project, there can be many tasks, so searching by “Assignee = me” is critical.

## Owner
Who created the task.

An “Owner” attribute is typically recorded automatically. In most cases, it’s not heavily used. It only matters if, for example, you need to track who introduced a problematic task. But if you find you’re referencing “who created it?” often, it might mean your workflow is too complicated or entangled in politics. That doesn’t necessarily mean politics is unjustified—some contexts might require it.

## Contributor
Who contributed to the task.

This is helpful in contexts where a single task record (e.g., in a bug tracker or “BTS”) might hold extensive discussions. You can see at a glance who participated in that discussion, letting you decide what to read. In a high-volume environment, sometimes you judge an item’s importance by who’s involved. 

“Contributor” is best recorded automatically whenever someone posts a comment or modifies the task. It’s visually effective to show user icons (avatars) on the task. Possibly you might even show them in a task list for quick scanning. The benefit: you can skim for tasks involving certain people, which reduces reading time. The downside: it can intensify workplace politics, as people might focus only on tasks by “favorite” or “important” individuals. This is the **Contributor Attribute Dilemma**—the tension between efficiency and politics.

## Subscriber
Who is “watching” or “following” the task. Sometimes called “Watcher.”

“Subscriber” is about receiving notifications when the task is updated. If you subscribe to Task A, you’ll be notified whenever something happens on A. This is useful for tasks that rarely update but are important to you, or critical tasks where you need real-time awareness. Of course, over-subscribing can lead to notification overload. Use it selectively.

We haven’t really seen a mainstream approach that fully leverages subscriptions as the backbone of a task management system (※1).

- ※
  - 1 This area might be worth exploring. We know from RSS readers and SNS that “subscribe and read updates in chronological order” is valuable. Yet we don’t see it much in task management systems—particularly in bug trackers or project boards. Possibly a system that uses subscription as a core concept would be a “killer app.” It might be especially useful in modern, self-organizing teams (like “Teal Organizations”) where people float among various tasks. Currently, that often requires everyone to be physically present or always on Slack. If we had a subscription-based task environment that neatly shows “tasks I’m following, sorted by latest update,” that could replicate real-time awareness in a remote setup. [Scrapbox](ref#scrapbox) plus some filters and “sort by modified date” can approximate this. There’s potential for a dedicated solution, though we haven’t seen a widely adopted one yet.
