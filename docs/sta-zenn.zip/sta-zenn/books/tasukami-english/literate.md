---
title: Literate Task Management(1/2)
---

Recently, one concept has begun to stand out in the field of task management. If one were to give it a name, one might call it “literate task management.” Literate—in other words, it is a way of managing tasks that is based on the act of writing.

In this chapter, I will organize my thoughts on the concept of literate task management.

# Overview of Literate Task Management

## Literate Task Management

**Literate Task Management (LTM)** refers to task management conducted in a literary or writing-centered manner.

Please understand “literary” here simply as “the act of writing.” It naturally goes along with things like notebooks or memos. There is no requirement for artistry. In other words, LTM means managing tasks through the process of writing for your own use. Whether it’s a diary, a journal, or a record of thoughts, as long as you are continuously writing **for yourself** and including your tasks within that writing, it counts. Of course, task management requires a task list or a “view” (a way of presenting tasks) that collects tasks without noise, and as mentioned in [the previous chapter](plaintext), if you interact with text digitally, you must understand plain text. By incorporating these ideas effectively, you can strike a balance that values the act of writing while also managing tasks.

### The Benefit Is Respect for Context

The benefit of LTM is that it **respects context**. As discussed in [the chapter on context](context), by writing you make the contexts of your life, work, and daily existence clearer. When you read, add to, or revise your writing while thinking about your tasks, you can address them in a way that respects their context.

### The Goal Is an Improved Quality of Life

The goal of LTM is to **improve quality of life (QoL)**. Acting based on your own context is, in and of itself, a pleasurable experience.

Note that this approach does not necessarily lead directly to increased productivity or growth. If you aim to boost productivity or personal growth, you may simply ignore context and power through your necessary tasks with determination. In contrast, LTM prioritizes respecting your own context. Although working in this way may, in the long run, also lead to higher productivity or growth, the primary purpose of LTM is to enhance QoL. In particular, LTM is not suited for hectic, crisis-driven situations.

### It Is a Solo Activity and Not for Everyone

LTM is a method for individual task management. That is, it is done by oneself. It is not intended for group or partner task management methods such as project-based or team-based task management. In this chapter, we will deal exclusively with LTM as a method for managing personal tasks.

Furthermore, LTM is not suitable for everyone. At the very least, it requires that you can continuously engage in the act of reading and writing, that you have a certain amount of time available for reading and writing (for example, at least one hour a day), and that you use digital tools rather than analog ones. If you cannot meet these three conditions, then LTM might not be right for you. However, you need not worry about your language proficiency or writing speed—task management is inherently a personal matter, and it is enough if you can create your own literary style.

## The Roots of “Literate ••”

To understand the nuance of “literate,” let’s briefly look at its origins.

### Literate Programming

The most famous and foundational concept is literate programming.

Originally proposed by Donald Knuth, the idea is to write code interwoven with documentation. In conventional programming, code is written in a specialized language that the computer reads and executes. Reading code can be challenging, and because one must preserve the design ideas and intentions behind the code (so that modifications can be made later), a separate explanation is often written in natural language. Sometimes this explanation is embedded in the code using comment syntax. In any case, linking “code” with “documentation (a detailed explanation written in natural language)” is not simple. Not only must the two be kept in sync, but updating both after making changes to the code involves double maintenance and can be very laborious. Literate programming offers a new approach to this issue by saying, “Well, if that’s the case, why not center the documentation and just write the code within it?”

Today, the most well-known implementation of literate programming is probably Jupyter Notebook. It is used for data analysis, and in a file called a notebook you can include your step-by-step work, memos, experimental code, and even the output of that code—all bundled together. In a way, it is literate programming in that your documentation, which contains your experimental process and memos, includes the code and its output. Although the use is somewhat limited to experimental contexts, it is a good example of literate programming.

### The Potential of Literate Task Management

It is not clear when the concept of literate task management first emerged, but I have found two examples.

One example is the article “Recommendation for Literate Task Management (Literate Task Management)” by ari’s world, dated June 2020. In the article, the process is described as “writing everything—notes, reflections, plans, and task breakdowns—into one document without separating planning from execution.” Although the idea draws inspiration from literate programming, the approach is not to embed tasks within prose but rather to write everything out in a text-based format, then later extract tasks from it. This is more akin to the exploratory task management described in the next chapter.

The next example is from December 2021 in the article “Project List-less Project List Management and Literate Task Management | R-style.” I personally felt that this was a perfect example of literate task management. In the article, the author writes, “Before processing ‘tasks,’ I want to manage the ‘context’ that creates them.” In practice, they write a document (Todo.md) in which they first write freely and then extract tasks from it. They even created a script that scans through the Dropbox folder for any files containing Todo.txt or Todo.md and extracts their content to display in a view. This, too, draws inspiration from literate programming.

## The Necessity of a Notebook

In LTM, a notebook is absolutely indispensable.

For example, the following are **not** considered LTM:

- Social media or chat systems such as X (formerly Twitter), LINE, Slack/Discord/Teams, which are based on short posts and timeline displays.
- Online blogging systems like Hatena Blog.
- Traditional Wiki systems such as Atwiki, Pukiwiki, or MediaWiki.
- Systems like [GitHub Issues](ref#github-issues) that serve as bug tracking systems.
- Multifunctional note-taking tools such as Notion.

To perform LTM, you must be able to write without friction. You must be able to write freely without the burden of composing text for an audience. As mentioned in the previous chapter about the [3-second barrier](plaintext#3-秒の壁を突破する), it is essential that you can write as naturally as breathing. **Most existing systems for sharing information or communicating do not meet this requirement.** Even many multifunctional note tools lack the necessary lightness. As explained in the previous chapter, it is preferable to use “plain text” and “offline tools,” though later I will explain that it is possible to use some online tools.

In addition, you must be able to handle large amounts of text. There might be times when you write around 1,000 characters at once, or even 10,000 characters in a day; other times, you may write short snippets—perhaps a list of 100 single words. Whatever the case, the tool must be able to handle multiple lines of text effortlessly. Social media or chat systems, which are designed for short messages, are not suitable for this (or, even if they can handle it, they are inconvenient).

When you hear “writing,” many people will imagine the tools mentioned above. However, those are not sufficient for LTM. You need a tool that is both lightweight enough for fluid writing and has the potential of a “notebook” to manage larger bodies of text.

## Preparing for LTM

Now, let’s organize the means and ways necessary to begin LTM. In this section, I will cover the fundamentals (how to use and set up your notebook) needed before diving into task management itself. The actual task management aspects of LTM will be addressed in the next section.

### Tools Capable of Running LTM

Although I mentioned that LTM requires a notebook, what kind of notebook tool should you use?

#### Three Approaches

As of 2024, I believe there are three approaches:

- 1: Offline plain text editors
- 2: Networked note-taking tools
    - Examples: [Scrapbox](ref#scrapbox), [Obsidian](ref#obsidian), as well as Roam Research, Logseq, etc.
    - They can be offline or online.
    - (In [the chapter on strategy](strategy#応用1%3A-どのツールを使うか), these are also presented as third-generation note tools.)
- 3: Outliners
    - Examples: WorkFlowy, Dynalist
    - *Note: Although there are also offline outliners, I will not cover them here.*

Approach 1, using an offline plain text editor, has already been explained in the previous chapter: you handle plain text with a text editor or IDE. Being offline, it is very nimble; however, it is essentially just for editing text, so it lacks advanced features. If you need more advanced functions, you must either build them yourself or come up with workarounds. It is a DIY approach. With enough effort, you could even incorporate some of the potentials of approaches 2 or 3 (see note below).

Approach 2, using networked note-taking tools, has emerged in recent years. Their greatest feature is that they allow you to link notes together. For example, writing `[[B]]` in page A creates a link from A to B. When you view page B, it may show meta-information such as “linked from A” (backlinks), and you can click on links within the text to jump to another page. Just as you can browse between webpages using links, you can create your own network by manually linking your personal notes. By doing so, your entire notebook becomes a network, making it easier to explore by following links or to display related information that is connected to the page you are viewing.

There are both online and offline tools. Scrapbox is online. Tools like Obsidian or Logseq work offline. Even offline tools can have online features (especially cloud storage or data synchronization) added through various techniques.

Approach 3, outliners, is a bit special. They express all information as bullet points. They allow you to arrange items hierarchically, sort them, collapse lower levels, and so on. While you could use them for LTM, their ability to create networks is somewhat limited. I will not cover outliners in this chapter.

- *Note: For example, I personally use Hidemaru Editor with my own self-made tools [Hidemaru SCB](https://github.com/stakiran/hidemaru_scb) and [houtliner](https://github.com/stakiran/houtliner) based on it. As of 2024, I no longer use houtliner, but I still love Hidemaru SCB. I have made it publicly available, though I haven’t provided detailed documentation since it is for my own use. I mention it here only as a reference.*

#### Recommended Tools

If you already have a tool you like, then use it.

If not, I recommend using Scrapbox if you want an online tool or a plain text editor if you prefer offline. As a networked note-taking tool, I believe Scrapbox is overwhelmingly superior. I am a heavy user of it, and in my opinion, it leaves other tools far behind. However, being online it comes with some restrictions—if you need to write large amounts of text, if your connection is not strong, or if you must use a tool approved for work that does not allow cloud storage, then an offline plain text editor is a good alternative.

#### A Side Note: Infinite Canvas vs. Networked Note-Taking Tools

Sometimes, infinite canvas tools are mentioned as competitors to networked note-taking tools. These are the whiteboard tools represented by [Miro](ref#miro), often imagined for multi-user collaboration. However, when used by a single person, the infinite two-dimensional space can also be an excellent means of managing information or serving as a workspace.

In fact, infinite canvas tools are similar to the literary approach. Within a single workspace, you can include all “context”—that is, all related information—without having to compartmentalize. Traditional file management or databases tend to collapse when there are thousands of files, but these two paradigms can maintain order even under such conditions. Networked note-taking tools achieve this by emphasizing language (text) to create a network structure, while infinite canvas tools do so by spatially arranging diverse content. As far as I know, these are the only paradigms that can realistically manage large amounts of context.

So, can LTM be performed on an infinite canvas? And is it even suitable?

The conclusion is that it is less suited than networked note-taking tools. As discussed so far, task management is about dealing with language and, in personal task management, you are handling tasks that you have articulated yourself. This makes some note-taking tools more suitable than an infinite canvas. An infinite canvas is excellent for pasting others’ information or arranging items graphically, which is a more visual and spatial activity rather than a linguistic one. While it works well as a tool for managing information, making decisions, or serving as a workspace for creative activities, it does not match up well with task management. As I have stressed throughout this book, in personal task management you must confront language head-on.

Even though you could theoretically manage tasks on an infinite canvas, you would eventually find yourself relying on text-based notes. For example, the [Ink & Switch study “Embark”](https://www.inkandswitch.com/embark/), which is about travel planning, concludes that even when using an infinite canvas, people end up taking notes and acting on them. Notes are context. In the end, you have no choice but to leave context in language. Therefore, it is best to use note-taking tools that excel at managing text.

#### A Side Note: Supplementing the Shortcomings of Notebooks

The disadvantage of notebooks is that their views (ways of presenting information) are weak. Even in LTM, how to get an overview of the tasks written somewhere in your notebook is a major issue.

The key is **don’t give up on using notebooks just because the views are weak.** A notebook is ideal for a literary practice. But if the notebook’s views are weak, then simply supplement the notebook with an external view. As of 2024, the built-in views for LTM are still insufficient, so if you cannot create one yourself or through some workaround, you might be dissatisfied. Even so, do not abandon notebooks. **Once you stray from using a notebook, LTM is over.** Particularly for those who prefer having a view, the rugged, language-dense world of notebooks is often avoided—but if you truly wish to practice LTM, you must not stray from notebooks.

Regarding supplementing the view, I personally feel that the trend is shifting. In particular, generative AI is making an impact. This is because generative AI is very good at handling text, and even now it is capable of summarizing, transforming, or translating text. In the not-too-distant future, you might simply feed your notebook into an AI, ask it questions, and have it show you your task list, or even have it behave like a personal secretary in a more advanced manner. Limited examples of this already exist (see note below), and while not exactly task management, some note-taking tools—and even Miro as mentioned earlier—now support AI chat functions. ChatGPT, for instance, can generate diagrams from text instructions or data. In short, it isn’t hard to imagine that innovative methods to supplement views using generative AI will soon appear, and solutions or tools applying such ideas to task management may well emerge.

- *Note: The drawback is that the precision is not yet perfect. Particularly when managing tasks, you absolutely cannot afford to miss any tasks, yet current systems may still overlook some. For instance, if you give the AI one week’s worth of notes and instruct it, “Display all tasks from today onward in chronological order,” it might easily miss some. Generative AI is inherently probabilistic; it merely generates the most likely continuation based on its training data. It is not structurally suited to extracting every piece of information that has a particular meaning written in a specific place (even if you craft your instructions to improve accuracy, some omissions will still occur). This is scary enough to make it unsuitable for serious use. Of course, it is hard to predict the future, and it may be that some developers have already created tools that are practical enough for task management.*

## The Style of LTM

How should you proceed with LTM using a note-taking tool? There is no single correct method, but I have identified three common approaches:

- 1: Diary-based
- 2: Project-based
- 3: Network-based

They are listed in order of increasing complexity; the earlier ones are easier to start with, but they are not as effective as LTM ideally should be. In other words, the ideal for LTM is the network-based approach.

Let’s look at each individually.

### Diary-based

The diary-based approach is simply writing text on a daily basis—essentially, like keeping a diary. Its simplicity makes it easy to start with, but it is less effective for LTM. Ultimately, it is just a collection of daily texts. To identify tasks within LTM, to later review and grasp them, or even just to re-read the context of tasks, you end up having to **reread everything you’ve written**. Professional programmers say they spend more time reading code (their own or others’) than writing it, and writers spend more time revising their drafts than writing them initially. The same goes for practitioners using a diary-based LTM—the time spent reading far exceeds the time spent writing. Yet, re-reading one’s own writing can be tedious, and as mentioned in the plain text task management (PTTM) chapter, manually managing everything through daily maintenance can be burdensome. Diary-based methods simply do not suffice for LTM.

### Project-based

Next is the project-based approach, which involves treating tasks on a per-project basis by writing each project’s content in its own note. The unit of note could be a file, a page, or even a designated section marked like `■Project A`; the point is to separate each project so that everything related to it is contained within one area. For example, if you have tasks related to moving, you would create a file like “Moving.txt” or a section titled `■Moving` and write everything about it there. This way, you know that “all information related to Project A is in Note A.” Think of it as setting up a separate workspace for each project. In digital environments, there are no spatial constraints, so you could create 10, 100, or even 200 such spaces if you wished.

At first glance, this may seem to work well, but for most people it is quite challenging. Project-based methods essentially require you to **continuously organize and tidy up your texts**. That is, unless you are very good at organization, you will probably end up dumping everything into a “miscellaneous.txt” section, and your text will eventually become so cluttered that the system breaks down. Even if you are excellent at physical organization, you need the skills and inclination to properly handle plain text (or else the hassle of operations becomes so great that you simply stop trying), and so there is no guarantee this method will work. Moreover, how do you conceptualize what constitutes a “project”? And what do you do with information that spans multiple projects—for instance, a note related to both Project A and Project B? You can’t simply copy it to both places, and if there are three such overlapping projects, what then? The hassle is overwhelming, and it ends up being abandoned.

### Network-based

A new paradigm is needed to solve the issues encountered by the previous two approaches, and that is the network-based method. In this method, you write on a per-topic basis and link the topics to create a network structure. Whereas the project-based approach used one note per project, the network-based approach uses one note per “topic.” A topic might be a task or a project, but it can also be any subject—for example, you could create a note titled “I Really Love Chicken Rice.” I call this **topic orientation**. That is, you write everything related to topic A in Note A. The unit of the topic can be large or small and does not even have to be as neatly defined as a task. As a result, the number of notes will not be just a few hundred but could easily number in the thousands or, in some cases, tens of thousands. This is possible only because of digital technology. In my opinion, the paradigm that truly established this network approach was Scrapbox. If you want to experience it firsthand, I strongly recommend using Scrapbox.

This topic orientation requires a special kind of tool—that is, a networked note-taking tool, as introduced earlier.

### The Network Encompasses Both Projects and Diaries

The beauty of the network-based approach is that it can include both the project-based and diary-based approaches. Simply writing one note per project gives you the project-based method, and writing one note per day gives you the diary-based method. Since both projects and diaries come with their own history and familiarity, they are useful. However, because it is network-based, you are not limited to just these. For example, if on August 5, 2024, in your diary note you write “I really love chicken rice” and link it, a new note called “I really love chicken rice” is created. You can then accumulate insights or thoughts about chicken rice in that note. From there, you might think, “I want to check out some recipe sites,” or “Since my hometown has a diner, maybe starting a chicken rice business is viable.” Those too can be turned into separate notes with further elaboration and links, expanding the network. 

This approach reaches heights unattainable by a mere diary or project-based method. Networks are structures that our brains, transportation systems, the internet, and human relationships are very familiar with. By integrating this structure into your personal note-taking, you can achieve an overwhelming ease of writing and reading (in terms of traceability). It becomes possible to create a rich “second brain” of notes. And now, as the times have finally caught up, LTM has become feasible.

## ⚠ LTM ≒ Network

Based on what has been discussed so far, the recommended tool for LTM is a networked editor and the recommended style is network-based. From here on, I will explain LTM on the assumption that you are using a networked editor with a network-based style.

In other words, **from this point onward, I will assume that LTM is implemented using a networked editor in a network-based style.**

## How to Create a “Home”

Normally, we have a home (or residence) that serves as our base, and at work we have an office desk or workspace. Not long ago, the term “nomad worker” became popular, and even now, with remote work, it is possible to live without a fixed base—but even then you typically create a temporary base.

The same applies to LTM—you must first create a base. Let’s call this base the **home**. There are several common approaches to creating a home. Below are four examples:

- 1: A home note
- 2: A home view
- Dynamic homes:
   - 3: Date notes
   - 4: A trunk

If you are working offline and relying on manual operations, a home note, date note, or trunk might be best. Which one suits you depends on your personal style. They do not differ greatly in terms of operational difficulty, so it might be worth trying each one. If you are using an online tool that comes with built-in views—like Scrapbox—then a home view is available.

Let’s look at the details of each.

*By the way, depending on the tool, what we call a “note” here might be referred to as a “page.” The term for each unit of information depends on the tool. In Scrapbox, they are called pages. **In this book, I use the term “note.”***

### Home Note

You create one note that serves as the sole entrance to your system. This is called the **home note**.

The home note is like your front door, and every note you write as part of LTM should be reachable from it. What you write and how you write it is entirely up to you. You might scribble everything down on it like a messy desk, or you might create separate notes for, say, Project A and then include only a one-line link to that note in your home note.

Structurally, there will likely emerge three parts:

1. Things you freely jot down in the home note.
2. Things that are somewhat organized but still directly written in the home note.
3. A collection of links.
   - Things not written directly in the home note exist in other notes, but if they are not linked from the home note, they cannot be reached. Thus, the home note ends up having a list of links—a link collection.

There is no need to write out the link collection directly on the home note. For example, you might create a note called “Not Reviewed Anymore” and use that as your link collection. The home note then would have only a one-line link to the “Not Reviewed Anymore” note, which in turn contains hundreds of links to other notes that you no longer review. If you put all those links directly in the home note, it would become cluttered; instead, you create an intermediary note.

The idea is to maintain your “entrance” well yourself. If you are good at organizing, then a home note is enough. If not, you might want to use a home view or a date note that forces movement, as I discuss later.

### Home View

A home view is a view that nicely presents the collection of notes you have created, serving as your home. 

In a home view, your notes might be listed as a list or cards, with a search box, sorting or filtering widgets, or even an option to create new notes. Because it is a view, you cannot write directly into it; rather, it is used for managing your notes at an overview level.

Of course, such a view cannot be created with a standard note-taking tool alone; you must use a tool that provides a view (or build one yourself, but I won’t cover that here). And that view must be robust enough to serve as a home. One of the views I know well is Scrapbox’s. Below is an example of one of my projects (I have blurred out private details).

![](/images/taskmanagement-kamikudaku/scrapbox_view.png)

In this project, within a workspace you create pages (notes). This project serves as a view by displaying the pages in a card format. From here you can open any card you want to read, create a new card with the “+” (green button at the top), and use search, sort, or filter functions. Cards you use often can be pinned to the top for easy access. If you want to use a home view, you’ll need a view roughly as capable as this.

### Date Note

The date note method involves creating a note named for the date (for example, “2024-08-06”) and using today’s date note as your home. Tomorrow, “2024-08-07” becomes your home, and so on. This is exactly the concept of the [daily area](strategy#概要) discussed in the chapter on strategy.

A date note is like staying in a hotel where you change rooms every day. It takes some effort to switch rooms, but you get a fresh space each day. If your home note becomes too cluttered, using a date note as your home might be a better solution.

Here, however, a dilemma arises. Frequently used link collections or texts that you need to maintain often appear in your daily writing (a typical example is a daily task list) and you want them always to be at hand. If you use a date note as your home, you have to move these items every day. This is inconvenient, and if these items become very long, the date note itself becomes unwieldy. So, you might consider creating a separate “warehouse” note where you store such items, and then in the date note just include a one-line link to the “warehouse.” But then, every time you want to view the contents of the warehouse, you have to open that link. Alternatively, you might display both the date note and the warehouse note side by side (for example, in different windows or tabs), but that forces you to constantly switch between the two, which increases the risk of **overlooking tasks**. Even if you diligently write your task list, splitting it among multiple places means your attention is divided, leading to forgetfulness. Therefore, it is best to have **only one note that is always displayed and read.**  
   
*Note: If you have a large display or multiple monitors, you might be able to display both the date note and the warehouse note simultaneously.*

Thus, handling daily texts in a date note is surprisingly difficult. You must find a balance that minimizes both the inconvenience and the chance of overlooking tasks.

In practice, a hybrid approach is best. For example, you might use a home note as your primary home, and then in the home note include a link collection of date notes for the current month. By putting today’s date note as the very top link, you can access today’s content easily. In Scrapbox, you can also pin today’s date page so that even when using a home view as your home, you can quickly access the date note (a hybrid of home view and date note). That is, rather than using the date note as the sole home, you create another home and make the date note easily accessible from it. In that sense, the balance also concerns “what to include (and how much) in a date note.”

### Trunk

**Trunk** literally means “the main stem,” evoking an image of a trunk with many branches extending from it. A trunk is any note from which many links extend. In this sense, the home note or a link collection is the thickest trunk, and a date note that links to many things is also a fairly thick trunk—but you are not limited to just those.

Suppose you start LTM today with a note called “Test” because you’re not sure what to do yet. As you go about your day writing your task lists, memos, and your thoughts, the text will naturally grow. If you do nothing, the text will just become bloated, but since you’re in a network, you can create a separate note for specific topics and then link to it. For instance, you might move all notes related to moving into a “Moving” note, or notes about changing jobs into a “Want to Change Jobs” note, and your date notes into notes like “2024-08-06” or “2024-08-07.” In this way, you gradually offload content. Of course, if you just offload without linking, you won’t be able to trace them later, so you should include links from the “Test” note. In this case, the “Test” note functions as a trunk. The more time you spend in the “Test” note, the more links (branches) accumulate.

After a while, suppose you have completed your job change and moving, and your life has undergone a dramatic change—but the “Test” note remains as is. It will likely become too cluttered, so you might decide to change your home. For example, if you move from Osaka to Okayama, you might create a note titled “New Life in Okayama.” You would then copy the necessary content from the “Test” note to the “New Life in Okayama” note. From then on, the “New Life in Okayama” note becomes your home. New links will grow from there. If possible, to be able to trace back later, write a note in the “Test” note indicating that you have moved and link to “New Life in Okayama.”  

After some time, suppose you settle into your new life in Okayama and even have a long vacation coming up. You might then create a “2024 Travel” note. All travel-related planning would be done in that note (not in the “New Life in Okayama” note). In that sense, the “2024 Travel” note will also function as a trunk. The point is that trunks do not need to be permanently fixed. You can adopt a nomadic style of changing your home—as long as you leave links behind when you move, so you can trace back later. In other words, just as when people part ways they hold a farewell ceremony or send-off, in nomadic LTM leaving a link behind serves as that ritual.

To summarize this section: **The use of trunks need not be permanent.** You may change your home like a nomad, but when parting, be sure to leave links so that you can trace back. In other words, when you leave a trunk, let the act of linking serve as a farewell ritual.

## Summary

In preparing for LTM, I have covered the following points:

- Use a networked editor.
- Employ a network-based approach.
    - Although you can use diary-based or project-based methods, the ideal is network-based.
- Create a “home.”
    - Options include a home note, a date note, or a trunk.
    - If your tool has a built-in view, a home view is also acceptable.

However, all the above has been about the notebook. The crucial subject of task management itself has not yet been discussed; that will be covered from the next section.

...
