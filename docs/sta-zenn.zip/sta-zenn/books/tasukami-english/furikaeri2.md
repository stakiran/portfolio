---
title: Reflection(2/2)
---

# Collection of Tips

From here on, I will cover various tips that may be useful for each step of reflection—input, deliberation, and output.

## Methods for Input

As mentioned earlier, there are essentially three methods:

1. **Look at records.**
2. **Recall from memory.**
3. **Use hints to recall.**

For method 1 (records), this includes everything from quantitative data (such as measurements) to qualitative descriptions like diary entries. It is necessary either to have these prepared in advance or to record them diligently. In fact, you might even design your reflection in advance—deciding what to record so that it can be useful during deliberation—and then record daily. However, it is hard to immediately narrow down exactly what and how to record; therefore, establishing a system or habit of recording frequently (even if imperfectly) is the first priority.

For method 2 (memory), you use what is stored in your mind as input rather than external records. However, human memory is unreliable—and if you could simply rely on memory, you wouldn’t need to reflect (since you could handle things on the spot if you wanted). But if something particularly striking is imprinted in your memory and you really want to do something about it, you should create an opportunity to focus on it intensively or approach it in a relaxed manner.

For method 3 (hints), instead of producing output faithfully from daily records as in method 1, you use more rough hints and let ideas flow from them as the basis for your output. How can you gather these hints as input? There was a time when, after leaving work on time, I would have a meal at a food court while watching the people passing by—and I would reflect on my life using those people as hints. For example, watching a group of high schoolers having fun might prompt thoughts like, “Do I want to recapture that spirit?”, “No, I’m not at an age where I can enjoy that vibe anymore,” or “I chose to enjoy things alone now; maybe I should push a little harder.” These changing cues are what I call **dynamic hints**—they are not so much gathered as experienced by going to the places where they naturally occur; they are like input that you are immersed in. In contrast, the hints I will describe later that are prepared in advance (or can be prepared during deliberation) and remain unchanged once set are called **static hints**. Static hints are obtained either by collecting something that someone else has created or by creating them yourself—they are “gathered” input.

Regarding how to choose between these hints, it is generally better to rely on static hints. Since reflection is something you continue over time and gradually get the hang of, having fixed hints can be helpful. On the other hand, relying solely on static hints can become dull and may lead to stagnation in your thinking, so it is good to occasionally immerse yourself in dynamic hints to balance things out.

## Tips for Deliberation

There are various methods to deliberate, and you can design your approach in many ways; however, I will not cover all those details here. Instead, I will introduce two kinds of hints that might be useful during deliberation: frameworks and trigger lists.

#### Reflection Frameworks

In recent years, it has been the era of teams—and there are countless work methodologies aimed at teams. Reflection is one such area, and there are various frameworks available.

I recommend an article by postalk, which I think is very appropriate. Although these frameworks are designed for teams, there are aspects that you can use even when reflecting individually.

- [10 Reflection Methods! Introducing Interesting Overseas Methods That Can Be Used in Agile Development | postalk park](https://postalk.jp/blog/1c30gd2PYy2uTUaX9eIRrH/)

Please refer to the article for details; here I will briefly cover some of them.

You are probably familiar with KPT and YWT. KPT stands for “Keep” (things you want to continue), “Problem” (issues you are facing), and “Try” (things you want to try), while YWT stands for “Yatta” (what you did), “Wakatta” (what you understood), and “Tsugiyaru” (what to do next). For individual use, YWT might be easier because it is simpler to list what you did or understood. One thing to note is that both methods encourage you to list what to do next. In this chapter, I have stated that reflection should yield an output—tasks and mottos. Deciding on your next actions is important.

Methods such as “mad, sad, glad” or the “A” (for Appreciations: things you are grateful for) in WRAP deal with emotions, suggesting that it is perfectly fine to use emotions as part of your input in reflection. There is no right answer in reflection, and since we are human, the influence of our emotions is inevitable—so it is certainly acceptable to face them. For example, if you record your emotions daily and can identify what makes you happy or unhappy, your overall quality of life (QoL) might improve.

Later in the article, frameworks that help visualize and classify topics—for example, Lean Coffee or even approaches inspired by Mario Kart—are discussed. This way of thinking is effective in reflection, as it helps you determine what to reflect on and visualize how deeply you have deliberated on a subject. (Although the article is essentially a promotional piece for a whiteboard tool called postalk, whiteboards are very useful. Other tools like [Miro](ref#miro) are also available, and of course, you can use sticky notes and a pen on a desk.)

#### Trigger List

In this book, I refer to a similar idea as a [chain association list](source#連想リスト), but the original “trigger list” is a concept from GTD. It is a self‑questioning list designed to externalize those vague or nagging thoughts in your head. This trigger list can be very useful as a perspective during your deliberation in reflection. There are several examples online; here are a few:

- [【2018 Edition】My Own GTD Trigger List - BrownDots](https://browndots.net/2018/03/27/my-gtd-trigerlist-ver2018/)
- [【Copyable】Trigger List for Teachers – Google Workspace for Education Communication by Paidagogos](https://gsuite.paidagogos.me/?p=1932)
- [GTD Trigger List | PDF](https://www.slideshare.net/slideshow/gtd-62061332/62061332)
- [I Made a GTD Trigger List for Housewives – Mrs. Kanchigai’s Blog](http://kanchigai.blog45.fc2.com/blog-entry-614.html)
- [My Ultra‑Personal Trigger List! – Mei‑ki](https://mei-ki.hatenablog.com/entry/2016/10/05/235039)

For details, please refer to each article; here I will summarize the essence in my own words.

First, you’ll notice that these lists are divided into large categories—such as “work,” “private life,” “hobbies,” “money,” “health,” and “family.” Personally, I also often use categories like “housing,” “marriage,” and “common sense.” Looking at these large categories may bring various ideas to mind. If there is something that you usually neglect, this is a good opportunity to make it a subject of reflection. For example, if you have been neglecting dating or marriage, you might hold a “How About Marriage? Reflection Meeting” once a week to gradually work through what your current situation is, what you want for yourself, and what to do next. I have already mentioned that reflection should be treated as a scheduled appointment. Once you secure an appointment, even if you’re busy, you can concentrate on reflection during that time—even if it’s just an hour or 30 minutes, over time it will have a cumulative effect.

Next, for areas you are frequently involved in, you can subdivide further. For example, a trigger list for teachers is easy to understand because it includes categories such as homeroom class, grade-level groups, responsibilities, and committees. This will differ from person to person. Alternatively, if you prefer a simpler approach, you might create categories based on the projects you’re handling, the teams you belong to, or your main stakeholders. Looking at these categories can help you come up with things to reflect on.

Another way is to divide each item using MSCW—which stands for Must (things you must do), Should (things you should do), Could (things you could do), and Wouldn’t (things you don’t want to do). In other words, you can use this to guide your reflection: reflecting on what you must do, what you should do, and how to avoid what you don’t want to do.

#### The 4R Matrix for Reflection

Reflection can be divided into four patterns based on two axes: “what is it about” and “whether it emphasizes subjectivity or objectivity.” This is called the **4R Matrix for Reflection**. Which pattern you use depends on the situation, but more importantly, it comes down to personal preference. Since reflection is a personal practice (as defined in this chapter) and is only valuable if you continue it, I recommend choosing a method that appeals to you.

The matrix is as follows:

|                         | Regarding Yourself              | Regarding Others/Activities/Systems    |
|-------------------------|---------------------------------|----------------------------------------|
| **Objectivity‑focused** | 1. Reassessment               | 2. Review                              |
| **Subjectivity‑focused**| 3. Reflection                 | 4. Recollection                        |

Here, “objectivity” means relying on records, data, evidence, or the opinions of others, while “subjectivity” means relying on memory, hunches, or guesses. As the matrix suggests, the balance is a gradient; you are never 100% objective and 0% subjective. It comes down to whether you emphasize objectivity or subjectivity.

Let’s examine each pattern:

1. **Reassessment**: Objectively reflecting on yourself. For example, if you are managing your health or finances and want to review the data you record (e.g. via an app), that falls under this category. You are quantitatively reflecting on yourself. In such cases, quantitative data must be properly recorded in advance or done diligently.
2. **Review**: Objectively reflecting on something other than yourself. In the context of work, this is usually the case, and with the current data‑driven trend, terms like “evidence” and “facts” are common. If you do this, you are unlikely to go wrong—but it is extremely laborious, and unless it is work‑related, you might not be inclined to do it. Essentially, you must gather data about that “something.” With Reassessment (yourself), it can be managed relatively easily, but Review is more challenging. The necessary data might not be recorded in advance, and getting it recorded is usually difficult, so you may have to ask others. In fact, many of the frameworks introduced earlier assume you are discussing things with a team. It’s a primitive method, but it is the only realistic approach in many cases.
3. **Reflection**: Subjectively reflecting on yourself. Although the term “reflection” is polysemous, it is well‑suited to the idea of introspection. It is subjective—but in return, it requires you to think deeply and confront yourself. In practice, if you do not engage deeply, nothing will come out. (I have already introduced several methods in [Designing Your Reflection](#設計のやり方), all of which require you to face yourself.)
4. **Recollection**: Subjectively reflecting on something other than yourself. In other words, you use your subjective judgment to deliberate on others, activities, or systems (the original meaning of “recollection” is “remembering” or “reminiscence”). Although the current business trend is data‑driven (as in Review), Recollection might sound less appealing because clear data is rarely available (see Note 1). In practice, however, you often have to rely on recollection. Of course, subjective impressions are not always correct, so later verification is necessary. This leads to a cycle or loop of hypothesis testing, and reflection itself must be done regularly. This hypothesis testing is important—without it, you will end up with fixed assumptions or mere speculation. With Reflection (yourself), that may be acceptable since you know yourself best, but in the case of Recollection (others), it often results in a poorly formed hypothesis. (If you do not want to simply conclude with assumptions,) engaging in hypothesis testing is essential.

- **Note:**
  - 1: Relying solely on data is not impossible, but it is difficult. Nowadays, there is a trend of data‑driven management, and even lean startups devote significant effort to defining data items and organizing data collection for hypothesis testing. What is common to both approaches is that they must be properly designed in advance—and, if possible, organized to be automatically recorded using IT. Both require a level of sophistication that necessitates specialized personnel. Without such preparation, you cannot obtain useful data. Conversely, without it, the data may be insufficient, of poor quality, require too much manual effort, or become overly personalized—leading to mere ritual or even politicization.

## How to Produce the Output

For the output, you are to produce tasks and mottos—and ideally context as well. How do you do that?

#### Producing Tasks

If your deliberation is going well, tasks that you should undertake next should naturally emerge. If nothing comes up, it is likely that your deliberation or input is insufficient. Even if nothing emerges, you can at least set something as a hypothesis. Alternatively, you can deliberately choose not to set anything and simply wait and see.

It is advisable to differentiate between “ad‑hoc tasks” and “[routine tasks](habit#ルーチンタスク).” Ad‑hoc tasks are one‑time tasks that, once completed, are done. Routine tasks are those you perform repeatedly at a specified frequency (such as once per day or once every three days) and may take a long time to complete or continue indefinitely. Start by outputting ad‑hoc tasks and loosely schedule when to do them. However, if you merely list them, you risk procrastinating. To avoid that, incorporate them into your schedule or, if the task involves other people, send an initial contact message to prompt action. And since ad‑hoc tasks alone might not suffice—if you find yourself thinking “I won’t know until I try”—then create routine tasks. (For more details, please refer to the linked page.)

#### Producing Mottos

For mottos, please refer to the [Motto chapter](motto).

In the context of reflection, it is useful to differentiate between the following two types:

- **1:** Producing a “specific, limited motto” that you should keep in mind for a particular situation.
- **2:** Producing a motto that you wish to adopt for your life in general.

For type 1, for example, in a work‑related reflection you might derive a motto such as “From now on, I will check in with Person A more frequently to provide support.” This is a work‑related, specific motto regarding Person A. Since it is not something that can be acted on immediately, it is produced as a motto rather than a task. However, in that case, you might also convert it into a task—for instance, “If Person A agrees, arrange a weekly one‑on‑one meeting.” As explained in the Motto chapter, some people are better at applying a motto as it is (the “applier” type) while others, who are not as good at direct application but excel at turning ideas into tasks or habits and following through diligently (the “athlete” type), may need to convert them accordingly. Choose the method that works best for you.

For type 2, you might hold a “Life Reflection Meeting” or a “Meeting on How to Proceed from Next Month Onward” specifically to derive mottos. Mottos, by nature, are more profound than the specific, limited ones of type 1—they are about philosophy, belief, or character. They do not typically emerge simply by drifting through the day, so you need to create an opportunity to extract them. In terms of the 4R Matrix mentioned above, this falls under Reflection—that is, introspective reflection is recommended. In doing so, mottos from other people or organizations can be useful. In the Motto chapter, I refer to “External Mottos” (which can be inspirational), but mottos are inherently personal and need to be optimized for yourself (forming your “Internal Motto”). In other words, you create your Internal Motto by using External Mottos as a reference. Introspection is key for this; objective information alone will not yield a true Internal Motto. Otherwise, you risk becoming a slave to someone else’s life (see Note 1).

- **Note:**
  - 1: I’m not saying that relying solely on others’ words or objective data is bad. In fact, it can make you more flexible because you are not dependent on your own trivial beliefs or pride. However, without a sense of self, you may become aimless. Excessive reliance can even make you more susceptible to deception (which is why scams and cults are so dangerous). On the other hand, as I mentioned earlier, you should focus on introspection to build “yourself”—there is no escaping the need to confront your own self, and doing so without evasion is one of the messages I wish to convey in this book.

#### Producing Context

For context, please refer to the [Context chapter](context).

In reflection, “producing context” means outputting what I call “loaded context.” By recording the context (i.e. why you produced a certain task or motto, including any compromises or reasoning), you can refer back to it during your next reflection session. This reduces the burden of context switching. In short, writing down the context means that you can remember the previous situation, allowing you to eliminate gaps over time. Conversely, if you reflect each time without any reference to context, each session will be isolated and you will miss out on the “aha!” moments—the sense that “the essence has become clear” or “I’m starting to understand.” This sense of insight and clarity is both fascinating and rewarding, and it is key to whether you will continue reflecting.

# Summary

- **Reflection is the act of deliberating based on input and producing an output.**
  - Input may come from memory or records.
  - Deliberation can be in any form.
  - The output consists of tasks, mottos, and (optionally) context.
    - Producing an output is essential for linking to your next actions; mere deliberation is not enough.
- **Reflection is a personal practice and there is no “right” answer.**
  - Each person must explore the optimal methods and balance for themselves.
  - It’s okay if the process is rough at first—and even one output is sufficient.
    - As with habits, build up gradually—one step at a time.
  - The most important thing is to continue.
- **Key characteristics of reflection:**
  - **PROC:**  
    - Purpose, Remembering (how to gather input), Oppotunity (when to reflect), Continuation (whether it’s a one-time event or ongoing)
  - **DWMY:**  
    - It is best to conduct reflection on a regular basis using Day, Week, Month, and Year intervals.
    - Using the output from the previous session as input (the DWMY Hierarchy) reduces the effort needed to gather input.
  - **KAP:**  
    - The purpose of reflection can be broadly categorized into three: Know (to know), Advance (to advance), Protect (to protect).
  - **4R Matrix:**  
    - There are four patterns of reflection based on whether you reflect on “yourself” or “something else” and whether you emphasize subjectivity or objectivity.
- **Practices:**
  - Treat reflection as a scheduled appointment—dedicate proper time to it.
  - If you cannot hold or maintain reflection on your own, rely on external support (to get on the starting line).
  - I have introduced several methods for designing your reflection (e.g. the Enum and Assign method).
  - When deliberating, using reflection frameworks or trigger lists can be very helpful.
