---
title: Task Management with Plain Text(1/2)
---

# Introduction

## What Is Plain Text?
Task management is something that is handled through language, and inevitably, reading and writing are involved. Therefore, if reading and writing become too cumbersome, the system will quickly degenerate into a mere formality. In work contexts one might endure this inconvenience, but for personal task management it often isn’t worthwhile.

So, how can we solve the “cumbersomeness of reading and writing”? Fortunately, there were pioneers before us. Engineers who deal with program code and vast documents already know how to handle digital reading and writing using various tools. Many spare no effort to improve their productivity. The wisdom accumulated by these people is, in a word, **plain text**. Although literally translated as “raw text,” plain text refers to the character data produced when you type on a keyboard or touchscreen. It is the common language that computers understand, and plain text can be handled on PCs, smartphones, and virtually every device and tool. However, it does not include any formatting such as font size, color, or links. For example, if you write “big red text” in Microsoft Word and paste it into LINE or X, it won’t appear with the same formatting; only the raw characters will be pasted. This is because formatting information is specific to each tool, whereas the raw character data—the plain text—is universal.

We read and write words, and in the digital realm the common language we use is plain text.

In short, remember these two points:
- **1:** When handling digital reading and writing, you are dealing with “plain text.”
- **2:** Plain text refers to raw character data without any formatting.

## Achieving the Flexibility of Analog Task Management in a Digital World
Many people manage tasks using analog methods like notebooks. While digital methods are generally more convenient, why would someone choose analog?

One reason is that with paper you can handle language freely. You can write anywhere on the page, cross out text if needed, or highlight important tasks. As long as there is enough paper and ink, you can write anywhere, in any style. It doesn’t require any special skills—if you can read and write, you can do it.

Conversely, if you learn the digital ways and acquire the necessary skills, you too can handle text just as freely as with analog methods. As mentioned earlier [here](view_personal_taskmanagement#ツールはアナログか、デジタルか), digital tools offer benefits such as speed, ease of modification, and accessibility through data synchronization. In short, you can achieve the “complete freedom” that was once exclusive to analog methods even in the digital world.

And at the root of these digital methods and skills is plain text. In the digital world, reading and writing are done in plain text, so understanding plain text is the shortcut to mastering free-form task management.

# Understanding Plain Text
Before diving into plain text–based task management, let’s explain what plain text is. If you’re already familiar, feel free to skip this section.

Many people can skillfully use pen and paper because they understand their properties. For example, if you want to erase something, you use a pencil (or mechanical pencil) and an eraser; if you make only a few mistakes, a ballpoint pen might suffice. Or even if you make an error with a ballpoint, you can simply cross it out or move the text, and if you need a certain layout, you can use commercially available graph paper or diaries. This seems obvious because we understand the specifications of analog tools.

Now, digital tools work differently—the “specifications” are plain text. In this section, we will explain the specifications of plain text so that you can eventually use it as flexibly as you would with analog methods.

## Getting Started
- This guide targets PCs running Windows.
    - It might not apply to smartphones or other operating systems such as macOS—please adapt as needed.
- If possible, set up an editing area where you can experiment with the text.
    - Anything that supports multi-line input will do.
    - This could be a text editor like Notepad, a web service, or a website input form.
    - I even prepared one: https://stakiran.github.io/textarea/
- We won’t cover basic character input methods.

For those wishing to learn in depth, I recommend my book [here](ref#25). Although it’s aimed at writers rather than task management, it also provides detailed explanations on mastering plain text.

## The World of Lining Up Lines
Plain text exists in a world of lines.

For example, below are three lines each containing “あああ”:

```
あああ
あああ
あああ

いいい


ううう
```


Here, there is one empty line (called an “empty line”) between the three “あああ” lines and the “いいい” line, and two empty lines between “いいい” and “ううう.” Plain text is thus composed of lines. In analog, you can write anywhere on a page in two dimensions, but with plain text you can only arrange lines in sequence. Hence, in task management it’s common to use the rule “one line equals one task.”

## A Wide Range of Characters
Plain text can only handle characters, but many different characters are available.

```
ひらがな(Hiragana)
カタカナ(Katakana)
漢字(Kanji)
Whitespace characters: Half-width space " ", full-width space "　", tab "	"
Symbols part 1: (^_^) ← You can create emoticons like this
Symbols part 2: ■ ® ※ 〆 ∞ …… You can enter these by converting from "kigou" (symbol)
Emojis: ✅ 👍 💣 🐰 🚃 You can enter these by converting from terms like "usagi" (rabbit) or "densha" (train) if emojis are available
```

In task management, the challenge is to use these characters cleverly to create visual accents that make your tasks easier to read. For example, if you want to mark a “take out the trash” task as completed, you might write it in several ways. There might be slight differences, like spacing or whether the “X” is uppercase or lowercase, but there’s no single “correct” way—it’s entirely up to your personal preference.

```
✅Taking out the trash
✅ Taking out the trash
[X] Taking out the trash
X Taking out the trash
XTaking out the trash
xTaking out the trash
```

As an aside, if you want a quick reference of available characters, my article might be helpful: [Summary of Half-width Alphanumeric Symbols and Full-width Kana & Symbols #Symbols - Qiita](https://qiita.com/sta/items/848e7a8c4699a59c604f)

## Various Saving Units
In analog, simply writing on paper preserves your work automatically, but with plain text you must save it in some form.

On a PC, the most familiar method is to open a text editor, write your text, and save it as a **file** (for example, task.txt). Opening task.txt will show what you’ve written, and you can continue to add to it and save it.

When using certain applications, you might write and save within the app, or it might auto-save. The unit of saving can vary; for example, you might see terms such as:

- Project
- Workspace
- Page
- File
- Note
- Document

When managing tasks, it’s important to be aware of the saving unit. If you manage tasks with files, you might wonder whether to write everything in one file (like task.txt), use a monthly file (such as 2024_07.txt), or create a “Tasks” folder with individual files (like “Moving.txt” or “Project A.txt”). There are many possibilities.

## Cursor-Centered Operations
Plain text is operated based on the cursor’s position. Both inputting and deleting characters occur at the cursor’s location. Here’s an example:

![caret](/images/taskmanagement-kamikudaku/caret_input.gif)

Operations like copying and pasting after selecting a block are also based on the cursor. See the example below:

![caret](/images/taskmanagement-kamikudaku/caret_selection.gif)

Also, when dealing with long lines of text, the area around the cursor is always displayed. If there are 300 lines of text, it’s likely impossible to display everything on the screen (or if it is, the text might be too small to read). To see the end of a long line, you need to move the cursor to the end. See the example below:

![caret](/images/taskmanagement-kamikudaku/caret_move.gif)

Strictly speaking, the “display area” and the “cursor position” are separate; you can scroll without moving the cursor, but as soon as you perform an operation, the display will jump back to the cursor. Ultimately, every operation is based on the cursor’s position, so you must learn to move the cursor efficiently.

The key point here is that **handling plain text depends on how skillfully you can manipulate the cursor.** In analog, moving a pen to a desired location is easy, but in digital, the equivalent is moving the cursor. In task management, you’ll be moving the cursor frequently. The GIFs above show my smooth, practiced movements; if you can move the cursor that deftly, you’ll be able to manage text as easily as if you were using a pen. Conversely, if you struggle with cursor operations, you might end up tediously tapping or holding down the arrow keys, which can be exhausting and may lead to the system becoming nothing more than a formality.

## Digital-Specific Operations
One advantage of digital methods is that they can overcome the limitations of analog tools. Even when working with plain text, there are some convenient digital operations. Examples include:

- Easy duplication:
    - The classic copy-paste (copy & paste).
- Search functionality:
    - In analog, you would have to search manually with your eyes, but in digital it is instantaneous.
- Quick error correction:
    - In task management, you often reuse tasks, search for tasks you believe you’ve written, and correct typos—all of which are much easier to do digitally than analogically.

Because these operations are so simple, you can implement management methods that would be nearly impossible with analog pen and paper. For example, while you might have dozens of tasks (including minor routines) in a single day, digital methods allow you to manage all of them. Managing that many tasks with pen and paper would be too burdensome, but it’s possible digitally.

## Summary
We have covered the characteristics of plain text:

- It is composed of lines.
- A wide variety of characters can be used (including emojis).
- The saving unit can vary (not limited to files).
- Operations are centered on the cursor (so mastering cursor movements is crucial).
- You benefit from digital conveniences like duplication, search, and quick corrections.

While analog methods are constrained by the limits of paper and pen, digital methods are constrained by the limits of plain text. Understanding these will help you later when you consider plain text–based task management.

...
