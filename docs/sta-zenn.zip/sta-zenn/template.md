---
title: "★"
emoji: ""
type: "idea"
topics: [""]
published: false
---

# TODO
- まずは false のまま articles/ にアップしてデプロイ画面でプレビュー
- publish前にファイル名先頭に日付つける
    - slugは12文字以上である必要があるため日付文字列で稼がないと自然な名前(特に短い名前)をつけれない
- 必要なら emoji と topics をつける
- いけそうなら true
