# Zenn 記事用
- my url
    - https://zenn.dev/sta
- deploy status
    - https://zenn.dev/dashboard/deploys

# LICENSE
ありません。

# 以下はポートフォリオ読者向け情報です
- Zenn による記事と書籍の原稿データをまとめています
    - 一部 PDF もあります（books/xxxx/merged.pdf）
